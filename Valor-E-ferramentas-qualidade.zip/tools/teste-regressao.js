#!/usr/bin/env node
// Teste de regressão do Valor-E (navegador sem tela). Uso: node tools/teste-regressao.js
// Requer: playwright. Sobe um servidor local, carrega dados de exemplo e confere telas e fluxos principais.
const { chromium } = require(process.env.PW_PATH || 'playwright'); const fs = require('fs'), path = require('path'), http = require('http');
const app = path.resolve(__dirname, '..', 'app'), seed = fs.readFileSync(path.join(__dirname, 'fixtures', process.env.SEED || 'seed.js'), 'utf8');
const TIPOS = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.json': 'application/json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
const srv = http.createServer((q, s) => { let f = path.join(app, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, d) => { if (e) { s.writeHead(404); s.end(); } else { s.writeHead(200, { 'content-type': TIPOS[path.extname(f)] || 'application/octet-stream' }); s.end(d); } }); });
let falhas = 0, ok = 0; const ev = [];
const T = (nome, cond, det) => { if (cond) ok++; else { falhas++; console.log('✗ ' + nome + (det ? ' — ' + det : '')); } };
(async () => {
  await new Promise(r => srv.listen(0, r)); const url = 'http://localhost:' + srv.address().port + '/index.html';
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => ev.push('erro: ' + e.message + ' @ ' + String(e.stack).split('\n').slice(1, 3).join(' | '))); p.on('console', m => { if (m.type() === 'error' && !/favicon|Failed to load resource/.test(m.text())) ev.push('console: ' + m.text()); });
  p.on('dialog', d => d.accept('Teste'));
  await p.addInitScript(() => { window.__maprisHost = { invocar: (o) => o === 'chave' ? 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90' : (o === 'gravar' ? 'ok' : '') }; });
  await p.goto(url); await p.waitForFunction(() => window.DB && DB.db); await p.evaluate(seed);
  const ir = async h => { await p.evaluate(h => { location.hash = h; }, h); await p.waitForTimeout(350); };
  const limpa = () => { const e = ev.splice(0); return e; };
  // 1) rastreia todas as telas alcançáveis por links internos
  const vistos = new Set(), fila = ['#/painel']; let n = 0;
  while (fila.length && n < 80) {
    const h = fila.shift(); if (vistos.has(h)) continue; vistos.add(h); n++;
    await ir(h); const e = limpa();
    T('tela ' + h + ' sem erros', !e.length, e[0]);
    const txt = await p.evaluate(() => document.body.innerText);
    T('tela ' + h + ' sem "Erro ao montar"', !/Erro ao montar a tela/.test(txt), txt.match(/Erro ao montar a tela[^\n]*/) ? txt.match(/Erro ao montar a tela[^\n]*/)[0] : '');
    const links = await p.evaluate(() => [...document.querySelectorAll('a[href^="#/"]')].map(a => a.getAttribute('href')));
    links.filter(l => !vistos.has(l) && !/excluir|apagar/.test(l)).slice(0, 40).forEach(l => fila.push(l));
  }
  console.log('telas percorridas: ' + vistos.size);
  // 2) projetos: editar e criar com vínculos
  const save = () => p.evaluate(() => { const x = [...document.querySelectorAll('.modal.show button, button')].find(x => /^(Salvar|Criar projeto)$/.test(x.textContent.trim())); x && x.click(); });
  await ir('#/projetos'); await p.evaluate(() => Proj.editar(1)); await p.waitForTimeout(400);
  await p.fill('#formProj #pn', 'Central EDITADA'); await p.selectOption('#formProj #pacao', { index: 1 }); await save(); await p.waitForTimeout(500);
  T('projeto editado', (await p.evaluate(() => DB.one('SELECT nome FROM projetos WHERE id=1').nome)) === 'Central EDITADA');
  await p.evaluate(() => Proj.novo()); await p.waitForTimeout(400);
  await p.fill('#formProj #pn', 'Projeto NOVO'); await p.selectOption('#formProj #pmapa', { index: 1 }); await p.selectOption('#formProj #pobj', { index: 1 }); await p.selectOption('#formProj #pacao', { index: 1 }); await p.selectOption('#formProj #pini', { index: 1 }); await save(); await p.waitForTimeout(600);
  const pn = await p.evaluate(() => DB.one("SELECT mapa_id m,objetivo_id o,acao_id a,iniciativa_id i FROM projetos WHERE nome='Projeto NOVO'"));
  T('projeto novo com 4 vínculos', pn && pn.m && pn.o && pn.a && pn.i, JSON.stringify(pn));
  T('cadastro de projeto abre em página própria (como o risco)', await p.evaluate(() => { Proj.novo(); return location.hash.indexOf('#/projeto-form') === 0; }) && await p.evaluate(() => new Promise(r => setTimeout(() => r(!!document.querySelector('#formProj .passo') && !document.querySelector('.modal.show')), 500))));
  const nProj = await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM projetos').n);
  await p.fill('#formProj #pn', 'Projeto da página'); await save(); await p.waitForTimeout(500);
  T('salvar projeto novo permanece na página e habilita Abrir/Excluir', await p.evaluate(() => location.hash.indexOf('#/projeto-form?id=') === 0 && !document.getElementById('pjDel').disabled) && (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM projetos').n)) === nProj + 1);
  await p.fill('#formProj #pn', 'Projeto da página 2'); await save(); await p.waitForTimeout(400);
  T('salvar de novo atualiza, sem duplicar', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM projetos').n)) === nProj + 1 && await p.evaluate(() => !!DB.one("SELECT 1 x FROM projetos WHERE nome = 'Projeto da página 2'")));
  // processo: mesma página de cadastro
  await ir('#/processos'); await p.evaluate(() => Proc.novo()); await p.waitForTimeout(500);
  T('cadastro de processo abre em página própria', await p.evaluate(() => location.hash.indexOf('#/processo-form') === 0 && !!document.querySelector('#formProc .passo')));
  const nPr = await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM processos').n);
  await p.click('button:has-text("Salvar")'); await p.waitForTimeout(300);
  T('processo sem nome não é salvo', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM processos').n)) === nPr);
  await p.fill('#prn', 'Processo da página'); await p.selectOption('#prm', { index: 1 }); await p.fill('#prr', 'Chefe da seção'); await p.click('button:has-text("Salvar")'); await p.waitForTimeout(500);
  const prN = await p.evaluate(() => DB.one("SELECT id, macro_id, responsavel FROM processos WHERE nome = 'Processo da página'"));
  T('processo novo salvo com macroprocesso e responsável', prN && prN.macro_id && prN.responsavel === 'Chefe da seção', JSON.stringify(prN));
  T('após salvar, Folha e Diagrama são liberados', await p.evaluate(() => !document.getElementById('prFolha').classList.contains('disabled') && /folha\?id=/.test(document.getElementById('prFolha').getAttribute('href'))));
  await p.fill('#prn', 'Processo da página (editado)'); await p.click('button:has-text("Salvar")'); await p.waitForTimeout(400);
  T('editar processo não duplica', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM processos').n)) === nPr + 1 && await p.evaluate(() => !!DB.one("SELECT 1 x FROM processos WHERE nome = 'Processo da página (editado)'")));
  await ir('#/processos'); T('lista de processos tem botão de editar os dados', await p.evaluate(() => !!document.querySelector('a[href^="#/processo-form?id="]')));
  // 3) linha de base lança valor no indicador do projeto; indicador de projeto sem botão Registro
  await p.evaluate(() => Proj.baseline(1)); await p.waitForTimeout(300); await p.fill('.modal.show #bn', 'LB teste');
  await p.evaluate(() => { [...document.querySelectorAll('.modal.show button')].find(x => /Salvar linha de base/.test(x.textContent)).click(); }); await p.waitForTimeout(500);
  T('linha de base lançou valor no indicador', await p.evaluate(() => !!DB.one("SELECT 1 x FROM lanc_ind l JOIN indicadores i ON i.id=l.indicador_id WHERE i.codigo='PRJ-PROG-1' AND l.observacao LIKE 'Linha de base:%'")));
  await ir('#/indicadores'); T('lista de indicadores sem Registro em indicador de projeto', await p.evaluate(() => [...document.querySelectorAll('tbody tr')].filter(t => /PRJ-PROG/.test(t.textContent)).every(t => !/Registro/.test(t.textContent))));
  // 4) riscos: origem reconhecida
  const vis = () => p.evaluate(() => ['blocoOrigem', 'blocoProj', 'blocoProc'].map(i => document.getElementById(i).offsetHeight > 0 ? 1 : 0).join(''));
  const rp = await p.evaluate(() => E.riscoSalvar({ nome: 'R projeto', ambiente: 'x', projeto_id: 1, fatores: [] })); await ir('#/risco?id=' + rp); T('risco de projeto mostra só projeto', (await vis()) === '010', await vis());
  const rq = await p.evaluate(() => E.riscoSalvar({ nome: 'R processo', ambiente: 'x', processo_id: DB.one('SELECT id FROM processos').id, fatores: [] })); await ir('#/risco?id=' + rq); T('risco de processo mostra só processo', (await vis()) === '001', await vis());
  await ir('#/risco'); T('risco novo pergunta a origem', (await vis()) === '100', await vis());
  await p.evaluate(() => DB.run('UPDATE riscos SET processo_id=(SELECT id FROM processos LIMIT 1) WHERE id=?', [DB.one("SELECT id FROM riscos WHERE nome='R projeto'").id])); await ir('#/riscos'); await ir('#/risco?id=' + rp); T('risco de projeto com processo legado esconde o processo', (await vis()) === '010', await vis());
  // 4b) botões inline do risco (Salvar, Duplicar, Excluir, + causa) e da Folha do processo (Salvar, Ordenar, Gerar)
  await ir('#/risco'); await p.fill('#f_nome', 'Risco pelo botão'); await p.selectOption('#f_origem', 'outro'); await p.fill('#f_ambiente', 'Ambiente livre');
  await p.click('button:has-text("Salvar")'); await p.waitForTimeout(700);
  T('botão Salvar do risco grava', await p.evaluate(() => !!DB.one("SELECT 1 x FROM riscos WHERE nome='Risco pelo botão'")), limpa()[0]);
  await p.evaluate(() => Risco.addFator()); await p.waitForTimeout(200);
  T('botão + causa do risco', await p.evaluate(() => Risco.estado.R.fatores.length >= 1));
  await p.click('#bDup'); await p.waitForTimeout(800);
  T('botão Duplicar do risco', await p.evaluate(() => DB.one("SELECT COUNT(*) n FROM riscos WHERE nome LIKE 'Risco pelo botão%'").n) >= 2);
  const pid = await p.evaluate(() => DB.one('SELECT id FROM processos ORDER BY id LIMIT 1').id);
  await ir('#/folha?id=' + pid); const eF = limpa(); T('Folha abre sem erro', !eF.length, eF[0]);
  T('Folha expõe os botões em Folha.*', await p.evaluate(() => ['salvar', 'addLinha', 'ordenar', 'renumerar', 'gerar'].every(n => typeof Folha[n] === 'function')));
  await p.evaluate(() => Folha.ordenar()); await p.click('button:has-text("Salvar")').catch(() => {}); await p.waitForTimeout(600);
  const eF2 = limpa(); T('botões da Folha sem erro', !eF2.length, eF2[0]);
  // 4d) sincronia bandeira do diagrama BPMN ↔ módulo de riscos
  const fid = await p.evaluate(() => E.flagDoElemento(3, 'Activity_X', 'Conferir documentação'));
  await p.evaluate(f => E.flagRiscoAdicionar(f, { nome: 'Risco da bandeira', probabilidade: 3, impacto: 3, categoria: 'Operacional' }), fid);
  const rb = await p.evaluate(() => DB.one("SELECT id, processo_id, flag_id FROM riscos WHERE flag_id IS NOT NULL"));
  T('risco criado pela bandeira fica ligado ao processo e à bandeira', rb && rb.processo_id === 3 && rb.flag_id === fid, JSON.stringify(rb));
  await ir('#/risco?id=' + rb.id); T('formulário do risco da bandeira mostra o processo', (await p.evaluate(() => document.getElementById('f_processo_id').value)) === '3' && (await vis()) === '001');
  await p.fill('#f_nome', 'Risco da bandeira RENOMEADO'); await p.click('button:has-text("Salvar")'); await p.waitForTimeout(700);
  T('renomear no módulo de riscos aparece na bandeira do diagrama', await p.evaluate(f => E.flagsDoProcesso(3).some(x => x.id === f && x.riscos.some(r => r.nome === 'Risco da bandeira RENOMEADO')), fid));
  await p.click('#bDup'); await p.waitForTimeout(900);
  T('cópia do risco continua na mesma bandeira', await p.evaluate(f => DB.all('SELECT id FROM riscos WHERE flag_id = ?', [f]).length, fid) === 2);
  await p.click('button:has-text("Excluir")'); await p.waitForTimeout(700);
  T('excluir uma cópia mantém a bandeira', await p.evaluate(f => !!DB.one('SELECT 1 x FROM flags WHERE id = ?', [f]), fid));
  await p.evaluate(r => { location.hash = '#/risco?id=' + r; }, rb.id); await p.waitForTimeout(700); await p.click('button:has-text("Excluir")'); await p.waitForTimeout(700);
  T('excluir o último risco remove a bandeira do diagrama', await p.evaluate(f => !DB.one('SELECT 1 x FROM flags WHERE id = ?', [f]), fid));
  // 4c) migrações versionadas
  T('migrações registradas em schema_versoes', await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM schema_versoes').n) >= 5);
  T('camada única de dados (sem OptDB)', await p.evaluate(() => typeof window.OptDB === 'undefined' && typeof DB.rows === 'function'));
  // 5) Valor Estratégico: ciclos, metas e plano 5W2H
  await ir('#/valor/ciclos'); await p.evaluate(() => UI.formMetasCiclo(1)); await p.waitForTimeout(400);
  T('metas do ciclo sem linha de base', await p.evaluate(() => !/Linha de base/.test(document.body.innerText)));
  await ir('#/valor/objetivos?oe=3'); T('objetivos sem botão Novo objetivo', await p.evaluate(() => !/Novo objetivo/.test(document.body.innerText)));
  // 6) exportação e importação por itens (ida e volta)
  const rt = await p.evaluate(() => { const t = []; Mapris.baixar = (n, x) => { t.push(x); }; Pacote.exportarXml(); return t[0] ? t[0].length : 0; }); T('exportação XML gera conteúdo', rt > 1000, String(rt));
  // 7) pontos de restauração, unidade de origem e prévia de importação
  const nr0 = await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n);
  T('ponto do dia não apaga ponto "antes de…" recente', await p.evaluate(async () => { await Pontos.excluir((await Pontos.listar())[0] ? (await Pontos.listar())[0].id : ''); await Pontos.criar('Antes de importar (teste)', 'antes'); await Pontos.aoIniciar(); await new Promise(r => setTimeout(r, 500)); const l = await Pontos.listar(); return l.length === 1 && l[0].tipo === 'antes'; }));
  const ptId = await p.evaluate(() => Pontos.criar('teste', 'manual')); T('cria ponto de restauração', !!ptId);
  T('ponto aparece na lista', await p.evaluate(i => Pontos.listar().then(l => l.some(x => x.id === i)), ptId));
  await p.evaluate(() => { DB.run('DELETE FROM riscos'); });
  T('dados apagados antes de restaurar', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n)) === 0);
  await p.evaluate(i => Pontos.restaurar(i), ptId);
  T('restaurar devolve os dados', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n)) === nr0, 'esperado ' + nr0);
  T('restaurar guarda o estado anterior ("antes de restaurar")', await p.evaluate(() => Pontos.listar().then(l => l.some(x => /Antes de restaurar/.test(x.motivo)))));
  await p.evaluate(async () => { for (let i = 0; i < 12; i++) await Pontos.criar('lote ' + i, 'manual'); });
  T('guarda só o ponto mais recente', await p.evaluate(() => Pontos.listar().then(l => l.length === 1 && l[0].motivo === 'lote 11')));
  await p.evaluate(async () => { for (const x of await Pontos.listar()) await Pontos.excluir(x.id); await Pontos.aoIniciar(); });
  await p.waitForTimeout(600); await p.evaluate(() => Pontos.aoIniciar()); await p.waitForTimeout(600);
  T('ponto automático do dia: criado uma única vez', (await p.evaluate(() => Pontos.listar().then(l => l.filter(x => x.tipo === 'auto').length))) === 1);
  await p.evaluate(() => { const d = new Date(Date.now() - 40 * 864e5).toISOString(); Pontos.cfgSet('copia_externa_em', d); localStorage.setItem('valore_copia_externa_em', d); });
  T('aviso de cópia externa quando passa de 30 dias', await p.evaluate(() => /há \d+ dias/.test(Pontos.avisoCopia())));
  await p.evaluate(() => Pontos.copiaExterna()); T('sem aviso logo após uma cópia externa', await p.evaluate(() => Pontos.avisoCopia() === ''));
  await p.evaluate(() => { Org.recarregarTela = () => {}; Org.salvar(Org.ativa().id, 'TESTE', 'Unidade de Teste'); }); await ir('#/dados');
  const xmlT = await p.evaluate(() => { let t = ''; Mapris.baixar = (n, x) => { t = x; }; Pacote.exportarXml(); return t; });
  T('pacote exportado traz a unidade de origem', /unidade="TESTE"/.test(xmlT) && /unidade_nome="Unidade de Teste"/.test(xmlT));
  const r1 = await p.evaluate(() => DB.one('SELECT id, codigo, nome FROM riscos ORDER BY id LIMIT 1'));
  await p.evaluate(i => DB.run("UPDATE riscos SET nome = 'LOCAL ALTERADO' WHERE id = ?", [i]), r1.id);
  const nr1 = await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n);
  await ir('#/dados'); await p.check('input[name=pmodo][value=mesclar]');
  await p.setInputFiles('#pArq', { name: 'pacote-teste.xml', mimeType: 'text/xml', buffer: Buffer.from(xmlT) }); await p.click('button:has-text("Importar arquivo inteiro")'); await p.waitForSelector('#pPrevia .pv-esc', { timeout: 8000 });
  T('prévia identifica a unidade de origem', await p.evaluate(() => /TESTE/.test(document.getElementById('pPrevia').innerText)));
  T('prévia não altera o banco', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n)) === nr1 && (await p.evaluate(i => DB.one('SELECT nome FROM riscos WHERE id = ?', [i]).nome, r1.id)) === 'LOCAL ALTERADO');
  await p.selectOption('#pPrevia .pv-esc >> nth=0', 'manter'); await p.evaluate(() => Array.from(document.querySelectorAll('#pPrevia .pv-esc')).forEach(s => { s.value = 'manter'; }));
  await p.click('button:has-text("Confirmar importação")'); await p.waitForTimeout(900);
  T('“manter o meu” preserva o valor local', (await p.evaluate(i => DB.one('SELECT nome FROM riscos WHERE id = ?', [i]).nome, r1.id)) === 'LOCAL ALTERADO');
  await ir('#/dados'); await p.check('input[name=pmodo][value=mesclar]');
  await p.setInputFiles('#pArq', { name: 'pacote-teste.xml', mimeType: 'text/xml', buffer: Buffer.from(xmlT) }); await p.click('button:has-text("Importar arquivo inteiro")'); await p.waitForSelector('#pPrevia .pv-esc', { timeout: 8000 });
  await p.click('button:has-text("Confirmar importação")'); await p.waitForTimeout(900);
  T('“usar o do arquivo” atualiza o item', (await p.evaluate(i => DB.one('SELECT nome FROM riscos WHERE id = ?', [i]).nome, r1.id)) === r1.nome);
  T('importação não duplicou riscos', (await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n)) === nr1);
  T('importações ficam registradas com a origem', await p.evaluate(() => DB.all("SELECT unidade FROM importacoes WHERE unidade = 'TESTE'").length) >= 2);
  const idem = await p.evaluate(() => { let t = ''; Mapris.baixar = (n, x) => { t = x; }; Pacote.exportarXml(); const r = Pacote.importarTexto(t, 'mesclar'); return Object.keys(r.tabelas).filter(k => r.tabelas[k]).map(k => k + ':' + r.tabelas[k]).join(','); });
  T('reimportar o próprio pacote não cria registros novos (idempotente)', idem === '', idem);
  T('ponto "antes de importar" criado', await p.evaluate(() => Pontos.listar().then(l => l.some(x => /Antes de importar/.test(x.motivo)))));
  // 7b) organizações: dona dos dados; troca em cascata; importação e exportação por organização
  const cont = () => p.evaluate(() => ['riscos', 'processos', 'projetos', 'indicadores', 'cva_ciclos', 'me_mapas', 'macroprocessos', 'objetivos_estrategicos'].map(t => DB.one('SELECT COUNT(*) n FROM ' + t).n).join(','));
  const cA = await cont(); const idA = await p.evaluate(() => Org.ativa().id);
  T('há dados na organização A', cA.split(',').some(x => +x > 0), cA);
  await ir('#/painel');
  T('Painel traz o seletor de organização', await p.evaluate(() => !!document.getElementById('orgSel') && /TESTE/.test(document.getElementById('orgSel').innerText)));
  const idB = await p.evaluate(() => Org.criar('ORG-B', 'Organização B'));
  T('organização nova começa vazia e a anterior fica guardada', await p.evaluate(i => { Org.ativar(i); return Org.ativa().codigo === 'ORG-B' && !!DB.one('SELECT 1 x FROM org_arquivo WHERE organizacao_id = ?', [1]) || !!DB.one('SELECT 1 x FROM org_arquivo'); }, idB) && (await cont()) === '0,0,0,0,0,0,0,0', await cont());
  await p.evaluate(() => { DB.run("INSERT INTO processos (nome) VALUES ('Processo só da B')"); DB.sujo(); });
  await p.evaluate(i => Org.ativar(i), idA);
  T('voltar à A restaura exatamente os dados dela', (await cont()) === cA, await cont());
  T('dados da B não vazam para a A', await p.evaluate(() => !DB.one("SELECT 1 x FROM processos WHERE nome = 'Processo só da B'")));
  await p.evaluate(i => Org.ativar(i), idB);
  T('dados da B voltam ao abrir a B', await p.evaluate(() => !!DB.one("SELECT 1 x FROM processos WHERE nome = 'Processo só da B'")));
  const pkA = await p.evaluate(i => { const o = Org.pacoteDe(i); return { u: o.unidade, n: o.tabelas.riscos ? o.tabelas.riscos.linhas.length : 0 }; }, idA);
  T('exportar organização guardada traz os dados dela', pkA.u === 'TESTE' && pkA.n === +cA.split(',')[0], JSON.stringify(pkA));
  // importar um arquivo da A estando na B: abre a A e importa nela
  await ir('#/dados'); await p.check('input[name=pmodo][value=mesclar]');
  await p.setInputFiles('#pArq', { name: 'da-A.xml', mimeType: 'text/xml', buffer: Buffer.from(xmlT) }); await p.click('button:has-text("Importar arquivo inteiro")'); await p.waitForSelector('#pPrevia .pv-esc, #pPrevia button', { timeout: 8000 });
  T('arquivo de outra organização abre a organização dele', (await p.evaluate(() => Org.ativa().codigo)) === 'TESTE');
  T('prévia na organização certa mostra que nada há a importar (dados iguais)', await p.evaluate(() => document.querySelector('#pPrevia button.btn-warning').disabled));
  await p.evaluate(() => Pacote.previaCancelar());
  T('importar na organização certa não duplica nem mistura', (await cont()) === cA, await cont());
  T('ponto de restauração antes de trocar por importação', await p.evaluate(() => Pontos.listar().then(l => l.some(x => /Antes de abrir a organização/.test(x.motivo)))));
  // arquivo de organização desconhecida cria a organização
  const xmlN = xmlT.replace('unidade="TESTE"', 'unidade="NOVA-X"').replace(/unidade_nome="[^"]*"/, 'unidade_nome="Organização Nova"');
  await ir('#/dados'); await p.check('input[name=pmodo][value=mesclar]');
  await p.setInputFiles('#pArq', { name: 'nova.xml', mimeType: 'text/xml', buffer: Buffer.from(xmlN) }); await p.click('button:has-text("Importar arquivo inteiro")'); await p.waitForSelector('#pPrevia button', { timeout: 8000 });
  T('organização desconhecida é cadastrada e aberta', await p.evaluate(() => Org.ativa().codigo === 'NOVA-X' && !!Org.achar('NOVA-X')));
  await p.click('button:has-text("Confirmar importação")'); await p.waitForTimeout(900);
  T('organização nova recebeu só o que veio no arquivo', (await cont()) === cA, await cont());
  T('A e B continuam guardadas, sem mistura', await p.evaluate(() => Org.lista().length === 3 && !!DB.one('SELECT 1 x FROM org_arquivo WHERE organizacao_id = ?', [1])));
  // arquivo sem organização vai para a ativa, sem perguntar
  const xmlS = xmlT.replace(/ unidade="[^"]*"/, '').replace(/ unidade_nome="[^"]*"/, '');
  T('arquivo sem organização é aceito na ativa', await p.evaluate(t => Org.rotear({ unidade: '' }), xmlS));
  T('não exclui a organização ativa', await p.evaluate(() => { try { Org.excluir(Org.ativa().id); return false; } catch (e) { return true; } }));
  await p.evaluate(i => Org.ativar(i), idA);
  await p.evaluate(i => Org.excluir(i), idB);
  T('excluir organização guardada remove os dados dela', await p.evaluate(i => !DB.one('SELECT 1 x FROM org_arquivo WHERE organizacao_id = ?', [i]) && !DB.one('SELECT 1 x FROM organizacoes WHERE id = ?', [i]), idB));
  T('“Limpar dados” e restauração não afetam o cadastro de organizações', await p.evaluate(() => Org.lista().length >= 1 && !!Org.ativa()));
  // 7c) editor de texto rico (TipTap): descrição de projetos e processos, conversão do formato antigo e saneamento
  {
    T('Quill não está mais carregado e o TipTap está', await p.evaluate(() => !window.Quill && !!window.TipTap && !!window.SisrelEditor));
    const q = await p.evaluate(() => {
      const H = SisrelHtml, r = {};
      r.lista = H.seguro('<ol><li data-list="bullet"><span class="ql-ui" contenteditable="false"></span>um</li><li data-list="bullet">dois</li><li data-list="ordered">tres</li><li data-list="checked">feito</li></ol>');
      r.alin = H.seguro('<p class="ql-align-center ql-indent-1">meio</p>');
      r.xss = H.seguro('<p onclick="x()">a</p><img src=x onerror="alert(1)"><script>alert(2)</script><a href="javascript:alert(3)">l</a><iframe src="x"></iframe>');
      r.plano = H.seguro('linha 1\nlinha 2 & 3 < 4');
      r.fundo = H.seguro('<p><span style="background-color: rgb(255, 255, 0);">dest</span></p>');
      return r;
    });
    T('lista antiga do Quill vira ul/ol/tarefas sem restos', /<ul><li>um<\/li><li>dois<\/li><\/ul><ol><li>tres<\/li><\/ol>/.test(q.lista) && /data-type="taskList"/.test(q.lista) && !/ql-/.test(q.lista), q.lista);
    T('alinhamento antigo vira estilo padrão', /text-align:\s*center/.test(q.alin) && !/ql-/.test(q.alin), q.alin);
    T('destaque antigo vira marca-texto', /<mark/.test(q.fundo), q.fundo);
    T('HTML malicioso é limpo (script, onerror, onclick, javascript:, iframe)', !/script|onerror|onclick|javascript|iframe/i.test(q.xss), q.xss);
    T('texto simples antigo ganha parágrafos e é escapado', /<p>linha 1<\/p>/.test(q.plano) && /<p>linha 2 &amp; 3 &lt; 4<\/p>/.test(q.plano), q.plano);
    // projeto: digitar com negrito e salvar
    await ir('#/projetos'); await p.evaluate(() => Proj.novo()); await p.waitForSelector('#pd .ProseMirror'); await p.waitForTimeout(200);
    T('projeto: descrição usa o editor com barra de ferramentas', await p.evaluate(() => !!document.querySelector('#pd .sr-ed-barra .bi-type-bold') && !document.querySelector('textarea#pd')));
    await p.fill('#formProj #pn', 'Projeto com descrição rica');
    await p.click('#pd .ProseMirror'); await p.keyboard.type('Objetivo do projeto'); await p.keyboard.press('Control+A'); await p.click('#pd button[title^="Negrito"]');
    await p.click('#pd .ProseMirror'); await p.keyboard.press('End'); await p.keyboard.press('Enter'); await p.click('#pd button[title="Lista com marcadores"]'); await p.keyboard.type('item A'); await p.keyboard.press('Enter'); await p.keyboard.type('item B');
    await p.click('button:has-text("Salvar")'); await p.waitForTimeout(500);
    const dsc = await p.evaluate(() => (DB.one("SELECT descricao d FROM projetos WHERE nome='Projeto com descrição rica'") || {}).d);
    T('descrição do projeto salva em HTML (negrito e lista)', /<strong>Objetivo do projeto<\/strong>/.test(dsc) && /<ul><li><p>item A<\/p><\/li><li><p>item B<\/p><\/li><\/ul>/.test(dsc), dsc);
    const pid = await p.evaluate(() => DB.one("SELECT id FROM projetos WHERE nome='Projeto com descrição rica'").id);
    await ir('#/projeto-form?id=' + pid); await p.waitForSelector('#pd .ProseMirror'); await p.waitForTimeout(200);
    T('ao reabrir, o editor mostra a descrição formatada', await p.evaluate(() => !!document.querySelector('#pd .ProseMirror strong') && document.querySelectorAll('#pd .ProseMirror li').length === 2));
    // descrição antiga (texto simples) e maliciosa importada
    await p.evaluate(id => { DB.run("UPDATE projetos SET descricao=? WHERE id=?", ['primeira linha\nsegunda linha', id]); DB.sujo(); }, pid);
    await ir('#/projetos'); await ir('#/projeto-form?id=' + pid); await p.waitForSelector('#pd .ProseMirror'); await p.waitForTimeout(200);
    T('descrição antiga em texto simples abre no editor', await p.evaluate(() => document.querySelectorAll('#pd .ProseMirror p').length === 2 && /segunda linha/.test(document.querySelector('#pd .ProseMirror').textContent)));
    await p.evaluate(id => { DB.run("UPDATE projetos SET descricao=? WHERE id=?", ['<p>ok</p><img src=x onerror="window.__xss=1"><script>window.__xss=2</script>', id]); DB.sujo(); }, pid);
    await ir('#/projeto?id=' + pid); await p.waitForTimeout(500);
    T('descrição maliciosa no detalhe do projeto não executa', await p.evaluate(() => !window.__xss && !document.querySelector('[onerror]') && /ok/.test(document.body.textContent)));
    await ir('#/projeto-form?id=' + pid); await p.waitForSelector('#pd .ProseMirror'); await p.waitForTimeout(200);
    T('descrição maliciosa no editor não executa', await p.evaluate(() => !window.__xss && !document.querySelector('#pd [onerror], #pd script')));
    // processo
    await ir('#/processos'); await p.evaluate(() => Proc.novo()); await p.waitForSelector('#prd .ProseMirror'); await p.waitForTimeout(200);
    await p.fill('#prn', 'Processo com descrição rica'); await p.click('#prd .ProseMirror'); await p.keyboard.type('Finalidade do processo'); await p.keyboard.press('Control+A'); await p.click('#prd button[title^="Itálico"]');
    await p.click('button:has-text("Salvar")'); await p.waitForTimeout(500);
    const dp = await p.evaluate(() => (DB.one("SELECT descricao d FROM processos WHERE nome='Processo com descrição rica'") || {}).d);
    T('descrição do processo salva em HTML (itálico)', /<em>Finalidade do processo<\/em>/.test(dp), dp);
    const prid = await p.evaluate(() => DB.one("SELECT id FROM processos WHERE nome='Processo com descrição rica'").id);
    await ir('#/processo-form?id=' + prid); await p.waitForSelector('#prd .ProseMirror'); await p.waitForTimeout(200);
    T('ao reabrir o processo, a descrição formatada aparece', await p.evaluate(() => !!document.querySelector('#prd .ProseMirror em')));
    // editor genérico: tabela, tarefas, cor e ida e volta
    const rt = await p.evaluate(async () => {
      const el = document.createElement('div'); document.body.appendChild(el);
      const ed = await SisrelEditor.criar(el, { dados: '<ul data-type="taskList"><li data-type="taskItem" data-checked="true"><p>feito</p></li></ul><table><tbody><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></tbody></table><p><span style="color:#c00000">vermelho</span></p>' });
      const html = SisrelHtml.seguro(ed.getData()); ed.setData(html); const html2 = SisrelHtml.seguro(ed.getData());
      const vazio = (await SisrelEditor.criar(document.body.appendChild(document.createElement('div')))).getData();
      await ed.destroy(); el.remove(); return { html, html2, vazio };
    });
    T('tabela, tarefa e cor sobrevivem à ida e volta', /<table/.test(rt.html) && /data-checked="true"/.test(rt.html) && /color:\s*(#c00000|rgb\(192, 0, 0\))/i.test(rt.html) && rt.html === rt.html2, rt.html);
    T('editor vazio devolve texto vazio', rt.vazio === '');
    // folha de dados usa o mesmo editor
    await ir('#/folha?id=' + prid); await p.waitForTimeout(900);
    T('folha de dados: campos de texto usam o editor TipTap', await p.evaluate(() => document.querySelectorAll('.folha-rico .ProseMirror').length > 0 && !document.querySelector('.ql-editor')));
    const e7c = limpa(); T('sem erros de página no editor', e7c.length === 0, e7c.join(' || '));
  }
  // 7d) configuração com senha ativa e banco em claro: não pode bloquear gravações nem pontos
  {
    const p2 = await b.newPage();
    await p2.addInitScript(() => { localStorage.setItem('valore_sec', JSON.stringify({ senhaAtiva: true, modo: 'sistema' })); window.__maprisHost = { invocar: (o) => o === 'chave' ? 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90' : (o === 'gravar' ? 'ok' : '') }; });
    await p2.goto(url); await p2.waitForFunction(() => window.DB && DB.db); await p2.waitForTimeout(1500);
    T('senha ativa na configuração + banco em claro: chave carregada e ponto criado', await p2.evaluate(async () => !!SEC._sessionPassword && !!(await Pontos.criar('t', 'manual'))));
    await p2.close();
  }
  // 7e) o registro da cópia externa sobrevive à troca do banco (restaurar, importar substituindo, limpar)
  {
    await p.evaluate(() => { Pontos.copiaExterna(); DB.run("DELETE FROM config WHERE chave='copia_externa_em'"); DB.sujo(); });
    T('aviso de cópia externa não some quando o banco é trocado', await p.evaluate(() => !!Pontos.ultimaCopiaExterna() && Pontos.avisoCopia() === ''));
  }
  // 8) exportação PowerPoint / Excel
  await ir('#/painel');
  T('Painel oferece exportação', await p.evaluate(() => /Exportar/.test(document.body.innerText) && !!document.querySelector('[onclick*="Exportar.pptxUI"]')));
  const saidas = await p.evaluate(async () => {
    const o = {}; Mapris.baixarBin = (nome, b64) => { o[nome.split('.').pop()] = b64; };
    await Exportar.pptx(); await Exportar.xlsx(); return o;
  });
  const dirx = require('os').tmpdir() + '/valore-exp'; fs.mkdirSync(dirx, { recursive: true });
  T('pptx gerado', !!saidas.pptx && saidas.pptx.length > 20000); T('xlsx gerado', !!saidas.xlsx && saidas.xlsx.length > 5000);
  if (saidas.pptx && saidas.xlsx) {
    fs.writeFileSync(dirx + '/r.pptx', Buffer.from(saidas.pptx, 'base64')); fs.writeFileSync(dirx + '/r.xlsx', Buffer.from(saidas.xlsx, 'base64'));
    const info = JSON.parse(require('child_process').execFileSync('python3', ['-I', '-c', `
import zipfile,json,re
x=zipfile.ZipFile('${dirx}/r.xlsx'); wb=x.read('xl/workbook.xml').decode()
pp=zipfile.ZipFile('${dirx}/r.pptx'); nl=[n for n in pp.namelist() if re.match(r'ppt/slides/slide[0-9]+[.]xml$',n)]
print(json.dumps({'abas':re.findall(r'<sheet [^>]*name="([^"]+)"',wb),'slides':len(nl),'txt':' '.join(pp.read(n).decode() for n in nl)[:200000],'ok':x.testzip() is None and pp.testzip() is None}))`]).toString());
    T('arquivos zip íntegros', info.ok);
    T('xlsx tem as abas esperadas', ['Resumo', 'Indicadores', 'Riscos', 'Projetos', 'Valor estratégico'].every(a => info.abas.includes(a)), info.abas.join('|'));
    T('pptx tem 8 slides', info.slides === 8, String(info.slides));
    T('pptx traz a unidade e riscos do banco', /UNID-TESTE|Unidade de Teste/.test(info.txt) && /Matriz|matriz/.test(info.txt));
    const nR = await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n);
    const linhas = JSON.parse(require('child_process').execFileSync('python3', ['-I', '-c', `
import zipfile,re,json
x=zipfile.ZipFile('${dirx}/r.xlsx'); wb=x.read('xl/workbook.xml').decode(); names=re.findall(r'<sheet [^>]*name="([^"]+)"',wb)
i=names.index('Riscos')+1; s=x.read('xl/worksheets/sheet%d.xml'%i).decode(); print(len(re.findall(r'<row ',s)))`]).toString());
    T('aba Riscos tem uma linha por risco (+cabeçalho)', linhas === nR + 1, linhas + ' vs ' + nR);
  }
  const e = limpa(); T('sem erros nos fluxos', !e.length, e[0]);
  await b.close(); srv.close();
  console.log(falhas ? `\n${falhas} falha(s), ${ok} verificações ok.` : `✓ ${ok} verificações ok.`); process.exit(falhas ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
