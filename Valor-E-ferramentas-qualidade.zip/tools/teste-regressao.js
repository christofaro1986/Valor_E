#!/usr/bin/env node
// Teste de regressão do Valor-E (navegador sem tela). Uso: node tools/teste-regressao.js
// Requer: playwright. Sobe um servidor local, carrega dados de exemplo e confere telas e fluxos principais.
const { chromium } = require(process.env.PW_PATH || 'playwright'); const fs = require('fs'), path = require('path'), http = require('http');
const app = path.resolve(__dirname, '..', 'app'), seed = fs.readFileSync(path.join(__dirname, 'fixtures', 'seed.js'), 'utf8');
const TIPOS = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.json': 'application/json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
const srv = http.createServer((q, s) => { let f = path.join(app, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, d) => { if (e) { s.writeHead(404); s.end(); } else { s.writeHead(200, { 'content-type': TIPOS[path.extname(f)] || 'application/octet-stream' }); s.end(d); } }); });
let falhas = 0, ok = 0; const ev = [];
const T = (nome, cond, det) => { if (cond) ok++; else { falhas++; console.log('✗ ' + nome + (det ? ' — ' + det : '')); } };
(async () => {
  await new Promise(r => srv.listen(0, r)); const url = 'http://localhost:' + srv.address().port + '/index.html';
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => ev.push('erro: ' + e.message + ' @ ' + String(e.stack).split('\n').slice(1, 3).join(' | '))); p.on('console', m => { if (m.type() === 'error' && !/favicon|Failed to load resource/.test(m.text())) ev.push('console: ' + m.text()); });
  p.on('dialog', d => d.accept('Teste'));
  await p.addInitScript(() => { window.__maprisHost = { invocar: (o) => o === 'chave' ? 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90' : (o === 'gravar' ? 'ok' : '') }; });
  await p.goto(url); await p.waitForFunction(() => window.DB && DB.db); await p.evaluate(seed);
  const ir = async h => { await p.evaluate(h => { location.hash = h; }, h); await p.waitForTimeout(350); };
  const limpa = () => { const e = ev.splice(0); return e; };
  // 1) rastreia todas as telas alcançáveis por links internos
  const vistos = new Set(), fila = ['#/painel']; let n = 0;
  while (fila.length && n < 80) {
    const h = fila.shift(); if (vistos.has(h)) continue; vistos.add(h); n++;
    await ir(h); const e = limpa();
    T('tela ' + h + ' sem erros', !e.length, e[0]);
    const txt = await p.evaluate(() => document.body.innerText);
    T('tela ' + h + ' sem "Erro ao montar"', !/Erro ao montar a tela/.test(txt), txt.match(/Erro ao montar a tela[^\n]*/) ? txt.match(/Erro ao montar a tela[^\n]*/)[0] : '');
    const links = await p.evaluate(() => [...document.querySelectorAll('a[href^="#/"]')].map(a => a.getAttribute('href')));
    links.filter(l => !vistos.has(l) && !/excluir|apagar/.test(l)).slice(0, 40).forEach(l => fila.push(l));
  }
  console.log('telas percorridas: ' + vistos.size);
  // 2) projetos: editar e criar com vínculos
  const save = () => p.evaluate(() => { const x = [...document.querySelectorAll('.modal.show button, button')].find(x => /^(Salvar|Criar projeto)$/.test(x.textContent.trim())); x && x.click(); });
  await ir('#/projetos'); await p.evaluate(() => Proj.editar(1)); await p.waitForTimeout(400);
  await p.fill('.modal.show #pn', 'Central EDITADA'); await p.selectOption('.modal.show #pacao', { index: 1 }); await save(); await p.waitForTimeout(500);
  T('projeto editado', (await p.evaluate(() => DB.one('SELECT nome FROM projetos WHERE id=1').nome)) === 'Central EDITADA');
  await p.evaluate(() => Proj.novo()); await p.waitForTimeout(400);
  await p.fill('.modal.show #pn', 'Projeto NOVO'); await p.selectOption('.modal.show #pmapa', { index: 1 }); await p.selectOption('.modal.show #pobj', { index: 1 }); await p.selectOption('.modal.show #pacao', { index: 1 }); await p.selectOption('.modal.show #pini', { index: 1 }); await save(); await p.waitForTimeout(600);
  const pn = await p.evaluate(() => DB.one("SELECT mapa_id m,objetivo_id o,acao_id a,iniciativa_id i FROM projetos WHERE nome='Projeto NOVO'"));
  T('projeto novo com 4 vínculos', pn && pn.m && pn.o && pn.a && pn.i, JSON.stringify(pn));
  // 3) linha de base lança valor no indicador do projeto; indicador de projeto sem botão Registro
  await p.evaluate(() => Proj.baseline(1)); await p.waitForTimeout(300); await p.fill('.modal.show #bn', 'LB teste');
  await p.evaluate(() => { [...document.querySelectorAll('.modal.show button')].find(x => /Salvar linha de base/.test(x.textContent)).click(); }); await p.waitForTimeout(500);
  T('linha de base lançou valor no indicador', await p.evaluate(() => !!DB.one("SELECT 1 x FROM lanc_ind l JOIN indicadores i ON i.id=l.indicador_id WHERE i.codigo='PRJ-PROG-1' AND l.observacao LIKE 'Linha de base:%'")));
  await ir('#/indicadores'); T('lista de indicadores sem Registro em indicador de projeto', await p.evaluate(() => [...document.querySelectorAll('tbody tr')].filter(t => /PRJ-PROG/.test(t.textContent)).every(t => !/Registro/.test(t.textContent))));
  // 4) riscos: origem reconhecida
  const vis = () => p.evaluate(() => ['blocoOrigem', 'blocoProj', 'blocoProc'].map(i => document.getElementById(i).offsetHeight > 0 ? 1 : 0).join(''));
  const rp = await p.evaluate(() => E.riscoSalvar({ nome: 'R projeto', ambiente: 'x', projeto_id: 1, fatores: [] })); await ir('#/risco?id=' + rp); T('risco de projeto mostra só projeto', (await vis()) === '010', await vis());
  const rq = await p.evaluate(() => E.riscoSalvar({ nome: 'R processo', ambiente: 'x', processo_id: DB.one('SELECT id FROM processos').id, fatores: [] })); await ir('#/risco?id=' + rq); T('risco de processo mostra só processo', (await vis()) === '001', await vis());
  await ir('#/risco'); T('risco novo pergunta a origem', (await vis()) === '100', await vis());
  await p.evaluate(() => DB.run('UPDATE riscos SET processo_id=(SELECT id FROM processos LIMIT 1) WHERE id=?', [DB.one("SELECT id FROM riscos WHERE nome='R projeto'").id])); await ir('#/riscos'); await ir('#/risco?id=' + rp); T('risco de projeto com processo legado esconde o processo', (await vis()) === '010', await vis());
  // 4b) botões inline do risco (Salvar, Duplicar, Excluir, + causa) e da Folha do processo (Salvar, Ordenar, Gerar)
  await ir('#/risco'); await p.fill('#f_nome', 'Risco pelo botão'); await p.selectOption('#f_origem', 'outro'); await p.fill('#f_ambiente', 'Ambiente livre');
  await p.click('button:has-text("Salvar")'); await p.waitForTimeout(700);
  T('botão Salvar do risco grava', await p.evaluate(() => !!DB.one("SELECT 1 x FROM riscos WHERE nome='Risco pelo botão'")), limpa()[0]);
  await p.evaluate(() => Risco.addFator()); await p.waitForTimeout(200);
  T('botão + causa do risco', await p.evaluate(() => Risco.estado.R.fatores.length >= 1));
  await p.click('#bDup'); await p.waitForTimeout(800);
  T('botão Duplicar do risco', await p.evaluate(() => DB.one("SELECT COUNT(*) n FROM riscos WHERE nome LIKE 'Risco pelo botão%'").n) >= 2);
  const pid = await p.evaluate(() => DB.one('SELECT id FROM processos ORDER BY id LIMIT 1').id);
  await ir('#/folha?id=' + pid); const eF = limpa(); T('Folha abre sem erro', !eF.length, eF[0]);
  T('Folha expõe os botões em Folha.*', await p.evaluate(() => ['salvar', 'addLinha', 'ordenar', 'renumerar', 'gerar'].every(n => typeof Folha[n] === 'function')));
  await p.evaluate(() => Folha.ordenar()); await p.click('button:has-text("Salvar")').catch(() => {}); await p.waitForTimeout(600);
  const eF2 = limpa(); T('botões da Folha sem erro', !eF2.length, eF2[0]);
  // 4d) sincronia bandeira do diagrama BPMN ↔ módulo de riscos
  const fid = await p.evaluate(() => E.flagDoElemento(3, 'Activity_X', 'Conferir documentação'));
  await p.evaluate(f => E.flagRiscoAdicionar(f, { nome: 'Risco da bandeira', probabilidade: 3, impacto: 3, categoria: 'Operacional' }), fid);
  const rb = await p.evaluate(() => DB.one("SELECT id, processo_id, flag_id FROM riscos WHERE flag_id IS NOT NULL"));
  T('risco criado pela bandeira fica ligado ao processo e à bandeira', rb && rb.processo_id === 3 && rb.flag_id === fid, JSON.stringify(rb));
  await ir('#/risco?id=' + rb.id); T('formulário do risco da bandeira mostra o processo', (await p.evaluate(() => document.getElementById('f_processo_id').value)) === '3' && (await vis()) === '001');
  await p.fill('#f_nome', 'Risco da bandeira RENOMEADO'); await p.click('button:has-text("Salvar")'); await p.waitForTimeout(700);
  T('renomear no módulo de riscos aparece na bandeira do diagrama', await p.evaluate(f => E.flagsDoProcesso(3).some(x => x.id === f && x.riscos.some(r => r.nome === 'Risco da bandeira RENOMEADO')), fid));
  await p.click('#bDup'); await p.waitForTimeout(900);
  T('cópia do risco continua na mesma bandeira', await p.evaluate(f => DB.all('SELECT id FROM riscos WHERE flag_id = ?', [f]).length, fid) === 2);
  await p.click('button:has-text("Excluir")'); await p.waitForTimeout(700);
  T('excluir uma cópia mantém a bandeira', await p.evaluate(f => !!DB.one('SELECT 1 x FROM flags WHERE id = ?', [f]), fid));
  await p.evaluate(r => { location.hash = '#/risco?id=' + r; }, rb.id); await p.waitForTimeout(700); await p.click('button:has-text("Excluir")'); await p.waitForTimeout(700);
  T('excluir o último risco remove a bandeira do diagrama', await p.evaluate(f => !DB.one('SELECT 1 x FROM flags WHERE id = ?', [f]), fid));
  // 4c) migrações versionadas
  T('migrações registradas em schema_versoes', await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM schema_versoes').n) >= 5);
  T('camada única de dados (sem OptDB)', await p.evaluate(() => typeof window.OptDB === 'undefined' && typeof DB.rows === 'function'));
  // 5) Valor Estratégico: ciclos, metas e plano 5W2H
  await ir('#/valor/ciclos'); await p.evaluate(() => UI.formMetasCiclo(1)); await p.waitForTimeout(400);
  T('metas do ciclo sem linha de base', await p.evaluate(() => !/Linha de base/.test(document.body.innerText)));
  await ir('#/valor/objetivos?oe=3'); T('objetivos sem botão Novo objetivo', await p.evaluate(() => !/Novo objetivo/.test(document.body.innerText)));
  // 6) exportação e importação por itens (ida e volta)
  const rt = await p.evaluate(() => { const t = []; Mapris.baixar = (n, x) => { t.push(x); }; Pacote.exportarXml(); return t[0] ? t[0].length : 0; }); T('exportação XML gera conteúdo', rt > 1000, String(rt));
  const e = limpa(); T('sem erros nos fluxos', !e.length, e[0]);
  await b.close(); srv.close();
  console.log(falhas ? `\n${falhas} falha(s), ${ok} verificações ok.` : `✓ ${ok} verificações ok.`); process.exit(falhas ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
