#!/usr/bin/env node
// Teste de ATUALIZAÇÃO de bancos antigos: abre, na versão atual do Valor-E, bancos criados por versões anteriores
// (sem a tabela de migrações, com colunas a menos, ou no formato AXIA 3.x) e confere que nada se perde.
// Uso: PW_PATH=$(npm root -g)/playwright node tools/teste-banco-antigo.js
const { chromium } = require(process.env.PW_PATH || 'playwright'); const fs = require('fs'), path = require('path'), http = require('http');
const app = path.resolve(__dirname, '..', 'app'), seedCompleto = fs.readFileSync(path.join(__dirname, 'fixtures', 'seed-completo.js'), 'utf8');
const TIPOS = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.json': 'application/json' };
const srv = http.createServer((q, s) => { let f = path.join(app, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, d) => { if (e) { s.writeHead(404); return s.end(); } s.writeHead(200, { 'Content-Type': TIPOS[path.extname(f)] || 'application/octet-stream' }); s.end(d); }); });
let ok = 0, falhas = 0; const T = (n, c, d) => { if (c) { ok++; console.log('  ✓ ' + n); } else { falhas++; console.log('  ✗ ' + n + (d ? ' — ' + d : '')); } };
const CHAVE = 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90';

// esquema "de época" (sem as colunas e tabelas que vieram depois)
const BASE = [
  "CREATE TABLE riscos (id INTEGER PRIMARY KEY AUTOINCREMENT, ambiente TEXT NOT NULL DEFAULT '', nome TEXT NOT NULL, descricao TEXT DEFAULT '', consequencias TEXT DEFAULT '', categoria TEXT DEFAULT '', responsavel TEXT DEFAULT '', status TEXT DEFAULT 'Identificado', resposta TEXT DEFAULT '', prob_media REAL, imp_medio REAL, indice_medio INTEGER, nivel_medio TEXT, prob_res REAL, imp_res REAL, indice_res INTEGER, nivel_res TEXT, nivel_est TEXT, indice_est INTEGER, nivel_def TEXT, indice_def INTEGER, criado_em TEXT DEFAULT CURRENT_TIMESTAMP, atualizado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
  "CREATE TABLE fatores (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, ordem INTEGER DEFAULT 0, nome TEXT DEFAULT '', descricao TEXT DEFAULT '', probabilidade INTEGER DEFAULT 3, impacto INTEGER DEFAULT 3, indice INTEGER, nivel TEXT, p_res REAL, i_res REAL, indice_res INTEGER, nivel_res TEXT, indice_est INTEGER, nivel_est TEXT, indice_def INTEGER, nivel_def TEXT, eficacia REAL DEFAULT 0)",
  "CREATE TABLE controles (id INTEGER PRIMARY KEY AUTOINCREMENT, fator_id INTEGER NOT NULL REFERENCES fatores(id) ON DELETE CASCADE, ordem INTEGER DEFAULT 0, descricao TEXT DEFAULT '', tipo_controle TEXT DEFAULT 'Preventivo', natureza TEXT DEFAULT 'Manual', eficacia REAL DEFAULT 0, status TEXT DEFAULT 'Planejado', prob_controle INTEGER DEFAULT 3, imp_controle INTEGER DEFAULT 3, indice INTEGER, nivel TEXT, responsavel TEXT DEFAULT '', prazo TEXT, data_implementacao TEXT, observacoes TEXT DEFAULT '')",
  "CREATE TABLE planos (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, controle_id INTEGER REFERENCES controles(id) ON DELETE SET NULL, controle_desc TEXT DEFAULT '', descricao TEXT DEFAULT '', responsavel TEXT DEFAULT '', prazo TEXT, status TEXT DEFAULT 'Pendente', prioridade TEXT DEFAULT 'Média', observacoes TEXT DEFAULT '', concluido_em TEXT)",
  "CREATE TABLE revisoes (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, data TEXT NOT NULL, parecer TEXT DEFAULT '', autor TEXT DEFAULT '', nivel_inerente TEXT, indice_inerente INTEGER, nivel_residual TEXT, indice_residual INTEGER, criado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
  "CREATE TABLE config (chave TEXT PRIMARY KEY, valor TEXT)"];
const PROC = "(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, folha_json TEXT NOT NULL DEFAULT '{}', atividades_json TEXT NOT NULL DEFAULT '[]', opcoes_json TEXT NOT NULL DEFAULT '{}', bpmn_xml TEXT, bpmn_svg TEXT, bpmn_origem TEXT, bpmn_hash TEXT, criado_em TEXT DEFAULT CURRENT_TIMESTAMP, atualizado_em TEXT DEFAULT CURRENT_TIMESTAMP)";
function dados(axia, semFlagId) {
  const rk = axia ? 'cenario_id' : null, o = [];
  o.push(axia ? 'CREATE TABLE cenarios ' + PROC : 'CREATE TABLE processos ' + PROC);
  BASE.forEach(s => o.push(axia ? s.replace("ambiente TEXT NOT NULL DEFAULT ''", "cenario_id INTEGER, " + (semFlagId ? '' : 'flag_id INTEGER, ') + "ambiente TEXT NOT NULL DEFAULT ''") : s));
  if (axia) { o.push("CREATE TABLE flags (id INTEGER PRIMARY KEY AUTOINCREMENT, cenario_id INTEGER, pagina INTEGER, x REAL, y REAL, risco_id INTEGER)"); o.push("CREATE TABLE cenario_pdf (id INTEGER PRIMARY KEY AUTOINCREMENT, cenario_id INTEGER, dados BLOB)"); }
  const T = axia ? 'cenarios' : 'processos';
  o.push(`INSERT INTO ${T} (nome) VALUES ('Compras de material'), ('Recebimento'), ('Manutenção preventiva')`);
  for (let i = 1; i <= 5; i++) {
    o.push(`INSERT INTO riscos (${axia ? 'cenario_id,' + (semFlagId ? '' : ' flag_id,') : ''} ambiente, nome, descricao, categoria, responsavel, status, resposta, prob_media, imp_medio, indice_medio, nivel_medio, indice_res, nivel_res) VALUES (${axia ? ((i % 3) + 1) + ',' + (semFlagId ? '' : ' ' + (i <= 2 ? i : 'NULL') + ',') : ''} '${i % 2 ? 'Compras de material' : 'Almoxarifado'}', 'Risco antigo ${i}', 'Descrição ${i}', 'Operacional', 'Chefe ${i}', 'Em tratamento', 'Reduzir', 3.5, 4, ${8 + i}, 'Alto', ${4 + i}, 'Médio')`);
    o.push(`INSERT INTO fatores (risco_id, ordem, nome, probabilidade, impacto, indice, nivel) VALUES (${i}, 1, 'Fator ${i}.1', 4, 4, 16, 'Alto'), (${i}, 2, 'Fator ${i}.2', 2, 3, 6, 'Médio')`);
    o.push(`INSERT INTO controles (fator_id, descricao, tipo_controle, eficacia, status) VALUES (${i * 2 - 1}, 'Controle do fator ${i}', 'Preventivo', 50, 'Implementado')`);
    o.push(`INSERT INTO planos (risco_id, controle_id, descricao, responsavel, prazo, status) VALUES (${i}, ${i}, 'Plano ${i}', 'Resp ${i}', '2026-0${i}-15', 'Pendente')`);
    o.push(`INSERT INTO revisoes (risco_id, data, parecer, autor) VALUES (${i}, '2026-0${i}-01', 'Revisado ${i}', 'Gestor')`);
  }
  if (axia) { o.push('INSERT INTO flags (cenario_id, pagina, x, y, risco_id) VALUES (1, 1, 10, 10, 1), (2, 1, 20, 20, 2)'); o.push("INSERT INTO cenario_pdf (cenario_id, dados) VALUES (1, x'25504446')"); }
  o.push("INSERT INTO config (chave, valor) VALUES ('apetite', 'moderado')");
  return o;
}

(async () => {
  await new Promise(r => srv.listen(0, r)); const url = 'http://localhost:' + srv.address().port + '/index.html';
  const b = await chromium.launch(); const erros = [];
  let banco = '';   // "disco" do aplicativo simulado: o que o aplicativo gravou por último
  async function abrir(inicial) {
    banco = inicial || '';
    const ctx = await b.newContext({ viewport: { width: 1300, height: 900 } }), p = await ctx.newPage();
    await p.exposeFunction('__hostNode', (op, d) => { if (op === 'carregar') return banco; if (op === 'gravar') { banco = d; return 'ok'; } if (op === 'chave') return CHAVE; return ''; });
    await p.addInitScript(() => { window.__maprisHost = { invocar: (op, d) => window.__hostNode(op, d || '') }; });
    p.on('pageerror', e => erros.push(e.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); }); p.on('dialog', d => d.accept());
    await p.goto(url); await p.waitForFunction(() => window.DB && DB.db, null, { timeout: 15000 }); await p.waitForTimeout(700); const quebrou = await p.evaluate(() => /Não foi possível abrir o banco/.test(document.body.innerText)); if (quebrou) erros.push('tela de erro na abertura do banco: ' + await p.evaluate(() => document.body.innerText.slice(0, 200))); return p;
  }
  const contar = () => { const o = {}; DB.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").forEach(t => { o[t.name] = DB.one('SELECT COUNT(*) n FROM ' + t.name).n; }); return o; };
  async function construir(sqls) {   // cria os bytes do banco antigo usando o próprio sql.js do aplicativo
    const p = await abrir(''); const b64 = await p.evaluate(q => { const d = new DB.SQL.Database(); q.forEach(s => d.run(s)); const u = d.export(); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }, sqls); await p.context().close(); return b64;
  }
  async function verificar(p, nome) {
    const integr = await p.evaluate(() => DB.all('PRAGMA integrity_check').map(r => r.integrity_check).join(','));
    const fk = await p.evaluate(() => DB.all('PRAGMA foreign_key_check').length);
    T(nome + ': integridade do banco', integr === 'ok', integr); T(nome + ': sem violações de chave estrangeira', fk === 0, fk + ' violação(ões)');
    T(nome + ': migrações registradas', await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM schema_versoes').n) >= 5);
    // telas principais abrem sem erro
    const e0 = erros.length;
    for (const h of ['#/', '#/riscos', '#/painelrisco', '#/processos', '#/projetos', '#/indicadores', '#/valor', '#/dados']) { await p.evaluate(x => { location.hash = x; }, h); await p.waitForTimeout(350); }
    T(nome + ': telas principais abrem sem erro', erros.length === e0, erros.slice(e0)[0]);
    // gravação e releitura: o que o aplicativo gravou reabre com os mesmos dados
    const antes = await p.evaluate(contar); await p.evaluate(() => DB.flush()); const salvo = banco; await p.context().close();
    const q = await abrir(salvo); const depois = await q.evaluate(contar);
    const dif = Object.keys(antes).filter(t => t !== 'sec_auditoria' && antes[t] !== depois[t]);
    T(nome + ': dados gravados reabrem idênticos (cifrado)', !dif.length, dif.map(t => t + ' ' + antes[t] + '→' + depois[t]).join(', ')); return q;
  }

  console.log('A) Banco de uma versão anterior ao Valor-E 2.0 (sem migrações, sem as colunas novas)');
  let p = await abrir(await construir(dados(false)));
  const A = await p.evaluate(() => ({ r: DB.one('SELECT COUNT(*) n FROM riscos').n, f: DB.one('SELECT COUNT(*) n FROM fatores').n, c: DB.one('SELECT COUNT(*) n FROM controles').n, pl: DB.one('SELECT COUNT(*) n FROM planos').n, rv: DB.one('SELECT COUNT(*) n FROM revisoes').n, pr: DB.one('SELECT COUNT(*) n FROM processos').n, semCod: DB.one("SELECT COUNT(*) n FROM riscos WHERE codigo IS NULL OR codigo = ''").n, nomes: DB.all('SELECT nome FROM riscos ORDER BY id').map(x => x.nome).join('|'), ap: (DB.one("SELECT valor v FROM config WHERE chave='apetite'") || {}).v, cols: DB.all('PRAGMA table_info(riscos)').map(c => c.name) }));
  T('A: nenhum registro perdido', A.r === 5 && A.f === 10 && A.c === 5 && A.pl === 5 && A.rv === 5 && A.pr === 3, JSON.stringify(A));
  T('A: nomes e configuração preservados', A.nomes === 'Risco antigo 1|Risco antigo 2|Risco antigo 3|Risco antigo 4|Risco antigo 5' && A.ap === 'moderado');
  T('A: colunas novas criadas e códigos R1… atribuídos', ['processo_id', 'flag_id', 'projeto_id', 'codigo'].every(c => A.cols.includes(c)) && A.semCod === 0);
  await p.evaluate(() => { const id = E.riscoSalvar({ nome: 'Risco novo após atualizar', ambiente: 'Compras de material', categoria: 'Operacional', status: 'Identificado', resposta: 'Reduzir', fatores: [{ nome: 'F', probabilidade: 3, impacto: 3, controles: [] }] }); return id; });
  T('A: dá para criar um risco novo no banco atualizado', await p.evaluate(() => DB.one("SELECT COUNT(*) n FROM riscos WHERE nome = 'Risco novo após atualizar'").n) === 1);
  await p.evaluate(() => { Proj.novoRisco && 0; DB.run("INSERT INTO cva_ciclos (nome,status) VALUES ('Ciclo novo','Vigente')"); DB.sujo(); });
  p = await verificar(p, 'A'); await p.context().close();

  console.log('B) Banco no formato AXIA 3.x (cenários, bandeiras em PDF)');
  p = await abrir(await construir(dados(true)));
  const B = await p.evaluate(() => ({ proc: DB.all('SELECT nome FROM processos ORDER BY id').map(x => x.nome).join('|'), cen: DB.all("SELECT name FROM sqlite_master WHERE name = 'cenarios'").length, r: DB.one('SELECT COUNT(*) n FROM riscos').n, fl: DB.one('SELECT COUNT(*) n FROM flags').n, comFlag: DB.one('SELECT COUNT(*) n FROM riscos WHERE flag_id IS NOT NULL').n, ligados: DB.one('SELECT COUNT(*) n FROM riscos WHERE processo_id IS NOT NULL').n, pdf: DB.all("SELECT name FROM sqlite_master WHERE name = 'cenario_pdf'").length }));
  T('B: cenários viraram processos, com os mesmos nomes', B.proc === 'Compras de material|Recebimento|Manutenção preventiva' && B.cen === 0, JSON.stringify(B));
  T('B: riscos preservados e ligados aos processos', B.r === 5 && B.ligados === 5, JSON.stringify(B));
  T('B: bandeiras antigas (posição em PDF) descartadas, sem ficar apontando para nada', B.fl === 0 && B.comFlag === 0 && B.pdf === 0);
  p = await verificar(p, 'B'); await p.context().close();

  console.log('B2) AXIA 3.x sem a coluna flag_id nos riscos');
  p = await abrir(await construir(dados(true, true)));
  T('B2: abre e preserva os 5 riscos e os 3 processos', await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM riscos').n === 5 && DB.one('SELECT COUNT(*) n FROM processos').n === 3));
  p = await verificar(p, 'B2'); await p.context().close();

  console.log('C) Banco do Valor-E 2.0 criado sem a tabela de migrações (todos os módulos com dados)');
  const pc = await abrir(''); await pc.evaluate(seedCompleto); const cont0 = await pc.evaluate(contar);
  await pc.evaluate(() => { DB.db.run('DROP TABLE schema_versoes'); DB.db.run('DROP TABLE IF EXISTS importacoes'); });
  const b64C = await pc.evaluate(() => { const u = DB.exportarBytes(); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }); await pc.context().close();
  p = await abrir(b64C); const cont1 = await p.evaluate(contar);
  const difC = Object.keys(cont0).filter(t => !['schema_versoes', 'importacoes', 'sec_auditoria'].includes(t) && cont0[t] !== cont1[t]);
  T('C: todas as tabelas com os mesmos registros depois da atualização', !difC.length, difC.map(t => t + ' ' + cont0[t] + '→' + cont1[t]).join(', '));
  T('C: migrações voltam a ser registradas sem refazer dados', await p.evaluate(() => DB.one('SELECT COUNT(*) n FROM schema_versoes').n === DB.extras.filter(m => m.id).length));
  T('C: alertas de risco continuam funcionando', await p.evaluate(() => { let n = 0; DB.all('SELECT id FROM riscos').forEach(r => { n += E.alertasRisco(E.riscoCarregar(r.id)).length; }); return n > 0; }));
  T('C: indicador de progresso de projeto e linha de base preservados', await p.evaluate(() => DB.one("SELECT COUNT(*) n FROM indicadores WHERE codigo LIKE 'PRJ-PROG-%'").n) === 9 && await p.evaluate(() => DB.one("SELECT COUNT(*) n FROM lanc_ind WHERE observacao LIKE 'Linha de base:%'").n) >= 3);
  p = await verificar(p, 'C'); await p.context().close();

  T('nenhum erro de página durante todo o teste', !erros.length, erros[0]);
  await b.close(); srv.close();
  console.log(falhas ? `\n${falhas} falha(s), ${ok} verificações ok.` : `\n✓ ${ok} verificações ok.`); process.exit(falhas ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
