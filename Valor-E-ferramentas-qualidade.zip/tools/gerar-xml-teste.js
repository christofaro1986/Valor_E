#!/usr/bin/env node
// Gera o XML completo de testes do Valor-E e confere que ele volta íntegro ao ser importado.
// Uso: PW_PATH=$(npm root -g)/playwright node tools/gerar-xml-teste.js [arquivo-de-saida.xml]
const { chromium } = require(process.env.PW_PATH || 'playwright'); const fs = require('fs'), path = require('path'), http = require('http');
const app = path.resolve(__dirname, '..', 'app'), seed = fs.readFileSync(path.join(__dirname, 'fixtures', 'seed-completo.js'), 'utf8');
const saida = path.resolve(process.argv[2] || 'Valor-E-xml-de-teste.xml');
const TIPOS = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.json': 'application/json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
const srv = http.createServer((q, s) => { let f = path.join(app, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, d) => { if (e) { s.writeHead(404); return s.end(); } s.writeHead(200, { 'Content-Type': TIPOS[path.extname(f)] || 'application/octet-stream' }); s.end(d); }); });
const erros = [];
async function abrir(b, url) {
  const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => erros.push(e.message)); p.on('dialog', d => d.accept('Teste'));
  await p.addInitScript(() => { window.__maprisHost = { invocar: o => o === 'chave' ? 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90' : (o === 'gravar' ? 'ok' : '') }; });
  await p.goto(url); await p.waitForFunction(() => window.DB && DB.db); return p;
}
const contagens = () => { const o = {}; DB.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT IN ('schema_versoes','config')").forEach(t => { o[t.name] = DB.one('SELECT COUNT(*) AS n FROM ' + t.name).n; }); return o; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const url = 'http://localhost:' + srv.address().port + '/index.html';
  const b = await chromium.launch();
  const p = await abrir(b, url);
  const antesTudo = await p.evaluate(contagens);
  await p.evaluate(seed);
  const antes = await p.evaluate(contagens);
  const xml = await p.evaluate(() => { let t = ''; Mapris.baixar = (n, x) => { t = x; }; Pacote.exportarXml(); return t; });
  fs.writeFileSync(saida, xml);
  // verificação: importa em um banco limpo (modo substituir) e compara as contagens
  const q = await abrir(b, url);
  const r = await q.evaluate(t => { try { Pacote.importarTexto(t, 'substituir'); return null; } catch (e) { return String(e.message || e); } }, xml);
  const depois = await q.evaluate(contagens);
  // alertas e lacunas esperados
  const alertas = await q.evaluate(() => { const o = {}; try { DB.all('SELECT id FROM riscos').forEach(x => { E.alertasRisco(E.riscoCarregar(x.id)).forEach(a => { o[a.cod] = (o[a.cod] || 0) + 1; }); }); } catch (e) { o.erro = String(e.message); } return o; });
  const amostra = await q.evaluate(() => ({
    riscosProjeto: DB.one('SELECT COUNT(*) n FROM riscos WHERE projeto_id IS NOT NULL').n, riscosProcesso: DB.one('SELECT COUNT(*) n FROM riscos WHERE processo_id IS NOT NULL').n,
    riscosComBandeira: DB.one('SELECT COUNT(*) n FROM riscos WHERE flag_id IS NOT NULL').n, riscosProjetoComProcesso: DB.one('SELECT COUNT(*) n FROM riscos WHERE projeto_id IS NOT NULL AND (processo_id IS NOT NULL OR flag_id IS NOT NULL)').n,
    indProjeto: DB.one("SELECT COUNT(*) n FROM indicadores WHERE codigo LIKE 'PRJ-PROG-%'").n, baselineNoIndicador: DB.one("SELECT COUNT(*) n FROM lanc_ind WHERE observacao LIKE 'Linha de base:%'").n,
    codigosDuplicados: DB.all('SELECT codigo FROM riscos GROUP BY codigo HAVING COUNT(*) > 1').length, bpmnValidos: DB.all("SELECT bpmn_xml FROM processos WHERE bpmn_xml IS NOT NULL").length }));
  let dif = []; Object.keys(antes).forEach(t => { if (antes[t] !== depois[t]) dif.push(t + ': ' + antes[t] + ' → ' + depois[t]); });
  const vazias = Object.keys(antes).filter(t => antes[t] === 0 && antesTudo[t] === 0);
  console.log('arquivo:', saida, '(' + Math.round(xml.length / 1024) + ' KB)');
  console.log('importação em banco limpo:', r ? 'ERRO ' + r : 'ok'); console.log('tabelas com divergência após importar:', dif.length ? dif.join('; ') : 'nenhuma');
  console.log('linhas por tabela:', JSON.stringify(depois)); console.log('tabelas vazias:', vazias.join(', ') || 'nenhuma');
  console.log('alertas de risco:', JSON.stringify(alertas)); console.log('amostra:', JSON.stringify(amostra));
  console.log('erros de página:', erros.length ? erros.join(' | ') : 'nenhum');
  await b.close(); srv.close(); process.exit(r || dif.length || erros.length ? 1 : 0);
})();
