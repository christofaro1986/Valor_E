# Ferramentas de qualidade do Valor-E

Não entram nos instaladores; servem para quem desenvolve.

## 1. Verificador de módulos — `lint-modulos.js`
Acusa nomes que se sobrescrevem em silêncio:
- função declarada duas vezes no mesmo escopo (a última vence);
- o mesmo nome global ou de módulo (`window.X`, `Proj.editar`) definido em mais de um arquivo.

    node tools/lint-modulos.js app          # precisa do pacote npm "typescript"

Nomes compartilhados de propósito ficam em `lint-ignorar.json`, com o motivo.

## 2. Teste de regressão — `teste-regressao.js`
Abre o aplicativo num navegador sem tela, carrega `fixtures/seed.js` e confere:
- todas as telas alcançáveis por links (sem erro de console nem "Erro ao montar a tela");
- projetos (editar, criar com vínculos), linha de base lançando valor no indicador;
- formulário de risco (origem processo/projeto) e seus botões Salvar, Duplicar e + causa; botões da Folha do processo;
- metas por ciclo, exportação, migrações versionadas e camada única de dados.

    node tools/teste-regressao.js            # precisa do pacote npm "playwright"

## Antes de gerar uma versão
Rode os dois. Se algum falhar, não empacote.
Ao acrescentar um fluxo novo, acrescente a verificação correspondente no teste.

## Convenções de módulos
- Cada arquivo é uma função isolada; o que outros usam é exposto num namespace (`Proj`, `Mapa`, `Risco`, `Folha`, `Pacote`…).
- Manipuladores em HTML (`onclick="Risco.salvar(true)"`) sempre usam o namespace; não crie funções globais soltas.
- Tabelas novas: `DB.migracao('modulo-NNN-assunto', fn)`; a migração roda uma vez por banco e deve ser idempotente.
- Acesso a dados: sempre pela camada `DB` (`all`/`rows`, `one`, `run`, `tx`, `exec`, `persistir`).
