# Ferramentas de qualidade do Valor-E

Não entram nos instaladores; servem para quem desenvolve.

## 1. Verificador de módulos — `lint-modulos.js`
Acusa nomes que se sobrescrevem em silêncio:
- função declarada duas vezes no mesmo escopo (a última vence);
- o mesmo nome global ou de módulo (`window.X`, `Proj.editar`) definido em mais de um arquivo.

    node tools/lint-modulos.js app          # precisa do pacote npm "typescript"

Nomes compartilhados de propósito ficam em `lint-ignorar.json`, com o motivo.

## 2. Teste de regressão — `teste-regressao.js`
Abre o aplicativo num navegador sem tela, carrega `fixtures/seed.js` e confere:
- todas as telas alcançáveis por links (sem erro de console nem "Erro ao montar a tela");
- projetos (editar, criar com vínculos), linha de base lançando valor no indicador;
- formulário de risco (origem processo/projeto) e seus botões Salvar, Duplicar e + causa; botões da Folha do processo;
- metas por ciclo, exportação, migrações versionadas e camada única de dados.

    node tools/teste-regressao.js            # precisa do pacote npm "playwright"

## Antes de gerar uma versão
Rode os dois. Se algum falhar, não empacote.
Ao acrescentar um fluxo novo, acrescente a verificação correspondente no teste.

## Convenções de módulos
- Cada arquivo é uma função isolada; o que outros usam é exposto num namespace (`Proj`, `Mapa`, `Risco`, `Folha`, `Pacote`…).
- Manipuladores em HTML (`onclick="Risco.salvar(true)"`) sempre usam o namespace; não crie funções globais soltas.
- Tabelas novas: `DB.migracao('modulo-NNN-assunto', fn)`; a migração roda uma vez por banco e deve ser idempotente.
- Acesso a dados: sempre pela camada `DB` (`all`/`rows`, `one`, `run`, `tx`, `exec`, `persistir`).

## XML completo de testes

`node tools/gerar-xml-teste.js [saida.xml]` abre o Valor-E, carrega `fixtures/seed-completo.js` (todos os módulos, com casos bons e casos propositalmente problemáticos), exporta pelo botão oficial "Exportar tudo (.xml)" e confere que o arquivo volta íntegro ao ser importado em um banco limpo (contagem de linhas de todas as tabelas).

`SEED=seed-completo.js node tools/teste-regressao.js` percorre as 80 telas com esse conjunto maior de dados. (A seção 4d da suíte assume o seed simples; use o seed completo apenas para o percurso de telas.)

## Teste de bancos de versões antigas

`node tools/teste-banco-antigo.js` cria bancos no formato de versões anteriores (AXIA 3.x e intermediários) com dados, abre cada um no Valor-E 2.0 e confere: migração sem erro, `integrity_check` e `foreign_key_check`, telas abrindo e gravação cifrada que volta íntegra. Use também com um `.sqlite` real de uma versão antiga (cópia!) para validar o seu caso.
