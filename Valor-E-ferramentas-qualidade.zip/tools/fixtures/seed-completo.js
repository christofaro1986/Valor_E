// executado dentro da página (window): popula o banco com um conjunto COMPLETO de dados de teste
// (todos os módulos, com casos "bons" e casos propositalmente problemáticos para exercitar alertas e lacunas).
(function () {
  var run = function (s, p) { DB.run(s, p || []); }, id = function () { return DB.lastId(); };

  // ---- BPMN mínimo, válido, com diagrama (DI) para as bandeiras de risco ----
  function bpmn(pid, nomes) {
    var shapes = '', fluxos = '', edges = '', x = 160, tasks = '', ant = 'Start_' + pid;
    shapes += '<bpmndi:BPMNShape id="S_Start" bpmnElement="Start_' + pid + '"><dc:Bounds x="100" y="102" width="36" height="36"/></bpmndi:BPMNShape>';
    nomes.forEach(function (n, i) {
      var tid = 'Task_' + pid + '_' + (i + 1), fid = 'Flow_' + pid + '_' + (i + 1);
      tasks += '<bpmn:task id="' + tid + '" name="' + n + '"/>';
      fluxos += '<bpmn:sequenceFlow id="' + fid + '" sourceRef="' + ant + '" targetRef="' + tid + '"/>';
      shapes += '<bpmndi:BPMNShape id="S_' + tid + '" bpmnElement="' + tid + '"><dc:Bounds x="' + x + '" y="80" width="100" height="80"/></bpmndi:BPMNShape>';
      edges += '<bpmndi:BPMNEdge id="E_' + fid + '" bpmnElement="' + fid + '"><di:waypoint x="' + (x - 24) + '" y="120"/><di:waypoint x="' + x + '" y="120"/></bpmndi:BPMNEdge>';
      ant = tid; x += 140;
    });
    fluxos += '<bpmn:sequenceFlow id="Flow_' + pid + '_fim" sourceRef="' + ant + '" targetRef="End_' + pid + '"/>';
    shapes += '<bpmndi:BPMNShape id="S_End" bpmnElement="End_' + pid + '"><dc:Bounds x="' + x + '" y="102" width="36" height="36"/></bpmndi:BPMNShape>';
    edges += '<bpmndi:BPMNEdge id="E_fim" bpmnElement="Flow_' + pid + '_fim"><di:waypoint x="' + (x - 40) + '" y="120"/><di:waypoint x="' + x + '" y="120"/></bpmndi:BPMNEdge>';
    return '<?xml version="1.0" encoding="UTF-8"?><bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Defs_' + pid + '" targetNamespace="http://valore/teste">' +
      '<bpmn:process id="Proc_' + pid + '" isExecutable="false"><bpmn:startEvent id="Start_' + pid + '" name="Início"/>' + tasks + '<bpmn:endEvent id="End_' + pid + '" name="Fim"/>' + fluxos + '</bpmn:process>' +
      '<bpmndi:BPMNDiagram id="Dg_' + pid + '"><bpmndi:BPMNPlane id="Pl_' + pid + '" bpmnElement="Proc_' + pid + '">' + shapes + edges + '</bpmndi:BPMNPlane></bpmndi:BPMNDiagram></bpmn:definitions>';
  }
  var mes = function (n) { return '2026-' + (n < 10 ? '0' : '') + n; };

  DB.tx(function () {
    // ===== 1. Cadeia de valor: ciclo vigente (13 macros) e ciclo encerrado =====
    run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES ('Ciclo 2025','Prover serviços logísticos à Força.','Valor entregue em 2025','2025-01-01','2025-12-31','Encerrado','Principal')"); var c25 = id();
    run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES ('Ciclo 2026','Prover serviços logísticos confiáveis e tempestivos à Força, com eficiência no uso dos recursos públicos.','Valor entregue à sociedade e aos usuários finais','2026-01-01','2026-12-31','Vigente','Principal')"); var c = id();
    run("INSERT INTO macroprocessos (ciclo_id,tipo,nome,ordem) VALUES (?,?,?,1)", [c25, 'Finalístico', 'Suprimento (2025)']);
    var T = { F: 'Finalístico', G: 'Gerencial', A: 'Apoio' }, M = {};
    [['F', 'Planejamento Logístico'], ['F', 'Suprimento'], ['F', 'Manutenção de Material'], ['F', 'Distribuição e Transporte'], ['F', 'Gestão de Estoques'],
     ['G', 'Gestão Estratégica'], ['G', 'Gestão de Riscos e Integridade'], ['G', 'Gestão de Projetos'],
     ['A', 'Gestão de Pessoas'], ['A', 'Tecnologia da Informação'], ['A', 'Finanças e Orçamento'], ['A', 'Infraestrutura e Patrimônio'], ['A', 'Comunicação Social']].forEach(function (m, i) {
      run("INSERT INTO macroprocessos (ciclo_id,tipo,nome,responsavel,ordem) VALUES (?,?,?,?,?)", [c, T[m[0]], m[1], 'Chefe de ' + m[1], i + 1]); M[m[1]] = id(); });

    // ===== 2. Processos (com diagrama) =====
    var P = {}, procs = [
      ['Planejamento Logístico', 'Elaborar plano de suprimento anual', 'Ativo', 'Manter', ['Levantar demandas', 'Consolidar necessidades', 'Aprovar o plano']],
      ['Planejamento Logístico', 'Programar demandas', 'Ativo', 'Revisar', ['Receber pedidos', 'Priorizar']],
      ['Suprimento', 'Realizar aquisição de material', 'Ativo', 'Alterar', ['Elaborar termo de referência', 'Cotar preços', 'Homologar a licitação', 'Emitir empenho']],
      ['Suprimento', 'Receber e conferir material', 'Ativo', '', ['Receber a carga', 'Conferir itens', 'Registrar entrada']],
      ['Manutenção de Material', 'Executar manutenção preventiva', 'Em revisão', '', ['Programar a inspeção', 'Inspecionar', 'Substituir peças']],
      ['Gestão de Riscos e Integridade', 'Gerenciar riscos corporativos', 'Ativo', 'Manter', ['Identificar riscos', 'Avaliar', 'Tratar']],
      ['Tecnologia da Informação', 'Prover suporte técnico', 'Ativo', '', ['Abrir chamado', 'Atender']],
      ['Gestão de Estoques', 'Controlar estoques', 'Ativo', '', ['Inventariar', 'Ajustar saldos']]];
    var elem = {};
    procs.forEach(function (p, k) {
      var xml = bpmn('P' + (k + 1), p[4]);
      run("INSERT INTO processos (nome,macro_id,status,validacao,descricao,responsavel,bpmn_xml,bpmn_origem) VALUES (?,?,?,?,?,?,?,?)", [p[1], M[p[0]], p[2], p[3], 'Processo de teste: ' + p[1], 'Seção de ' + p[0], xml, 'teste']);
      P[p[1]] = id(); elem[p[1]] = p[4].map(function (n, i) { return ['Task_P' + (k + 1) + '_' + (i + 1), n]; });
    });
    run("INSERT INTO processos (nome,status,descricao) VALUES ('Processo sem macroprocesso','Ativo','Caso de teste: lacuna no mapa de processos')");
    var PK = Object.keys(P);
    function flag(proc, i) { var e = elem[proc][i]; run("INSERT INTO flags (processo_id,elemento,tarefa) VALUES (?,?,?)", [P[proc], e[0], e[1]]); return id(); }

    // ===== 3. Mapa estratégico, objetivos, ações, iniciativas =====
    run("INSERT INTO me_mapas (nome,missao,visao) VALUES ('Mapa Estratégico 2026','Prover apoio logístico com excelência.','Ser referência em gestão logística até 2030.')"); var mp = id(), pers = [];
    ['Sociedade e clientes', 'Processos internos', 'Aprendizado e recursos'].forEach(function (n, i) { run("INSERT INTO me_perspectivas (mapa_id,nome,ordem) VALUES (?,?,?)", [mp, n, i + 1]); pers.push(id()); });
    run("INSERT INTO me_temas (perspectiva_id,nome,ordem) VALUES (?,?,1)", [pers[1], 'Eficiência operacional']); var tm = id();
    run("INSERT INTO me_temas (perspectiva_id,nome,ordem) VALUES (?,?,2)", [pers[1], 'Integridade e conformidade']); var tm2 = id();
    var OE = [[0, 0, 'OE-01', 'Assegurar o atendimento tempestivo e confiável às Organizações Militares'], [0, 0, 'OE-02', 'Ampliar a satisfação dos usuários com os serviços logísticos prestados'], [1, tm, 'OE-03', 'Aprimorar o ciclo de suprimento e reduzir o tempo de resposta'], [1, tm, 'OE-04', 'Elevar a disponibilidade do material de emprego militar'], [1, tm2, 'OE-05', 'Fortalecer a gestão de riscos e a integridade'], [2, 0, 'OE-06', 'Desenvolver competências das equipes e a cultura de resultados'], [2, 0, 'OE-07', 'Modernizar a infraestrutura de TI']];
    var oes = []; OE.forEach(function (o, i) { run("INSERT INTO objetivos_estrategicos (codigo,nome,descricao) VALUES (?,?,?)", [o[2], o[3], 'Objetivo de teste ' + o[2]]); var oe = id(); oes.push(oe); run("INSERT INTO me_objetivos (perspectiva_id,tema_id,oe_id,ordem) VALUES (?,?,?,?)", [pers[o[0]], o[1] || null, oe, i + 1]); });
    var ac = []; [[0, 'AE-01', 'Implantar a central de atendimento ao usuário'], [0, 'AE-02', 'Padronizar os prazos de resposta'], [2, 'AE-03', 'Reengenharia do processo de aquisição'], [2, 'AE-04', 'Implantar o sistema de gestão de estoques'], [2, 'AE-05', 'Integrar os sistemas de suprimento'], [3, 'AE-06', 'Programa de manutenção preditiva'], [4, 'AE-07', 'Estruturar o escritório de integridade'], [5, 'AE-08', 'Programa de capacitação continuada']].forEach(function (a, i) { run("INSERT INTO acoes_estrategicas (objetivo_id,codigo,nome,ordem) VALUES (?,?,?,?)", [oes[a[0]], a[1], a[2], i + 1]); ac.push(id()); });
    var ini = []; [[0, 'IE-01.1', 'Canal único de atendimento'], [0, 'IE-01.2', 'Painel de acompanhamento'], [2, 'IE-03.1', 'Novo fluxo de compras'], [3, 'IE-04.1', 'Plataforma de estoques'], [5, 'IE-06.1', 'Sensores de condição'], [6, 'IE-05.1', 'Núcleo de integridade']].forEach(function (x, k) { run("INSERT INTO iniciativas_estrategicas (acao_id,codigo,nome,ordem) VALUES (?,?,?,?)", [ac[x[0]], x[1], x[2], k + 1]); ini.push(id()); });

    // ===== 4. Projetos, tarefas, dependências, recursos, linha de base =====
    var PJ = {};
    [['PRJ-01', 'Central de Atendimento 1746', oes[0], ac[0], ini[0], 'Em andamento', '2026-02-01', '2026-12-15', 'Maj Silva'],
     ['PRJ-02', 'Painel de prazos de resposta', oes[0], ac[1], ini[1], 'Planejado', '2026-09-01', '2027-03-31', 'Cap Lima'],
     ['PRJ-03', 'Modelagem do novo fluxo de compras', oes[2], ac[2], ini[2], 'Em andamento', '2026-03-01', '2026-11-30', 'TC Souza'],
     ['PRJ-04', 'Sistema de Estoques v2', oes[2], ac[3], ini[3], 'Em andamento', '2026-01-15', '2027-01-30', 'Maj Costa'],
     ['PRJ-05', 'Barramento de integração', oes[2], ac[4], null, 'Planejado', '2027-01-10', '2027-08-30', 'Cap Alves'],
     ['PRJ-06', 'Sensores de condição de frota', oes[3], ac[5], ini[4], 'Em andamento', '2026-04-01', '2027-02-28', 'Ten Rocha'],
     ['PRJ-07', 'Projeto sem ação vinculada', oes[4], null, null, 'Planejado', '2026-11-01', '2027-04-30', 'Cap Mendes'],
     ['PRJ-08', 'Migração do e-mail institucional', oes[6], null, null, 'Concluído', '2026-01-10', '2026-08-30', 'Maj Prado'],
     ['PRJ-09', 'Piloto de drones de inventário', oes[3], null, null, 'Cancelado', '2026-03-01', '2026-06-30', 'Cap Dias']].forEach(function (p) {
      run("INSERT INTO projetos (codigo,nome,descricao,mapa_id,objetivo_id,acao_id,iniciativa_id,status,inicio,fim,responsavel,orcado,cadeia) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'Principal')", [p[0], p[1], 'Projeto de teste: ' + p[1], mp, p[2], p[3], p[4], p[5], p[6], p[7], p[8], 150000]); PJ[p[0]] = id(); });
    var REC = {}; ['Equipe de TI', 'Analista de processos', 'Fornecedor externo'].forEach(function (n, i) { run("INSERT INTO proj_recursos (projeto_id,nome,tipo,custo_hora,capacidade) VALUES (?,?,?,?,?)", [PJ['PRJ-01'], n, i === 2 ? 'Externo' : 'Humano', 80 + i * 20, 100]); REC[n] = id(); });
    // tarefas: [projeto, nome, parent(índice local) , inicio, fim, progresso, recurso]
    function tarefas(cod, lista) {
      var ids = [];
      lista.forEach(function (t, i) {
        var dur = Math.max(1, Math.round((Date.parse(t[3]) - Date.parse(t[2])) / 864e5) + 1);
        run("INSERT INTO proj_tarefas (projeto_id,parent_id,nome,inicio,fim,duracao,progresso,ordem,responsavel,recurso_id,custo) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          [PJ[cod], t[1] === null ? null : ids[t[1]], t[0], t[2], t[3], dur, t[4], i + 1, 'Resp. ' + (i + 1), t[5] ? REC[t[5]] : null, t[6] || 0]); ids.push(id()); });
      return ids;
    }
    var t1 = tarefas('PRJ-01', [['Fase 1 — Planejamento', null, '2026-02-01', '2026-03-15', 100], ['Levantar requisitos', 0, '2026-02-01', '2026-02-20', 100, 'Analista de processos', 8000], ['Definir arquitetura', 0, '2026-02-21', '2026-03-15', 100, 'Equipe de TI', 12000],
      ['Fase 2 — Construção', null, '2026-03-16', '2026-09-30', 80], ['Desenvolver o portal', 3, '2026-03-16', '2026-07-31', 90, 'Equipe de TI', 40000], ['Integrar telefonia', 3, '2026-08-01', '2026-09-30', 70, 'Fornecedor externo', 25000],
      ['Fase 3 — Implantação', null, '2026-10-01', '2026-12-15', 20], ['Treinar atendentes', 6, '2026-10-01', '2026-11-15', 40], ['Entrada em operação', 6, '2026-11-16', '2026-12-15', 0]]);
    [[1, 2], [4, 5], [5, 7], [7, 8]].forEach(function (d) { run("INSERT INTO proj_deps (pred_id,succ_id,tipo,lag) VALUES (?,?,'FS',0)", [t1[d[0]], t1[d[1]]]); });
    var t3 = tarefas('PRJ-03', [['Mapear processo atual', null, '2026-03-01', '2026-04-30', 100], ['Redesenhar o fluxo', null, '2026-05-01', '2026-08-31', 100], ['Validar com as áreas', null, '2026-09-01', '2026-10-31', 90], ['Publicar o novo fluxo', null, '2026-11-01', '2026-11-30', 40]]);
    run("INSERT INTO proj_deps (pred_id,succ_id,tipo,lag) VALUES (?,?,'FS',0)", [t3[0], t3[1]]); run("INSERT INTO proj_deps (pred_id,succ_id,tipo,lag) VALUES (?,?,'FS',2)", [t3[1], t3[2]]);
    var t4 = tarefas('PRJ-04', [['Modelar dados', null, '2026-01-15', '2026-03-31', 100], ['Construir módulos', null, '2026-04-01', '2026-10-30', 60], ['Migrar cadastros', null, '2026-11-01', '2027-01-30', 10]]);
    var t6 = tarefas('PRJ-06', [['Especificar sensores', null, '2026-04-01', '2026-05-31', 100], ['Instalar em 20 viaturas', null, '2026-06-01', '2026-12-31', 45], ['Calibrar e validar', null, '2027-01-01', '2027-02-28', 0]]);
    var t8 = tarefas('PRJ-08', [['Migrar caixas postais', null, '2026-01-10', '2026-06-30', 100], ['Desligar o servidor antigo', null, '2026-07-01', '2026-08-30', 100]]);
    var t9 = tarefas('PRJ-09', [['Avaliar fornecedores', null, '2026-03-01', '2026-04-15', 100], ['Executar piloto', null, '2026-04-16', '2026-06-30', 15]]);
    // progresso (média das tarefas-folha) + indicador automático do projeto + linha de base lançada no indicador
    function folhas(cod) { var ts = DB.all('SELECT id,parent_id,progresso FROM proj_tarefas WHERE projeto_id = ?', [PJ[cod]]); var f = ts.filter(function (t) { return !ts.some(function (x) { return x.parent_id === t.id; }); }); var s = 0; f.forEach(function (t) { s += t.progresso || 0; }); return f.length ? Math.round(s / f.length * 10) / 10 : 0; }
    ['PRJ-01', 'PRJ-03', 'PRJ-04', 'PRJ-06', 'PRJ-08', 'PRJ-09'].forEach(function (cod) { Proj.definirProgresso(PJ[cod], folhas(cod)); });
    [['PRJ-02', 5], ['PRJ-05', 0], ['PRJ-07', 10]].forEach(function (x) { Proj.definirProgresso(PJ[x[0]], x[1]); });
    ['PRJ-01', 'PRJ-03', 'PRJ-08'].forEach(function (cod, k) {
      var ts = DB.all('SELECT id,nome,inicio,fim,duracao,progresso,custo,parent_id FROM proj_tarefas WHERE projeto_id = ?', [PJ[cod]]);
      run("INSERT INTO proj_baseline (projeto_id,nome,dados_json) VALUES (?,?,?)", [PJ[cod], 'Linha de base 1', JSON.stringify({ projeto: { id: PJ[cod] }, tarefas: ts })]);
      var ind = DB.one("SELECT id FROM indicadores WHERE codigo = ?", ['PRJ-PROG-' + PJ[cod]]);
      if (ind) run("UPDATE lanc_ind SET observacao = 'Linha de base: Linha de base 1' WHERE indicador_id = ? AND mes_ano = ?", [ind.id, '2026-11']);
    });
    // histórico do indicador de progresso do PRJ-01 (meses anteriores)
    var ip = DB.one("SELECT id FROM indicadores WHERE codigo = ?", ['PRJ-PROG-' + PJ['PRJ-01']]);
    if (ip) [[8, 55], [9, 68], [10, 74]].forEach(function (x) { run("INSERT OR IGNORE INTO lanc_ind (indicador_id,mes_ano,valor,observacao) VALUES (?,?,?,'Sincronizado do módulo Projetos')", [ip.id, mes(x[0]), x[1]]); });

    // ===== 5. Capacidades, fatores determinantes, ciclo estratégico, metas =====
    var CAP = {}; [['CAP-01', 'Suprimento responsivo'], ['CAP-02', 'Manutenção confiável'], ['CAP-03', 'Gestão de riscos e integridade'], ['CAP-04', 'Prontidão tecnológica']].forEach(function (x) { run("INSERT INTO capacidades (codigo,nome,descricao) VALUES (?,?,?)", [x[0], x[1], 'Capacidade de teste']); CAP[x[0]] = id(); });
    var FD = {}; [['CAP-01', 'DIM-01', 'Processos de suprimento'], ['CAP-01', 'DIM-02', 'Pessoas e competências'], ['CAP-02', 'DIM-03', 'Disponibilidade de peças'], ['CAP-03', 'DIM-04', 'Cultura de riscos'], ['CAP-04', 'DIM-05', 'Infraestrutura de TI']].forEach(function (x) { run("INSERT INTO fatores_determinantes (capacidade_id,codigo,nome,status,priorizado) VALUES (?,?,?,'ativo',1)", [CAP[x[0]], x[1], x[2]]); FD[x[1]] = id(); });
    [[2, 'CAP-01', 0.5], [3, 'CAP-02', 0.6], [4, 'CAP-03', 0.4], [6, 'CAP-04', 0.5], [2, 'CAP-04', 0.2]].forEach(function (x) { run("INSERT OR IGNORE INTO objetivo_capacidades (objetivo_id,capacidade_id,wc,meta_requerida) VALUES (?,?,?,0.8)", [oes[x[0]], CAP[x[1]], x[2]]); });
    run("INSERT INTO ciclos_estrategicos (codigo,nome,data_inicio,data_fim,status) VALUES ('CE-01','Planejamento Estratégico 2026-2029','2026-01-01','2029-12-31','vigente')"); var ce = id();
    run("INSERT INTO ciclos_estrategicos (codigo,nome,data_inicio,data_fim,status) VALUES ('CE-00','Planejamento Estratégico 2022-2025','2022-01-01','2025-12-31','encerrado')"); var ce0 = id();
    [['P1', '2026', '2026-01-01', '2026-12-31'], ['P2', '2027', '2027-01-01', '2027-12-31']].forEach(function (x, i) { run("INSERT INTO periodos_ciclo (ciclo_id,codigo,nome,data_inicio,data_fim,ordem) VALUES (?,?,?,?,?,?)", [ce, x[0], 'Período ' + x[1], x[2], x[3], i + 1]); });
    [[2, 40, 85], [3, 55, 90], [4, 30, 80], [6, 20, 70]].forEach(function (x) { run("INSERT INTO metas_objetivo_ciclo (objetivo_id,ciclo_id,linha_base_poe,meta_poe) VALUES (?,?,?,?)", [oes[x[0]], ce, x[1], x[2]]); });
    run("INSERT INTO metas_objetivo_ciclo (objetivo_id,ciclo_id,linha_base_poe,meta_poe) VALUES (?,?,?,?)", [oes[2], ce0, 25, 60]);

    // ===== 6. Indicadores (simples, múltiplo, menor-melhor, sem lançamentos), vínculos e lançamentos =====
    function ind(cod, nome, proc, pol, un, tipo, meta, serie, cap, fator) {
      run("INSERT INTO indicadores (codigo,nome,descricao,formula,unidade,polaridade,fonte,periodicidade,status,tipo,responsavel,item_nome,om_responsavel,usuario_cadastro,processo_id) VALUES (?,?,?,?,?,?,?,?, 'ativo',?,?,?,?,?,?)",
        [cod, nome, 'Indicador de teste', 'valor apurado / valor previsto', un, pol, 'Sistema de teste', 'mensal', tipo, 'Chefe do processo', 'Item', 'Seção responsável', 'teste', proc ? P[proc] : null]); var i = id();
      run("INSERT INTO ind_ciclos (indicador_id,data_inicio,data_fim,meta) VALUES (?,?,?,?)", [i, '2026-01-01', '2026-12-31', meta]);
      if (serie) serie.forEach(function (v, k) { if (v != null) run("INSERT OR IGNORE INTO lanc_ind (indicador_id,mes_ano,valor,observacao) VALUES (?,?,?,?)", [i, mes(k + 1), v, k === 9 ? 'Último mês' : '']); });
      if (cap) { run("INSERT OR IGNORE INTO indicador_capacidades (indicador_id,capacidade_id,grh) VALUES (?,?,1)", [i, CAP[cap]]); }
      if (fator) { run("INSERT OR IGNORE INTO indicador_fatores (indicador_id,fator_id,grh) VALUES (?,?,1)", [i, FD[fator]]); run("INSERT OR IGNORE INTO metas_indicador_ciclo (indicador_id,ciclo_id,linha_base,meta,valor_atual) VALUES (?,?,?,?,?)", [i, ce, serie ? serie[0] : null, meta, serie ? serie[9] : null]); }
      return i;
    }
    ind('IND-01', 'Prazo médio de aquisição', 'Realizar aquisição de material', 'menor_melhor', 'dias', 'simples', 60, [92, 90, 88, 85, 83, 80, 78, 75, 74, 72], 'CAP-01', 'DIM-01');
    ind('IND-02', 'Acuracidade do estoque', 'Receber e conferir material', 'maior_melhor', '%', 'simples', 98, [90, 91, 92, 93, 93, 94, 95, 95, 96, 96], 'CAP-01', 'DIM-02');
    ind('IND-03', 'Disponibilidade de material', 'Executar manutenção preventiva', 'maior_melhor', '%', 'simples', 90, [70, 72, 71, 75, 74, 78, 80, 79, 83, 85], 'CAP-02', 'DIM-03');
    ind('IND-04', 'Aderência ao plano anual', 'Elaborar plano de suprimento anual', 'maior_melhor', '%', 'simples', 95, [60, 62, 65, 70, 72, 75, 80, 82, 84, 88], null, null);
    ind('IND-05', 'Chamados atendidos no prazo', 'Prover suporte técnico', 'maior_melhor', '%', 'simples', 90, [95, 96, 94, 93, 92, 90, 88, 85, 80, 78], 'CAP-04', 'DIM-05');
    ind('IND-06', 'Perdas e avarias', 'Controlar estoques', 'menor_melhor', '%', 'simples', 2, [4, 4, 3.8, 3.5, 3.2, 3, 3, 2.8, 2.5, 2.4], null, null);
    ind('IND-07', 'Indicador sem lançamentos', 'Programar demandas', 'maior_melhor', '%', 'simples', 80, null, null, null);   // caso: lacuna
    ind('IND-08', 'Indicador sem processo', null, 'maior_melhor', '%', 'simples', 50, [10, 20, 30], null, null);                  // caso: lacuna
    var im = ind('IND-09', 'Maturidade de gestão de riscos (composto)', 'Gerenciar riscos corporativos', 'maior_melhor', 'pontos', 'multiplo', 80, null, 'CAP-03', 'DIM-04');
    [['Cobertura de riscos', 0.4, [50, 52, 55, 58, 60, 62, 65, 66, 68, 70]], ['Planos de tratamento em dia', 0.35, [60, 61, 63, 65, 66, 68, 70, 72, 74, 75]], ['Controles avaliados', 0.25, [40, 42, 45, 50, 52, 55, 58, 60, 63, 65]]].forEach(function (it, o) {
      run("INSERT INTO indicador_itens (indicador_id,nome,unidade,peso,ordem) VALUES (?,?,?,?,?)", [im, it[0], '%', it[1], o + 1]); var iid = id();
      it[2].forEach(function (v, k) { run("INSERT OR IGNORE INTO lanc_itm (item_id,indicador_id,mes_ano,valor) VALUES (?,?,?,?)", [iid, im, mes(k + 1), v]); }); });
    // séries históricas (análise estatística) e lançamentos por ciclo estratégico
    var i1 = DB.one("SELECT id FROM indicadores WHERE codigo='IND-01'").id;
    [90, 88, 85, 84, 80, 79, 76, 75].forEach(function (v, k) { run("INSERT INTO series_historicas (indicador_id,data_observacao,valor,fonte,valido) VALUES (?,?,?,'histórico',1)", [i1, '2025-0' + (k + 1) + '-15', v]); });
    run("INSERT INTO lancamentos_indicador (indicador_id,ciclo_id,mes_ano,valor,meta) VALUES (?,?,?,?,?)", [i1, ce, '2026-10', 72, 60]);

    // ===== 7. Riscos (via regra de negócio, para que índices e níveis saiam corretos) =====
    function fator(n, p, i, ctl) { return { nome: n, descricao: '', probabilidade: p, impacto: i, controles: ctl || [] }; }
    function ctl(d, tipo, p, i, ef, st, planos, mon) { return { descricao: d, tipo_controle: tipo, natureza: 'Manual', eficacia: ef, status: st || 'Implementado', prob_controle: p, imp_controle: i, responsavel: 'Resp. do controle', planos: planos || [], monitoramentos: mon || [] }; }
    function risco(o) { return E.riscoSalvar(o); }
    var f1 = flag(PK[2], 0), f2 = flag(PK[2], 2), f3 = flag(PK[3], 1), f4 = flag(PK[4], 1);
    risco({ nome: 'Atraso na aquisição de material', processo_id: P[PK[2]], flag_id: f1, categoria: 'Operacional', responsavel: 'Chefe de Suprimento', status: 'Em tratamento', resposta: 'Reduzir', descricao: 'Demora na instrução dos processos de compra.', consequencias: 'Ruptura de suprimento nas OM.',
      fatores: [fator('Termos de referência incompletos', 4, 4, [ctl('Lista de verificação do TR', 'Preventivo', 2, 4, 40, 'Implementado', [{ descricao: 'Treinar elaboradores de TR', responsavel: 'Seç Pessoal', prazo: '2026-12-15', status: 'Em andamento', prioridade: 'Alta' }], [{ data: '2026-10-05', acao: 'Auditoria por amostragem', resultado: '3 de 10 TR com falhas' }])]), fator('Equipe reduzida', 3, 4, [])],
      revisoes: [{ data: '2026-06-10', parecer: 'Manter em tratamento.', autor: 'Gestor de riscos', nivel_inerente: 'Alto', indice_inerente: 14, nivel_residual: 'Médio', indice_residual: 8 }], proxima_revisao: '2026-09-01' });          // revisão vencida
    risco({ nome: 'Falha na homologação da licitação', processo_id: P[PK[2]], flag_id: f2, categoria: 'Legal/Conformidade', responsavel: 'Presidente da CPL', status: 'Identificado', resposta: 'Reduzir',
      fatores: [fator('Recursos administrativos', 3, 5, [ctl('Parecer jurídico prévio', 'Preventivo', 2, 3, 60, 'Planejado', [{ descricao: 'Contratar consultoria jurídica', responsavel: 'Assessoria', prazo: '2026-09-30', status: 'Pendente', prioridade: 'Média' }])])] });   // plano vencido
    risco({ nome: 'Falha na conferência de itens', processo_id: P[PK[3]], flag_id: f3, categoria: 'Operacional', responsavel: 'Fiel de armazém', status: 'Em tratamento', resposta: 'Reduzir', fatores: [fator('Conferência por amostragem', 3, 3, [ctl('Dupla conferência', 'Detectivo', 1, 3, 70)])] });
    risco({ nome: 'Falta de peças de reposição', processo_id: P[PK[4]], flag_id: f4, categoria: 'Material/Físico', responsavel: 'Chefe de Manutenção', status: 'Em tratamento', resposta: 'Compartilhar', fatores: [fator('Fornecedor único', 4, 5, [ctl('Contrato de reserva técnica', 'Corretivo', 3, 3, 50, 'Implementado', [], [{ data: '2026-11-02', acao: 'Verificação de estoque de segurança', resultado: 'Abaixo do mínimo' }])])] });
    risco({ nome: 'Planejamento incompatível com a demanda', processo_id: P[PK[0]], categoria: 'Estratégico', responsavel: 'Chefe de Planejamento', status: 'Aceito', resposta: 'Aceitar', resposta_just: 'Custo de tratamento superior ao benefício.', aceite_por: 'Cmt da Unidade', aceite_validade: '2026-06-30', fatores: [fator('Demanda volátil', 2, 2, [])] });   // aceite vencido
    risco({ nome: 'Vazamento de informação sigilosa', processo_id: P[PK[5]], categoria: 'Integridade', responsavel: 'Encarregado de integridade', status: 'Identificado', resposta: 'Evitar', fatores: [fator('Acesso excessivo a documentos', 3, 5, [ctl('Segregação de acessos', 'Preventivo', 1, 4, 80)])] });
    risco({ nome: 'Indisponibilidade do suporte técnico', processo_id: P[PK[6]], categoria: 'Tecnológico', responsavel: 'Chefe de TI', status: 'Identificado', resposta: 'Reduzir', fatores: [fator('Falta de redundância', 3, 4, [])] });       // sem controles
    // riscos de projeto (ambiente = nome do projeto; sem processo/atividade)
    risco({ nome: 'Atraso na integração da telefonia', projeto_id: PJ['PRJ-01'], categoria: 'Tecnológico', responsavel: 'Maj Silva', status: 'Em tratamento', resposta: 'Reduzir', fatores: [fator('Dependência do fornecedor', 4, 4, [ctl('Cláusula de penalidade contratual', 'Preventivo', 2, 3, 50)])] });
    risco({ nome: 'Rejeição do novo fluxo pelas áreas', projeto_id: PJ['PRJ-03'], categoria: 'Estratégico', responsavel: 'TC Souza', status: 'Identificado', resposta: 'Reduzir', fatores: [fator('Resistência a mudanças', 3, 4, [])] });
    risco({ nome: 'Estouro do orçamento do sistema de estoques', projeto_id: PJ['PRJ-04'], categoria: 'Financeiro', responsavel: 'Maj Costa', status: 'Em tratamento', resposta: 'Reduzir', fatores: [fator('Escopo crescente', 4, 3, [ctl('Comitê de mudanças', 'Preventivo', 2, 2, 60)])] });
    risco({ nome: 'Reabertura de pendências após a migração de e-mail', projeto_id: PJ['PRJ-08'], categoria: 'Tecnológico', responsavel: 'Maj Prado', status: 'Identificado', resposta: 'Reduzir', fatores: [fator('Contas esquecidas', 2, 3, [])] });   // projeto CONCLUÍDO com risco aberto → alerta
    risco({ nome: 'Perda do investimento do piloto de drones', projeto_id: PJ['PRJ-09'], categoria: 'Financeiro', responsavel: 'Cap Dias', status: 'Identificado', resposta: 'Aceitar', fatores: [fator('Cancelamento antecipado', 3, 2, [])] });          // projeto CANCELADO com risco aberto → alerta
    // risco sem processo nem projeto (lacuna do Painel) e risco duplicado a partir de outro
    risco({ nome: 'Risco reputacional da unidade', ambiente: 'Unidade (corporativo)', categoria: 'Institucional', responsavel: 'Cmt da Unidade', status: 'Identificado', resposta: 'Reduzir', fatores: [fator('Exposição na mídia', 2, 5, [])] });
    var pri = DB.one("SELECT id FROM riscos WHERE nome = 'Atraso na aquisição de material'").id; E.riscoDuplicar(pri);

    // ===== 8. Planos 5W2H e planos de intervenção =====
    run("INSERT INTO va_planos (objetivo_id,ciclo_id,titulo,o_que,por_que,onde,quando_inicio,quando_fim,quem,como,quanto,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", [oes[2], ce, 'Reduzir o prazo de aquisição', 'Padronizar modelos de TR', 'Prazo médio acima da meta', 'Seção de Aquisições', '2026-03-01', '2026-12-31', 'Chefe de Suprimento', 'Oficinas e checklist', 'R$ 20.000', 'Em andamento']);
    run("INSERT INTO va_planos (objetivo_id,ciclo_id,titulo,o_que,por_que,quando_inicio,quando_fim,quem,status) VALUES (?,?,?,?,?,?,?,?,?)", [oes[3], ce, 'Estoque de segurança de peças críticas', 'Definir níveis mínimos', 'Disponibilidade abaixo da meta', '2026-05-01', '2026-10-30', 'Chefe de Manutenção', 'Atrasado']);
    run("INSERT INTO planos_intervencao (ciclo_id,tipo_alvo,alvo_id,titulo,descricao,responsavel,prazo,status,prioridade,problema,causa,risco,recursos,resultado_esperado,evidencia,criterio_reavaliacao) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      [ce, 'indicador', i1, 'Recuperar o prazo médio de aquisição', 'Plano para atingir a meta de 60 dias', 'Chefe de Suprimento', '2026-12-20', 'aberto', 'alta', 'Prazo acima da meta', 'TR incompletos', 'Ruptura de suprimento', 'Equipe de apoio', 'Prazo ≤ 60 dias', 'Série mensal do IND-01', 'Reavaliar em 90 dias']);
    run("INSERT INTO ahp_registros (escopo,ref_id,ciclo_id,rotulos_json,pesos_json,rc,consistente) VALUES ('objetivo',?,?,?,?,?,1)", [oes[2], ce, JSON.stringify(['CAP-01', 'CAP-04']), JSON.stringify([0.7, 0.3]), 0.02]);

    // ===== 9. Validações da cadeia, histórico, metas por ciclo, lançamentos de item, usuário =====
    run("INSERT INTO cva_validacoes (ciclo_id,alvo,ref_id,nome,decisao,obs) VALUES (?,?,?,?,?,?)", [c, 'processo', P[PK[2]], PK[2], 'Alterar', 'Revisar etapas de homologação']);
    run("INSERT INTO cva_validacoes (ciclo_id,alvo,ref_id,nome,decisao,obs) VALUES (?,?,?,?,?,?)", [c, 'processo', P[PK[0]], PK[0], 'Manter', '']);
    run("INSERT INTO cva_documentos (ciclo_id,titulo,html,obs) VALUES (?,?,?,?)", [c, 'Relatório da cadeia de valor 2026', '<h1>Relatório de teste</h1><p>Documento gerado para o pacote de testes.</p>', 'teste']);
    run("INSERT INTO historico (tipo,ciclo_id,descricao) VALUES ('ciclo',?,'Ciclo 2026 aberto (teste)')", [ce]);
    run("INSERT INTO ciclos_meta_indicador (indicador_id,ciclo_id,codigo,data_inicio,data_fim,meta,observacao) VALUES (?,?,'P1','2026-01-01','2026-12-31',60,'Meta do período 2026')", [i1, ce]);
    var it1 = DB.one('SELECT id FROM indicador_itens WHERE indicador_id = ? ORDER BY ordem', [im]).id;
    run("INSERT INTO lancamentos_item (item_id,indicador_id,ciclo_id,mes_ano,valor) VALUES (?,?,?,'2026-10',70)", [it1, im, ce]);
    run("UPDATE organizacoes SET codigo = 'UNID-TESTE', nome = 'Unidade de Teste (dados fictícios)' WHERE ativa = 1");
    run("INSERT OR IGNORE INTO usuarios (nome,login,senha) VALUES ('Usuário de Teste','teste','teste')");
  });
})();
