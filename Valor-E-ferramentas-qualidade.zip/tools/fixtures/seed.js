// executado dentro da página (window): popula o banco com dados de teste
(function(){
  var run=function(s,p){DB.run(s,p||[]);}, id=function(){return DB.lastId();};
  DB.tx(function(){
    run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES ('Ciclo 2026','Prover serviços logísticos confiáveis e tempestivos à Força, com eficiência no uso dos recursos públicos.','Valor entregue à sociedade e aos usuários finais','2026-01-01','2026-12-31','Vigente','Principal')"); var c=id();
    var T={F:'Finalístico',G:'Gerencial',A:'Apoio'}, M={};
    [['F','Planejamento Logístico'],['F','Suprimento'],['F','Manutenção de Material'],['F','Distribuição e Transporte'],['F','Gestão de Estoques'],
     ['G','Gestão Estratégica'],['G','Gestão de Riscos e Integridade'],['G','Gestão de Projetos'],
     ['A','Gestão de Pessoas'],['A','Tecnologia da Informação'],['A','Finanças e Orçamento'],['A','Infraestrutura e Patrimônio'],['A','Comunicação Social']].forEach(function(m,i){
      run("INSERT INTO macroprocessos (ciclo_id,tipo,nome,ordem) VALUES (?,?,?,?)",[c,T[m[0]],m[1],i+1]); M[m[1]]=id(); });
    var P={}, procs=[['Planejamento Logístico','Elaborar plano de suprimento anual','Ativo','Manter'],['Planejamento Logístico','Programar demandas','Ativo','Revisar'],['Suprimento','Realizar aquisição de material','Ativo','Alterar'],['Suprimento','Receber e conferir material','Ativo',''],['Manutenção de Material','Executar manutenção preventiva','Em revisão',''],['Gestão de Riscos e Integridade','Gerenciar riscos corporativos','Ativo','Manter'],['Tecnologia da Informação','Prover suporte técnico','Ativo','']];
    procs.forEach(function(p){ run("INSERT INTO processos (nome,macro_id,status,validacao) VALUES (?,?,?,?)",[p[1],M[p[0]],p[2],p[3]]); P[p[1]]=id(); });
    run("INSERT INTO processos (nome,status) VALUES ('Processo sem macroprocesso','Ativo')");
    var pk=Object.keys(P);
    [['RISCO-001','Atraso na aquisição de material',P[pk[2]],'Alto','Extremo'],['RISCO-002','Falha na conferência de itens',P[pk[3]],'Médio','Baixo'],['RISCO-003','Falta de peças de reposição',P[pk[4]],'Alto','Alto'],['RISCO-004','Planejamento incompatível com a demanda',P[pk[0]],'Baixo','Muito Baixo']].forEach(function(r){
      run("INSERT INTO riscos (ambiente,nome,processo_id,nivel_medio,nivel_res,codigo) VALUES (?,?,?,?,?,?)",['Processo',r[1],r[2],r[3],r[4],r[0]]);});
    [['IND-01','Prazo médio de aquisição',P[pk[2]]],['IND-02','Acuracidade do estoque',P[pk[3]]],['IND-03','Disponibilidade de material',P[pk[4]]],['IND-04','Aderência ao plano anual',P[pk[0]]]].forEach(function(r){ run("INSERT INTO indicadores (codigo,nome,processo_id) VALUES (?,?,?)",[r[0],r[1],r[2]]); });
    // mapa
    run("INSERT INTO me_mapas (nome,missao,visao) VALUES ('Mapa Estratégico 2026','Prover apoio logístico com excelência.','Ser referência em gestão logística até 2030.')"); var mp=id(), pers=[];
    ['Sociedade e clientes','Processos internos','Aprendizado e recursos'].forEach(function(n,i){ run("INSERT INTO me_perspectivas (mapa_id,nome,ordem) VALUES (?,?,?)",[mp,n,i+1]); pers.push(id()); });
    run("INSERT INTO me_temas (perspectiva_id,nome,ordem) VALUES (?,?,1)",[pers[1],'Eficiência operacional']); var tm=id();
    var OE=[[0,0,'OE-01','Assegurar o atendimento tempestivo e confiável às Organizações Militares'],[0,0,'OE-02','Ampliar a satisfação dos usuários com os serviços logísticos prestados'],[1,tm,'OE-03','Aprimorar o ciclo de suprimento e reduzir o tempo de resposta'],[1,tm,'OE-04','Elevar a disponibilidade do material de emprego militar'],[1,0,'OE-05','Fortalecer a gestão de riscos e a integridade'],[2,0,'OE-06','Desenvolver competências das equipes e a cultura de resultados'],[2,0,'OE-07','Modernizar a infraestrutura de TI']];
    var oes=[]; OE.forEach(function(o,i){ run("INSERT INTO objetivos_estrategicos (codigo,nome) VALUES (?,?)",[o[2],o[3]]); var oe=id(); oes.push(oe); run("INSERT INTO me_objetivos (perspectiva_id,tema_id,oe_id,ordem) VALUES (?,?,?,?)",[pers[o[0]],o[1]||null,oe,i+1]); });
    var ac=[]; [[0,'AE-01','Implantar a central de atendimento ao usuário'],[0,'AE-02','Padronizar os prazos de resposta'],[2,'AE-03','Reengenharia do processo de aquisição'],[2,'AE-04','Implantar o sistema de gestão de estoques'],[2,'AE-05','Integrar os sistemas de suprimento'],[3,'AE-06','Programa de manutenção preditiva'],[4,'AE-07','Estruturar o escritório de integridade']].forEach(function(a,i){ run("INSERT INTO acoes_estrategicas (objetivo_id,codigo,nome,ordem) VALUES (?,?,?,?)",[oes[a[0]],a[1],a[2],i+1]); ac.push(id()); });
    [['PRJ-01','Central de Atendimento 1746',oes[0],ac[0],'Em andamento'],['PRJ-02','Painel de prazos de resposta',oes[0],ac[1],'Planejado'],['PRJ-03','Modelagem do novo fluxo de compras',oes[2],ac[2],'Em andamento'],['PRJ-04','Sistema de Estoques v2',oes[2],ac[3],'Em andamento'],['PRJ-05','Barramento de integração',oes[2],ac[4],'Planejado'],['PRJ-06','Sensores de condição de frota',oes[3],ac[5],'Em andamento'],['PRJ-07','Projeto sem ação vinculada',oes[4],null,'Planejado']].forEach(function(p){ run("INSERT INTO projetos (codigo,nome,mapa_id,objetivo_id,acao_id,status) VALUES (?,?,?,?,?,?)",[p[0],p[1],mp,p[2],p[3],p[4]]); });
    var pj=DB.all('SELECT id,codigo FROM projetos ORDER BY id'), ini=[];
    [[0,'IE-01.1','Canal único de atendimento'],[0,'IE-01.2','Painel de acompanhamento'],[2,'IE-03.1','Novo fluxo de compras'],[3,'IE-04.1','Plataforma de estoques']].forEach(function(x,k){ run("INSERT INTO iniciativas_estrategicas (acao_id,codigo,nome,ordem) VALUES (?,?,?,?)",[ac[x[0]],x[1],x[2],k+1]); ini.push(id()); });
    var vinc=[[0,0],[1,1],[2,2],[3,3]]; vinc.forEach(function(v){ run("UPDATE projetos SET iniciativa_id=? WHERE id=?",[ini[v[1]],pj[v[0]].id]); });
    run("UPDATE projetos SET iniciativa_id=? WHERE id=?",[ini[2],pj[4].id]);
    [95,40,92,60,80,70,10].forEach(function(p,k){ Proj.definirProgresso(pj[k].id,p); });
    // valor estratégico
    run("INSERT INTO capacidades (codigo,nome) VALUES ('CAP-01','Suprimento responsivo')"); var cp=id(); run("INSERT INTO objetivo_capacidades (objetivo_id,capacidade_id) VALUES (?,?)",[oes[2],cp]);

    run("INSERT INTO ciclos_estrategicos (codigo,nome,data_inicio,data_fim,status) VALUES ('CE-01','Planejamento Estratégico 2026-2029','2026-01-01','2029-12-31','vigente')"); var ce=id();
    run("INSERT INTO metas_objetivo_ciclo (objetivo_id,ciclo_id,linha_base_poe,meta_poe) VALUES (?,?,?,?)",[oes[2],ce,40,85]);
    run("INSERT INTO fatores_determinantes (capacidade_id,codigo,nome,status) VALUES (?,?,?,'ativo')",[cp,'DIM-01','Processos']); var fd=id();
    var iid=DB.all("SELECT id FROM indicadores WHERE codigo='IND-01'")[0].id;
    run("INSERT INTO indicador_fatores (indicador_id,fator_id,grh) VALUES (?,?,1)",[iid,fd]);
    run("INSERT INTO ind_ciclos (indicador_id,data_inicio,data_fim,meta) VALUES (?,?,?,?)",[iid,'2026-01-01','2026-12-31',100]);
    run("INSERT INTO lanc_ind (indicador_id,mes_ano,valor) VALUES (?,?,?)",[iid,'2026-10',80]);
  });
})();
