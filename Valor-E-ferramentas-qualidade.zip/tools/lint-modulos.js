#!/usr/bin/env node
// Verificador de módulos do Valor-E: acusa nomes repetidos que se sobrescrevem em silêncio.
//  1) funções declaradas duas vezes no mesmo escopo (a última vence, por içamento);
//  2) o mesmo nome global/exportado (window.X, Modulo.prop) definido em mais de um arquivo.
// Uso: node tools/lint-modulos.js [pasta-do-app]   (sai com código 1 se houver conflito)
const ts = require(process.env.TS_PATH || 'typescript'), fs = require('fs'), path = require('path');
const app = path.resolve(process.argv[2] || path.join(__dirname, '..', 'app'));
const jsDir = path.join(app, 'assets', 'js');
const html = fs.readFileSync(path.join(app, 'index.html'), 'utf8');
const ordem = [...html.matchAll(/src="assets\/js\/([^"]+\.js)"/g)].map(m => m[1])
  .filter(f => !/\.min\.js$|^(sqljs|chart|quill|bpmn|pdfjs|md5|jspdf|purify)/.test(f) && fs.existsSync(path.join(jsDir, f)));
const IGN = fs.existsSync(path.join(__dirname, 'lint-ignorar.json')) ? JSON.parse(fs.readFileSync(path.join(__dirname, 'lint-ignorar.json'), 'utf8')) : {};
const IGNORAR_DUP = new Set(Object.keys(IGN));   // nomes compartilhados de propósito, com o motivo registrado
let erros = 0; const def = {};   // nome exportado -> [{arq, linha}]
const err = m => { erros++; console.log('✗ ' + m); };
function nomeProp(n) { return ts.isIdentifier(n) ? n.text : ts.isStringLiteral(n) ? n.text : null; }
function txt(n, sf) { return n.getText(sf); }
for (const f of ordem) {
  const src = fs.readFileSync(path.join(jsDir, f), 'utf8');
  const sf = ts.createSourceFile(f, src, ts.ScriptTarget.ES2019, true, ts.ScriptKind.JS);
  const lin = n => sf.getLineAndCharacterOfPosition(n.getStart(sf)).line + 1;
  // 1) funções duplicadas por escopo
  (function escopo(corpo, nomeEsc) {
    const vistos = {};
    (function varre(n) {
      if (ts.isFunctionDeclaration(n) && n.name) {
        const k = n.name.text;
        if (vistos[k]) err(`${f}:${lin(n)} função "${k}" já declarada na linha ${vistos[k]} do mesmo escopo (${nomeEsc}) — a última sobrescreve a primeira`);
        else vistos[k] = lin(n);
        escopo(n.body, k); return;
      }
      if (ts.isFunctionExpression(n) || ts.isArrowFunction(n)) { if (n.body && ts.isBlock(n.body)) escopo(n.body, '(anônima:' + lin(n) + ')'); return; }
      ts.forEachChild(n, varre);
    })(corpo);
  })(sf, 'topo de ' + f);
  // 2) exportações: window.X = / w.X = / Modulo.prop = / Modulo = { ... } / function global no topo
  const registra = (nome, n) => { (def[nome] = def[nome] || []).push({ arq: f, linha: lin(n) }); };
  (function varre(n) {
    if (ts.isBinaryExpression(n) && n.operatorToken.kind === ts.SyntaxKind.EqualsToken && ts.isPropertyAccessExpression(n.left)) {
      const o = txt(n.left.expression, sf), p = n.left.name.text;
      const dir = txt(n.right, sf);
      if ((o === 'window' || o === 'w' || o === 'global') && new RegExp('^(window\\.|w\\.)?' + p + '\\s*\\|\\|').test(dir)) { /* criação do namespace compartilhado: X = X || {} */ }
      else if (o === 'window' || o === 'w' || o === 'global') registra(p, n);
      else if (/^[A-Z][A-Za-z0-9_]*$/.test(o) && !/^(E|O|M|A|P|S|D|T|N|R|X|I|C|F|B|L|H|U|V|W)$/.test(o)) registra(o + '.' + p, n);
    }
    ts.forEachChild(n, varre);
  })(sf);
  sf.statements.forEach(s => { if (ts.isFunctionDeclaration(s) && s.name) registra(s.name.text, s); });
}
for (const [nome, lista] of Object.entries(def)) {
  const arqs = [...new Set(lista.map(x => x.arq))];
  if (arqs.length > 1 && !IGNORAR_DUP.has(nome))
    err(`"${nome}" definido em ${lista.map(x => x.arq + ':' + x.linha).join(', ')} — o último arquivo carregado sobrescreve os demais`);
}
console.log(erros ? `\n${erros} conflito(s) de nomes.` : '✓ Nenhum conflito de nomes entre módulos.');
process.exit(erros ? 1 : 0);
