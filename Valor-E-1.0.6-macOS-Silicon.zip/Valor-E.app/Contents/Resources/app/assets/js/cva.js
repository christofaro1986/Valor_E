/* cva.js — Cadeia de Valor Agregado (Porter): ciclos de validação, macroprocessos (Finalísticos, Gerenciais, Apoio), missão, resultado e imagem. */
(function (w) {
  'use strict';
  var h = E.esc, TIPOS = ['Finalístico', 'Gerencial', 'Apoio'], PLURAL = { 'Finalístico': 'Finalísticos', 'Gerencial': 'Gerenciais', 'Apoio': 'De apoio' };
  var COR = { 'Finalístico': ['#1f6f54', '#ffffff'], 'Gerencial': ['#2f5d8a', '#ffffff'], 'Apoio': ['#8a6d1f', '#ffffff'] };

  DB.extras.push(function () {
    try { if (!DB.all('PRAGMA table_info(cva_ciclos)').some(function (c) { return c.name === 'cadeia'; })) DB.db.run("ALTER TABLE cva_ciclos ADD COLUMN cadeia TEXT DEFAULT 'Principal'"); DB.db.run("UPDATE cva_ciclos SET cadeia = 'Principal' WHERE cadeia IS NULL OR cadeia = ''"); } catch (e) {}
    DB.db.run("CREATE TABLE IF NOT EXISTS cva_validacoes (id INTEGER PRIMARY KEY AUTOINCREMENT, ciclo_id INTEGER NOT NULL, alvo TEXT NOT NULL, ref_id INTEGER NOT NULL, nome TEXT DEFAULT '', decisao TEXT NOT NULL, obs TEXT DEFAULT '', em TEXT DEFAULT CURRENT_TIMESTAMP)");
  });

  // ---------- dados ----------
  function hojeIso() { return E.hoje(); }
  function ciclos(cad) { return DB.all('SELECT * FROM cva_ciclos' + (cad ? ' WHERE cadeia = ?' : '') + ' ORDER BY (status = \'Vigente\') DESC, fim DESC, id DESC', cad ? [cad] : []); }
  function vigente(cad) { return DB.one("SELECT * FROM cva_ciclos WHERE status = 'Vigente'" + (cad ? ' AND cadeia = ?' : '') + ' ORDER BY id DESC', cad ? [cad] : []); }
  function cadeias() { return DB.all("SELECT cadeia, COUNT(*) AS n FROM cva_ciclos GROUP BY cadeia ORDER BY MIN(id)").map(function (x) { return x.cadeia || 'Principal'; }); }
  function macros(cid) { return DB.all('SELECT * FROM macroprocessos WHERE ciclo_id = ? ORDER BY ordem, id', [cid]); }
  function nProc(mid) { return DB.one('SELECT COUNT(*) AS n FROM processos WHERE macro_id = ?', [mid]).n; }
  function dias(fim) { if (!fim) return null; var a = new Date(hojeIso() + 'T00:00:00'), b = new Date(fim + 'T00:00:00'); return Math.round((b - a) / 86400000); }
  function validade(c) {
    if (!c) return { cls: 'secondary', txt: 'Sem ciclo', n: null };
    if (c.status !== 'Vigente') return { cls: 'secondary', txt: 'Encerrado em ' + (c.fim ? E.dataBr(c.fim) : '—'), n: null };
    var n = dias(c.fim);
    if (n === null) return { cls: 'success', txt: 'Vigente (sem data final)', n: null };
    if (n < 0) return { cls: 'danger', txt: 'Ciclo vencido há ' + (-n) + ' dia(s) — revisão necessária', n: n };
    if (n <= 60) return { cls: 'warning', txt: 'Vigente até ' + E.dataBr(c.fim) + ' — faltam ' + n + ' dia(s)', n: n };
    return { cls: 'success', txt: 'Vigente até ' + E.dataBr(c.fim) + ' — faltam ' + n + ' dias', n: n };
  }
  function cicloAtual(q) { var id = parseInt(q.ciclo, 10), cad = q.cadeia || ''; return (id && DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [id])) || (cad && (vigente(cad) || DB.one('SELECT * FROM cva_ciclos WHERE cadeia = ? ORDER BY id DESC', [cad]))) || vigente() || DB.one('SELECT * FROM cva_ciclos ORDER BY id DESC'); }

  // ---------- imagem de Porter ----------
  function quebra(t, max) {
    var p = String(t).split(/\s+/), l = [], c = '';
    p.forEach(function (x) { if ((c + ' ' + x).trim().length > max && c) { l.push(c); c = x; } else c = (c + ' ' + x).trim(); });
    if (c) l.push(c); return l.slice(0, 4);
  }
  /** Ícone clicável (somente no modo de edição; fica fora da imagem exportada). */
  function ic(x, y, acao, dica, tipo) {
    return '<g class="ic" onclick="' + acao + '" transform="translate(' + x + ',' + y + ')"><title>' + h(dica) + '</title><circle r="10" fill="#fff" stroke="#0a6fc2" stroke-width="1.5"/>' +
      (tipo === '+' ? '<path d="M-4 0H4M0-4V4" stroke="#0a6fc2" stroke-width="2" stroke-linecap="round"/>' : '<path d="M-4.5 4.5L-4 1.5L2.5-5L5-2.5L-1.5 4Z" fill="none" stroke="#0a6fc2" stroke-width="1.4" stroke-linejoin="round"/>') + '</g>';
  }
  function txt(x, y, linhas, cor, size, anc) {
    var o = '<text x="' + x + '" y="' + (y - (linhas.length - 1) * size * 0.6) + '" text-anchor="' + (anc || 'middle') + '" font-family="Arial,Helvetica,sans-serif" font-size="' + size + '" fill="' + cor + '" font-weight="600">';
    linhas.forEach(function (l, i) { o += '<tspan x="' + x + '" dy="' + (i ? size * 1.2 : 0) + '">' + h(l) + '</tspan>'; });
    return o + '</text>';
  }
  var PER = 6; // máximo de macroprocessos por linha; acima disso a faixa ganha novas linhas
  function linhasDe(n) { return Math.max(1, Math.ceil(n / PER)); }
  function repartir(lista) { var nl = linhasDe(lista.length), por = Math.ceil(lista.length / nl) || 1, r = []; for (var i = 0; i < lista.length; i += por) r.push(lista.slice(i, i + por)); return r; }
  function altFaixa(n) { return 36 + linhasDe(n) * 74; }
  function faixa(lista, x0, y0, W, tipo, rotulo, ed, cid) {
    var H = altFaixa(lista.length);
    var o = '<rect x="' + x0 + '" y="' + y0 + '" width="' + W + '" height="' + H + '" rx="6" fill="' + COR[tipo][0] + '" opacity=".12"/>' + txt(x0 + 12, y0 + 18, [rotulo.toUpperCase()], COR[tipo][0], 11, 'start');
    if (ed) o += ic(x0 + W - 16, y0 + 14, 'Cva.macro(' + cid + ',\'' + tipo + '\')', 'Adicionar macroprocesso (' + tipo.toLowerCase() + ')', '+');
    if (!lista.length) return { s: o + txt(x0 + W / 2, y0 + H / 2 + 8, [ed ? '(clique em + para adicionar)' : '(sem macroprocessos)'], '#888', 12), h: H };
    var gap = 8;
    repartir(lista).forEach(function (linha, r) {
      var bw = (W - 24 - gap * (PER - 1)) / PER; if (linha.length > PER) bw = (W - 24 - gap * (linha.length - 1)) / linha.length;
      var bw2 = (W - 24 - gap * (linha.length - 1)) / linha.length; bw = Math.min(bw2, 260);
      var tot = linha.length * bw + (linha.length - 1) * gap, xs = x0 + (W - tot) / 2;
      linha.forEach(function (m, i) {
        var x = xs + i * (bw + gap), y = y0 + 28 + r * 74, mw = Math.max(8, Math.floor((bw - 28) / 7));
        o += '<rect x="' + x + '" y="' + y + '" width="' + bw + '" height="66" rx="5" fill="' + COR[tipo][0] + '"/>' + txt(x + bw / 2, y + 37, quebra(m.nome, mw).slice(0, 4), COR[tipo][1], 12);
        if (ed) o += ic(x + bw - 14, y + 14, 'Cva.macro(' + cid + ',\'' + tipo + '\',' + m.id + ')', 'Editar ou excluir: ' + m.nome);
      });
    });
    return { s: o, h: H };
  }
  function svgPorter(c, ed) {
    var ms = macros(c.id), g = {}; TIPOS.forEach(function (t) { g[t] = ms.filter(function (m) { return m.tipo === t; }); });
    var W = 1300, L = 30, AW = 1040, nF = g['Finalístico'].length, rowsF = linhasDe(nF), hgt = rowsF === 1 ? 162 : 100;
    var yG = 122, fG = faixa(g['Gerencial'], L, yG, AW, 'Gerencial', PLURAL['Gerencial'] + ' — processos gerenciais', ed, c.id);
    var yA = yG + fG.h + 12, fA = faixa(g['Apoio'], L, yA, AW, 'Apoio', 'Processos de apoio', ed, c.id);
    var y0 = yA + fA.h + 12, hh = 34 + rowsF * (hgt + 8), H = y0 + hh + 36;
    var o = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '"><rect width="' + W + '" height="' + H + '" fill="#ffffff"/>';
    o += '<text x="' + (W / 2) + '" y="30" text-anchor="middle" font-family="Arial" font-size="20" font-weight="700" fill="#0b2447">Cadeia de Valor Agregado</text>';
    o += '<rect x="' + L + '" y="46" width="' + (W - 2 * L) + '" height="62" rx="8" fill="#0b2447"/>' + txt(L + 14, 66, ['MISSÃO'], '#f9d56e', 11, 'start') + txt(W / 2, 90, quebra(c.missao || '(missão não informada)', 170).slice(0, 2), '#ffffff', 13);
    if (ed) o += ic(W - L - 18, 64, 'Cva.texto(' + c.id + ',\'missao\')', 'Editar a missão');
    o += fG.s + fA.s;
    // finalísticos: chevrons
    o += '<rect x="' + L + '" y="' + y0 + '" width="' + AW + '" height="' + hh + '" rx="6" fill="' + COR['Finalístico'][0] + '" opacity=".12"/>' + txt(L + 12, y0 + 18, ['PROCESSOS FINALÍSTICOS'], COR['Finalístico'][0], 11, 'start');
    if (ed) o += ic(L + AW - 16, y0 + 14, 'Cva.macro(' + c.id + ',\'Finalístico\')', 'Adicionar macroprocesso finalístico', '+');
    if (!nF) o += txt(L + AW / 2, y0 + hh / 2 + 8, [ed ? '(clique em + para adicionar)' : '(sem macroprocessos)'], '#888', 12);
    else {
      var pt = 38;
      repartir(g['Finalístico']).forEach(function (linha, r) {
        var cw = (AW - 24) / linha.length, yy = y0 + 30 + r * (hgt + 8);
        linha.forEach(function (m, i) {
          var x = L + 12 + i * cw;
          var pts = [x, yy, x + cw - pt, yy, x + cw, yy + hgt / 2, x + cw - pt, yy + hgt, x, yy + hgt, x + pt, yy + hgt / 2].join(' ');
          o += '<polygon points="' + pts + '" fill="' + COR['Finalístico'][0] + '" stroke="#fff" stroke-width="3"/>' + txt(x + cw / 2 + 4, yy + hgt / 2 + 4, quebra(m.nome, Math.max(8, Math.floor((cw - pt * 1.4) / 7))).slice(0, 5), '#fff', 12);
          if (ed) o += ic(x + cw - pt - 14, yy + 16, 'Cva.macro(' + c.id + ',\'Finalístico\',' + m.id + ')', 'Editar ou excluir: ' + m.nome);
        });
      });
    }
    // seta de resultado (acompanha a altura total)
    var rx = L + AW + 14, rw = W - rx - L, yb = y0 + hh, midY = (yG + yb) / 2;
    o += '<polygon points="' + rx + ',' + yG + ' ' + (rx + rw - 40) + ',' + yG + ' ' + (rx + rw) + ',' + midY + ' ' + (rx + rw - 40) + ',' + yb + ' ' + rx + ',' + yb + '" fill="#22b8d8"/>';
    if (ed) o += ic(rx + 24, yG + 24, 'Cva.texto(' + c.id + ',\'resultado\')', 'Editar o resultado');
    o += txt(rx + (rw - 20) / 2, midY, ['RESULTADO'].concat(quebra(c.resultado || '(resultado não informado)', 18)), '#0b2447', 12);
    o += '<text x="' + (W - L) + '" y="' + (H - 12) + '" text-anchor="end" font-family="Arial" font-size="10" fill="#777">' + h((c.nome || '') + (c.inicio ? ' · ' + E.dataBr(c.inicio) + ' a ' + (c.fim ? E.dataBr(c.fim) : '…') : '')) + '</text>';
    return o + '</svg>';
  }
  function baixarPng(svg, nome) {
    var img = new Image(), u = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    var vb = (svg.match(/viewBox="0 0 (\d+(?:\.\d+)?) (\d+(?:\.\d+)?)"/) || [0, 1100, 640]);
    img.onload = function () { var c = document.createElement('canvas'); c.width = 2200; c.height = Math.round(2200 * vb[2] / vb[1]); var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); c.toBlob(function (b) { Common.baixarBlob ? Common.baixarBlob(nome, b) : Mapris.baixar(nome, b, 'image/png'); }); };
    img.src = u;
  }

  w.SvgUtil = { quebra: quebra, png: baixarPng };

  // ---------- modal simples ----------
  function mdl(titulo, corpo, ok, rotulo) {
    var d = document.createElement('div'); d.className = 'modal fade'; d.tabIndex = -1;
    d.innerHTML = '<div class="modal-dialog modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h6 class="modal-title">' + titulo + '</h6><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">' + corpo + '<div class="text-danger small mt-2" data-erro></div></div><div class="modal-footer"><button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-success btn-sm" data-ok>' + (rotulo || 'Salvar') + '</button></div></div></div>';
    document.body.appendChild(d); var M = new bootstrap.Modal(d);
    d.querySelector('[data-ok]').onclick = function () { try { if (ok(d) !== false) { M.hide(); } } catch (e) { d.querySelector('[data-erro]').textContent = e.message; } };
    d.addEventListener('hidden.bs.modal', function () { M.dispose(); d.remove(); }); M.show(); return d;
  }
  w.Mdl = mdl;
  function v(d, s) { return d.querySelector(s).value; }

  // ---------- tela ----------
  var Cva = w.Cva = {
    macrosDoCicloVigente: function () { var c = vigente(); return c ? macros(c.id) : []; },
    cadeias: cadeias,
    macroPorId: function (id) { return DB.one('SELECT * FROM macroprocessos WHERE id = ?', [id]); },
    contarProcessos: nProc,
    resumo: function () { var c = vigente(); return c ? { ciclo: c.nome, validade: validade(c).txt, macros: macros(c.id).length } : null; },
    cicloNovo: function (cad) {
      cad = cad || 'Principal'; var c = vigente(cad);
      mdl('Novo ciclo de validação', '<div class="mb-2"><label class="form-label">Nome</label><input class="form-control" id="cn" value="' + h('Ciclo ' + new Date().getFullYear()) + '"></div><div class="row g-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ci" value="' + hojeIso() + '"></div><div class="col"><label class="form-label">Término</label><input type="date" class="form-control" id="cf"></div></div>' +
        (c ? '<div class="form-check mt-3"><input class="form-check-input" type="checkbox" id="cc" checked><label class="form-check-label" for="cc">Copiar missão, resultado e macroprocessos do ciclo atual ("' + h(c.nome) + '"), que será encerrado e arquivado</label></div>' : ''),
        function (d) {
          if (!v(d, '#cn').trim()) throw new Error('Informe o nome do ciclo.');
          if (v(d, '#cf') && v(d, '#cf') < v(d, '#ci')) throw new Error('O término deve ser posterior ao início.');
          var id = DB.tx(function () {
            var cp = c && d.querySelector('#cc') && d.querySelector('#cc').checked;
            if (c) DB.run("UPDATE cva_ciclos SET status='Encerrado' WHERE status='Vigente' AND cadeia = ?", [cad]);
            DB.run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES (?,?,?,?,?, 'Vigente', ?)", [v(d, '#cn').trim(), cp ? c.missao : '', cp ? c.resultado : '', v(d, '#ci') || null, v(d, '#cf') || null, cad]);
            var nid = DB.lastId();
            if (cp) macros(c.id).forEach(function (m) {
              DB.run('INSERT INTO macroprocessos (ciclo_id,tipo,nome,descricao,responsavel,ordem) VALUES (?,?,?,?,?,?)', [nid, m.tipo, m.nome, m.descricao, m.responsavel, m.ordem]);
              DB.run('UPDATE processos SET macro_id = ? WHERE macro_id = ?', [DB.lastId(), m.id]);   // os processos acompanham o macroprocesso copiado
            });
            return nid;
          });
          Nav.ir('#/cva?ciclo=' + id);
        }, 'Criar ciclo');
    },
    cadeiaNova: function () {
      mdl('Nova cadeia de valor', '<p class="small text-muted">Use para registrar outra cadeia de valor. Cada cadeia tem seus próprios ciclos, missão, resultado e macroprocessos, e os processos, indicadores, riscos e capacidades vinculados a ela ficam identificados.</p><div class="mb-2"><label class="form-label">Nome da cadeia</label><input class="form-control" id="cdn" placeholder="Nome da cadeia"></div><div class="mb-2"><label class="form-label">Nome do primeiro ciclo</label><input class="form-control" id="cn" value="' + h('Ciclo ' + new Date().getFullYear()) + '"></div><div class="row g-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ci" value="' + hojeIso() + '"></div><div class="col"><label class="form-label">Término</label><input type="date" class="form-control" id="cf"></div></div>',
        function (d) {
          var cd = v(d, '#cdn').trim(); if (!cd) throw new Error('Informe o nome da cadeia.');
          if (cadeias().some(function (x) { return x.toLowerCase() === cd.toLowerCase(); })) throw new Error('Já existe uma cadeia com este nome.');
          if (!v(d, '#cn').trim()) throw new Error('Informe o nome do ciclo.');
          if (v(d, '#cf') && v(d, '#cf') < v(d, '#ci')) throw new Error('O término deve ser posterior ao início.');
          var id = DB.tx(function () { DB.run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES (?,'','',?,?, 'Vigente', ?)", [v(d, '#cn').trim(), v(d, '#ci') || null, v(d, '#cf') || null, cd]); return DB.lastId(); });
          Nav.ir('#/cva?ciclo=' + id);
        }, 'Criar cadeia');
    },
    cadeiaRenomear: function (cad) {
      mdl('Renomear cadeia de valor', '<div class="mb-2"><label class="form-label">Nome da cadeia</label><input class="form-control" id="cdn" value="' + h(cad) + '"></div>',
        function (d) {
          var nv = v(d, '#cdn').trim(); if (!nv) throw new Error('Informe o nome.');
          if (nv.toLowerCase() !== cad.toLowerCase() && cadeias().some(function (x) { return x.toLowerCase() === nv.toLowerCase(); })) throw new Error('Já existe uma cadeia com este nome.');
          DB.tx(function () { DB.run('UPDATE cva_ciclos SET cadeia = ? WHERE cadeia = ?', [nv, cad]); });
          Nav.ir('#/cva?cadeia=' + encodeURIComponent(nv));
        });
    },
    cicloEditar: function (id) {
      var c = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [id]);
      mdl('Dados do ciclo', '<div class="mb-2"><label class="form-label">Nome</label><input class="form-control" id="cn" value="' + h(c.nome) + '"></div><div class="row g-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ci" value="' + h(c.inicio || '') + '"></div><div class="col"><label class="form-label">Término</label><input type="date" class="form-control" id="cf" value="' + h(c.fim || '') + '"></div></div><div class="mt-2"><label class="form-label">Observações</label><textarea class="form-control" id="co" rows="2">' + h(c.obs || '') + '</textarea></div>',
        function (d) { if (!v(d, '#cn').trim()) throw new Error('Informe o nome.'); DB.tx(function () { DB.run('UPDATE cva_ciclos SET nome=?,inicio=?,fim=?,obs=? WHERE id=?', [v(d, '#cn').trim(), v(d, '#ci') || null, v(d, '#cf') || null, v(d, '#co'), id]); }); Nav.ir('#/cva?ciclo=' + id); });
    },
    cicloExcluir: function (id) {
      var n = DB.one('SELECT COUNT(*) AS n FROM macroprocessos WHERE ciclo_id = ?', [id]).n;
      if (!confirm('Excluir este ciclo e seus ' + n + ' macroprocesso(s)? Os processos vinculados ficarão sem macroprocesso.')) return;
      DB.tx(function () { DB.run('UPDATE processos SET macro_id = NULL WHERE macro_id IN (SELECT id FROM macroprocessos WHERE ciclo_id = ?)', [id]); DB.run('DELETE FROM macroprocessos WHERE ciclo_id = ?', [id]); DB.run('DELETE FROM cva_validacoes WHERE ciclo_id = ?', [id]); DB.run('DELETE FROM cva_ciclos WHERE id = ?', [id]); });
      Nav.ir('#/cva');
    },
    texto: function (cid, campo) {
      var c = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [cid]), rot = campo === 'missao' ? 'Missão' : 'Resultado (valor entregue / margem)';
      mdl('Editar — ' + rot, '<label class="form-label">' + rot + '</label><textarea class="form-control" id="tx" rows="5">' + h(c[campo] || '') + '</textarea>',
        function (d) { DB.tx(function () { DB.run('UPDATE cva_ciclos SET ' + (campo === 'missao' ? 'missao' : 'resultado') + '=? WHERE id=?', [v(d, '#tx'), cid]); }); Nav.ir('#/cva?ciclo=' + cid); });
    },
    textos: function (id) { DB.tx(function () { DB.run('UPDATE cva_ciclos SET missao=?, resultado=? WHERE id=?', [document.getElementById('cvMis').value, document.getElementById('cvRes').value, id]); }); Nav.ir('#/cva?ciclo=' + id); },
    macro: function (cid, tipo, id) {
      var m = id ? DB.one('SELECT * FROM macroprocessos WHERE id = ?', [id]) : { tipo: tipo, nome: '', descricao: '', responsavel: '' };
      var dlg = mdl((id ? 'Editar' : 'Novo') + ' macroprocesso', '<div class="mb-2"><label class="form-label">Tipo</label><select class="form-select" id="mt">' + TIPOS.map(function (t) { return '<option value="' + t + '"' + (t === m.tipo ? ' selected' : '') + '>' + PLURAL[t] + '</option>'; }).join('') + '</select></div><div class="mb-2"><label class="form-label">Nome *</label><input class="form-control" id="mn" value="' + h(m.nome) + '"></div><div class="mb-2"><label class="form-label">Responsável</label><input class="form-control" id="mr" value="' + h(m.responsavel || '') + '"></div><div><label class="form-label">Descrição</label><textarea class="form-control" id="md" rows="3">' + h(m.descricao || '') + '</textarea></div>',
        function (d) {
          var nome = v(d, '#mn').trim(); if (!nome) throw new Error('Informe o nome do macroprocesso.');
          DB.tx(function () {
            if (id) DB.run('UPDATE macroprocessos SET tipo=?,nome=?,responsavel=?,descricao=? WHERE id=?', [v(d, '#mt'), nome, v(d, '#mr'), v(d, '#md'), id]);
            else DB.run('INSERT INTO macroprocessos (ciclo_id,tipo,nome,responsavel,descricao,ordem) VALUES (?,?,?,?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM macroprocessos WHERE ciclo_id=?))', [cid, v(d, '#mt'), nome, v(d, '#mr'), v(d, '#md'), cid]);
          }); Nav.ir('#/cva?ciclo=' + cid);
        }, id ? 'Salvar' : 'Adicionar');
      if (id) {
        var bd = dlg.querySelector('.modal-body'), n = nProc(id);
        var ex = document.createElement('div'); ex.className = 'd-flex flex-wrap gap-2 mt-3 pt-2 border-top';
        ex.innerHTML = '<a class="btn btn-sm btn-outline-secondary" href="#/processos?macro=' + id + '" data-bs-dismiss="modal"><i class="bi bi-diagram-3"></i> ' + n + ' processo(s)</a><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-left"></i> Mover</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1">Mover <i class="bi bi-arrow-right"></i></button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-xx><i class="bi bi-trash"></i> Excluir</button>';
        if (bd) { bd.appendChild(ex);
          Array.prototype.forEach.call(ex.querySelectorAll('[data-mv]'), function (b) { b.onclick = function () { var mo = bootstrap.Modal.getInstance(bd.closest('.modal')); if (mo) mo.hide(); Cva.mover(cid, id, +b.getAttribute('data-mv')); }; });
          ex.querySelector('[data-xx]').onclick = function () { var mo = bootstrap.Modal.getInstance(bd.closest('.modal')); if (mo) mo.hide(); Cva.macroExcluir(cid, id); };
        }
      }
    },
    macroExcluir: function (cid, id) {
      var n = nProc(id); if (!confirm('Excluir o macroprocesso?' + (n ? '\n' + n + ' processo(s) vinculado(s) ficarão sem macroprocesso (não serão excluídos).' : ''))) return;
      DB.tx(function () { DB.run('UPDATE processos SET macro_id = NULL WHERE macro_id = ?', [id]); DB.run('DELETE FROM macroprocessos WHERE id = ?', [id]); }); Nav.ir('#/cva?ciclo=' + cid);
    },
    mover: function (cid, id, dir) {
      var m = DB.one('SELECT * FROM macroprocessos WHERE id = ?', [id]), l = macros(cid).filter(function (x) { return x.tipo === m.tipo; }), i = l.findIndex(function (x) { return x.id === id; }), j = i + dir;
      if (j < 0 || j >= l.length) return;
      DB.tx(function () { l.splice(j, 0, l.splice(i, 1)[0]); l.forEach(function (x, k) { DB.run('UPDATE macroprocessos SET ordem = ? WHERE id = ?', [k + 1, x.id]); }); }); Nav.ir('#/cva?ciclo=' + cid);
    },
    svg: function (id, fmt) { var c = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [id]), s = svgPorter(c), n = 'cadeia-de-valor-' + String(c.nome).replace(/[^A-Za-z0-9_-]+/g, '_'); if (fmt === 'png') baixarPng(s, n + '.png'); else Mapris.baixar(n + '.svg', s, 'image/svg+xml'); },
    imprimir: function () { document.body.classList.add('imp-cva'); window.print(); setTimeout(function () { document.body.classList.remove('imp-cva'); }, 500); },
    revisao: function (cid) {
      var ms = macros(cid), linhas = '';
      ms.forEach(function (m) {
        linhas += '<tr class="table-light"><td colspan="3"><b>' + h(m.nome) + '</b> <small class="text-muted">(' + h(m.tipo) + ')</small></td><td>' + sel('m' + m.id) + '</td></tr>';
        DB.all('SELECT id,nome FROM processos WHERE macro_id = ? ORDER BY nome', [m.id]).forEach(function (p) { linhas += '<tr><td></td><td colspan="2">' + h(p.nome) + '</td><td>' + sel('p' + p.id) + '</td></tr>'; });
      });
      function sel(n) { return '<select class="form-select form-select-sm" data-rv="' + n + '"><option>Manter</option><option>Revisar</option><option>Alterar</option></select>'; }
      var sem = DB.all('SELECT id,nome FROM processos WHERE macro_id IS NULL OR macro_id NOT IN (SELECT id FROM macroprocessos WHERE ciclo_id = ?) ORDER BY nome', [cid]);
      sem.forEach(function (p) { linhas += '<tr><td colspan="3">' + h(p.nome) + ' <small class="text-muted">(sem macroprocesso neste ciclo)</small></td><td>' + sel('p' + p.id) + '</td></tr>'; });
      var d = mdl('Revisão do ciclo — manter, revisar ou alterar', '<p class="small text-muted">Para cada macroprocesso e processo, registre a decisão da validação. <b>Manter</b>: continua como está. <b>Revisar</b>: será reanalisado (a Folha de dados fica marcada). <b>Alterar</b>: haverá mudança no processo.</p><table class="table table-sm"><thead><tr><th style="width:20px"></th><th colspan="2">Item</th><th style="width:130px">Decisão</th></tr></thead><tbody>' + linhas + '</tbody></table><div><label class="form-label">Observações da validação</label><textarea class="form-control" id="ro" rows="2"></textarea></div>',
        function (d) {
          DB.tx(function () {
            Array.prototype.forEach.call(d.querySelectorAll('[data-rv]'), function (s) {
              var k = s.getAttribute('data-rv'), id = parseInt(k.slice(1), 10), alvo = k.charAt(0) === 'm' ? 'macroprocesso' : 'processo';
              var nome = (DB.one('SELECT nome FROM ' + (alvo === 'processo' ? 'processos' : 'macroprocessos') + ' WHERE id = ?', [id]) || {}).nome || '';
              DB.run('INSERT INTO cva_validacoes (ciclo_id,alvo,ref_id,nome,decisao,obs) VALUES (?,?,?,?,?,?)', [cid, alvo, id, nome, s.value, d.querySelector('#ro').value]);
              if (alvo === 'processo') DB.run('UPDATE processos SET validacao = ?, validado_ciclo_id = ? WHERE id = ?', [s.value, cid, id]);
            });
          });
          Nav.ir('#/cva?ciclo=' + cid);
        }, 'Registrar validação');
      d.querySelector('.modal-dialog').classList.add('modal-lg');
    }
  };

  function html(q) {
    var c = cicloAtual(q), cad = c ? (c.cadeia || 'Principal') : 'Principal', todos = ciclos(cad), cads = cadeias();
    if (!c) {
      return '<div class="pagina"><h1 class="h4"><i class="bi bi-bezier2"></i> CVA — Cadeia de Valor Agregado</h1><div class="cartao"><div class="vazio">Nenhum ciclo cadastrado. Crie o primeiro ciclo de validação para cadastrar a missão, o resultado e os macroprocessos da organização.<br><br><button class="btn btn-success" onclick="Cva.cicloNovo()"><i class="bi bi-plus-lg"></i> Criar ciclo da cadeia de valor</button></div></div></div>';
    }
    var vl = validade(c), ms = macros(c.id), o = '<div class="pagina cva-host">';
    o += '<div class="d-flex flex-wrap align-items-center mb-2"><h1 class="h4 mb-0 me-auto"><i class="bi bi-bezier2"></i> CVA — Cadeia de Valor Agregado</h1>' +
      '<select class="form-select form-select-sm" style="width:170px;margin-right:6px" title="Cadeia de valor" onchange="Nav.ir(\'#/cva?cadeia=\'+encodeURIComponent(this.value))">' + cads.map(function (x) { return '<option value="' + h(x) + '"' + (x === cad ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select><button class="btn btn-outline-secondary btn-sm" style="margin-right:8px" title="Renomear a cadeia" onclick="Cva.cadeiaRenomear(\'' + h(cad).replace(/'/g, '\\\'') + '\')"><i class="bi bi-tag"></i></button>' +
      '<select class="form-select form-select-sm" style="width:190px;margin-right:6px" title="Ciclo" onchange="Nav.ir(\'#/cva?ciclo=\'+this.value)">' + todos.map(function (x) { return '<option value="' + x.id + '"' + (x.id === c.id ? ' selected' : '') + '>' + h(x.nome) + (x.status === 'Vigente' ? ' (vigente)' : ' (encerrado)') + '</option>'; }).join('') + '</select>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="Cva.cicloEditar(' + c.id + ')"><i class="bi bi-pencil"></i> Ciclo</button><button class="btn btn-outline-danger btn-sm" style="margin-right:6px" onclick="Cva.cicloExcluir(' + c.id + ')"><i class="bi bi-trash"></i></button><button class="btn btn-success btn-sm" style="margin-right:6px" onclick="Cva.cicloNovo(\'' + h(cad).replace(/'/g, '\\\'') + '\')"><i class="bi bi-plus-lg"></i> Novo ciclo</button><button class="btn btn-outline-success btn-sm" onclick="Cva.cadeiaNova()" title="Cadastrar outra cadeia de valor"><i class="bi bi-diagram-2"></i> Nova cadeia</button></div>';
    o += '<div class="alert alert-' + vl.cls + ' d-flex flex-wrap align-items-center py-2"><i class="bi bi-calendar-check" style="margin-right:8px"></i><span class="me-auto"><b>Ciclo de validação:</b> ' + h(c.nome) + (c.inicio ? ' · ' + E.dataBr(c.inicio) + ' a ' + (c.fim ? E.dataBr(c.fim) : '…') : '') + ' — ' + h(vl.txt) + '</span>' +
      (c.status === 'Vigente' ? '<button class="btn btn-sm btn-' + (vl.n !== null && vl.n <= 60 ? 'dark' : 'outline-dark') + '" onclick="Cva.revisao(' + c.id + ')"><i class="bi bi-clipboard-check"></i> Revisar e validar a cadeia</button>' : '') + '</div>';
    o += '<div class="cartao"><h2><span class="me-auto"><i class="bi bi-bezier2"></i> Cadeia de valor — edite direto na imagem</span><span class="no-print"><button class="btn btn-sm btn-outline-secondary" onclick="Cva.svg(' + c.id + ',\'png\')"><i class="bi bi-filetype-png"></i> PNG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Cva.svg(' + c.id + ',\'svg\')"><i class="bi bi-filetype-svg"></i> SVG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Cva.imprimir()"><i class="bi bi-printer"></i> Imprimir</button></span></h2><div class="corpo cva-img"><div class="ajuda no-print" style="margin-bottom:6px">Clique em <b>+</b> para adicionar um macroprocesso e no ícone de <b>lápis</b> para editar, mover ou excluir. A missão e o resultado também são editados pelo lápis. Os ícones não aparecem na imagem exportada.</div>' + svgPorter(c, true) + '</div></div>';
    var hist = DB.all('SELECT * FROM cva_validacoes WHERE ciclo_id = ? ORDER BY id DESC LIMIT 60', [c.id]);
    if (hist.length) o += '<div class="cartao"><h2><i class="bi bi-clock-history"></i> Histórico de validações deste ciclo</h2><div class="corpo"><table class="tabela"><thead><tr><th>Data</th><th>Item</th><th>Nome</th><th>Decisão</th><th>Obs.</th></tr></thead><tbody>' + hist.map(function (x) { return '<tr><td>' + E.dataBr(String(x.em).slice(0, 10)) + '</td><td>' + h(x.alvo) + '</td><td>' + h(x.nome) + '</td><td>' + h(x.decisao) + '</td><td>' + h(x.obs) + '</td></tr>'; }).join('') + '</tbody></table></div></div>';
    return o + '</div>';
  }
  Modulos.registrar('/cva', { ativo: 'cva', titulo: 'CVA — Cadeia de Valor', html: html });
})(window);
