/* imprimir.js — pré-visualização de impressão da Folha de Dados (port de imprimir.php) */
(function () {
  'use strict';
  var h = Common.esc, nl = Common.nl2br;
  function lista(l) { l = (l || []).filter(function (x) { return String(x === null || x === undefined ? '' : x).trim() !== ''; }); return l.length ? '<ul>' + l.map(function (x) { return '<li>' + h(x) + '</li>'; }).join('') + '</ul>' : ''; }
  /** Texto da folha: HTML do editor rico (saneado) ou texto simples legado. */
  function rico(v) {
    v = String(v === null || v === undefined ? '' : v); if (!v.trim()) return '';
    if (!/^\s*<(p|ul|ol|h[1-6]|div|blockquote)[\s>]/i.test(v)) return nl(v);
    var t = document.createElement('div'); t.innerHTML = v;
    Array.prototype.forEach.call(t.querySelectorAll('script,style,iframe,object,embed,link,meta,img,form,.ql-ui'), function (e) { e.remove(); });
    Array.prototype.forEach.call(t.querySelectorAll('*'), function (e) {
      Array.prototype.slice.call(e.attributes).forEach(function (a) {
        var n = a.name.toLowerCase();
        if (n === 'class' && /^ql-(indent|align)-/.test(a.value.split(' ').pop())) return;
        if (n === 'data-list') return;
        if (n === 'href' && /^(https?:|mailto:)/i.test(a.value)) return;
        if (n === 'style') { var ok = (a.value.match(/(?:^|;)\s*(color|background-color)\s*:\s*(#[0-9a-f]{3,8}|rgba?\([\d\s,.]+\))/gi) || []).join(';'); if (ok) e.setAttribute('style', ok); else e.removeAttribute('style'); return; }
        e.removeAttribute(a.name);
      });
    });
    // Quill 2 grava todas as listas como <ol>; as de marcadores viram <ul>
    Array.prototype.forEach.call(t.querySelectorAll('ol'), function (ol) {
      var li = ol.querySelector('li'); if (li && li.getAttribute('data-list') === 'bullet') { var ul = document.createElement('ul'); ul.innerHTML = ol.innerHTML; ol.parentNode.replaceChild(ul, ol); }
    });
    return t.innerHTML;
  }
  function cheio(v) { return String(v === null || v === undefined ? '' : v).trim() !== ''; }
  function tabela(cols, rows, num) {
    var o = '<table><thead><tr>' + (num ? '<th>Item</th>' : '') + cols.map(function (c) { return '<th>' + h(c[1]) + '</th>'; }).join('') + '</tr></thead><tbody>';
    rows = (rows || []).filter(function (r) { return cols.some(function (c) { return cheio(r && r[c[0]]); }); });
    if (!rows.length) return '';
    rows.forEach(function (r, i) { o += '<tr>' + (num ? '<td>' + (i + 1) + '</td>' : '') + cols.map(function (c) { return '<td>' + nl(r[c[0]]) + '</td>'; }).join('') + '</tr>'; });
    return o + '</tbody></table>';
  }
  function seqTxt(r, rot) {
    var s = r.seq || {}, o = [];
    function f(x, pre) {
      if (!x || typeof x !== 'object') return '';
      var a = x.alvo || '', via = x.via || 'fluxo';
      return pre + (a !== '' ? (rot[a] !== undefined ? rot[a] : '?') : 'seguinte') + (via !== 'fluxo' ? ' (' + (via === 'dados' ? 'documento' : 'mensagem') + (x.nome ? ': ' + x.nome : '') + ')' : '');
    }
    [['sim', 'SIM → '], ['nao', 'NÃO → '], ['proxima', '→ ']].forEach(function (k) { if (s[k[0]] && Object.keys(s[k[0]]).length) o.push(f(s[k[0]], k[1])); });
    (s.ramos || []).forEach(function (rm) { o.push(f(rm, (rm.rotulo || '') !== '' ? rm.rotulo + ' → ' : '→ ')); });
    return o.map(h).join('<br>');
  }
  /* remove títulos/seções sem conteúdo (itens não preenchidos não saem na impressão) */
  function limpaVazios(raiz) {
    Array.prototype.forEach.call(raiz.querySelectorAll('table'), function (tb) { if (!Array.prototype.some.call(tb.querySelectorAll('td'), function (c) { return c.textContent.trim(); })) tb.remove(); });
    Array.prototype.forEach.call(raiz.querySelectorAll('p.v, div.v'), function (p) { if (!p.textContent.trim() || p.textContent.trim() === '—') p.remove(); });
    function vazioApos(t, ate) {
      var n = t.nextElementSibling;
      while (n && !n.matches(ate)) {
        if (n.querySelector('svg,img')) return false;
        var tds = n.matches('table') ? n : (n.querySelector ? n.querySelector('table') : null);
        if (tds) { if (Array.prototype.some.call(tds.querySelectorAll('td'), function (c) { return c.textContent.trim(); })) return false; }
        else if (n.textContent.trim()) return false;
        n = n.nextElementSibling;
      }
      return true;
    }
    Array.prototype.forEach.call(raiz.querySelectorAll('h3'), function (t) { if (vazioApos(t, 'h2,h3,.pag-diag,.rodape')) t.remove(); });
    Array.prototype.forEach.call(raiz.querySelectorAll('h2'), function (t) {
      if (t.parentNode.classList.contains('pag-diag')) { if (!document.getElementById('diag') || !document.getElementById('diag').textContent.trim() && !document.getElementById('diag').querySelector('svg')) { if (!document.getElementById('tmp')) t.parentNode.remove(); } return; }
      if (vazioApos(t, 'h2,.pag-diag,.rodape')) t.remove();
    });
  }
  // ---------- PDF direto (jsPDF): garante a página do diagrama em paisagem em qualquer sistema ----------
  function textoDe(n) {
    var o = '';
    (function rec(x) {
      Array.prototype.forEach.call(x.childNodes, function (c) {
        if (c.nodeType === 3) { o += c.nodeValue.replace(/\s+/g, ' '); return; }
        if (c.nodeType !== 1) return;
        var t = c.tagName;
        if (t === 'BR') { o += '\n'; return; }
        if (t === 'LI') { if (o && o.slice(-1) !== '\n') o += '\n'; o += '• '; rec(c); return; }
        var blk = /^(P|DIV|UL|OL|H\d|BLOCKQUOTE)$/.test(t);
        if (blk && o && o.slice(-1) !== '\n') o += '\n';
        rec(c);
        if (blk && o.slice(-1) !== '\n') o += '\n';
      });
    })(n);
    return o.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/^\n+|\n+$/g, '').replace(/[\u2192]/g, '->').replace(/[\u2610\u2611]/g, '[ ]');
  }
  function svgParaCanvas(svgTxt, cb) {
    var div = document.createElement('div'); div.innerHTML = svgTxt; var sv = div.querySelector('svg');
    var vb = (sv.getAttribute('viewBox') || '').split(/[\s,]+/).map(parseFloat), W = parseFloat(sv.getAttribute('width')) || vb[2] || 1000, H = parseFloat(sv.getAttribute('height')) || vb[3] || 600;
    if (!sv.getAttribute('xmlns')) sv.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    sv.setAttribute('width', W); sv.setAttribute('height', H);
    var esc = 2, img = new Image();
    img.onload = function () { var c = document.createElement('canvas'); c.width = Math.round(W * esc); c.height = Math.round(H * esc); var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); cb(c); };
    img.onerror = function () { cb(null); };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(sv));
  }
  function gerarPdf(nomeArq) {
    var doc = document.querySelector('.fimp .doc'); if (!doc) return;
    var jp = new window.jspdf.jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait', compress: true });
    var PW = 595.28, PH = 841.89, M = 42, TW = PW - 2 * M, y = M, titulo = document.title.replace(/^Folha de Dados — /, '');
    function nova(orient) { jp.addPage('a4', orient || 'portrait'); y = M; }
    function larg() { return jp.internal.pageSize.getWidth(); }
    function alt() { return jp.internal.pageSize.getHeight(); }
    function garante(hh) { if (y + hh > alt() - M - 6) nova(jp.internal.pageSize.getWidth() > jp.internal.pageSize.getHeight() ? 'landscape' : 'portrait'); }
    function par(txt, tam, estilo, cor, indent, centro) {
      jp.setFont('helvetica', estilo || 'normal'); jp.setFontSize(tam); jp.setTextColor(cor || 0);
      var lh = tam * 1.28, ls = jp.splitTextToSize(String(txt), larg() - 2 * M - (indent || 0));
      ls.forEach(function (l) { garante(lh); jp.text(l, centro ? larg() / 2 : M + (indent || 0), y + tam, centro ? { align: 'center' } : undefined); y += lh; });
    }
    function tabela(tb) {
      var linhas = Array.prototype.map.call(tb.querySelectorAll('tr'), function (tr) { return { cab: !!tr.querySelector('th'), cel: Array.prototype.map.call(tr.children, function (c) { return textoDe(c); }) }; });
      if (!linhas.length) return;
      var nc = Math.max.apply(null, linhas.map(function (l) { return l.cel.length; })), mx = [];
      for (var c = 0; c < nc; c++) mx[c] = Math.max(6, Math.min(60, Math.max.apply(null, linhas.map(function (l) { return Math.sqrt(String(l.cel[c] || '').length + 1) * 4 + 4; }))));
      var soma = mx.reduce(function (a, b) { return a + b; }, 0), ws = mx.map(function (v) { return Math.max(34, TW * v / soma); }), sw = ws.reduce(function (a, b) { return a + b; }, 0); ws = ws.map(function (v) { return v * TW / sw; });
      var cab = linhas.filter(function (l) { return l.cab; })[0];
      function desenha(l, isCab) {
        jp.setFont('helvetica', isCab ? 'bold' : 'normal'); jp.setFontSize(8.6);
        var cels = ws.map(function (w, i) { return jp.splitTextToSize(String(l.cel[i] || ''), w - 8); }), nl = Math.max.apply(null, cels.map(function (a) { return a.length; })), rh = nl * 11 + 6;
        if (y + rh > alt() - M - 6) { nova('portrait'); if (!isCab && cab) desenha(cab, true); }
        var x = M; ws.forEach(function (w, i) {
          if (isCab) { jp.setFillColor(232, 235, 238); jp.rect(x, y, w, rh, 'F'); }
          jp.setDrawColor(150); jp.rect(x, y, w, rh); jp.setTextColor(0); jp.setFont('helvetica', isCab ? 'bold' : 'normal'); jp.setFontSize(8.6);
          cels[i].forEach(function (t, k) { jp.text(t, x + 4, y + 10 + k * 11); }); x += w;
        }); y += rh;
      }
      linhas.forEach(function (l) { desenha(l, l.cab); }); y += 8;
    }
    var logo = window.LOGO_PDF; if (logo) { var lw = 150, lh = lw * logo.h / logo.w; jp.addImage(logo.png, 'PNG', M, y, lw, lh); y += lh + 10; }
    var fila = [], diagEl = null;
    Array.prototype.forEach.call(doc.children, function (n) {
      var t = n.tagName, c = n.className || '';
      if (/pag-diag/.test(c)) { diagEl = n; fila.push({ k: 'diag', n: n }); return; }
      if (/rodape/.test(c)) { fila.push({ k: 'rod', n: n }); return; }
      fila.push({ k: t, n: n, c: c });
    });
    var pend = fila.slice();
    function passo() {
      while (pend.length) {
        var it = pend.shift(), n = it.n;
        if (it.k === 'H1') { par(n.textContent, /sub/.test(it.c) ? 13 : 15, 'bold', 0, 0, true); y += /sub/.test(it.c) ? 8 : 2; }
        else if (it.k === 'H2') { garante(40); y += 8; par(n.textContent, 11, 'bold', 0); y += 3; }
        else if (it.k === 'H3') { garante(30); y += 4; par(n.textContent, 10, 'bold', 0); y += 2; }
        else if (it.k === 'TABLE') tabela(n);
        else if (it.k === 'rod') { /* rodapé do documento */ }
        else if (it.k === 'diag') {
          var sv = n.querySelector('svg'); nova('landscape'); par('12. FLUXOGRAMA (BPMN)', 11, 'bold', 0); y += 4;
          if (!sv) { par('Diagrama não disponível.', 10, 'normal', 90); continue; }
          svgParaCanvas(new XMLSerializer().serializeToString(sv), function (cv) {
            if (cv) {
              var aw = larg() - 2 * M, ah = alt() - y - M - 10, r = Math.min(aw / cv.width, ah / cv.height), iw = cv.width * r, ih = cv.height * r;
              jp.addImage(cv.toDataURL('image/jpeg', 0.93), 'JPEG', M + (aw - iw) / 2, y, iw, ih, undefined, 'FAST');
            } else par('Não foi possível desenhar o diagrama.', 10, 'normal', 90);
            nova('portrait'); passo();
          });
          return;
        }
        else if (n.textContent.trim()) { par(textoDe(n), 9.8, 'normal', 0); y += 4; }
      }
      // fecha: remove página em branco final, numera e salva
      var np = jp.getNumberOfPages(); if (np > 1 && y <= M + 1) { jp.deletePage(np); np--; }
      for (var i = 1; i <= np; i++) {
        jp.setPage(i); var W = jp.internal.pageSize.getWidth(), Hh = jp.internal.pageSize.getHeight();
        jp.setFont('helvetica', 'normal'); jp.setFontSize(7.5); jp.setTextColor(120);
        jp.text('Valor-E · Folha de Dados — ' + titulo, M, Hh - 20); jp.text('Página ' + i + ' de ' + np, W - M, Hh - 20, { align: 'right' });
      }
      Common.baixar(nomeArq, jp.output('blob'));
    }
    passo();
  }
  window.__folhaPdf = gerarPdf;

  Common.pagina('imprimir', function () {
    var id = Common.id(), p = API.buscar(id);
    if (!p) { Common.ir('#/cenarios'); return; }
    var d = API.dados(p), F = d.folha, A = d.atividades.slice().sort(function (a, b) { return (parseFloat(a.ordem) || 0) - (parseFloat(b.ordem) || 0); });
    document.title = 'Folha de Dados — ' + p.nome;
    var rot = {}; A.forEach(function (r) { var t = String(r.descricao || ''); rot[r.uid || ''] = (r.ordem === undefined || r.ordem === null ? '' : r.ordem) + ' ' + (Array.from(t).length > 40 ? Array.from(t).slice(0, 39).join('') + '…' : t); });
    var tipos = {}; Object.keys(Bpmn.tipos).forEach(function (k) { tipos[k] = Bpmn.tipos[k][4]; });
    var KA = { dados: 'Documento', sistema: 'Sistema', mensagem: 'Mensagem', subprocesso: 'Subprocesso', anotacao: 'Anotação', normativo: 'Normativo' };
    var x = '<div class="fimp"><div class="barra"><a class="btn btn-sm btn-outline-light" href="#/folha?id=' + id + '">← Voltar</a><b style="flex:1">Pré-visualização de impressão</b><button class="btn btn-sm btn-light" onclick="window.__folhaPdf(\'folha-\' + (document.title.replace(/^Folha de Dados — /, \'\').replace(/[^A-Za-z0-9_-]+/g, \'_\')) + \'.pdf\')"><i class="bi bi-filetype-pdf"></i> Baixar PDF (diagrama em paisagem)</button><button class="btn btn-sm btn-warning" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button></div><div class="doc">';
    x += '<h1>Folha de Dados do Processo</h1><h1 class="sub">' + h(p.nome) + '</h1>';
    x += '<h2>1. OBJETIVO</h2><div class="v rico">' + (rico(F.objetivo) || '') + '</div>';
    x += '<h2>2. SIGLAS E DEFINIÇÕES</h2>' + tabela([['sigla', 'Sigla'], ['definicao', 'Definição']], F.siglas);
    x += '<h2>3. CAMPO DE APLICAÇÃO</h2><div class="v rico">' + (rico(F.campo_aplicacao) || '') + '</div>';
    x += '<h2>4. RESPONSABILIDADES</h2><h3>Gestor do Processo</h3>' + lista(F.gestor) + '<h3>Executores do Processo</h3>' + lista(F.executores);
    x += '<h2>5. LIMITES DO PROCESSO</h2><h3>Escopo</h3>' + ((rico(F.escopo_inicio) || rico(F.escopo_fim)) ? '<table><tr><th>Início</th><th>Fim</th></tr><tr><td>' + rico(F.escopo_inicio) + '</td><td>' + rico(F.escopo_fim) + '</td></tr></table>' : '');
    x += '<h3>Áreas envolvidas</h3>' + lista(F.areas) + '<h3>Fornecedores do Processo</h3>' + tabela([['area', 'Área/Processo'], ['entradas', 'Entradas'], ['requisitos', 'Requisitos']], F.fornecedores);
    x += '<h3>Clientes do Processo</h3>' + tabela([['area', 'Área/Processo'], ['saidas', 'Saídas'], ['requisitos', 'Requisitos']], F.clientes);
    x += '<h2>6. DOCUMENTOS DE REFERÊNCIA</h2>' + lista(F.documentos);
    x += '<h2>7. DESCRIÇÃO DO PROCESSO</h2><table><thead><tr><th>Nº</th><th>Elemento</th><th>Entrada</th><th>Atividade / Descrição</th><th>Saída</th><th>Sequência</th><th>Responsável</th></tr></thead><tbody>';
    A.forEach(function (r) {
      if (!r.tipo && !r.descricao) return;
      x += '<tr><td>' + h(r.ordem === undefined || r.ordem === null ? '' : r.ordem) + '</td><td>' + h(tipos[r.tipo || ''] || '') + '</td><td>' + nl(r.entrada) + '</td><td>' + nl(r.descricao);
      (r.anexos || []).forEach(function (a) { x += '<br><small><i>' + h(KA[a.kind || ''] || '') + ': ' + h(a.nome) + '</i></small>'; });
      x += '</td><td>' + nl(r.saida) + '</td><td>' + seqTxt(r, rot) + '</td><td>' + h(r.responsavel) + '</td></tr>';
    });
    x += '</tbody></table>';
    x += '<h2>8. COMPETÊNCIAS REQUERIDAS</h2>' + tabela([['funcao', 'Função'], ['educacao', 'Educação'], ['treinamento', 'Treinamento'], ['experiencia', 'Experiência'], ['habilidades', 'Habilidades'], ['atitudes', 'Atitudes']], F.competencias);
    x += '<h2>9. REGISTROS GERADOS</h2>' + tabela([['titulo', 'Título'], ['meio', 'Meio'], ['sistema', 'Sistema'], ['acesso', 'Acesso'], ['local', 'Local'], ['indexacao', 'Indexação'], ['corrente', 'Corrente'], ['intermediario', 'Intermediário'], ['disposicao', 'Disposição']], F.registros, true);
    x += '<h2>10. PONTOS DE ALERTA</h2>' + tabela([['ponto', 'Ponto de Alerta'], ['descricao', 'Descrição']], F.alertas);
    x += '<h2>11. CONTROLES DO PROCESSO</h2><h3>Monitoramento e medição</h3>' + tabela([['tipo', 'Tipo de indicador'], ['indicador', 'Indicador'], ['formula', 'Fórmula de cálculo'], ['frequencia', 'Frequência'], ['fonte', 'Fonte dos dados'], ['polaridade', 'Polaridade'], ['responsavel', 'Responsável']], F.indicadores);
    x += '<h3>Controles ambientais</h3>' + tabela([['variavel', 'Variável a ser controlada'], ['minimo', 'Mínimo'], ['maximo', 'Máximo']], F.ambientais);
    x += '<h3>Infraestrutura</h3>' + ((lista(F.instalacoes) || lista(F.equipamentos) || lista(F.softwares)) ? '<table><tr><th>Instalações</th><th>Equipamentos</th><th>Softwares</th></tr><tr><td>' + lista(F.instalacoes) + '</td><td>' + lista(F.equipamentos) + '</td><td>' + lista(F.softwares) + '</td></tr></table>' : '');
    x += '<div class="pag-diag"><h2>12. FLUXOGRAMA (BPMN)</h2><div class="diag" id="diag">' + (p.bpmn_xml ? '<span class="text-muted">Carregando diagrama…</span>' : '') + '</div></div>';
    x += '<h2>13. CONTROLE DE ALTERAÇÕES</h2>' + tabela([['versao', 'Identificação'], ['descricao', 'Descrição da alteração']], F.alteracoes);
    x += '<div class="rodape"><span>Elaboração: ' + h(F.elaboracao) + '</span><span>Aprovação: ' + h(F.aprovacao) + '</span></div></div></div>';
    if (p.bpmn_xml) x += '<div id="tmp" style="position:absolute;left:-9999px;top:0;width:1600px;height:900px"></div>';
    document.getElementById('fraiz').innerHTML = x;
    limpaVazios(document.getElementById('fraiz'));
    if (!p.bpmn_xml) return;
    try {
      var m = new BpmnJS({ container: '#tmp' });
      return Promise.resolve(m.importXML(p.bpmn_xml)).then(function () { return m.saveSVG(); }).then(function (s) {
        document.getElementById('diag').innerHTML = s.svg.replace(/^<\?xml[^>]*\?>/, ''); document.getElementById('tmp').remove();
      }).catch(function (e) { document.getElementById('diag').textContent = 'Não foi possível desenhar o diagrama: ' + e.message; });
    } catch (e) { document.getElementById('diag').textContent = 'Não foi possível desenhar o diagrama: ' + e.message; }
  });
})();
