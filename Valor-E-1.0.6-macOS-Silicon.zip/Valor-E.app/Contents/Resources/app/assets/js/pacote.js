/* pacote.js — exportar / importar TUDO (todas as tabelas, todos os módulos) em JSON ou XML, com remapeamento de vínculos (modo "mesclar") ou restauração integral (modo "substituir"). */
(function (w) {
  'use strict';
  var h = E.esc, FORMATO = 'axia-pacote', VERSAO = '4.0';
  // vínculos lógicos (além das FKs declaradas): tabela.coluna -> tabela pai
  var LOGICAS = {
    '*.processo_id': 'processos', '*.flag_id': 'flags', '*.macro_id': 'macroprocessos', '*.risco_id': 'riscos', '*.objetivo_id': 'objetivos_estrategicos',
    '*.capacidade_id': 'capacidades', '*.projeto_id': 'projetos', 'proj_deps.pred_id': 'proj_tarefas', 'proj_deps.succ_id': 'proj_tarefas', 'proj_tarefas.parent_id': 'proj_tarefas', 'proj_tarefas.recurso_id': 'proj_recursos', 'projetos.mapa_id': 'me_mapas', '*.indicador_id': 'indicadores', '*.item_id': 'indicador_itens', '*.validado_ciclo_id': 'cva_ciclos',
    'controles.fator_id': 'fatores', 'indicador_fatores.fator_id': 'fatores_determinantes', 'fatores_determinantes.capacidade_id': 'capacidades',
    'me_perspectivas.mapa_id': 'me_mapas', 'me_temas.perspectiva_id': 'me_perspectivas', 'me_objetivos.perspectiva_id': 'me_perspectivas', 'me_objetivos.tema_id': 'me_temas', 'me_objetivos.oe_id': 'objetivos_estrategicos',
    'macroprocessos.ciclo_id': 'cva_ciclos', 'cva_validacoes.ciclo_id': 'cva_ciclos', 'planos.controle_id': 'controles', 'monitoramentos.controle_desc': 'controles'
  };
  // chave natural de cada tabela: se já existe um registro com os mesmos valores (após refazer os vínculos), ele é ATUALIZADO; senão é criado
  var CHAVES = {
    projetos: ['codigo', 'nome'], proj_tarefas: ['projeto_id', 'parent_id', 'nome', 'inicio', 'fim', 'ordem'], proj_recursos: ['projeto_id', 'nome'], proj_baseline: ['projeto_id', 'nome', 'salvo_em'], proj_deps: ['pred_id', 'succ_id'],
    cva_ciclos: ['cadeia', 'nome'], macroprocessos: ['ciclo_id', 'tipo', 'nome'], processos: ['nome', 'macro_id'], flags: ['processo_id', 'elemento'],
    riscos: ['nome', 'processo_id', 'ambiente'], fatores: ['risco_id', 'nome'], controles: ['fator_id', 'descricao'], planos: ['risco_id', 'descricao'],
    revisoes: ['risco_id', 'data'], monitoramentos: ['risco_id', 'data', 'acao'],
    indicadores: ['nome', 'processo_id'], indicador_itens: ['indicador_id', 'nome'], ind_ciclos: ['indicador_id', 'data_inicio', 'data_fim'],
    ciclos_meta_indicador: ['indicador_id', 'data_inicio', 'data_fim'], lanc_ind: ['indicador_id', 'mes_ano'], lanc_itm: ['item_id', 'mes_ano'],
    lancamentos_indicador: ['indicador_id', 'ciclo_id', 'mes_ano'], lancamentos_item: ['item_id', 'ciclo_id', 'mes_ano'], metas_indicador_ciclo: ['indicador_id', 'ciclo_id'],
    series_historicas: ['indicador_id', 'data_observacao'], indicador_capacidades: ['indicador_id', 'capacidade_id'], indicador_fatores: ['indicador_id', 'fator_id'],
    capacidades: ['nome'], fatores_determinantes: ['capacidade_id', 'nome'], objetivos_estrategicos: ['nome'], objetivo_capacidades: ['objetivo_id', 'capacidade_id'],
    ciclos_estrategicos: ['nome'], periodos_ciclo: ['ciclo_id', 'codigo'], metas_objetivo_ciclo: ['objetivo_id', 'ciclo_id'],
    me_mapas: ['nome'], me_perspectivas: ['mapa_id', 'nome'], me_temas: ['perspectiva_id', 'nome'], me_objetivos: ['perspectiva_id', 'oe_id'],
    planos_intervencao: ['tipo_alvo', 'alvo_id', 'titulo'], cva_validacoes: ['ciclo_id', 'alvo', 'ref_id', 'em']
  };
  var GENERICOS_CICLO = { 'ciclo_id': 'ciclos_estrategicos' };
  function tabelas() { return DB.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").map(function (t) { return t.name; }); }
  function colunas(t) { return DB.all('PRAGMA table_info(' + t + ')').map(function (c) { return c.name; }); }
  function pai(t, c) {
    if (LOGICAS[t + '.' + c]) return LOGICAS[t + '.' + c];
    var fk = DB.all('PRAGMA foreign_key_list(' + t + ')').filter(function (f) { return f.from === c; })[0];
    if (fk) return fk.table;
    if (LOGICAS['*.' + c]) return LOGICAS['*.' + c];
    if (GENERICOS_CICLO[c]) return GENERICOS_CICLO[c];
    return null;
  }
  function ordenar(ts) {
    var dep = {}, out = [], vis = {};
    ts.forEach(function (t) { dep[t] = colunas(t).map(function (c) { return pai(t, c); }).filter(function (p) { return p && p !== t && ts.indexOf(p) >= 0; }); });
    function v(t) { if (vis[t]) return; vis[t] = 1; dep[t].forEach(v); out.push(t); }
    ts.forEach(v); return out;
  }

  function coletar() {
    var o = { formato: FORMATO, versao: VERSAO, aplicativo: 'Valor-E ' + (w.APP_VERSAO || ''), gerado_em: new Date().toISOString(), tabelas: {}, seguranca: { integridade: 'sha256' } };
    tabelas().forEach(function (t) {
      if (!/^[a-z0-9_]+$/i.test(t)) return; // só nomes de tabela seguros
      var cs = colunas(t).filter(function (c) { return /^[a-z0-9_]+$/i.test(c); });
      o.tabelas[t] = { colunas: cs, linhas: DB.all('SELECT * FROM ' + t).map(function (r) { return cs.map(function (c) { return r[c]; }); }) };
    });
    return o;
  }

  /* ===== Exportação segmentada: Processos | Projetos | Riscos | Indicadores (os vínculos acompanham) ===== */
  var ESCOPOS = { processos: 'Processos', projetos: 'Projetos', riscos: 'Riscos', indicadores: 'Indicadores' };
  var FILHAS_RISCO = [['fatores', 'risco_id'], ['planos', 'risco_id'], ['monitoramentos', 'risco_id'], ['revisoes', 'risco_id']];
  var FILHAS_IND = [['indicador_itens', 'indicador_id'], ['ind_ciclos', 'indicador_id'], ['lanc_ind', 'indicador_id'], ['lanc_itm', 'indicador_id'], ['ciclos_meta_indicador', 'indicador_id'], ['series_historicas', 'indicador_id'], ['lancamentos_indicador', 'indicador_id'], ['lancamentos_item', 'indicador_id'], ['metas_indicador_ciclo', 'indicador_id']];
  function inList(ids) { return '(' + ids.map(function (i) { return parseInt(i, 10) || 0; }).join(',') + ')'; }
  function existe(t) { return tabelas().indexOf(t) >= 0; }
  /** Lista os registros de cada escopo para a tela de seleção. */
  function listar(esc) {
    var q = {
      processos: "SELECT p.id, p.nome AS nome, COALESCE(m.nome,'') AS ref FROM processos p LEFT JOIN macroprocessos m ON m.id = p.macro_id ORDER BY p.nome",
      projetos: "SELECT id, nome, COALESCE(codigo,'') AS ref FROM projetos ORDER BY nome",
      riscos: "SELECT id, nome, COALESCE(codigo,'') AS ref FROM riscos ORDER BY codigo, nome",
      indicadores: "SELECT id, nome, COALESCE(codigo,'') AS ref FROM indicadores WHERE COALESCE(codigo,'') NOT LIKE 'PRJ-PROG-%' ORDER BY codigo, nome"
    }[esc];
    try { return DB.all(q); } catch (e) { return []; }
  }
  function coletarSeg(esc, ids) {
    if (!ESCOPOS[esc]) throw new Error('Módulo desconhecido.');
    var sel = {}; // tabela -> {id: true}
    function pegar(t, where, par) {
      if (!existe(t)) return [];
      var rs = DB.all('SELECT * FROM ' + t + (where ? ' WHERE ' + where : ''), par || []); sel[t] = sel[t] || {};
      rs.forEach(function (r) { if (r.id !== undefined) sel[t][r.id] = true; else sel[t]['#' + Object.keys(sel[t]).length] = r; });
      return rs;
    }
    function idsDe(rs) { return rs.map(function (r) { return r.id; }); }
    function riscosCom(rs) {
      if (!rs.length) return;
      FILHAS_RISCO.forEach(function (f) { var fr = pegar(f[0], f[1] + ' IN ' + inList(idsDe(rs))); if (f[0] === 'fatores' && fr.length) pegar('controles', 'fator_id IN ' + inList(idsDe(fr))); });
    }
    function indicadoresCom(rs) { if (!rs.length) return; FILHAS_IND.forEach(function (f) { pegar(f[0], f[1] + ' IN ' + inList(idsDe(rs))); }); }
    function ancestraisProcessos(ps) {
      var ms = ps.filter(function (p) { return p.macro_id; }).map(function (p) { return p.macro_id; });
      if (!ms.length) return;
      var mm = pegar('macroprocessos', 'id IN ' + inList(ms));
      var cs = mm.filter(function (m) { return m.ciclo_id; }).map(function (m) { return m.ciclo_id; });
      if (cs.length) pegar('cva_ciclos', 'id IN ' + inList(cs));
    }
    var todos = !ids || !ids.length, vis = {}, EXCL = { config: 1, usuarios: 1, organizacoes: 1, historico: 1, ahp_registros: 1 }, TT = tabelas();
    function numCol(t, c) { var r = DB.all('PRAGMA table_info(' + t + ')').filter(function (x) { return x.name === c; })[0]; return !!r && numerico(r.type); }
    /** Desce pelos vínculos: tudo que depende (por FK ou vínculo lógico) dos registros já coletados acompanha. */
    function descer(t, rs) {
      vis[t] = vis[t] || {}; rs = rs.filter(function (r) { if (r.id === undefined || vis[t][r.id]) return false; vis[t][r.id] = 1; return true; });
      if (!rs.length) return;
      var lst = inList(idsDe(rs));
      TT.forEach(function (c) {
        if (EXCL[c] || !/^[a-z0-9_]+$/i.test(c)) return;
        colunas(c).forEach(function (col) {
          if (col === 'id' || pai(c, col) !== t || !numCol(c, col)) return;
          if (c === t && col !== 'parent_id') return;
          var fr = pegar(c, col + ' IN ' + lst); if (fr.length) descer(c, fr);
        });
      });
      if (t === 'proj_tarefas') pegar('proj_deps', 'pred_id IN ' + lst + ' OR succ_id IN ' + lst);
    }
    /** Sobe pelos vínculos: os "pais" dos registros coletados (macroprocesso, ciclo, processo, projeto, mapa...) acompanham, sem arrastar os irmãos. */
    function subir() {
      var mudou = true, guarda = 0;
      while (mudou && guarda++ < 12) {
        mudou = false;
        Object.keys(sel).forEach(function (t) {
          colunas(t).forEach(function (col) {
            if (col === 'id' || !numCol(t, col)) return;
            var p = pai(t, col); if (!p || p === t || !existe(p) || EXCL[p]) return;
            var v = []; Object.keys(sel[t]).forEach(function (k) { if (k.charAt(0) === '#') return; var r = DB.one('SELECT ' + col + ' AS v FROM ' + t + ' WHERE id = ?', [k]); if (r && r.v) v.push(r.v); });
            v = v.filter(function (x) { return !(sel[p] && sel[p][x]); }); if (!v.length) return;
            var n0 = Object.keys(sel[p] || {}).length; pegar(p, 'id IN ' + inList(v)); if (Object.keys(sel[p] || {}).length > n0) mudou = true;
          });
        });
      }
    }
    var raiz;
    if (esc === 'processos') {
      raiz = pegar('processos', todos ? '' : 'id IN ' + inList(ids)); if (!raiz.length) throw new Error('Nenhum processo para exportar.');
      descer('processos', raiz);
    } else if (esc === 'projetos') {
      raiz = pegar('projetos', todos ? '' : 'id IN ' + inList(ids)); if (!raiz.length) throw new Error('Nenhum projeto para exportar.');
      descer('projetos', raiz);
      var cods = idsDe(raiz).map(function (i) { return "'PRJ-PROG-" + (parseInt(i, 10) || 0) + "'"; }).join(',');
      var pg = pegar('indicadores', 'codigo IN (' + cods + ')'); descer('indicadores', pg);
    } else if (esc === 'riscos') {
      raiz = pegar('riscos', todos ? '' : 'id IN ' + inList(ids)); if (!raiz.length) throw new Error('Nenhum risco para exportar.');
      descer('riscos', raiz);
    } else if (esc === 'indicadores') {
      raiz = pegar('indicadores', todos ? "COALESCE(codigo,'') NOT LIKE 'PRJ-PROG-%'" : 'id IN ' + inList(ids)); if (!raiz.length) throw new Error('Nenhum indicador para exportar.');
      descer('indicadores', raiz);
    }
    subir();
    var o = { formato: FORMATO, versao: VERSAO, escopo: esc, aplicativo: 'Valor-E ' + (w.APP_VERSAO || ''), gerado_em: new Date().toISOString(), tabelas: {}, seguranca: { integridade: 'sha256' } };
    Object.keys(sel).forEach(function (t) {
      if (!/^[a-z0-9_]+$/i.test(t)) return;
      var cs = colunas(t).filter(function (c) { return /^[a-z0-9_]+$/i.test(c); }), idsT = Object.keys(sel[t]).filter(function (k) { return k.charAt(0) !== '#'; });
      var rows = idsT.length ? DB.all('SELECT * FROM ' + t + ' WHERE id IN ' + inList(idsT) + ' ORDER BY id') : Object.keys(sel[t]).map(function (k) { return sel[t][k]; });
      if (rows.length) o.tabelas[t] = { colunas: cs, linhas: rows.map(function (r) { return cs.map(function (c) { return r[c]; }); }) };
    });
    return o;
  }
  function bytesParaB64(u) { var s = '', n = 0x8000; for (var i = 0; i < u.length; i += n) s += String.fromCharCode.apply(null, u.subarray(i, i + n)); return btoa(s); }
  function jsonStr(o) { return JSON.stringify(o, function (k, v) { return (v instanceof Uint8Array) ? { __b64: bytesParaB64(v) } : v; }); }
  function xesc(s) { return String(s).replace(/[&<>"\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, function (c) { return c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '"' ? '&quot;' : ''; }); }
  function xml(o) {
    var s = '<?xml version="1.0" encoding="UTF-8"?>\n<axia-pacote formato="' + FORMATO + '" versao="' + VERSAO + '"' + (o.escopo ? ' escopo="' + o.escopo + '"' : '') + ' gerado_em="' + o.gerado_em + '">\n';
    Object.keys(o.tabelas).forEach(function (t) {
      var T = o.tabelas[t]; s += '  <tabela nome="' + t + '" colunas="' + xesc(T.colunas.join(',')) + '">\n';
      T.linhas.forEach(function (l) { s += '    <linha>' + l.map(function (v) { return v === null || v === undefined ? '<c n="1"/>' : (v instanceof Uint8Array ? '<c b="1">' + bytesParaB64(v) + '</c>' : '<c>' + xesc(v) + '</c>'); }).join('') + '</linha>\n'; });
      s += '  </tabela>\n';
    });
    return s + '</axia-pacote>\n';
  }
  function deXml(txt) {
    var d = new DOMParser().parseFromString(txt, 'application/xml');
    if (d.getElementsByTagName('parsererror').length) throw new Error('O arquivo não é um XML válido.');
    var r = d.documentElement; if (r.nodeName !== 'axia-pacote' && r.nodeName !== 'nomika-pacote') return null;
    var o = { formato: FORMATO, versao: r.getAttribute('versao'), escopo: r.getAttribute('escopo') || null, tabelas: {} };
    Array.prototype.forEach.call(r.getElementsByTagName('tabela'), function (t) {
      var cs = (t.getAttribute('colunas') || '').split(',');
      o.tabelas[t.getAttribute('nome')] = { colunas: cs, linhas: Array.prototype.map.call(t.getElementsByTagName('linha'), function (l) {
        return Array.prototype.map.call(l.getElementsByTagName('c'), function (c) { if (c.getAttribute('n')) return null; if (c.getAttribute('b')) return { __b64: c.textContent }; return c.textContent; });
      }) };
    });
    return o;
  }
  function numerico(def) { return /INT|REAL|NUM|FLOA|DOUB/i.test(def || ''); }
  function aplicar(o, modo) {
    var res = { tabelas: {}, atualizados: {}, avisos: [] };
    if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote') || !o.tabelas) throw new Error('Arquivo não reconhecido como pacote do Valor-E.');
    if (o.escopo && modo === 'substituir') throw new Error('Pacote parcial (' + (ESCOPOS[o.escopo] || o.escopo) + ') só pode ser importado no modo Mesclar.');
    var existentes = tabelas(), nomes = ordenar(Object.keys(o.tabelas).filter(function (t) { return existentes.indexOf(t) >= 0; }));
    Object.keys(o.tabelas).forEach(function (t) { if (existentes.indexOf(t) < 0) res.avisos.push('Tabela desconhecida ignorada: ' + t); });
    var mapa = {}; DB.db.run('PRAGMA foreign_keys = OFF');
    try {
      DB.db.run('BEGIN');
      if (modo === 'substituir') existentes.forEach(function (t) { DB.db.run('DELETE FROM ' + t); });
      nomes.forEach(function (t) {
        var T = o.tabelas[t], cols = colunas(t), tipos = {}; DB.all('PRAGMA table_info(' + t + ')').forEach(function (c) { tipos[c.name] = c.type; });
        var temId = cols.indexOf('id') >= 0, n = 0, at = 0, pais = {}; cols.forEach(function (c) { pais[c] = pai(t, c); });
        mapa[t] = mapa[t] || {};
        T.linhas.forEach(function (l) {
          var reg = {}; T.colunas.forEach(function (c, i) { if (cols.indexOf(c) >= 0) { var v = l[i]; reg[c] = (v && typeof v === 'object' && v.__b64 !== undefined) ? (function (b) { var s = atob(b), u = new Uint8Array(s.length); for (var k = 0; k < s.length; k++) u[k] = s.charCodeAt(k); return u; })(v.__b64) : v; } });
          var antigo = reg.id;
          if (modo === 'mesclar') {
            cols.forEach(function (c) {
              if (c === 'id' || !pais[c] || reg[c] === null || reg[c] === undefined || reg[c] === '') return;
              if (o.escopo && !o.tabelas[pais[c]] && tipos[c] !== undefined && numerico(tipos[c])) { reg[c] = null; return; } // pai fora do pacote parcial
              var m = mapa[pais[c]]; if (!m) return;
              var novo = m[reg[c]]; reg[c] = novo !== undefined ? (numerico(tipos[c]) ? novo : String(novo)) : (numerico(tipos[c]) ? null : reg[c]);
            });
            if (t === 'cva_ciclos' && !reg.cadeia) reg.cadeia = 'Principal';
            if (t === 'config') { if (DB.one('SELECT 1 AS x FROM config WHERE chave = ?', [reg.chave])) return; }
            if (t === 'organizacoes' || t === 'usuarios') return;
            if (t === 'ahp_registros' || t === 'historico') return;
            // já existe? então atualiza
            var ch = CHAVES[t], ex = null;
            if (ch && temId) {
              var kk = ch.filter(function (c) { return cols.indexOf(c) >= 0; });
              if (kk.length && kk.some(function (c) { return reg[c] !== null && reg[c] !== undefined && reg[c] !== ''; })) {
                ex = DB.one('SELECT id FROM ' + t + ' WHERE ' + kk.map(function (c) { return c + ' IS ? COLLATE NOCASE'; }).join(' AND '), kk.map(function (c) { return reg[c] === undefined ? null : reg[c]; }));
              }
            }
            if (ex) {
              var up = Object.keys(reg).filter(function (c) { return c !== 'id' && c !== 'criado_em' && !(t === 'riscos' && c === 'codigo'); });
              try {
                if (up.length) DB.db.run('UPDATE ' + t + ' SET ' + up.map(function (c) { return c + ' = ?'; }).join(', ') + ' WHERE id = ?', up.map(function (c) { return reg[c]; }).concat([ex.id]));
                mapa[t][antigo] = ex.id; at++;
              } catch (e) { if (res.avisos.length < 12) res.avisos.push(t + ': ' + e.message); }
              return;
            }
            if (t === 'riscos' && reg.codigo && !E.codigoRiscoLivre(reg.codigo)) reg.codigo = E.proximoCodigoRisco();
            if (temId) delete reg.id;
          }
          var ks = Object.keys(reg);
          try {
            DB.db.run('INSERT INTO ' + t + ' (' + ks.join(',') + ') VALUES (' + ks.map(function () { return '?'; }).join(',') + ')', ks.map(function (c) { return reg[c]; }));
            if (temId) mapa[t][antigo] = modo === 'mesclar' ? DB.one('SELECT last_insert_rowid() AS i').i : antigo;
            n++;
          } catch (e) { if (res.avisos.length < 12) res.avisos.push(t + ': ' + e.message); }
        });
        res.tabelas[t] = n; res.atualizados[t] = at;
      });
      // indicadores de progresso de projetos: o código acompanha o novo id do projeto
      if (modo === 'mesclar' && mapa.projetos && mapa.indicadores && o.tabelas.indicadores) {
        var ic = o.tabelas.indicadores.colunas, ii = ic.indexOf('id'), ik = ic.indexOf('codigo'), mv = [];
        o.tabelas.indicadores.linhas.forEach(function (l) { var mm = /^PRJ-PROG-(\d+)$/.exec(String(l[ik] || '')); if (mm && mapa.projetos[mm[1]] !== undefined && mapa.indicadores[l[ii]] !== undefined) mv.push([mapa.indicadores[l[ii]], 'PRJ-PROG-' + mapa.projetos[mm[1]]]); });
        mv.forEach(function (p, k) { DB.db.run('UPDATE indicadores SET codigo = ? WHERE id = ?', ['~tmp' + k, p[0]]); });
        mv.forEach(function (p, k) { var outro = DB.one('SELECT id FROM indicadores WHERE codigo = ? AND id != ?', [p[1], p[0]]); if (outro) DB.db.run('DELETE FROM indicadores WHERE id = ?', [outro.id]); DB.db.run('UPDATE indicadores SET codigo = ? WHERE id = ?', [p[1], p[0]]); });
      }
      // vínculos que apontam para tabelas importadas depois (ex.: processos.validado_ciclo_id) já foram resolvidos pela ordem topológica
      DB.db.run('COMMIT');
    } catch (e) { try { DB.db.run('ROLLBACK'); } catch (x) {} DB.db.run('PRAGMA foreign_keys = ON'); throw e; }
    DB.db.run('PRAGMA foreign_keys = ON'); DB.sujo();
    return res;
  }
  var Pacote = w.Pacote = {
    coletar: coletar,
    exportarJson: function () {
      var o = coletar(), body = jsonStr(o);
      function baixa(txt) { Mapris.baixar('valore-' + E.hoje() + '.json', txt, 'application/json'); if (w.SEC) SEC.audit('exportar', 'json'); }
      if (w.SEC && SEC.sha256Hex) {
        SEC.sha256Hex(body).then(function (hash) {
          try { var j = JSON.parse(body); j.seguranca = j.seguranca || {}; j.seguranca.sha256 = hash; baixa(JSON.stringify(j)); }
          catch (e) { baixa(body); }
        });
      } else baixa(body);
    },
    escopos: ESCOPOS, listar: listar, coletarSeg: coletarSeg,
    exportarSeg: function (esc, ids, fmt) {
      var o = coletarSeg(esc, ids), nome = 'valore-' + esc + '-' + E.hoje();
      if (fmt === 'json') { Mapris.baixar(nome + '.json', jsonStr(o), 'application/json'); } else Mapris.baixar(nome + '.xml', xml(o), 'application/xml');
      if (w.SEC) SEC.audit('exportar', esc + ' ' + (fmt || 'xml'));
      return o;
    },
    segUI: function () {
      var esc = document.getElementById('segEsc').value, ls = listar(esc), box = document.getElementById('segLista');
      box.innerHTML = ls.length ? '<div class="form-check mb-1"><input class="form-check-input" type="checkbox" id="segTodos" checked onchange="Pacote.segTodos(this.checked)"><label class="form-check-label" for="segTodos"><b>Todos (' + ls.length + ')</b></label></div>' +
        ls.map(function (r) { return '<div class="form-check"><input class="form-check-input seg-i" type="checkbox" value="' + r.id + '" checked onchange="Pacote.segMarca()"><label class="form-check-label">' + (r.ref ? '<span class="text-muted">' + h(r.ref) + '</span> ' : '') + h(r.nome) + '</label></div>'; }).join('') : '<p class="text-muted mb-0">Nenhum registro cadastrado neste módulo.</p>';
      document.getElementById('segDica').textContent = {
        processos: 'Leva junto: macroprocesso e CVA de origem, bandeiras, riscos (com fatores, controles e planos) e indicadores (com itens, metas e registros) vinculados ao processo.',
        projetos: 'Leva junto: tarefas, dependências, recursos, linha de base, riscos do projeto e o indicador de progresso com seus registros.',
        riscos: 'Leva junto: fatores, controles, planos, monitoramentos, revisões e o processo/projeto de origem do risco.',
        indicadores: 'Leva junto: itens, ciclos de metas e todos os registros de valores, e o processo de origem do indicador.'
      }[esc];
    },
    segTodos: function (v) { Array.prototype.forEach.call(document.querySelectorAll('.seg-i'), function (c) { c.checked = v; }); },
    segMarca: function () { var a = document.querySelectorAll('.seg-i'), n = document.querySelectorAll('.seg-i:checked'); document.getElementById('segTodos').checked = a.length === n.length; },
    segExportar: function (fmt) {
      var esc = document.getElementById('segEsc').value, a = document.querySelectorAll('.seg-i'), n = document.querySelectorAll('.seg-i:checked');
      if (a.length && !n.length) return alert('Marque ao menos um registro.');
      try { var ids = a.length === n.length ? null : Array.prototype.map.call(n, function (c) { return c.value; }); var o = Pacote.exportarSeg(esc, ids, fmt);
        document.getElementById('segRes').textContent = 'Exportado: ' + Object.keys(o.tabelas).map(function (t) { return t + ' (' + o.tabelas[t].linhas.length + ')'; }).join(', '); }
      catch (e) { alert(e.message); }
    },
    exportarXml: function () { Mapris.baixar('valore-' + E.hoje() + '.xml', xml(coletar()), 'application/xml'); if (w.SEC) SEC.audit('exportar', 'xml'); },
    /** Lê o texto do arquivo, detecta o formato e importa. Retorna {res, legado}. */
    importarTexto: function (txt, modo) {
      if (w.SEC) SEC.validateImportText(txt);
      var xmlTxt = txt.trim().charAt(0) === '<', o = null;
      if (xmlTxt) o = deXml(txt); else { try { o = JSON.parse(txt); } catch (e) { throw new Error('Arquivo inválido.'); } }
      if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote')) return null;
      if (w.SEC && SEC.sanitizarObjeto) o = SEC.sanitizarObjeto(o);
      // rejeita tabelas com nomes suspeitos
      if (o.tabelas) {
        Object.keys(o.tabelas).forEach(function (t) {
          if (!/^[a-z0-9_]+$/i.test(t)) throw new Error('Pacote rejeitado: nome de tabela inválido (' + t + ').');
        });
      }
      if (w.SEC) SEC.audit('importar', (modo || 'mesclar') + ' pacote');
      return aplicar(o, modo);
    },
    resumo: function (r) { var ls = Object.keys(r.tabelas).filter(function (t) { return r.tabelas[t] || (r.atualizados && r.atualizados[t]); }).map(function (t) { return t + ': ' + r.tabelas[t] + ' novo(s), ' + ((r.atualizados && r.atualizados[t]) || 0) + ' atualizado(s)'; }); return ls.join('\n') + (r.avisos.length ? '\n\nAvisos:\n' + r.avisos.join('\n') : ''); },
    /** Cartão da tela de configurações. */
    cartao: function () {
      setTimeout(function () { if (document.getElementById('segEsc')) Pacote.segUI(); }, 30);
      var n = tabelas().reduce(function (s, t) { return s + DB.one('SELECT COUNT(*) AS n FROM ' + t).n; }, 0);
      var sec = (w.SEC && SEC.cartaoUI) ? SEC.cartaoUI(h) : '';
      return sec + '<div class="cartao mb-3"><h2><i class="bi bi-arrow-left-right"></i> Exportar e importar tudo</h2><div class="corpo">' +
        '<p class="ajuda">Inclui <b>todos os módulos</b>: CVA, processos (Folha de dados e diagramas), bandeiras e riscos, indicadores e registros, Valor Estratégico (objetivos, capacidades, dimensões, pesos) e parâmetros. Hoje há ' + n + ' registro(s).</p>' +
        '<div class="d-flex flex-wrap gap-2 mb-3"><button class="btn btn-success" onclick="Pacote.exportarJson()"><i class="bi bi-filetype-json"></i> Exportar tudo (.json)</button><button class="btn btn-outline-success" onclick="Pacote.exportarXml()"><i class="bi bi-filetype-xml"></i> Exportar tudo (.xml)</button><button class="btn btn-outline-secondary" onclick="Acoes.expBanco()"><i class="bi bi-database"></i> Cópia do banco (.sqlite)</button></div>' +
        '<h6>Exportar por módulo</h6><div class="row g-2 align-items-end mb-2"><div class="col-auto"><select class="form-select" id="segEsc" onchange="Pacote.segUI()">' + Object.keys(ESCOPOS).map(function (k) { return '<option value="' + k + '">' + ESCOPOS[k] + '</option>'; }).join('') + '</select></div><div class="col-auto"><button class="btn btn-success" onclick="Pacote.segExportar(\'xml\')"><i class="bi bi-filetype-xml"></i> Exportar seleção (.xml)</button> <button class="btn btn-outline-success" onclick="Pacote.segExportar(\'json\')"><i class="bi bi-filetype-json"></i> .json</button></div></div>' +
        '<p class="ajuda mb-1" id="segDica"></p><div id="segLista" class="border rounded p-2 mb-2" style="max-height:220px;overflow:auto"></div><pre id="segRes" class="small" style="white-space:pre-wrap"></pre>' +
        '<h6>Importar</h6><p class="ajuda mb-1">Serve para pacotes completos e por módulo. Pacotes por módulo só podem ser importados em <b>Mesclar</b>; os vínculos (riscos, indicadores, tarefas…) são refeitos.</p><div class="mb-2"><label class="me-3"><input type="radio" name="pmodo" value="mesclar" checked> <b>Mesclar</b> — o que já existe é <b>atualizado</b> e o que não existe é <b>criado</b> (vínculos são refeitos)</label><label><input type="radio" name="pmodo" value="substituir"> <b>Substituir tudo</b> — restaura o pacote e apaga o conteúdo atual</label></div>' +
        '<input type="file" class="form-control" id="pArq" accept=".json,.xml,.sqlite,.db" style="max-width:420px"><div class="mt-2"><button class="btn btn-warning" onclick="Pacote.importarArquivo()"><i class="bi bi-upload"></i> Importar arquivo</button></div><pre id="pRes" class="small mt-2" style="white-space:pre-wrap"></pre></div></div>';
    },
    importarArquivo: function () {
      var f = document.getElementById('pArq').files[0]; if (!f) return alert('Escolha um arquivo.');
      var modo = document.querySelector('input[name=pmodo]:checked').value;
      if (/\.(sqlite|db)$/i.test(f.name)) {
        if (f.size > ((w.SEC && SEC.MAX_IMPORT_BYTES) || 80*1024*1024)) return alert('Arquivo acima do limite de segurança.');
        if (!confirm('Substituir TODO o banco atual por este arquivo? Esta ação não pode ser desfeita.')) return;
        var fr0 = new FileReader(); fr0.onload = function () {
          try {
            var u = new Uint8Array(fr0.result);
            // SQLite magic "SQLite format 3"
            var mag = String.fromCharCode.apply(null, u.subarray(0, 15));
            if (mag.indexOf('SQLite format 3') !== 0) throw new Error('Não é um arquivo SQLite válido.');
            DB.substituir(u);
            if (w.SEC) SEC.audit('importar', 'sqlite substituir');
            alert('Banco restaurado.'); Nav.ir('#/');
          } catch (e) { alert('Arquivo inválido: ' + e.message); }
        }; fr0.readAsArrayBuffer(f); return;
      }
      if (modo === 'substituir' && !confirm('Isto APAGA o conteúdo atual e restaura o pacote. Continuar?')) return;
      var fr = new FileReader(); fr.onload = function () {
        try {
          var r = Pacote.importarTexto(String(fr.result), modo);
          if (r) { document.getElementById('pRes').textContent = 'Importação concluída (' + (modo === 'substituir' ? 'substituir' : 'mesclar') + ').\n' + Pacote.resumo(r); return; }
          Acoes.importar(f);   // formatos anteriores (riscos .xml/.json, processos)
        } catch (e) { document.getElementById('pRes').textContent = 'Erro: ' + e.message; }
      };
      fr.readAsText(f);
    }
  };
})(window);
