/* risco.js — formulário do risco (causas → controles → planos / monitoramento) */
window.iniciarRisco = function () {
  'use strict';
  var R = window.RISCO, CFG = window.CFG;
  R.fatores = R.fatores || [];
  var sujo = false, timer = null, salvando = false;

  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'class') e.className = attrs[k]; else if (k === 'html') e.innerHTML = attrs[k];
      else if (k.indexOf('on') === 0) e.addEventListener(k.slice(2), attrs[k]); else e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function $(id) { return document.getElementById(id); }

  // ---------- cálculo (espelha lib/matriz.php) ----------
  function nivelDe(idx) { return idx >= 20 ? 'Extremo' : idx >= 12 ? 'Alto' : idx >= 6 ? 'Médio' : idx >= 2 ? 'Baixo' : 'Muito Baixo'; }
  function clamp(v) { v = Math.round(+v || 3); return Math.max(1, Math.min(5, v)); }
  function ind(p, i) { p = clamp(p); i = clamp(i); return { p: p, i: i, idx: p * i, nivel: nivelDe(p * i) }; }
  function media(a) { return a.length ? a.reduce(function (s, x) { return s + x; }, 0) / a.length : null; }
  function calc() {
    var pm = [], im = [], ix = [], rp = [], ri = [], rx = [], ex = [], dx = [];
    R.fatores.forEach(function (f) {
      var m = ind(f.probabilidade, f.impacto); f._m = m; pm.push(m.p); im.push(m.i); ix.push(m.idx);
      var tp = [], ti = [], tx = [], xe = [], xd = [];
      (f.controles || []).forEach(function (c) {
        var mc = ind(c.prob_controle, c.imp_controle); c._m = mc; tp.push(mc.p); ti.push(mc.i); tx.push(mc.idx);
        if (c.tipo_controle === 'Preventivo' || c.tipo_controle === 'Detectivo') xe.push(mc.idx);
        if (c.tipo_controle === 'Corretivo') xd.push(mc.idx);
      });
      f._r = null;
      if (tp.length) { var pr = Math.round(media(tp)), ir = Math.round(media(ti)); f._r = ind(pr, ir); f._r.idx = Math.round(media(tx)); f._r.nivel = ind(pr, ir).nivel; rp.push(pr); ri.push(ir); rx.push(f._r.idx); }
      if (xe.length) ex.push(Math.round(media(xe)));
      if (xd.length) dx.push(Math.round(media(xd)));
    });
    var out = { inerente: null, residual: null, est: null, def: null };
    if (pm.length) { var p = Math.round(media(pm) * 100) / 100, i = Math.round(media(im) * 100) / 100; var m = ind(p, i); out.inerente = { p: p, i: i, idx: Math.round(media(ix)), nivel: m.nivel, pp: m.p, ii: m.i }; }
    if (rp.length) { var p2 = Math.round(media(rp) * 100) / 100, i2 = Math.round(media(ri) * 100) / 100; var m2 = ind(p2, i2); out.residual = { p: p2, i: i2, idx: Math.round(media(rx)), nivel: m2.nivel, pp: m2.p, ii: m2.i }; }
    if (ex.length) { var x = Math.round(media(ex)); out.est = { idx: x, nivel: nivelDe(x) }; }
    if (dx.length) { var y = Math.round(media(dx)); out.def = { idx: y, nivel: nivelDe(y) }; }
    return out;
  }

  // ---------- componentes ----------
  function badge(n, txt) { return '<span class="nv ' + (n ? n.replace(' ', '-') : 'nd') + '">' + (txt || n || '—') + '</span>'; }
  function sel(opts, val, on, cls) {
    var s = el('select', { class: cls || 'form-select form-select-sm' });
    opts.forEach(function (o) { var v = Array.isArray(o) ? o[0] : o, t = Array.isArray(o) ? o[1] : o; var op = el('option', { value: v }, [String(t)]); if (String(v) === String(val)) op.selected = true; s.appendChild(op); });
    s.addEventListener('change', function () { on(s.value); });
    return s;
  }
  function inp(val, on, attrs) {
    var i = el('input', Object.assign({ class: 'form-control form-control-sm' }, attrs || {})); i.value = val == null ? '' : val;
    i.addEventListener('input', function () { on(i.value); }); return i;
  }
  function area(val, on, rows, ph) {
    var t = el('textarea', { class: 'form-control form-control-sm', rows: rows || 2, placeholder: ph || '' }); t.value = val || '';
    t.addEventListener('input', function () { on(t.value); }); return t;
  }
  function dat(val, on) { return Mapris.campoData(val, on); }
  function campo(rot, ctl, cls) { return el('div', { class: cls || '' }, [el('label', { class: 'lbl' }, [rot]), ctl]); }
  var PROB = [1, 2, 3, 4, 5].map(function (n) { return [n, n + ' — ' + CFG.rotProb[n]]; });
  var IMP = [1, 2, 3, 4, 5].map(function (n) { return [n, n + ' — ' + CFG.rotImp[n]]; });

  function mudou() { sujo = true; $('st').textContent = 'Alterações pendentes…'; clearTimeout(timer); timer = setTimeout(function () { salvar(false); }, 1600); atualizar(); }

  function planoRow(c, p) {
    var row = el('div', { class: 'linha-sub pl' }, [
      area(p.descricao, function (v) { p.descricao = v; mudou(); }, 1, 'Ação a realizar'),
      inp(p.responsavel, function (v) { p.responsavel = v; mudou(); }, { placeholder: 'Responsável' }),
      dat(p.prazo, function (v) { p.prazo = v; mudou(); }),
      sel(['Pendente', 'Em Andamento', 'Concluído', 'Cancelado'], p.status || 'Pendente', function (v) { p.status = v; mudou(); }),
      sel(['Alta', 'Média', 'Baixa'], p.prioridade || 'Média', function (v) { p.prioridade = v; mudou(); }),
      inp(p.observacoes, function (v) { p.observacoes = v; mudou(); }, { placeholder: 'Observações' }),
      el('button', { class: 'btn-mini del', type: 'button', title: 'Remover', onclick: function () { c.planos.splice(c.planos.indexOf(p), 1); desenhar(); mudou(); } }, ['✕'])]);
    return row;
  }
  function monRow(c, m) {
    return el('div', { class: 'linha-sub mo' }, [
      dat(m.data, function (v) { m.data = v; mudou(); }),
      area(m.acao, function (v) { m.acao = v; mudou(); }, 1, 'Ação de monitoramento'),
      area(m.resultado, function (v) { m.resultado = v; mudou(); }, 1, 'Resultado'),
      inp(m.evidencias, function (v) { m.evidencias = v; mudou(); }, { placeholder: 'Evidências' }),
      el('button', { class: 'btn-mini del', type: 'button', title: 'Remover', onclick: function () { c.monitoramentos.splice(c.monitoramentos.indexOf(m), 1); desenhar(); mudou(); } }, ['✕'])]);
  }

  function controleCard(f, c, n) {
    c.planos = c.planos || []; c.monitoramentos = c.monitoramentos || [];
    var b = el('span', { 'data-b': 'c' });
    var card = el('div', { class: 'controle' });
    var dica = el('div', { class: 'dica' }, [CFG.tiposDesc[c.tipo_controle || 'Preventivo']]);
    card.appendChild(el('div', { class: 'controle-h' }, [
      el('b', {}, ['Controle ' + n]),
      sel(['Preventivo', 'Detectivo', 'Corretivo'], c.tipo_controle || 'Preventivo', function (v) { c.tipo_controle = v; dica.textContent = CFG.tiposDesc[v]; mudou(); }),
      sel(['Manual', 'Semi-automático', 'Automático'], c.natureza || 'Manual', function (v) { c.natureza = v; mudou(); }),
      sel(['Planejado', 'Em Implementação', 'Implementado', 'Cancelado'], c.status || 'Planejado', function (v) { c.status = v; mudou(); }),
      el('span', { class: 'ms-auto' }), b,
      el('button', { class: 'btn-mini del', type: 'button', title: 'Remover controle', onclick: function () { if (confirm('Remover este controle?')) { f.controles.splice(f.controles.indexOf(c), 1); desenhar(); mudou(); } } }, ['✕'])]));
    card.appendChild(dica);
    card.appendChild(area(c.descricao, function (v) { c.descricao = v; mudou(); }, 2, 'Descrição do controle'));
    var g = el('div', { class: 'row g-2 mt-1' }, [
      campo('Probabilidade após o controle', sel(PROB, c.prob_controle || 3, function (v) { c.prob_controle = +v; mudou(); }), 'col-md-3'),
      campo('Impacto após o controle', sel(IMP, c.imp_controle || 3, function (v) { c.imp_controle = +v; mudou(); }), 'col-md-3'),
      campo('Eficácia (%)', inp(c.eficacia, function (v) { c.eficacia = v; mudou(); }, { type: 'number', min: 0, max: 100, step: 5 }), 'col-md-2'),
      campo('Responsável', inp(c.responsavel, function (v) { c.responsavel = v; mudou(); }), 'col-md-4'),
      campo('Prazo de implantação', dat(c.prazo, function (v) { c.prazo = v; mudou(); }), 'col-md-3'),
      campo('Implementado em', dat(c.data_implementacao, function (v) { c.data_implementacao = v; mudou(); }), 'col-md-3'),
      campo('Observações', inp(c.observacoes, function (v) { c.observacoes = v; mudou(); }), 'col-md-6')]);
    card.appendChild(g);
    var sp = el('div', { class: 'sub' }, [el('h4', {}, ['Planos de ação', el('button', { class: 'btn btn-outline-success btn-sm', type: 'button', onclick: function () { c.planos.push({ descricao: '', status: 'Pendente', prioridade: 'Média' }); desenhar(); mudou(); } }, ['+ Plano'])])]);
    c.planos.forEach(function (p) { sp.appendChild(planoRow(c, p)); });
    card.appendChild(sp);
    var sm = el('div', { class: 'sub' }, [el('h4', {}, ['Monitoramento', el('button', { class: 'btn btn-outline-success btn-sm', type: 'button', onclick: function () { c.monitoramentos.push({ data: Mapris.hojeIso() }); desenhar(); mudou(); } }, ['+ Registro'])])]);
    c.monitoramentos.forEach(function (m) { sm.appendChild(monRow(c, m)); });
    card.appendChild(sm);
    c._b = b;
    return card;
  }

  function fatorCard(f, n) {
    f.controles = f.controles || [];
    var b = el('span'), br = el('span');
    var card = el('div', { class: 'fator' });
    card.appendChild(el('div', { class: 'fator-h' }, [
      el('span', { class: 'ord' }, ['Causa ' + n]),
      el('input', { class: 'form-control form-control-sm nome', placeholder: 'Descreva a causa (fator de risco)', value: f.nome || '', oninput: function (e) { f.nome = e.target.value; mudou(); } }),
      el('label', { class: 'lbl mb-0' }, ['P']), sel(PROB, f.probabilidade || 3, function (v) { f.probabilidade = +v; mudou(); }, 'form-select form-select-sm w-auto'),
      el('label', { class: 'lbl mb-0' }, ['I']), sel(IMP, f.impacto || 3, function (v) { f.impacto = +v; mudou(); }, 'form-select form-select-sm w-auto'),
      b, br,
      el('button', { class: 'btn-mini del', type: 'button', title: 'Remover causa', onclick: function () { if (confirm('Remover esta causa e seus controles?')) { R.fatores.splice(R.fatores.indexOf(f), 1); desenhar(); mudou(); } } }, ['✕'])]));
    var body = el('div', { class: 'fator-c' });
    body.appendChild(area(f.descricao, function (v) { f.descricao = v; mudou(); }, 2, 'Detalhes da causa (opcional)'));
    f.controles.forEach(function (c, i) { body.appendChild(controleCard(f, c, i + 1)); });
    body.appendChild(el('button', { class: 'btn btn-outline-success btn-sm mt-2', type: 'button', onclick: function () { f.controles.push({ tipo_controle: 'Preventivo', natureza: 'Manual', status: 'Planejado', prob_controle: 3, imp_controle: 3, eficacia: 0, planos: [], monitoramentos: [] }); desenhar(); mudou(); } }, ['+ Controle']));
    card.appendChild(body);
    f._b = b; f._br = br;
    return card;
  }

  function desenhar() {
    var box = $('fatores'); box.innerHTML = '';
    R.fatores.forEach(function (f, i) { box.appendChild(fatorCard(f, i + 1)); });
    $('semFatores').style.display = R.fatores.length ? 'none' : '';
    atualizar();
  }

  function sugestoes() {
    var cat = $('f_categoria').value, box = $('sug'); box.innerHTML = '';
    (CFG.sugestoes[cat] || []).forEach(function (t) {
      box.appendChild(el('span', { class: 'chip', title: 'Adicionar como causa', onclick: function () { R.fatores.push({ nome: t, probabilidade: 3, impacto: 3, controles: [] }); desenhar(); mudou(); } }, ['+ ' + t]));
    });
  }

  function heatMini(res) {
    var o = '<div class="heatw" style="max-width:300px"><div class="ylab"><span>Probabilidade</span></div><div class="yt">';
    for (var p = 5; p >= 1; p--) o += '<i>' + p + '</i>';
    o += '</div><div class="heat">';
    for (p = 5; p >= 1; p--) for (var i = 1; i <= 5; i++) {
      var n = nivelDe(p * i).replace(' ', '-'), mark = '';
      if (res.inerente && res.inerente.pp === p && res.inerente.ii === i) mark += '<b class="mk">●</b>';
      if (res.residual && res.residual.pp === p && res.residual.ii === i) mark += '<b class="mk">◆</b>';
      o += '<div class="c ' + n + '"><small>' + (p * i) + '</small>' + mark + '</div>';
    }
    o += '</div><div></div><div></div><div class="xt">';
    for (i = 1; i <= 5; i++) o += '<i>' + i + '</i>';
    return o + '</div><div></div><div></div><div class="xlab">Impacto</div></div><div class="ajuda mt-2">● inerente &nbsp; ◆ residual</div>';
  }

  function atualizar() {
    var res = calc();
    R.fatores.forEach(function (f) {
      if (f._b) f._b.innerHTML = badge(f._m.nivel, 'Inerente ' + f._m.idx + ' · ' + f._m.nivel);
      if (f._br) f._br.innerHTML = f._r ? badge(f._r.nivel, 'Residual ' + f._r.idx + ' · ' + f._r.nivel) : '';
      (f.controles || []).forEach(function (c) { if (c._b) c._b.innerHTML = badge(c._m.nivel, 'Após controle ' + c._m.idx + ' · ' + c._m.nivel); });
    });
    var h = '';
    function lin(t, o) { return '<div class="res-lin"><span>' + t + '</span><span>' + (o ? badge(o.nivel, o.nivel + ' · ' + o.idx) : badge(null)) + '</span></div>'; }
    h += lin('Risco inerente', res.inerente);
    if (res.inerente) h += '<div class="ajuda mb-2">Probabilidade média ' + res.inerente.p + ' · Impacto médio ' + res.inerente.i + '</div>';
    h += lin('Risco residual (todos os controles)', res.residual);
    h += lin('Residual estimado (preventivos e detectivos)', res.est);
    h += lin('Residual definitivo (corretivos)', res.def);
    h += '<div class="mt-3">' + heatMini(res) + '</div>';
    h += '<div class="ajuda mt-3"><b>Como é calculado:</b> índice = probabilidade × impacto (1–5). Extremo ≥ 20 · Alto ≥ 12 · Médio ≥ 6 · Baixo ≥ 2. O risco usa a média das causas.</div>';
    $('resumo').innerHTML = h;
    veredito(res);
    $('tituloPag').textContent = (R.nome ? R.nome : (R.id ? 'Editar risco' : 'Novo risco'));
  }

  var ORD = ['Muito Baixo', 'Baixo', 'Médio', 'Alto', 'Extremo'];
  function veredito(res) {
    var box = $('veredito'); if (!box) return;
    var at = res.residual || res.inerente;
    if (!at) { box.className = 'avaliacao'; box.innerHTML = '<i class="bi bi-info-circle"></i> Cadastre ao menos uma causa para avaliar o risco em relação ao apetite (<b>' + CFG.apetite + '</b>).'; return; }
    var acima = ORD.indexOf(at.nivel) > ORD.indexOf(CFG.apetite);
    box.className = 'avaliacao ' + (acima ? 'acima' : 'dentro');
    box.innerHTML = acima
      ? '<i class="bi bi-exclamation-octagon-fill"></i> <b>Acima do apetite.</b> O nível ' + (res.residual ? 'residual ' : '') + '<b>' + at.nivel + '</b> excede o apetite (<b>' + CFG.apetite + '</b>): é necessário tratar (evitar, reduzir ou compartilhar) ou aceitar formalmente.'
      : '<i class="bi bi-check-circle-fill"></i> <b>Dentro do apetite.</b> O nível ' + (res.residual ? 'residual ' : '') + '<b>' + at.nivel + '</b> está dentro do apetite (<b>' + CFG.apetite + '</b>). Mantenha monitoramento e revisões em dia.';
  }
  var SEVROT = { critico: 'Crítico', atencao: 'Atenção', aviso: 'Aviso' }, SEVIC = { critico: 'bi-exclamation-octagon-fill', atencao: 'bi-exclamation-triangle-fill', aviso: 'bi-info-circle-fill' };
  function esc(t) { var d = document.createElement('div'); d.textContent = t == null ? '' : t; return d.innerHTML; }
  function renderAlertas(lista) {
    var box = $('alertas'); if (!box) return;
    if (!R.id) { box.innerHTML = '<div class="ajuda">Os alertas aparecem assim que o risco for salvo.</div>'; return; }
    if (!lista || !lista.length) { box.innerHTML = '<div class="ok-alerta"><i class="bi bi-shield-check"></i> Nenhum alerta. Este risco está em dia.</div>'; return; }
    box.innerHTML = lista.map(function (a) {
      return '<div class="alerta-mini ' + a.sev + '"><div class="ti"><i class="bi ' + SEVIC[a.sev] + '"></i> ' + esc(a.titulo) + '</div><div class="pv">' + esc(a.prov) + '</div></div>';
    }).join('');
  }
  function renderRevisoes() {
    $('ultRev').textContent = R.ultima_revisao ? Mapris.isoToBr(R.ultima_revisao) : 'Nunca revisado';
    var h = (R.revisoes || []);
    $('histRev').innerHTML = h.length ? '<div class="lbl">Histórico de revisões</div><table class="mini"><thead><tr><th>Data</th><th>Inerente</th><th>Residual</th><th>Parecer</th></tr></thead><tbody>' +
      h.map(function (x) { return '<tr><td>' + Mapris.isoToBr(x.data) + '</td><td>' + (x.nivel_inerente ? badge(x.nivel_inerente) : '—') + '</td><td>' + (x.nivel_residual ? badge(x.nivel_residual) : '—') + '</td><td>' + esc(x.parecer || '') + '</td></tr>'; }).join('') + '</tbody></table>' : '';
  }
  window.revisarAgora = function () {
    var go = function () {
      if (!R.id) { alert('Preencha o ambiente e o evento de risco para poder registrar a revisão.'); return; }
      Mapris.revisar(R.id, R.nome, function (r) {
        R.ultima_revisao = r.ultima_revisao; R.proxima_revisao = r.proxima_revisao; R.revisoes = r.revisoes;
        if (slotProx) { slotProx.innerHTML = ''; slotProx.appendChild(dat(R.proxima_revisao, function (v) { R.proxima_revisao = v; mudou(); })); }
        renderRevisoes(); renderAlertas(r.alertas);
      });
    };
    if (!R.id) salvar(true).then(go); else if (sujo) salvar(false).then(go); else go();
  };

  // ---------- persistência ----------
  function limpo() { return JSON.parse(JSON.stringify(R, function (k, v) { return k.charAt(0) === '_' ? undefined : v; })); }
  function salvar(manual) {
    if (salvando) { if (manual) setTimeout(function () { salvar(true); }, 500); return Promise.resolve(); }
    if (!R.ambiente.trim() || !R.nome.trim()) {
      $('st').textContent = 'Preencha o ambiente de análise e o evento de risco para salvar.';
      if (manual) alert('Preencha o ambiente de análise e o evento de risco para salvar.');
      return Promise.resolve();
    }
    if (R.processo_id && R._elem) { var _el = E.processoElementos(R.processo_id).filter(function (x) { return x.id === R._elem; })[0]; R.flag_id = E.flagDoElemento(R.processo_id, R._elem, _el ? _el.nome : ''); R._elem = ''; }
    else if (R._elem === '' && R.flag_id && R.processo_id) { /* mantém */ }
    salvando = true; clearTimeout(timer); $('st').textContent = 'Salvando…';
    return Mapris.api('salvar', limpo()).then(function (r) {
        salvando = false;
        if (!r.ok) { $('st').textContent = 'Erro ao salvar'; sujo = false; alert(r.erro || 'Erro ao salvar'); return; }
        sujo = false;
        if (r.risco && !R.proxima_revisao && r.risco.proxima_revisao) { R.proxima_revisao = r.risco.proxima_revisao; if (slotProx) { slotProx.innerHTML = ''; slotProx.appendChild(dat(R.proxima_revisao, function (v) { R.proxima_revisao = v; mudou(); })); } }
        if (!R.id) { R.id = r.id; history.replaceState(null, '', '#/risco?id=' + r.id); Nav.atual = '#/risco?id=' + r.id; $('bDup').disabled = false; $('bDel').disabled = false; }
        renderAlertas(r.alertas);
        $('st').textContent = 'Salvo às ' + new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      }).catch(function (e) { salvando = false; $('st').textContent = 'Erro ao salvar'; });
  }
  window.salvar = salvar;
  window.addFator = function () { R.fatores.push({ nome: '', probabilidade: 3, impacto: 3, controles: [] }); desenhar(); mudou(); };
  window.excluir = function () {
    if (!R.id || !confirm('Excluir este risco? Esta ação não pode ser desfeita.')) return;
    Mapris.api('excluir', { id: R.id }).then(function (r) { sujo = false; if (r.ok) Nav.ir('#/riscos'); else alert(r.erro); });
  };
  window.duplicar = function () {
    salvar(false).then(function () {
      Mapris.api('duplicar', { id: R.id }).then(function (r) { if (r.ok) { sujo = false; Nav.ir('#/risco?id=' + r.id); } else alert(r.erro); });
    });
  };
  window.__riscoSair = function () { clearTimeout(timer); return (sujo && R.nome && R.ambiente) ? salvar(false) : Promise.resolve(); };

  // ---------- campos do topo ----------
  var slotProx = $('slotProxRev');
  function respostaUI() {
    $('dicaResposta').textContent = CFG.respostasDesc[R.resposta] || 'Escolha entre evitar, reduzir, compartilhar ou aceitar o risco.';
    $('blocoAceite').style.display = R.resposta === 'Aceitar' ? '' : 'none';
  }
  if (!R.id && !R.codigo) R.codigo = E.proximoCodigoRisco();
  ['codigo', 'ambiente', 'nome', 'objetivo', 'partes', 'categoria', 'status', 'resposta', 'resposta_just', 'aceite_por', 'responsavel', 'descricao', 'consequencias'].forEach(function (k) {
    var e = $('f_' + k); e.value = R[k] || '';
    var h = function () { R[k] = e.value; if (k === 'categoria') sugestoes(); if (k === 'resposta') respostaUI(); mudou(); };
    e.addEventListener('input', h); e.addEventListener('change', h);
  });
  // ---------- vínculo com o mapa (processo / flag) ----------
  function flagsOpts() {
    var cid = parseInt($('f_processo_id').value, 10) || 0, sel = $('f_flag_id');
    var fl0 = R.flag_id ? E.flagCarregar(R.flag_id) : null, atual = R._elem || (fl0 ? fl0.elemento : '');
    var els = cid ? E.processoElementos(cid) : [];
    sel.innerHTML = '<option value="">' + (cid ? (els.length ? '— risco do processo em geral (sem atividade) —' : '— o processo ainda não tem diagrama —') : '— escolha um processo —') + '</option>' + els.map(function (x) { return '<option value="' + esc(x.id) + '"' + (x.id === atual ? ' selected' : '') + '>' + esc(x.nome || '(' + x.tipo + ' sem nome)') + '</option>'; }).join('');
    sel.disabled = !cid;
    var ab = $('f_ambiente'); ab.readOnly = !!cid;
    if (cid) { var c2 = E.processoCarregar(cid); if (c2) { R.ambiente = c2.nome; ab.value = c2.nome; } }
    var v = $('verMapa'); v.style.display = cid ? '' : 'none'; v.href = '#/diagrama?id=' + cid;
  }
  $('f_processo_id').addEventListener('change', function () { R.processo_id = parseInt(this.value, 10) || null; R.flag_id = null; R._elem = ''; flagsOpts(); mudou(); });
  $('f_flag_id').addEventListener('change', function () { R._elem = this.value; R.flag_id = null; mudou(); });
  $('slotAceiteVal').appendChild(dat(R.aceite_validade, function (v) { R.aceite_validade = v; mudou(); }));
  slotProx.appendChild(dat(R.proxima_revisao, function (v) { R.proxima_revisao = v; mudou(); }));
  flagsOpts(); respostaUI(); renderRevisoes(); renderAlertas(window.ALERTAS);
  sujo = false; $('st').textContent = 'Pronto';
  sugestoes(); desenhar();
};
