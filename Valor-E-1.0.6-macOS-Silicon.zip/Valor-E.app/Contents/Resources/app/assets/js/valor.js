/* valor.js — módulo Valor Estratégico: objetivos estratégicos → capacidades → dimensões → indicadores (lista do módulo Indicadores). */
(function (w) {
  'use strict';
  function reg(rota, chave, titulo) { Modulos.registrar(rota, { ativo: 'valor', titulo: titulo, html: function (q) { return UI.render(chave, q); } }); }
  reg('/valor', 'dashboard', 'Valor Estratégico'); reg('/valor/capacidade', 'capacidade', 'Capacidade'); reg('/valor/objetivos', 'objetivos', 'Objetivos e ICV');
  reg('/valor/monitoramento', 'monitoramento', 'Monitoramento'); reg('/valor/validacao', 'validacao', 'Verificação'); reg('/valor/relatorio', 'relatorio', 'Relatório do Valor Estratégico');
  w.Val = {
    resumo: function () {
      var os = DB.all('SELECT id FROM objetivos_estrategicos'), v = [];
      os.forEach(function (o) { try { var r = MET.icvObjetivo(o.id); if (r && r.icv != null) v.push(r.icv); } catch (e) {} });
      return { objetivos: os.length, capacidades: DB.one('SELECT COUNT(*) AS n FROM capacidades').n, icv: v.length ? v.reduce(function (a, b) { return a + b; }, 0) / v.length : null };
    }
  };
})(window);
