/* telas_processos.js — módulo Processos: lista, novo, importar Folha, exclusão sincronizada com riscos e indicadores. */
(function (w) {
  'use strict';
  var h = E.esc;
  function macrosAgrupados(sel, cadeia) {
    var l = DB.all("SELECT m.id, m.nome, m.tipo, c.cadeia FROM macroprocessos m JOIN cva_ciclos c ON c.id = m.ciclo_id WHERE c.status = 'Vigente'" + (cadeia ? ' AND c.cadeia = ?' : '') + " ORDER BY c.cadeia, m.tipo, m.ordem, m.nome", cadeia ? [cadeia] : []);
    if (!l.length) l = DB.all('SELECT m.id, m.nome, m.tipo, c.cadeia FROM macroprocessos m JOIN cva_ciclos c ON c.id = m.ciclo_id ORDER BY c.cadeia, m.tipo, m.ordem, m.nome');
    var varias = (w.Cva && Cva.cadeias ? Cva.cadeias().length : 1) > 1, g = {}, ord = [], o = '';
    l.forEach(function (m) { var k = (varias ? (m.cadeia || 'Principal') + ' › ' : '') + m.tipo + 's'; if (!g[k]) { g[k] = []; ord.push(k); } g[k].push(m); });
    ord.forEach(function (k) { o += '<optgroup label="' + h(k) + '">' + g[k].map(function (m) { return '<option value="' + m.id + '"' + (String(sel) === String(m.id) ? ' selected' : '') + '>' + h(m.nome) + '</option>'; }).join('') + '</optgroup>'; });
    return o;
  }
  w.macrosAgrupados = macrosAgrupados;

  function html(q) {
    var l = E.processosListar({ q: q.q || '', macro: q.macro || '', cadeia: q.cadeia || '' }), cads = (w.Cva && Cva.cadeias) ? Cva.cadeias() : [];
    var tem = DB.one('SELECT COUNT(*) AS n FROM processos').n;
    var o = '<div class="pagina"><div class="d-flex flex-wrap align-items-center mb-3"><h1 class="h4 mb-0 me-auto"><i class="bi bi-diagram-3"></i> Processos</h1>' +
      '<form class="filtros d-flex flex-wrap align-items-center" style="margin-right:8px"><input class="form-control form-control-sm" name="q" value="' + h(q.q || '') + '" placeholder="Buscar processo…" style="width:200px;margin-right:6px">' +
      (cads.length > 1 ? '<select class="form-select form-select-sm" name="cadeia" title="Cadeia de valor" style="width:190px;margin-right:6px"><option value="">Todas as cadeias</option>' + cads.map(function (x) { return '<option value="' + h(x) + '"' + (q.cadeia === x ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select>' : '') + '<select class="form-select form-select-sm" name="macro" style="width:200px;margin-right:6px"><option value="">Todos os macroprocessos</option>' + macrosAgrupados(q.macro, q.cadeia) + '</select><button class="btn btn-sm btn-outline-secondary">Filtrar</button></form>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="document.getElementById(\'impFolha\').click()"><i class="bi bi-upload"></i> Importar Folha (.xml)</button><input type="file" id="impFolha" accept=".xml" hidden>' +
      '<button class="btn btn-success btn-sm" onclick="Proc.novo()"><i class="bi bi-plus-lg"></i> Novo processo</button></div>';
    if (!l.length) o += '<div class="cartao"><div class="vazio">' + (tem ? 'Nenhum processo encontrado com o filtro.' : 'Nenhum processo cadastrado. Clique em <b>Novo processo</b> para preencher a Folha de dados e gerar o diagrama BPMN, onde você marca os riscos nas atividades.') + '</div></div>';
    else {
      o += '<div class="cartao"><div class="table-responsive"><table class="tabela"><thead><tr><th>Processo</th><th>Macroprocesso</th><th>Status</th><th class="text-center" title="Bandeiras de risco no diagrama">Bandeiras</th><th class="text-center">Riscos</th><th class="text-center">Indicadores</th><th>Atualizado</th><th></th></tr></thead><tbody>';
      l.forEach(function (c) {
        o += '<tr><td><a href="#/folha?id=' + c.id + '"><b>' + h(c.nome) + '</b></a></td><td>' + (c.macro_nome ? h(c.macro_nome) + (cads.length > 1 && c.cadeia ? ' <small class="text-muted">· ' + h(c.cadeia) + '</small>' : '') : '<span class="text-muted">—</span>') + '</td><td>' + h(c.status || '') + '</td>' +
          '<td class="text-center">' + c.n_flags + '</td><td class="text-center">' + (c.n_riscos ? '<a href="#/riscos?processo=' + c.id + '">' + c.n_riscos + '</a>' : 0) + '</td><td class="text-center">' + (c.n_ind ? '<a href="#/indicadores?processo=' + c.id + '">' + c.n_ind + '</a>' : 0) + '</td>' +
          '<td>' + h(E.dataBr(String(c.atualizado_em || '').slice(0, 10))) + '</td><td class="text-end text-nowrap">' +
          '<a class="btn btn-sm btn-outline-success" href="#/folha?id=' + c.id + '" title="Folha de dados"><i class="bi bi-file-earmark-text"></i> Folha</a> ' +
          '<a class="btn btn-sm btn-outline-success" href="#/diagrama?id=' + c.id + '" title="Diagrama BPMN e riscos"><i class="bi bi-diagram-3"></i> Diagrama</a> ' +
          '<a class="btn btn-sm btn-outline-primary" href="#/indicador?novo=1&processo=' + c.id + '" title="Novo indicador deste processo"><i class="bi bi-graph-up-arrow"></i> Indicador</a> ' +
          '<button class="btn btn-sm btn-outline-secondary" onclick="Proc.exportar(' + c.id + ')" title="Exportar Folha (.xml)"><i class="bi bi-download"></i></button> ' +
          '<button class="btn btn-sm btn-outline-danger" onclick="Proc.excluir(' + c.id + ')" title="Excluir"><i class="bi bi-trash"></i></button></td></tr>';
      });
      o += '</tbody></table></div></div>';
    }
    return o + '</div>';
  }
  function apos() {
    var f = document.getElementById('impFolha');
    if (f) f.addEventListener('change', function (e) {
      var a = e.target.files[0]; if (!a) return;
      var fr = new FileReader(); fr.onload = function () {
        var r = API.acao('importar_xml', { xml: String(fr.result) });
        if (!r.ok) return alert(r.erro);
        if (r.avisos && r.avisos.length) alert('Importado com avisos:\n' + r.avisos.join('\n'));
        Nav.ir('#/folha?id=' + r.id);
      };
      fr.readAsText(a);
    });
  }
  var Proc = w.Proc = {
    novo: function () {
      var nome = prompt('Nome do novo processo:'); if (nome === null) return;
      try { var id = E.processoSalvar({ nome: nome }); Nav.ir('#/folha?id=' + id); } catch (e) { alert(e.message); }
    },
    exportar: function (id) { var r = API.acao('exportar_xml', { id: id }); if (r.ok) Common.baixar(r.nome, r.texto, r.tipo); else alert(r.erro); },
    excluir: function (id) {
      var c = E.processoCarregar(id); if (!c) return;
      var nr = DB.one('SELECT COUNT(*) AS n FROM riscos WHERE processo_id = ?', [id]).n, modo = 'riscos';
      if (!confirm('Excluir o processo "' + c.nome + '" (Folha de dados e diagrama)?')) return;
      if (nr) modo = confirm(nr + ' risco(s) estão vinculados a este processo.\n\nOK = excluir também esses riscos.\nCancelar = manter os riscos (sem vínculo, com o ambiente preservado).') ? 'riscos' : 'manter';
      E.processoExcluir(id, modo);
      if (w.Ind && Ind.excluirVinculoProcesso) Ind.excluirVinculoProcesso(id);
      Nav.ir('#/processos');
    }
  };
  Modulos.registrar('/processos', { ativo: 'processos', titulo: 'Processos', html: html, apos: apos });
})(window);
