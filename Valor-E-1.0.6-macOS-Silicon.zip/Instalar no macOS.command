#!/bin/bash
cd "$(dirname "$0")" || exit 1
APP="Valor-E.app"
if [ ! -d "$APP" ]; then
  echo "Valor-E.app não encontrado nesta pasta."
  read -n 1 -s -r -p "Pressione qualquer tecla..."
  exit 1
fi
echo "Instalando Valor-E em /Applications ..."
# remove quarantine so Gatekeeper is less noisy for local builds
xattr -cr "$APP" 2>/dev/null
rm -rf "/Applications/Valor-E.app"
cp -R "$APP" /Applications/
xattr -cr "/Applications/Valor-E.app" 2>/dev/null
# ad-hoc sign so it opens more easily on modern macOS
codesign --force --deep --sign - "/Applications/Valor-E.app" 2>/dev/null
echo ""
echo "Pronto. Versão:"
cat "/Applications/Valor-E.app/Contents/Resources/app/VERSION" 2>/dev/null
echo ""
echo "Abrindo o Valor-E..."
open "/Applications/Valor-E.app"
read -n 1 -s -r -p "Pressione qualquer tecla para fechar..."
