#!/bin/bash
# Execute ESTE script em um Mac (tem hdiutil). Gera DMG arrastável.
cd "$(dirname "$0")" || exit 1
VER="1.0.6"
APP="Valor-E.app"
[ -d "$APP" ] || { echo "Valor-E.app ausente"; exit 1; }
TMP=$(mktemp -d /tmp/valore-dmg.XXXXXX)
mkdir -p "$TMP/dmg"
cp -R "$APP" "$TMP/dmg/"
ln -s /Applications "$TMP/dmg/Applications"
xattr -cr "$TMP/dmg/$APP" 2>/dev/null
codesign --force --deep --sign - "$TMP/dmg/$APP" 2>/dev/null
OUT="$PWD/Valor-E-$VER-macOS.dmg"
rm -f "$OUT"
hdiutil create -volname "Valor-E $VER" -srcfolder "$TMP/dmg" -ov -format UDZO "$OUT"
rm -rf "$TMP"
echo "Gerado: $OUT"
open -R "$OUT"
