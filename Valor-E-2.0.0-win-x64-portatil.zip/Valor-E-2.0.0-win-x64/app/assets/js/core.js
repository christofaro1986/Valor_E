/* core.js — regras do MAPRIS: matriz 5×5, configuração, repositório (SQLite), alertas, XML/JSON.
 * Porte fiel de matriz.php, repo.php, alertas.php e xml_dados.php. */
(function (w) {
  'use strict';
  var E = w.E = {};

  // ---------- constantes ----------
  E.NIVEIS = ['Muito Baixo', 'Baixo', 'Médio', 'Alto', 'Extremo'];
  E.COR_NIVEL = { 'Muito Baixo': '#1976d2', 'Baixo': '#388e3c', 'Médio': '#fbc02d', 'Alto': '#f57c00', 'Extremo': '#d32f2f' };
  E.ROT_PROB = { 1: 'Muito Baixa', 2: 'Baixa', 3: 'Média', 4: 'Alta', 5: 'Muito Alta' };
  E.ROT_IMP = { 1: 'Muito Baixo', 2: 'Baixo', 3: 'Médio', 4: 'Alto', 5: 'Muito Alto' };
  E.CATEGORIAS = ['Pessoal', 'Administrativo', 'Material/Físico', 'Financeiro', 'Institucional', 'Tecnológico', 'Legal/Conformidade', 'Estratégico', 'Integridade', 'Operacional', 'Outro'];
  E.STATUS_RISCO = ['Identificado', 'Em análise', 'Em avaliação', 'Em tratamento', 'Monitorado', 'Aceito', 'Encerrado'];
  E.RESPOSTAS = ['', 'Evitar', 'Reduzir', 'Compartilhar', 'Aceitar'];
  E.RESPOSTAS_DESC = {
    'Evitar': 'Descontinuar ou não iniciar a atividade que gera o risco, eliminando a exposição.',
    'Reduzir': 'Adotar controles e ações que diminuam a probabilidade e/ou o impacto até um nível tolerável.',
    'Compartilhar': 'Transferir ou dividir parte do risco com terceiros (seguro, terceirização, parcerias, contratos).',
    'Aceitar': 'Nenhuma ação adicional: o risco já está dentro do apetite, ou o custo de tratá-lo supera o benefício. Exige justificativa e aprovação formal.'
  };
  E.TIPOS_CONTROLE = ['Preventivo', 'Detectivo', 'Corretivo'];
  E.TIPOS_CONTROLE_DESC = {
    'Preventivo': 'Atua antes do evento para evitar que o risco se materialize, reduzindo a probabilidade. Ex.: políticas de compliance, senhas de acesso, treinamento de pessoal, manutenções preventivas.',
    'Detectivo': 'Identifica a ocorrência do evento adverso logo após ou enquanto acontece, permitindo reação rápida. Ex.: auditorias periódicas, alarmes, conciliações bancárias, monitoramento de redes.',
    'Corretivo': 'Atua depois que o risco se concretizou, para minimizar danos, conter o impacto e recuperar a normalidade. Ex.: planos de contingência, backups de dados, seguro empresarial, células de crise.'
  };
  E.FATORES_SUGERIDOS = {
    'Pessoal': ['Seleção inadequada', 'Falta de capacitação', 'Desvio de conduta', 'Insuficiência de efetivo'],
    'Administrativo': ['Processos mal definidos', 'Normas desatualizadas', 'Falhas de comunicação', 'Controles internos insuficientes'],
    'Material/Físico': ['Infraestrutura inadequada', 'Equipamentos obsoletos', 'Manutenção precária', 'Falta de recursos materiais'],
    'Financeiro': ['Contingenciamento orçamentário', 'Má gestão de recursos', 'Fraudes financeiras', 'Custos elevados'],
    'Institucional': ['Imagem institucional', 'Conflito de interesses', 'Falta de transparência', 'Integridade comprometida'],
    'Tecnológico': ['Sistema indisponível', 'Falha de segurança da informação', 'Obsolescência tecnológica', 'Dependência de fornecedor'],
    'Legal/Conformidade': ['Descumprimento de norma', 'Mudança na legislação', 'Contrato com falhas', 'Ausência de registro'],
    'Integridade': ['Conflito de interesses', 'Fraude ou corrupção', 'Assédio moral ou sexual', 'Uso indevido de recursos ou informações', 'Nepotismo ou favorecimento', 'Falha de ética e conduta'],
    'Estratégico': ['Objetivos mal definidos', 'Mudança de prioridades', 'Falta de patrocínio', 'Metas inalcançáveis'],
    'Operacional': ['Falha de execução', 'Prazo inadequado', 'Dependência de terceiros', 'Retrabalho']
  };
  E.SEV_ROTULO = { critico: 'Crítico', atencao: 'Atenção', aviso: 'Aviso' };
  var CONFIG_PADRAO = { apetite: 'Médio', 'rev_Extremo': 30, 'rev_Alto': 60, 'rev_Médio': 90, 'rev_Baixo': 180, 'rev_Muito Baixo': 365, antecedencia: 7, monit_dias: 180 };

  // ---------- utilitários ----------
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  E.hoje = function () { var d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  function ms(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) : NaN; }
  E.dias = function (de, ate) { return Math.round((ms(ate) - ms(de)) / 86400000); };
  E.somaDias = function (iso, n) { var d = new Date(ms(iso) + n * 86400000); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); };
  E.dataBr = function (iso) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso == null ? '' : iso).trim()); return m ? m[3] + '/' + m[2] + '/' + m[1] : ''; };
  E.dataHoraBr = function (v) { v = String(v == null ? '' : v).trim(); var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(v); return m ? m[3] + '/' + m[2] + '/' + m[1] + ' ' + m[4] + ':' + m[5] : E.dataBr(v); };
  function S(v, max) { v = String(v == null ? '' : v).trim(); return Array.from(v).slice(0, max || 4000).join(''); }
  function D(v) { v = String(v == null ? '' : v).trim(); return /^\d{4}-\d{2}-\d{2}/.test(v) ? v.substr(0, 10) : null; }
  function curto(t, n) { t = String(t == null ? '' : t).trim(); if (t === '') t = '(sem descrição)'; n = n || 70; var a = Array.from(t); return a.length > n ? a.slice(0, n - 1).join('') + '…' : t; }
  function nn(v) { return v === undefined ? null : v; }
  function r2(x) { return Math.round(x * 100) / 100; }
  function media(v) { if (!v.length) return null; var s = 0; v.forEach(function (x) { s += x; }); return s / v.length; }
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function arr(v) { return Array.isArray(v) ? v : []; }
  E.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  // ---------- matriz ----------
  E.nivelDoIndice = function (x) { return x >= 20 ? 'Extremo' : x >= 12 ? 'Alto' : x >= 6 ? 'Médio' : x >= 2 ? 'Baixo' : 'Muito Baixo'; };
  E.nivelOrdem = function (n) { return E.NIVEIS.indexOf(n); };
  E.matrizIndice = function (p, i) {
    p = clamp(Math.round(p), 1, 5); i = clamp(Math.round(i), 1, 5);
    var x = p * i, n = E.nivelDoIndice(x);
    return { p: p, i: i, indice: x, nivel: n, cor: E.COR_NIVEL[n] };
  };
  function soma(a) { var s = 0; a.forEach(function (x) { s += x; }); return s; }

  E.riscoCalcular = function (r) {
    var pm = [], im = [], ix = [], res = { p: [], i: [], x: [] }, est = [], def = [];
    var estN = [], defN = [];
    arr(r.fatores).forEach(function (f) {
      f.probabilidade = clamp(parseInt(f.probabilidade == null ? 3 : f.probabilidade, 10) || 3, 1, 5);
      f.impacto = clamp(parseInt(f.impacto == null ? 3 : f.impacto, 10) || 3, 1, 5);
      var m = E.matrizIndice(f.probabilidade, f.impacto);
      f.indice = m.indice; f.nivel = m.nivel;
      pm.push(f.probabilidade); im.push(f.impacto); ix.push(m.indice);
      var ctl = arr(f.controles), tp = [], ti = [], tx = [], ep = [], ei = [], ex = [], dp = [], di = [], dx = [], efi = 0;
      ctl.forEach(function (cc) {
        cc.prob_controle = clamp(parseInt(cc.prob_controle == null ? 3 : cc.prob_controle, 10) || 3, 1, 5);
        cc.imp_controle = clamp(parseInt(cc.imp_controle == null ? 3 : cc.imp_controle, 10) || 3, 1, 5);
        var mc = E.matrizIndice(cc.prob_controle, cc.imp_controle);
        cc.indice = mc.indice; cc.nivel = mc.nivel;
        cc.eficacia = clamp(parseFloat(cc.eficacia) || 0, 0, 100);
        tp.push(cc.prob_controle); ti.push(cc.imp_controle); tx.push(mc.indice); efi += cc.eficacia;
        var tipo = cc.tipo_controle || 'Preventivo';
        if (tipo === 'Preventivo' || tipo === 'Detectivo') { ep.push(cc.prob_controle); ei.push(cc.imp_controle); ex.push(mc.indice); }
        if (tipo === 'Corretivo') { dp.push(cc.prob_controle); di.push(cc.imp_controle); dx.push(mc.indice); }
      });
      f.controles = ctl;
      f.eficacia = Math.min(efi, 100);
      f.p_res = f.i_res = f.indice_res = f.nivel_res = null;
      f.indice_est = f.nivel_est = f.indice_def = f.nivel_def = null;
      if (ctl.length) {
        f.p_res = Math.round(soma(tp) / tp.length); f.i_res = Math.round(soma(ti) / ti.length);
        f.indice_res = Math.round(soma(tx) / tx.length);
        f.nivel_res = E.matrizIndice(f.p_res, f.i_res).nivel;
        res.p.push(f.p_res); res.i.push(f.i_res); res.x.push(f.indice_res);
      }
      if (ep.length) {
        f.indice_est = Math.round(soma(ex) / ex.length);
        f.nivel_est = E.matrizIndice(soma(ep) / ep.length, soma(ei) / ei.length).nivel;
        est.push(f.indice_est);
      }
      if (dp.length) {
        f.indice_def = Math.round(soma(dx) / dx.length);
        f.nivel_def = E.matrizIndice(soma(dp) / dp.length, soma(di) / di.length).nivel;
        def.push(f.indice_def);
      }
    });
    r.prob_media = r.imp_medio = r.indice_medio = r.nivel_medio = null;
    r.prob_res = r.imp_res = r.indice_res = r.nivel_res = null;
    r.nivel_est = r.indice_est = r.nivel_def = r.indice_def = null;
    if (pm.length) {
      r.prob_media = r2(media(pm)); r.imp_medio = r2(media(im)); r.indice_medio = Math.round(media(ix));
      r.nivel_medio = E.matrizIndice(r.prob_media, r.imp_medio).nivel;
    }
    if (res.p.length) {
      r.prob_res = r2(media(res.p)); r.imp_res = r2(media(res.i)); r.indice_res = Math.round(media(res.x));
      r.nivel_res = E.matrizIndice(r.prob_res, r.imp_res).nivel;
    }
    if (est.length) { r.indice_est = Math.round(media(est)); r.nivel_est = E.nivelDoIndice(r.indice_est); }
    if (def.length) { r.indice_def = Math.round(media(def)); r.nivel_def = E.nivelDoIndice(r.indice_def); }
    return r;
  };

  // ---------- configuração ----------
  E.config = function () {
    var c = {}; Object.keys(CONFIG_PADRAO).forEach(function (k) { c[k] = CONFIG_PADRAO[k]; });
    DB.all('SELECT chave, valor FROM config').forEach(function (x) {
      if (x.chave in CONFIG_PADRAO) c[x.chave] = typeof CONFIG_PADRAO[x.chave] === 'number' ? (parseInt(x.valor, 10) || CONFIG_PADRAO[x.chave]) : x.valor;
    });
    return c;
  };
  E.configSalvar = function (d) {
    DB.tx(function () {
      Object.keys(CONFIG_PADRAO).forEach(function (k) {
        if (!(k in d)) return;
        var v = d[k];
        if (k === 'apetite') { if (E.NIVEIS.indexOf(v) < 0) return; }
        else v = clamp(parseInt(v, 10) || 1, 1, 3650);
        DB.run('INSERT INTO config (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor', [k, String(v)]);
      });
    });
  };

  // ---------- repositório ----------
  E.riscoCarregar = function (id) {
    var r = DB.one('SELECT * FROM riscos WHERE id = ?', [id]);
    if (!r) return null;
    r.fatores = DB.all('SELECT * FROM fatores WHERE risco_id = ? ORDER BY ordem, id', [id]);
    r.fatores.forEach(function (f) {
      f.controles = DB.all('SELECT * FROM controles WHERE fator_id = ? ORDER BY ordem, id', [f.id]);
      f.controles.forEach(function (c) {
        c.planos = DB.all('SELECT * FROM planos WHERE controle_id = ? ORDER BY id', [c.id]);
        c.monitoramentos = DB.all('SELECT * FROM monitoramentos WHERE risco_id = ? AND controle_desc = ? ORDER BY data, id', [id, String(c.id)]);
      });
    });
    r.revisoes = DB.all('SELECT * FROM revisoes WHERE risco_id = ? ORDER BY data DESC, id DESC', [id]);
    r.flag = null;
    if (r.flag_id) {
      var fl = DB.one('SELECT f.*, c.nome AS processo_nome FROM flags f JOIN processos c ON c.id = f.processo_id WHERE f.id = ?', [r.flag_id]);
      if (fl) { fl.n = DB.one('SELECT COUNT(*) AS n FROM flags WHERE processo_id = ? AND id <= ?', [fl.processo_id, fl.id]).n; r.flag = fl; }
    }
    return r;
  };

  E.revisaoProximaData = function (nivel, base) {
    var dias = parseInt(E.config()['rev_' + nivel], 10) || 90;
    return E.somaDias(base, dias);
  };

  E.riscoSalvar = function (d) {
    var nome = S(d.nome, 500), amb = S(d.ambiente, 500);
    // vínculo com o mapa (processo / flag): o ambiente de análise acompanha o nome do processo
    var cenId = parseInt(d.processo_id, 10) || null, flagId = parseInt(d.flag_id, 10) || null;
    if (flagId) {
      var fl0 = DB.one('SELECT processo_id FROM flags WHERE id = ?', [flagId]);
      if (!fl0) flagId = null; else cenId = fl0.processo_id;
    }
    if (cenId) {
      var cn0 = DB.one('SELECT nome FROM processos WHERE id = ?', [cenId]);
      if (!cn0) { cenId = null; flagId = null; } else amb = cn0.nome;
    }
    // risco de projeto: o ambiente de análise é o projeto; não há vínculo com processo nem com atividade do diagrama
    var projId = parseInt(d.projeto_id, 10) || null;
    if (projId) {
      var pj0 = DB.one('SELECT nome FROM projetos WHERE id = ?', [projId]);
      if (!pj0) projId = null; else { amb = pj0.nome; cenId = null; flagId = null; }
    }
    if (nome === '') throw new Error('Informe o evento de risco.');
    if (amb === '') throw new Error('Informe o ambiente de análise.');
    d.fatores = arr(d.fatores).slice();
    d.fatores.forEach(function (f) { f.controles = arr(f.controles).slice(); });
    var c = E.riscoCalcular(d);
    return DB.tx(function () {
      var id = parseInt(d.id, 10) || 0;
      var nivRef = c.nivel_res || c.nivel_medio;
      var prox = D(d.proxima_revisao) || (nivRef ? E.revisaoProximaData(nivRef, E.hoje()) : null);
      var campos = [amb, nome, S(d.descricao), S(d.consequencias), S(d.categoria, 100), S(d.responsavel, 300), S(d.status || 'Identificado', 50), S(d.resposta, 50),
        c.prob_media, c.imp_medio, c.indice_medio, c.nivel_medio, c.prob_res, c.imp_res, c.indice_res, c.nivel_res,
        c.nivel_est, c.indice_est, c.nivel_def, c.indice_def,
        S(d.objetivo, 1000), S(d.partes, 1000), S(d.resposta_just), S(d.aceite_por, 300), D(d.aceite_validade), prox];
      if (id > 0 && DB.one('SELECT 1 AS x FROM riscos WHERE id = ?', [id])) {
        DB.run("UPDATE riscos SET ambiente=?,nome=?,descricao=?,consequencias=?,categoria=?,responsavel=?,status=?,resposta=?,prob_media=?,imp_medio=?,indice_medio=?,nivel_medio=?,prob_res=?,imp_res=?,indice_res=?,nivel_res=?,nivel_est=?,indice_est=?,nivel_def=?,indice_def=?,objetivo=?,partes=?,resposta_just=?,aceite_por=?,aceite_validade=?,proxima_revisao=?,atualizado_em=CURRENT_TIMESTAMP WHERE id=?", campos.concat([id]));
        // ordem importa: planos/monitoramentos primeiro (controle_id ON DELETE SET NULL) e depois fatores
        DB.run('DELETE FROM planos WHERE risco_id = ?', [id]);
        DB.run('DELETE FROM monitoramentos WHERE risco_id = ?', [id]);
        DB.run('DELETE FROM fatores WHERE risco_id = ?', [id]);
      } else {
        DB.run('INSERT INTO riscos (ambiente,nome,descricao,consequencias,categoria,responsavel,status,resposta,prob_media,imp_medio,indice_medio,nivel_medio,prob_res,imp_res,indice_res,nivel_res,nivel_est,indice_est,nivel_def,indice_def,objetivo,partes,resposta_just,aceite_por,aceite_validade,proxima_revisao) VALUES (' + new Array(27).join('?,').slice(0, -1) + ')', campos);
        id = DB.lastId();
        var ult = null;
        arr(d.revisoes).forEach(function (rv) {
          if (!rv || !D(rv.data)) return;
          DB.run('INSERT INTO revisoes (risco_id,data,parecer,autor,nivel_inerente,indice_inerente,nivel_residual,indice_residual) VALUES (?,?,?,?,?,?,?,?)',
            [id, D(rv.data), S(rv.parecer), S(rv.autor, 300), nn(rv.nivel_inerente), nn(rv.indice_inerente), nn(rv.nivel_residual), nn(rv.indice_residual)]);
          if (ult === null || D(rv.data) > ult) ult = D(rv.data);
        });
        if (ult) DB.run('UPDATE riscos SET ultima_revisao = ? WHERE id = ?', [ult, id]);
      }
      DB.run('UPDATE riscos SET processo_id = ?, flag_id = ? WHERE id = ?', [cenId, flagId, id]);
      try { DB.run('UPDATE riscos SET projeto_id = ? WHERE id = ?', [projId, id]); } catch (e) {}
      var cod = S(d.codigo, 20); if (cod === '') cod = (DB.one('SELECT codigo FROM riscos WHERE id = ?', [id]) || {}).codigo || E.proximoCodigoRisco();
      if (!E.codigoRiscoLivre(cod, id)) throw new Error('O código ' + cod + ' já está em uso por outro risco.');
      DB.run('UPDATE riscos SET codigo = ? WHERE id = ?', [cod, id]);
      c.fatores.forEach(function (f, i) {
        DB.run('INSERT INTO fatores (risco_id,ordem,nome,descricao,probabilidade,impacto,indice,nivel,p_res,i_res,indice_res,nivel_res,indice_est,nivel_est,indice_def,nivel_def,eficacia) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          [id, i, S(f.nome, 500), S(f.descricao), f.probabilidade, f.impacto, f.indice, f.nivel, f.p_res, f.i_res, f.indice_res, f.nivel_res, f.indice_est, f.nivel_est, f.indice_def, f.nivel_def, f.eficacia]);
        var fid = DB.lastId();
        f.controles.forEach(function (cc, j) {
          DB.run('INSERT INTO controles (fator_id,ordem,descricao,tipo_controle,natureza,eficacia,status,prob_controle,imp_controle,indice,nivel,responsavel,prazo,data_implementacao,observacoes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [fid, j, S(cc.descricao), S(cc.tipo_controle || 'Preventivo', 30), S(cc.natureza || 'Manual', 30), cc.eficacia, S(cc.status || 'Planejado', 40), cc.prob_controle, cc.imp_controle, cc.indice, cc.nivel, S(cc.responsavel, 300), D(cc.prazo), D(cc.data_implementacao), S(cc.observacoes)]);
          var cid = DB.lastId(), rot = S(cc.descricao, 300);
          arr(cc.planos).forEach(function (pl) {
            if (!pl || S(pl.descricao) === '') return;
            var stt = S(pl.status || 'Pendente', 40), conc = stt === 'Concluído' ? (D(pl.concluido_em) || E.hoje()) : null;
            DB.run('INSERT INTO planos (risco_id,controle_id,controle_desc,descricao,responsavel,prazo,status,prioridade,observacoes,concluido_em) VALUES (?,?,?,?,?,?,?,?,?,?)',
              [id, cid, rot, S(pl.descricao), S(pl.responsavel, 300), D(pl.prazo), stt, S(pl.prioridade || 'Média', 20), S(pl.observacoes), conc]);
          });
          arr(cc.monitoramentos).forEach(function (mo) {
            if (!mo || (S(mo.acao) === '' && S(mo.resultado) === '')) return;
            DB.run('INSERT INTO monitoramentos (risco_id,controle_desc,data,acao,resultado,evidencias) VALUES (?,?,?,?,?,?)',
              [id, String(cid), D(mo.data) || E.hoje(), S(mo.acao), S(mo.resultado), S(mo.evidencias)]);
          });
        });
      });
      return id;
    });
  };

  E.riscoExcluir = function (id) { DB.tx(function () {
    var r = DB.one('SELECT flag_id FROM riscos WHERE id = ?', [id]);
    DB.run('DELETE FROM riscos WHERE id = ?', [id]);
    if (r && r.flag_id && !DB.one('SELECT 1 AS x FROM riscos WHERE flag_id = ?', [r.flag_id])) DB.run('DELETE FROM flags WHERE id = ?', [r.flag_id]);   // bandeira sem riscos sai do diagrama
  }); };

  E.riscoDuplicar = function (id) {
    var r = E.riscoCarregar(id);
    if (!r) throw new Error('Risco não encontrado.');
    delete r.id; delete r.revisoes; delete r.ultima_revisao; delete r.proxima_revisao;
    r.nome += ' (cópia)';
    r.fatores.forEach(function (f) { f.controles.forEach(function (c) {
      c.planos.forEach(function (p) { p.status = 'Pendente'; p.concluido_em = null; });
      c.monitoramentos = [];
    }); });
    return E.riscoSalvar(r);
  };

  E.riscosListar = function (f) {
    f = f || {}; var w = [], p = [];
    if (f.ambiente) { w.push('ambiente = ?'); p.push(f.ambiente); }
    if (f.processo) { w.push('processo_id = ?'); p.push(parseInt(f.processo, 10)); }
    if (f.cadeia) { w.push('processo_id IN (SELECT pr.id FROM processos pr JOIN macroprocessos m ON m.id = pr.macro_id JOIN cva_ciclos cc ON cc.id = m.ciclo_id WHERE cc.cadeia = ?)'); p.push(f.cadeia); }
    if (f.nivel) { w.push('nivel_medio = ?'); p.push(f.nivel); }
    if (f.status) { w.push('status = ?'); p.push(f.status); }
    if (f.categoria) { w.push('categoria = ?'); p.push(f.categoria); }
    if (f.q) { w.push('(nome LIKE ? OR descricao LIKE ? OR ambiente LIKE ? OR responsavel LIKE ?)'); var q = '%' + f.q + '%'; p.push(q, q, q, q); }
    if (f.processo_id) { w.push('r.processo_id = ?'); p.push(f.processo_id); }
    if (f.flag_id) { w.push('r.flag_id = ?'); p.push(f.flag_id); }
    if (f.projeto_id) { w.push('r.projeto_id = ?'); p.push(parseInt(f.projeto_id, 10)); }
    return DB.all("SELECT r.*, (SELECT tarefa FROM flags WHERE id = r.flag_id) AS tarefa, (SELECT COUNT(*) FROM fatores WHERE risco_id = r.id) AS n_fatores, (SELECT COUNT(*) FROM planos WHERE risco_id = r.id AND status != 'Concluído' AND status != 'Cancelado') AS n_planos_abertos, (SELECT nome FROM projetos WHERE id = r.projeto_id) AS projeto_nome FROM riscos r" +
      (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY COALESCE(indice_medio,0) DESC, atualizado_em DESC', p);
  };

  E.ambientesLista = function () { return DB.all("SELECT ambiente, COUNT(*) n FROM riscos WHERE ambiente != '' GROUP BY ambiente ORDER BY ambiente COLLATE NOCASE"); };

  function contar(obj, k) { obj[k] = (obj[k] || 0) + 1; }
  function ordenarObj(o) { return Object.keys(o).map(function (k) { return [k, o[k]]; }).sort(function (a, b) { return b[1] - a[1]; }); }

  E.painelDados = function (ambiente) {
    ambiente = ambiente || '';
    var riscos = ambiente ? DB.all('SELECT * FROM riscos WHERE ambiente = ?', [ambiente]) : DB.all('SELECT * FROM riscos');
    var niv = {}, nivRes = {}, cat = {}, amb = {}, st = {}, mI = {}, mR = {};
    E.NIVEIS.forEach(function (n) { niv[n] = 0; nivRes[n] = 0; });
    for (var a = 1; a <= 5; a++) { mI[a] = {}; mR[a] = {}; for (var b = 1; b <= 5; b++) { mI[a][b] = 0; mR[a][b] = 0; } }
    riscos.forEach(function (r) {
      if (r.nivel_medio) niv[r.nivel_medio]++;
      if (r.nivel_res) nivRes[r.nivel_res]++;
      contar(cat, r.categoria || 'Sem categoria'); contar(amb, r.ambiente); contar(st, r.status);
      if (r.prob_media !== null) { var mi = E.matrizIndice(r.prob_media, r.imp_medio); mI[mi.p][mi.i]++; }
      if (r.prob_res !== null) { var mr = E.matrizIndice(r.prob_res, r.imp_res); mR[mr.p][mr.i]++; }
    });
    var wp = ambiente ? ' AND r.ambiente = ?' : '', pa = ambiente ? [ambiente] : [];
    var planos = DB.all("SELECT p.*, r.nome AS risco_nome, r.ambiente FROM planos p JOIN riscos r ON r.id = p.risco_id WHERE p.status NOT IN ('Concluído','Cancelado')" + wp + ' ORDER BY CASE WHEN p.prazo IS NULL THEN 1 ELSE 0 END, p.prazo LIMIT 8', pa);
    var nPl = DB.one("SELECT COUNT(*) total, SUM(CASE WHEN p.status='Concluído' THEN 1 ELSE 0 END) conc, SUM(CASE WHEN p.status NOT IN ('Concluído','Cancelado') AND p.prazo IS NOT NULL AND p.prazo < ? THEN 1 ELSE 0 END) atrasados FROM planos p JOIN riscos r ON r.id = p.risco_id WHERE 1=1" + wp, [E.hoje()].concat(pa));
    nPl.conc = nPl.conc || 0; nPl.atrasados = nPl.atrasados || 0;
    var top = riscos.slice().sort(function (x, y) { return (y.indice_medio || 0) - (x.indice_medio || 0); }).slice(0, 8);
    return { total: riscos.length, niveis: niv, niveis_res: nivRes, categorias: ordenarObj(cat), ambientes: ordenarObj(amb), status: st, matriz_inerente: mI, matriz_residual: mR, top: top, planos_proximos: planos, planos: nPl };
  };

  E.revisaoRegistrar = function (id, parecer, autor) {
    var r = DB.one('SELECT * FROM riscos WHERE id = ?', [id]);
    if (!r) throw new Error('Risco não encontrado.');
    var hoje = E.hoje(), nivRef = r.nivel_res || r.nivel_medio || 'Médio', prox = E.revisaoProximaData(nivRef, hoje);
    DB.tx(function () {
      DB.run('INSERT INTO revisoes (risco_id,data,parecer,autor,nivel_inerente,indice_inerente,nivel_residual,indice_residual) VALUES (?,?,?,?,?,?,?,?)',
        [id, hoje, S(parecer), S(autor, 300), r.nivel_medio, r.indice_medio, r.nivel_res, r.indice_res]);
      DB.run('UPDATE riscos SET ultima_revisao = ?, proxima_revisao = ? WHERE id = ?', [hoje, prox, id]);
    });
    return { ultima_revisao: hoje, proxima_revisao: prox };
  };

  E.planoPrazo = function (plano, prazo) {
    var pz = D(prazo); if (!pz) throw new Error('Data inválida');
    DB.tx(function () { DB.run('UPDATE planos SET prazo = ? WHERE id = ?', [pz, plano]); });
  };
  E.planoStatus = function (plano, st) {
    if (['Pendente', 'Em Andamento', 'Concluído', 'Cancelado'].indexOf(st) < 0) throw new Error('Status inválido');
    DB.tx(function () { DB.run('UPDATE planos SET status = ?, concluido_em = ? WHERE id = ?', [st, st === 'Concluído' ? E.hoje() : null, plano]); });
  };

  // ---------- alertas ----------
  E.alertasRisco = function (r, cfg) {
    cfg = cfg || E.config();
    var hoje = E.hoje(), A = [];
    if ((r.status || '') === 'Encerrado') return A;
    function add(cod, sev, titulo, prov, acao, planoId) { A.push({ cod: cod, sev: sev, titulo: titulo, prov: prov, acao: acao || 'abrir', plano_id: planoId == null ? null : planoId }); }
    var apet = String(cfg.apetite), apetOrd = E.nivelOrdem(apet);
    var nivInh = r.nivel_medio || null, nivRes = r.nivel_res || null, nivAtual = nivRes || nivInh, ordAtual = E.nivelOrdem(nivAtual), ordInh = E.nivelOrdem(nivInh);
    var acima = !!nivAtual && ordAtual > apetOrd, resposta = String(r.resposta || ''), fatores = arr(r.fatores);
    var controles = [], planos = [], temPrev = false, temCorr = false;
    fatores.forEach(function (f) {
      var ativos = 0;
      arr(f.controles).forEach(function (c) {
        if ((c.status || '') === 'Cancelado') return;
        c = Object.assign({}, c); c._fator = f; controles.push(c); ativos++;
        if (c.tipo_controle === 'Preventivo') temPrev = true;
        if (c.tipo_controle === 'Corretivo') temCorr = true;
        arr(c.planos).forEach(function (p) { planos.push(p); });
      });
      if (ativos === 0 && E.nivelOrdem(f.nivel || null) >= 3 && fatores.length > 1 && resposta !== 'Evitar')
        add('CAUSA_SEM_CONTROLE', 'atencao', 'Causa ' + (f.nivel || '') + ' sem controle: ' + curto(f.nome || ''), 'Você mapeou a causa e a deixou desprotegida. Qual controle vai atuar sobre ela?');
    });
    if (!fatores.length) add('SEM_ANALISE', 'atencao', 'Risco sem análise: nenhuma causa cadastrada', 'Sem causas não há probabilidade nem impacto — e sem eles não há nível de risco. Identifique o que pode originar este evento.');
    if (r.projeto_id) {
      var pjA = DB.one('SELECT nome, status FROM projetos WHERE id = ?', [r.projeto_id]);
      if (pjA && /^(Conclu|Cancel)/.test(pjA.status || '')) add('PROJETO_ENCERRADO', 'aviso', 'Projeto ' + String(pjA.status).toLowerCase() + ' com risco ainda aberto', 'O projeto “' + curto(pjA.nome || '') + '” já foi ' + String(pjA.status).toLowerCase() + '. Encerre o risco, ou registre por que ele ainda importa (ex.: efeito sobre o produto entregue).');
    }
    if (String(r.responsavel || '').trim() === '') add('SEM_DONO', 'atencao', 'Risco sem proprietário', 'Risco sem dono não é gerenciado, é apenas registrado. Quem responde por ele?');

    var nCtl = controles.length;
    if (fatores.length && nCtl === 0 && resposta !== 'Evitar' && resposta !== 'Aceitar') {
      if (nivInh && ordInh > apetOrd) add('SEM_CONTROLE', ordInh >= 3 ? 'critico' : 'atencao', 'Risco ' + nivInh + ' sem nenhum controle', 'Ele está totalmente exposto e acima do apetite (' + apet + '). O que está impedindo alguém de agir?');
      else if (resposta === 'Reduzir') add('REDUZIR_SEM_ACAO', 'atencao', 'Resposta “Reduzir” sem nenhum controle cadastrado', 'A decisão foi reduzir, mas nada foi cadastrado para reduzir. Qual é o controle?');
    }
    if (acima && resposta !== 'Aceitar' && nCtl > 0)
      add('ACIMA_APETITE', ordAtual >= 3 ? 'critico' : 'atencao', 'Risco ' + (nivRes ? 'residual ' : '') + nivAtual + ' acima do apetite (' + apet + ')', 'Mesmo com os controles atuais, o risco segue maior do que a organização tolera. Reforce os controles, evite, compartilhe — ou formalize a aceitação.');
    if (fatores.length && resposta === '')
      add('SEM_RESPOSTA', (acima || (nivInh && ordInh > apetOrd)) ? 'atencao' : 'aviso', 'Resposta ao risco não definida', 'Defina a resposta: evitar, reduzir, compartilhar ou aceitar. Sem decisão, o risco fica à deriva.');
    if (ordInh >= 3 && fatores.length && !temCorr && resposta !== 'Evitar')
      add('SEM_CORRETIVO', 'aviso', 'Sem controle corretivo (contingência)', 'Se o risco ' + nivInh + ' se concretizar hoje, qual é o plano para conter o dano e recuperar a normalidade?');
    if (ordInh >= 3 && controles.length && !temPrev && resposta !== 'Evitar')
      add('SEM_PREVENTIVO', 'aviso', 'Sem controle preventivo', 'Todos os controles agem depois do fato. Existe algo que reduza a probabilidade antes que ele ocorra?');

    if (resposta === 'Aceitar') {
      if (acima && String(r.aceite_por || '').trim() === '') add('ACEITE_SEM_APROVACAO', 'critico', 'Aceitação de risco ' + nivAtual + ' sem aprovação formal', 'Quem autorizou conviver com um risco acima do apetite? Registre a autoridade que aprovou a aceitação.');
      if (String(r.resposta_just || '').trim() === '') add('ACEITE_SEM_JUSTIFICATIVA', 'atencao', 'Aceitação sem justificativa', 'Aceitar exige uma razão registrada: custo de tratamento maior que o benefício, risco já dentro do apetite…');
      var val = String(r.aceite_validade || '');
      if (val !== '' && val < hoje) add('ACEITE_VENCIDO', 'critico', 'Aceitação vencida em ' + E.dataBr(val), 'A aprovação expirou. Revalide a aceitação com a autoridade competente ou trate o risco.');
      else if (val !== '' && E.dias(hoje, val) <= cfg.antecedencia) add('ACEITE_VENCENDO', 'aviso', 'Aceitação vence em ' + E.dias(hoje, val) + ' dia(s)', 'Providencie a revalidação antes do prazo.');
      else if (val === '' && acima) add('ACEITE_SEM_VALIDADE', 'aviso', 'Aceitação sem prazo de validade', 'Toda aceitação de risco acima do apetite deveria ter data para ser reavaliada.');
    }
    if (resposta === 'Compartilhar' && !planos.length && !controles.length)
      add('COMPARTILHAR_SEM_ACAO', 'aviso', 'Resposta “Compartilhar” sem ação registrada', 'Qual seguro, contrato ou parceria efetivamente transfere este risco? Cadastre como controle ou plano de ação.');

    var nivBase = nivAtual || 'Médio', prox = String(r.proxima_revisao || '');
    if (prox === '') {
      var base = String(r.ultima_revisao || '') || String(r.criado_em || hoje).substr(0, 10);
      prox = E.somaDias(base, parseInt(cfg['rev_' + nivBase], 10) || 90);
    }
    if (prox < hoje) {
      var d = E.dias(prox, hoje), ult = String(r.ultima_revisao || '');
      add('REVISAO_VENCIDA', (d > 30 || ordAtual >= 3) ? 'critico' : 'atencao', 'Revisão vencida há ' + d + ' dia(s)',
        (ult !== '' ? 'Última revisão em ' + E.dataBr(ult) + '. ' : 'Este risco nunca foi revisado. ') + 'Riscos mudam sem avisar: ele continua ' + (nivAtual || 'no mesmo nível') + '? Faça a análise crítica.', 'revisar');
    } else if (E.dias(hoje, prox) <= cfg.antecedencia) {
      add('REVISAO_PROXIMA', 'aviso', 'Revisão em ' + E.dias(hoje, prox) + ' dia(s) (' + E.dataBr(prox) + ')', 'Reserve tempo para reavaliar probabilidade, impacto e controles.', 'revisar');
    }
    if (['Identificado', 'Em análise', 'Em avaliação'].indexOf(r.status || '') >= 0) {
      var at = String(r.atualizado_em || '').substr(0, 10);
      if (at !== '' && E.dias(at, hoje) > 14) add('PARADO', 'aviso', 'Risco parado em “' + r.status + '” há ' + E.dias(at, hoje) + ' dias', 'Avance o ciclo da ISO 31000: análise → avaliação → tratamento → monitoramento.');
    }
    controles.forEach(function (c) {
      var nome = curto(c.descricao || '', 60), st = String(c.status || ''), prazo = String(c.prazo || '');
      if (['Planejado', 'Em Implementação'].indexOf(st) >= 0 && prazo !== '' && prazo < hoje)
        add('CONTROLE_ATRASADO', 'atencao', 'Implantação do controle atrasada ' + E.dias(prazo, hoje) + ' dia(s): ' + nome, 'Um controle que só existe no papel não protege ninguém. O que travou?');
      if (st === 'Implementado') {
        var ult = String(c.data_implementacao || '');
        arr(c.monitoramentos).forEach(function (m) { if (m.data && m.data > ult) ult = m.data; });
        if (ult === '' || E.dias(ult, hoje) > cfg.monit_dias)
          add('CONTROLE_SEM_TESTE', 'atencao', ult === '' ? 'Controle implementado nunca foi monitorado: ' + nome : 'Controle sem verificação há ' + E.dias(ult, hoje) + ' dias: ' + nome, 'Controle que não é testado é uma hipótese, não uma proteção. Registre o monitoramento e o resultado.');
        var f = c._fator;
        if ((c.indice || 0) >= (f.indice || 0) && (f.indice || 0) > 0)
          add('CONTROLE_INEFICAZ', 'aviso', 'Controle não reduz o risco da causa: ' + nome, 'Probabilidade e impacto após o controle iguais aos de antes. Ele realmente muda alguma coisa?');
      }
    });
    var semPrazo = 0, semResp = 0, ant = cfg.antecedencia;
    planos.forEach(function (p) {
      if (['Concluído', 'Cancelado'].indexOf(p.status || '') >= 0) return;
      var pz = String(p.prazo || ''), desc = curto(p.descricao || '', 60);
      if (pz === '') semPrazo++;
      if (String(p.responsavel || '').trim() === '') semResp++;
      if (pz !== '' && pz < hoje) add('PLANO_ATRASADO', 'critico', 'Plano de ação atrasado ' + E.dias(pz, hoje) + ' dia(s): ' + desc, 'O prazo era ' + E.dataBr(pz) + '. Execute, replaneje com justificativa ou cancele — não deixe vencer em silêncio.', 'plano', p.id);
      else if (pz !== '' && E.dias(hoje, pz) <= ant) { var dd = E.dias(hoje, pz); add('PLANO_PROXIMO', 'aviso', 'Plano vence ' + (dd === 0 ? 'hoje' : 'em ' + dd + ' dia(s)') + ': ' + desc, 'Está no caminho? Se precisar de apoio, peça agora.', 'plano', p.id); }
    });
    if (semPrazo) add('PLANO_SEM_PRAZO', 'aviso', semPrazo + ' plano(s) de ação sem prazo', 'Ação sem prazo é intenção. Defina a data.');
    if (semResp) add('PLANO_SEM_RESP', 'aviso', semResp + ' plano(s) de ação sem responsável', 'Se é de todos, não é de ninguém. Quem executa?');
    var o = { critico: 0, atencao: 1, aviso: 2 };
    return A.map(function (x, i) { return [x, i]; }).sort(function (a, b) { return (o[a[0].sev] - o[b[0].sev]) || (a[1] - b[1]); }).map(function (x) { return x[0]; });
  };

  E.alertasTodos = function (ambiente) {
    var cfg = E.config(), out = [];
    var ids = ambiente ? DB.all('SELECT id FROM riscos WHERE ambiente = ? ORDER BY id', [ambiente]) : DB.all('SELECT id FROM riscos ORDER BY id');
    ids.forEach(function (x) {
      var r = E.riscoCarregar(x.id); if (!r) return;
      E.alertasRisco(r, cfg).forEach(function (a) { a.risco_id = r.id; a.risco = r.nome; a.ambiente = r.ambiente; a.nivel = r.nivel_res || r.nivel_medio; out.push(a); });
    });
    var o = { critico: 0, atencao: 1, aviso: 2 };
    return out.map(function (x, i) { return [x, i]; }).sort(function (a, b) { return (o[a[0].sev] - o[b[0].sev]) || (E.nivelOrdem(b[0].nivel) - E.nivelOrdem(a[0].nivel)) || (a[1] - b[1]); }).map(function (x) { return x[0]; });
  };
  E.alertasContagem = function (lista) {
    var c = { critico: 0, atencao: 0, aviso: 0, riscos_com_alerta: 0 }, ids = {};
    lista.forEach(function (a) { c[a.sev]++; if (a.sev !== 'aviso') ids[a.risco_id] = 1; });
    c.riscos_com_alerta = Object.keys(ids).length; return c;
  };
  E.alertasSelo = function () { return E.alertasContagem(E.alertasTodos()); };

  // ---------- exportar / importar ----------
  E.limparParaImportar = function (r) {
    ['id', 'criado_em', 'atualizado_em', 'ultima_revisao'].forEach(function (k) { delete r[k]; });
    arr(r.revisoes).forEach(function (rv) { delete rv.id; delete rv.risco_id; });
    arr(r.fatores).forEach(function (f) {
      delete f.id; delete f.risco_id;
      arr(f.controles).forEach(function (c) {
        delete c.id; delete c.fator_id;
        arr(c.planos).forEach(function (p) { delete p.id; });
        arr(c.monitoramentos).forEach(function (m) { delete m.id; });
      });
    });
    return r;
  };
  E.riscosCompletos = function (ambiente, id) {
    var ids = id > 0 ? [id] : E.riscosListar(ambiente ? { ambiente: ambiente } : {}).map(function (r) { return r.id; });
    var out = []; ids.forEach(function (i) { var r = E.riscoCarregar(i); if (r) out.push(E.limparParaImportar(r)); });
    return out;
  };

  // XML no mesmo formato da versão PHP: <mapris formato="mapris-riscos" versao="1"><riscos t="l"><item t="o">…
  function xmlEsc(s) { return String(s).replace(/[^\u0009\u000A\u000D -퟿-�\u{10000}-\u{10FFFF}]/gu, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function fxNo(tag, v, ind) {
    var valido = /^[A-Za-z_][A-Za-z0-9_]*$/.test(tag) && tag.toLowerCase().indexOf('xml') !== 0;
    var nome = valido ? tag : 'c', at = valido ? '' : ' k="' + xmlEsc(tag).replace(/"/g, '&quot;') + '"', pad = new Array(ind + 1).join('  ');
    if (Array.isArray(v) || (v && typeof v === 'object')) {
      var lista = Array.isArray(v), filhos = lista ? v.map(function (x) { return fxNo('item', x, ind + 1); }) : Object.keys(v).map(function (k) { return fxNo(k, v[k], ind + 1); });
      return pad + '<' + nome + at + ' t="' + (lista ? 'l' : 'o') + '">' + (filhos.length ? '\n' + filhos.join('\n') + '\n' + pad : '') + '</' + nome + '>';
    }
    if (typeof v === 'boolean') return pad + '<' + nome + at + ' t="b">' + v + '</' + nome + '>';
    if (typeof v === 'number') return pad + '<' + nome + at + ' t="n">' + v + '</' + nome + '>';
    if (v === null || v === undefined) return pad + '<' + nome + at + ' t="z"/>';
    return pad + '<' + nome + at + '>' + xmlEsc(v) + '</' + nome + '>';
  }
  E.riscosParaXml = function (riscos) {
    return '<?xml version="1.0" encoding="UTF-8"?>\n<mapris formato="mapris-riscos" versao="1" exportado_em="' + new Date().toISOString() + '">\n' + fxNo('riscos', riscos, 1) + '\n</mapris>\n';
  };
  function fxValor(e) {
    var t = e.getAttribute('t');
    if (t === 'l' || t === 'o') {
      var r = t === 'l' ? [] : {};
      for (var c = e.firstElementChild; c; c = c.nextElementSibling) {
        if (t === 'l') r.push(fxValor(c)); else r[c.hasAttribute('k') ? c.getAttribute('k') : c.nodeName] = fxValor(c);
      }
      return r;
    }
    var txt = e.textContent;
    if (t === 'b') return txt === 'true';
    if (t === 'n') return parseFloat(txt);
    if (t === 'z') return null;
    return txt;
  }
  E.riscosDeXml = function (xml) {
    if (String(xml).trim() === '') throw new Error('Arquivo XML vazio.');
    var d = new DOMParser().parseFromString(xml, 'application/xml');
    if (d.getElementsByTagName('parsererror').length || !d.documentElement) throw new Error('O arquivo não é um XML válido.');
    var r = d.documentElement;
    if (r.nodeName !== 'mapris' || r.getAttribute('formato') !== 'mapris-riscos') throw new Error('Arquivo não reconhecido: esperado XML de riscos do MAPRIS.');
    for (var c = r.firstElementChild; c; c = c.nextElementSibling) if (c.nodeName === 'riscos') { var v = fxValor(c); return Array.isArray(v) ? v : []; }
    return [];
  };
  E.fxNo = fxNo; E.fxValor = fxValor;
  E.importarLista = function (lista) {
    var n = 0, at = 0, erros = [];
    lista.forEach(function (r) {
      if (!r || typeof r !== 'object') return;
      try {
        var d = E.limparParaImportar(r);
        // já existe um risco com o mesmo evento e ambiente? então atualiza; senão cria
        var ex = DB.one('SELECT id FROM riscos WHERE nome = ? COLLATE NOCASE AND ambiente = ? COLLATE NOCASE ORDER BY id LIMIT 1', [String(d.nome || '').trim(), String(d.ambiente || '').trim()]);
        if (ex) { d.id = ex.id; at++; } else n++;
        E.riscoSalvar(d);
      } catch (e) { erros.push((r.nome || '?') + ': ' + e.message); }
    });
    return { importados: n, atualizados: at, erros: erros };
  };
  E.backupJson = function () {
    var cen = DB.all('SELECT id FROM processos ORDER BY id').map(function (c) { return E.processoCompleto(c.id); });
    var soltos = DB.all('SELECT id FROM riscos WHERE processo_id IS NULL ORDER BY id').map(function (r) { return E.limparParaImportar(E.riscoCarregar(r.id)); });
    return JSON.stringify({ formato: 'mapris-backup', versao: 2, processos: cen, riscos: soltos, config: E.config() }, null, 2);
  };
})(window);
