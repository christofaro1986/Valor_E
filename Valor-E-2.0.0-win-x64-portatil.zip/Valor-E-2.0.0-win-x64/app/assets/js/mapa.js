/* mapa.js — Mapa Estratégico (padrão BSC): perspectivas, temas e objetivos editados direto na imagem.
   Os objetivos são os mesmos "objetivos estratégicos" do módulo Valor Estratégico (vínculo nos dois sentidos). */
(function (w) {
  'use strict';
  var h = E.esc, Mdl = function () { return w.Mdl.apply(null, arguments); };
  var CORES = ['#0b3a73', '#0a6fc2', '#01b2a1', '#0fbeca', '#085aa0', '#12d3a8'];
  var PADRAO = ['Sociedade e clientes', 'Processos internos', 'Aprendizado e recursos'];

  DB.extras.push(function () {
    DB.db.run("CREATE TABLE IF NOT EXISTS me_mapas (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, missao TEXT DEFAULT '', visao TEXT DEFAULT '', criado_em TEXT DEFAULT CURRENT_TIMESTAMP)");
    DB.db.run("CREATE TABLE IF NOT EXISTS me_perspectivas (id INTEGER PRIMARY KEY AUTOINCREMENT, mapa_id INTEGER NOT NULL, nome TEXT NOT NULL, ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE TABLE IF NOT EXISTS me_temas (id INTEGER PRIMARY KEY AUTOINCREMENT, perspectiva_id INTEGER NOT NULL, nome TEXT NOT NULL, ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE TABLE IF NOT EXISTS me_objetivos (id INTEGER PRIMARY KEY AUTOINCREMENT, perspectiva_id INTEGER NOT NULL, tema_id INTEGER, oe_id INTEGER NOT NULL, ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE TABLE IF NOT EXISTS acoes_estrategicas (id INTEGER PRIMARY KEY AUTOINCREMENT, objetivo_id INTEGER NOT NULL, codigo TEXT DEFAULT '', nome TEXT NOT NULL, descricao TEXT DEFAULT '', ordem INTEGER DEFAULT 0, status TEXT DEFAULT 'ativo')");
    DB.db.run("CREATE INDEX IF NOT EXISTS idx_acoes_oe ON acoes_estrategicas(objetivo_id)");
    // iniciativa estratégica = desdobramento da ação; um ou mais projetos realizam a iniciativa
    DB.db.run("CREATE TABLE IF NOT EXISTS iniciativas_estrategicas (id INTEGER PRIMARY KEY AUTOINCREMENT, acao_id INTEGER NOT NULL, codigo TEXT DEFAULT '', nome TEXT NOT NULL, descricao TEXT DEFAULT '', ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE INDEX IF NOT EXISTS idx_ini_acao ON iniciativas_estrategicas(acao_id)");
    try { var cp = DB.all('PRAGMA table_info(projetos)').map(function (c) { return c.name; }); if (cp.length && cp.indexOf('iniciativa_id') < 0) DB.db.run('ALTER TABLE projetos ADD COLUMN iniciativa_id INTEGER'); } catch (e) {}
  });

  // ---------- dados ----------
  function mapas() { return DB.all('SELECT * FROM me_mapas ORDER BY id'); }
  function mapaAtual(q) { var id = parseInt(q && q.mapa, 10); return (id && DB.one('SELECT * FROM me_mapas WHERE id = ?', [id])) || DB.one('SELECT * FROM me_mapas ORDER BY id LIMIT 1'); }
  function persps(mid) { return DB.all('SELECT * FROM me_perspectivas WHERE mapa_id = ? ORDER BY ordem, id', [mid]); }
  function temas(pid) { return DB.all('SELECT * FROM me_temas WHERE perspectiva_id = ? ORDER BY ordem, id', [pid]); }
  function objs(pid) {
    return DB.all('SELECT mo.id, mo.perspectiva_id, mo.tema_id, mo.oe_id, mo.ordem, o.codigo, o.nome, o.descricao FROM me_objetivos mo JOIN objetivos_estrategicos o ON o.id = mo.oe_id WHERE mo.perspectiva_id = ? ORDER BY mo.ordem, mo.id', [pid]);
  }
  function limpar() { DB.run('DELETE FROM me_objetivos WHERE oe_id NOT IN (SELECT id FROM objetivos_estrategicos)'); }
  function proxCodigo() { var n = DB.one('SELECT COUNT(*) AS n FROM objetivos_estrategicos').n + 1, c; do { c = 'OE-' + (n < 10 ? '0' : '') + n; n++; } while (DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(codigo) = ?', [c.toLowerCase()])); return c; }
  function nCaps(oe) { return DB.one('SELECT COUNT(*) AS n FROM objetivo_capacidades WHERE objetivo_id = ?', [oe]).n; }
  function acoesDoOe(oe) { try { return DB.all("SELECT * FROM acoes_estrategicas WHERE objetivo_id = ? AND COALESCE(status,'ativo') <> 'inativo' ORDER BY ordem, id", [oe]); } catch (e) { return []; } }
  function nAcoes(oe) { try { return DB.one('SELECT COUNT(*) AS n FROM acoes_estrategicas WHERE objetivo_id = ?', [oe]).n; } catch (e) { return 0; } }
  function reordenar(tab, filtroSql, args, ids) { ids.forEach(function (id, k) { DB.run('UPDATE ' + tab + ' SET ordem = ? WHERE id = ?', [k + 1, id]); }); }
  function v(d, s) { return d.querySelector(s).value; }
  function fecha(d) { var m = bootstrap.Modal.getInstance(d.closest ? d.closest('.modal') : d); if (m) m.hide(); }

  // ---------- imagem ----------
  var FS = 12;   // fonte base dos objetivos (figura compacta)
  function quebra(t, max) { return w.SvgUtil.quebra(t, max); }
  function tx(x, y, linhas, cor, size, anc, peso) {
    var o = '<text x="' + x + '" y="' + (y - (linhas.length - 1) * size * 0.6) + '" text-anchor="' + (anc || 'middle') + '" font-family="Arial,Helvetica,sans-serif" font-size="' + size + '" fill="' + cor + '" font-weight="' + (peso || 600) + '">';
    linhas.forEach(function (l, i) { o += '<tspan x="' + x + '" dy="' + (i ? size * 1.22 : 0) + '">' + h(l) + '</tspan>'; });
    return o + '</text>';
  }
  function ic(x, y, acao, dica, tipo) {
    var g = tipo === '+' ? '<path d="M-3.5 0H3.5M0-3.5V3.5" stroke="#0a6fc2" stroke-width="1.8" stroke-linecap="round"/>' :
      tipo === 't' ? '<rect x="-4.5" y="-4.5" width="9" height="9" rx="2" fill="none" stroke="#0a6fc2" stroke-width="1.2" stroke-dasharray="2 1.5"/><path d="M-2 0H2M0-2V2" stroke="#0a6fc2" stroke-width="1.3"/>' :
      '<path d="M-4 4L-3.5 1.3L2.2-4.4L4.4-2.2L-1.3 3.5Z" fill="none" stroke="#0a6fc2" stroke-width="1.3" stroke-linejoin="round"/>';
    return '<g class="ic" onclick="' + acao + '" transform="translate(' + x + ',' + y + ')"><title>' + h(dica) + '</title><circle r="9" fill="#fff" stroke="#0a6fc2" stroke-width="1.4"/>' + g + '</g>';
  }
  function barra(rotulo, texto, y, ed, acao, dica, W) {
    if (!texto && !ed) return { s: '', h: 0 };
    var linhas = quebra(rotulo + ' ' + (texto || '(clique no lápis para informar)'), 128).slice(0, 2), hh = 12 + linhas.length * 16;
    var o = '<rect x="24" y="' + y + '" width="' + (W - 48) + '" height="' + hh + '" rx="7" fill="#06183e"/><text x="' + (W / 2) + '" y="' + (y + 18) + '" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="12.5" fill="#fff">';
    linhas.forEach(function (l, i) {
      var t = h(l);
      if (i === 0 && l.indexOf(rotulo) === 0) t = '<tspan font-weight="700" fill="#12d3a8">' + h(rotulo) + '</tspan>' + h(l.slice(rotulo.length));
      o += '<tspan x="' + (W / 2) + '" dy="' + (i ? 16 : 0) + '">' + t + '</tspan>';
    });
    o += '</text>';
    if (ed) o += ic(W - 40, y + hh / 2, acao, dica);
    return { s: o, h: hh };
  }
  function svgMapa(m, ed) {
    var W = 960, L = 24, y = 10, o = '', ps = persps(m.id);
    o += '<text x="' + (W / 2) + '" y="' + (y + 16) + '" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="19" font-weight="700" fill="#06183e">' + h(m.nome) + '</text>';
    y += 30;
    var b = barra('Missão:', m.missao, y, ed, "Mapa.texto(" + m.id + ",'missao')", 'Editar a missão', W); o += b.s; y += b.h + (b.h ? 6 : 0);
    b = barra('Visão:', m.visao, y, ed, "Mapa.texto(" + m.id + ",'visao')", 'Editar a visão', W); o += b.s; y += b.h + (b.h ? 10 : 0);
    y += 4;
    ps.forEach(function (p, pi) {
      var cor = CORES[pi % CORES.length], ts = temas(p.id), os = objs(p.id);
      var grupos = ts.map(function (t) { return { t: t, os: os.filter(function (x) { return x.tema_id === t.id; }) }; });
      var soltos = os.filter(function (x) { return !x.tema_id || !ts.some(function (t) { return t.id === x.tema_id; }); });
      if (soltos.length || !grupos.length) grupos.push({ t: null, os: soltos });
      grupos.forEach(function (g) { g.cols = g.os.length >= 2 ? 2 : 1; g.rows = Math.max(1, Math.ceil(g.os.length / g.cols)); });
      var cx = L + 44, cw = W - L - 10 - cx, gap = 10, soma = grupos.reduce(function (a, g) { return a + g.cols; }, 0);
      var util = cw - gap * (grupos.length - 1), BH = 52, BG = 8;
      var gh = Math.max.apply(null, grupos.map(function (g) { return (g.t ? 28 : 4) + g.rows * (BH + BG) + 2; }));
      var ph = Math.max(gh + 34, 86), x0 = L, w0 = W - 2 * L;
      o += '<rect x="' + x0 + '" y="' + y + '" width="' + w0 + '" height="' + ph + '" rx="10" fill="#e8f1fb" stroke="#0a6fc2" stroke-width="1.3" stroke-dasharray="6 4"/>';
      var ln = quebra(p.nome, Math.max(8, Math.floor((ph - 14) / 7.8))).slice(0, 2);
      o += '<text transform="translate(' + (x0 + (ln.length > 1 ? 19 : 24)) + ',' + (y + ph / 2) + ') rotate(-90)" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="13" font-weight="700" fill="#06183e">' + ln.map(function (t, k) { return '<tspan x="0" dy="' + (k ? 14 : 0) + '">' + h(t) + '</tspan>'; }).join('') + '</text>';
      if (ed) {
        o += ic(x0 + w0 - 16, y + 14, 'Mapa.persp(' + m.id + ',' + p.id + ')', 'Editar, mover ou excluir a perspectiva "' + p.nome + '"');
        o += ic(x0 + w0 - 40, y + 14, 'Mapa.obj(' + m.id + ',' + p.id + ',0,0)', 'Novo objetivo em "' + p.nome + '"', '+');
        o += ic(x0 + w0 - 64, y + 14, 'Mapa.tema(' + m.id + ',' + p.id + ',0)', 'Novo tema (agrupador) em "' + p.nome + '"', 't');
      }
      var gx = cx;
      grupos.forEach(function (g) {
        var gw = util * g.cols / soma, gy = y + 26, bw = (gw - 12 - 8 * (g.cols - 1)) / g.cols;
        if (g.t) {
          o += '<rect x="' + gx + '" y="' + gy + '" width="' + gw + '" height="' + (ph - 34) + '" rx="8" fill="#fff" stroke="' + cor + '" stroke-width="1.2" stroke-dasharray="5 3"/>' + tx(gx + gw / 2, gy + 15, [g.t.nome], '#06183e', 12, 'middle', 700);
          if (ed) { o += ic(gx + gw - 13, gy + 12, 'Mapa.tema(' + m.id + ',' + p.id + ',' + g.t.id + ')', 'Editar o tema "' + g.t.nome + '"'); o += ic(gx + gw - 35, gy + 12, 'Mapa.obj(' + m.id + ',' + p.id + ',' + g.t.id + ',0)', 'Novo objetivo no tema "' + g.t.nome + '"', '+'); }
        }
        var top = gy + (g.t ? 26 : 4);
        if (!g.os.length && ed) o += tx(gx + gw / 2, top + 20, [g.t ? '(sem objetivos)' : '(sem objetivos — use +)'], '#8a96a3', 10, 'middle', 400);
        g.os.forEach(function (ob, k) {
          var col = k % g.cols, row = Math.floor(k / g.cols), bx = gx + 6 + col * (bw + 8), by = top + row * (BH + BG);
          var nomeLinhas = quebra(ob.nome, Math.max(10, Math.floor((bw - 24) / (FS * 0.56)))).slice(0, 3);
          o += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + BH + '" rx="6" fill="' + cor + '"/>' + tx(bx + bw / 2, by + BH / 2 + 4, nomeLinhas, '#fff', FS);
          if (ed) o += ic(bx + bw - 11, by + 11, 'Mapa.obj(' + m.id + ',' + p.id + ',' + (ob.tema_id || 0) + ',' + ob.id + ')', 'Editar ou excluir: ' + ob.nome);
        });
        gx += gw + gap;
      });
      y += ph;
      if (pi < ps.length - 1) { o += '<polygon points="' + (W / 2) + ',' + (y + 3) + ' ' + (W / 2 + 19) + ',' + (y + 17) + ' ' + (W / 2 + 9) + ',' + (y + 17) + ' ' + (W / 2 + 9) + ',' + (y + 23) + ' ' + (W / 2 - 9) + ',' + (y + 23) + ' ' + (W / 2 - 9) + ',' + (y + 17) + ' ' + (W / 2 - 19) + ',' + (y + 17) + '" fill="#0a6fc2"/>'; y += 27; }
    });
    if (ed) { y += 10; o += ic(W / 2 - 40, y + 4, 'Mapa.persp(' + m.id + ',0)', 'Nova perspectiva', '+') + tx(W / 2 - 24, y + 8, ['Nova perspectiva'], '#0a6fc2', 11, 'start', 600); y += 20; }
    var H = y + 10;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '"><rect width="' + W + '" height="' + H + '" fill="#ffffff"/>' + o + '</svg>';
  }

  // ---------- ações ----------
  function sel(id, opcoes, atual) { return '<select class="form-select" id="' + id + '">' + opcoes.map(function (o) { return '<option value="' + o[0] + '"' + (String(o[0]) === String(atual) ? ' selected' : '') + '>' + h(o[1]) + '</option>'; }).join('') + '</select>'; }
  function volta(mid) { Nav.ir('#/estrategia?mapa=' + mid); }
  function extra(dlg, html, ligacoes) {
    var bd = dlg.querySelector('.modal-body'), ex = document.createElement('div'); ex.className = 'd-flex flex-wrap gap-2 mt-3 pt-2 border-top'; ex.innerHTML = html; bd.appendChild(ex);
    Object.keys(ligacoes).forEach(function (s) { Array.prototype.forEach.call(ex.querySelectorAll(s), function (b) { b.onclick = function () { ligacoes[s](b); }; }); });
  }
  var Mapa = w.Mapa = {
    novo: function () {
      Mdl('Novo mapa estratégico', '<label class="form-label">Nome do mapa *</label><input class="form-control" id="mn" value="' + h('Mapa Estratégico ' + new Date().getFullYear()) + '"><div class="form-text">Serão criadas as perspectivas padrão, que você pode renomear, reordenar, incluir ou excluir.</div>', function (d) {
        var n = v(d, '#mn').trim(); if (!n) throw new Error('Informe o nome do mapa.');
        var id = DB.tx(function () { DB.run('INSERT INTO me_mapas (nome) VALUES (?)', [n]); var mid = DB.lastId(); PADRAO.forEach(function (p, i) { DB.run('INSERT INTO me_perspectivas (mapa_id,nome,ordem) VALUES (?,?,?)', [mid, p, i + 1]); }); return mid; });
        volta(id);
      }, 'Criar mapa');
    },
    dados: function (mid) {
      var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [mid]);
      var dlg = Mdl('Dados do mapa', '<label class="form-label">Nome do mapa *</label><input class="form-control" id="mn" value="' + h(m.nome) + '">', function (d) {
        var n = v(d, '#mn').trim(); if (!n) throw new Error('Informe o nome.'); DB.tx(function () { DB.run('UPDATE me_mapas SET nome = ? WHERE id = ?', [n, mid]); }); volta(mid);
      });
      extra(dlg, '<button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir este mapa</button>', { '[data-x]': function () {
        if (!confirm('Excluir o mapa "' + m.nome + '" com suas perspectivas e temas? Os objetivos estratégicos continuam no módulo Valor Estratégico.')) return;
        fecha(dlg); DB.tx(function () { persps(mid).forEach(function (p) { DB.run('DELETE FROM me_objetivos WHERE perspectiva_id = ?', [p.id]); DB.run('DELETE FROM me_temas WHERE perspectiva_id = ?', [p.id]); }); DB.run('DELETE FROM me_perspectivas WHERE mapa_id = ?', [mid]); DB.run('DELETE FROM me_mapas WHERE id = ?', [mid]); }); Nav.ir('#/estrategia');
      } });
    },
    texto: function (mid, campo) {
      var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [mid]), rot = campo === 'missao' ? 'Missão' : 'Visão';
      Mdl('Editar — ' + rot, '<label class="form-label">' + rot + '</label><textarea class="form-control" id="tx" rows="4">' + h(m[campo] || '') + '</textarea>', function (d) {
        DB.tx(function () { DB.run('UPDATE me_mapas SET ' + (campo === 'missao' ? 'missao' : 'visao') + ' = ? WHERE id = ?', [v(d, '#tx').trim(), mid]); }); volta(mid);
      });
    },
    persp: function (mid, id) {
      var p = id ? DB.one('SELECT * FROM me_perspectivas WHERE id = ?', [id]) : { nome: '' };
      var dlg = Mdl(id ? 'Editar perspectiva' : 'Nova perspectiva', '<label class="form-label">Nome da perspectiva *</label><input class="form-control" id="pn" value="' + h(p.nome) + '" placeholder="Ex.: Sociedade, Processos internos, Recursos…">', function (d) {
        var n = v(d, '#pn').trim(); if (!n) throw new Error('Informe o nome da perspectiva.');
        DB.tx(function () { if (id) DB.run('UPDATE me_perspectivas SET nome = ? WHERE id = ?', [n, id]); else DB.run('INSERT INTO me_perspectivas (mapa_id,nome,ordem) VALUES (?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM me_perspectivas WHERE mapa_id = ?))', [mid, n, mid]); });
        volta(mid);
      }, id ? 'Salvar' : 'Adicionar');
      if (!id) return;
      extra(dlg, '<button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-up"></i> Subir</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1"><i class="bi bi-arrow-down"></i> Descer</button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir</button>', {
        '[data-mv]': function (b) { var l = persps(mid), i = l.findIndex(function (x) { return x.id === id; }), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= l.length) return; fecha(dlg); DB.tx(function () { l.splice(j, 0, l.splice(i, 1)[0]); reordenar('me_perspectivas', '', [], l.map(function (x) { return x.id; })); }); volta(mid); },
        '[data-x]': function () {
          var n = DB.one('SELECT COUNT(*) AS n FROM me_objetivos WHERE perspectiva_id = ?', [id]).n;
          if (n) { alert('Esta perspectiva tem ' + n + ' objetivo(s). Mova ou exclua os objetivos antes de excluí-la.'); return; }
          if (!confirm('Excluir a perspectiva "' + p.nome + '"?')) return;
          fecha(dlg); DB.tx(function () { DB.run('DELETE FROM me_temas WHERE perspectiva_id = ?', [id]); DB.run('DELETE FROM me_perspectivas WHERE id = ?', [id]); }); volta(mid);
        } });
    },
    tema: function (mid, pid, id) {
      var t = id ? DB.one('SELECT * FROM me_temas WHERE id = ?', [id]) : { nome: '', perspectiva_id: pid };
      var dlg = Mdl(id ? 'Editar tema' : 'Novo tema', '<div class="mb-2"><label class="form-label">Nome do tema (agrupador) *</label><input class="form-control" id="tn" value="' + h(t.nome) + '" placeholder="Ex.: Gestão de pessoas, Eficiência operacional…"></div><div><label class="form-label">Perspectiva</label>' + sel('tp', persps(mid).map(function (p) { return [p.id, p.nome]; }), t.perspectiva_id) + '</div>', function (d) {
        var n = v(d, '#tn').trim(); if (!n) throw new Error('Informe o nome do tema.'); var np = +v(d, '#tp');
        DB.tx(function () {
          if (id) { DB.run('UPDATE me_temas SET nome = ?, perspectiva_id = ? WHERE id = ?', [n, np, id]); if (np !== t.perspectiva_id) DB.run('UPDATE me_objetivos SET perspectiva_id = ? WHERE tema_id = ?', [np, id]); }
          else DB.run('INSERT INTO me_temas (perspectiva_id,nome,ordem) VALUES (?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM me_temas WHERE perspectiva_id = ?))', [np, n, np]);
        }); volta(mid);
      }, id ? 'Salvar' : 'Adicionar');
      if (!id) return;
      extra(dlg, '<button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-left"></i> Mover</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1">Mover <i class="bi bi-arrow-right"></i></button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir tema</button>', {
        '[data-mv]': function (b) { var l = temas(t.perspectiva_id), i = l.findIndex(function (x) { return x.id === id; }), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= l.length) return; fecha(dlg); DB.tx(function () { l.splice(j, 0, l.splice(i, 1)[0]); reordenar('me_temas', '', [], l.map(function (x) { return x.id; })); }); volta(mid); },
        '[data-x]': function () { if (!confirm('Excluir o tema "' + t.nome + '"? Os objetivos dele permanecem na perspectiva, sem agrupador.')) return; fecha(dlg); DB.tx(function () { DB.run('UPDATE me_objetivos SET tema_id = NULL WHERE tema_id = ?', [id]); DB.run('DELETE FROM me_temas WHERE id = ?', [id]); }); volta(mid); } });
    },
    /** id = vínculo do mapa; oe = objetivo já existente no Valor (ainda fora do mapa). */
    obj: function (mid, pid, tid, id, oe) {
      var r = id ? DB.one('SELECT mo.*, o.codigo, o.nome, o.descricao FROM me_objetivos mo JOIN objetivos_estrategicos o ON o.id = mo.oe_id WHERE mo.id = ?', [id])
        : (oe ? (function () { var o = DB.one('SELECT * FROM objetivos_estrategicos WHERE id = ?', [oe]); return { perspectiva_id: pid, tema_id: tid || null, oe_id: oe, codigo: o.codigo, nome: o.nome, descricao: o.descricao || '' }; })()
          : { perspectiva_id: pid, tema_id: tid || null, oe_id: 0, codigo: proxCodigo(), nome: '', descricao: '' });
      var ps = persps(mid), pAtual = r.perspectiva_id || pid;
      function opTemas(p, atual) { return '<option value="">— sem tema —</option>' + temas(p).map(function (t) { return '<option value="' + t.id + '"' + (String(t.id) === String(atual) ? ' selected' : '') + '>' + h(t.nome) + '</option>'; }).join(''); }
      var acoesHtml = '<div class="form-text mt-2">As <b>ações estratégicas</b>, as <b>iniciativas</b> e os <b>projetos</b> deste objetivo são preenchidos no botão <b>Ações e iniciativas</b> (tabela de desdobramento do mapa).</div>';
      var dlg = Mdl(id ? 'Editar objetivo estratégico' : 'Novo objetivo estratégico',
        '<div class="mb-2"><label class="form-label">Objetivo estratégico *</label><textarea class="form-control" id="on" rows="2" placeholder="Ex.: Assegurar um atendimento ágil e confiável ao cidadão">' + h(r.nome) + '</textarea></div>' +
        '<div class="row g-2 mb-2"><div class="col-4"><label class="form-label">Código</label><input class="form-control" id="oc" maxlength="20" value="' + h(r.codigo) + '"></div><div class="col-8"><label class="form-label">Perspectiva</label>' + sel('op', ps.map(function (p) { return [p.id, p.nome]; }), pAtual) + '</div></div>' +
        '<div class="mb-2"><label class="form-label">Tema (agrupador, opcional)</label><select class="form-select" id="ot">' + opTemas(pAtual, r.tema_id) + '</select></div>' +
        '<div><label class="form-label">Descrição (opcional)</label><textarea class="form-control" id="od" rows="2">' + h(r.descricao || '') + '</textarea></div>' +
        '<div class="form-text mt-2">Este objetivo fica disponível, com o mesmo código, na lista de escolha do módulo <b>Valor Estratégico</b> (nova capacidade).</div>' + acoesHtml,
        function (d) {
          var nome = v(d, '#on').trim(), cod = v(d, '#oc').trim(), np = +v(d, '#op'), nt = v(d, '#ot') ? +v(d, '#ot') : null, desc = v(d, '#od').trim();
          if (!nome) throw new Error('Informe o objetivo estratégico.'); if (!cod) throw new Error('Informe o código.');
          if (DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(codigo) = ? AND id <> ?', [cod.toLowerCase(), r.oe_id || 0])) throw new Error('Já existe um objetivo com esse código.');
          DB.tx(function () {
            var oeId = r.oe_id;
            if (oeId) DB.run('UPDATE objetivos_estrategicos SET codigo=?, nome=?, descricao=? WHERE id=?', [cod, nome, desc, oeId]);
            else { DB.run("INSERT INTO objetivos_estrategicos (codigo,nome,descricao,status) VALUES (?,?,?,'ativo')", [cod, nome, desc]); oeId = DB.lastId(); }
            if (id) DB.run('UPDATE me_objetivos SET perspectiva_id=?, tema_id=? WHERE id=?', [np, nt, id]);
            else DB.run('INSERT INTO me_objetivos (perspectiva_id,tema_id,oe_id,ordem) VALUES (?,?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM me_objetivos WHERE perspectiva_id = ?))', [np, nt, oeId, np]);
          });
          volta(mid);
        }, id ? 'Salvar' : 'Adicionar');
      try { dlg.querySelector('.modal-dialog').classList.add('modal-lg'); } catch (e) {}
      dlg.querySelector('#op').addEventListener('change', function () { dlg.querySelector('#ot').innerHTML = opTemas(+this.value, ''); });
      if (!id) return;
      var n = nCaps(r.oe_id);
      extra(dlg, '<a class="btn btn-sm btn-outline-secondary" href="#/valor/objetivos" data-bs-dismiss="modal"><i class="bi bi-bullseye"></i> ' + n + ' capacidade(s) no Valor Estratégico</a><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-left"></i> Mover</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1">Mover <i class="bi bi-arrow-right"></i></button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir</button>', {
        '[data-mv]': function (b) {
          var l = objs(r.perspectiva_id).filter(function (x) { return (x.tema_id || null) === (r.tema_id || null); }), i = l.findIndex(function (x) { return x.id === id; }), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= l.length) return;
          fecha(dlg); DB.tx(function () { var all = objs(r.perspectiva_id), a = all.findIndex(function (x) { return x.id === l[i].id; }), c = all.findIndex(function (x) { return x.id === l[j].id; }); all.splice(c, 0, all.splice(a, 1)[0]); reordenar('me_objetivos', '', [], all.map(function (x) { return x.id; })); }); volta(mid);
        },
        '[data-x]': function () {
          if (n) { alert('Este objetivo tem ' + n + ' capacidade(s) no módulo Valor Estratégico. Reatribua ou exclua essas capacidades antes de excluí-lo.'); return; }
          if (!confirm('Excluir o objetivo estratégico "' + r.nome + '"? Ele também sai do módulo Valor Estratégico.')) return;
          fecha(dlg); DB.tx(function () {
            try { semVinculo('objetivo_id = ' + (+r.oe_id)); DB.run('DELETE FROM iniciativas_estrategicas WHERE acao_id IN (SELECT id FROM acoes_estrategicas WHERE objetivo_id = ?)', [r.oe_id]); DB.run('DELETE FROM acoes_estrategicas WHERE objetivo_id = ?', [r.oe_id]); } catch (e) {}
            DB.run('DELETE FROM me_objetivos WHERE id = ?', [id]);
            DB.run('DELETE FROM objetivos_estrategicos WHERE id = ?', [r.oe_id]);
          }); volta(mid);
        } });
    },
    svg: function (id, fmt) {
      var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [id]), s = svgMapa(m, false), n = 'mapa-estrategico-' + String(m.nome).replace(/[^A-Za-z0-9_-]+/g, '_');
      if (fmt === 'png') w.SvgUtil.png(s, n + '.png'); else Mapris.baixar(n + '.svg', s, 'image/svg+xml');
    },
    imprimir: function () { document.body.classList.add('imp-cva'); window.print(); setTimeout(function () { document.body.classList.remove('imp-cva'); }, 500); },
    /** Lista de escolha do módulo Valor Estratégico: objetivos do mapa, agrupados por perspectiva. */
    objetivosParaEscolha: function () {
      var res = [];
      DB.all('SELECT p.nome AS pn, mm.nome AS mn, o.codigo, o.nome FROM me_objetivos mo JOIN me_perspectivas p ON p.id = mo.perspectiva_id JOIN me_mapas mm ON mm.id = p.mapa_id JOIN objetivos_estrategicos o ON o.id = mo.oe_id ORDER BY p.mapa_id, p.ordem, mo.ordem').forEach(function (x) { res.push({ grupo: (DB.one('SELECT COUNT(*) AS n FROM me_mapas').n > 1 ? x.mn + ' › ' : '') + x.pn, codigo: x.codigo, nome: x.nome }); });
      DB.all("SELECT codigo, nome FROM objetivos_estrategicos WHERE status = 'ativo' AND id NOT IN (SELECT oe_id FROM me_objetivos) ORDER BY codigo").forEach(function (x) { res.push({ grupo: 'Fora do mapa estratégico', codigo: x.codigo, nome: x.nome }); });
      return res;
    },
    resumo: function () { var m = mapaAtual({}); return m ? { nome: m.nome, objetivos: DB.one('SELECT COUNT(*) AS n FROM me_objetivos WHERE perspectiva_id IN (SELECT id FROM me_perspectivas WHERE mapa_id = ?)', [m.id]).n } : null; }
  };

  // ---------- tabela de ações e iniciativas estratégicas (objetivo → ação → iniciativa → projetos) ----------
  var SIT = { critico: ['#c62828', '#ffffff', 'Crítico'], atencao: ['#f9a825', '#3b2f00', 'Atenção'], ok: ['#2e7d32', '#ffffff', 'Em conformidade'], nd: ['#94a3b8', '#ffffff', 'Sem dados'] };
  var SIT_PESO = { critico: 3, atencao: 2, ok: 1 };
  var COR_ST = { 'Concluído': '#2e7d32', 'Em andamento': '#0a6fc2', 'Planejado': '#64748b', 'Suspenso': '#f9a825', 'Cancelado': '#6b7280' };
  function q1(sql, args) { try { return DB.all(sql, args); } catch (e) { return []; } }
  /** Situação do projeto = situação do seu indicador de progresso (verde/amarelo/vermelho). */
  function sitProjeto(pid) {
    try { var i = DB.one('SELECT id FROM indicadores WHERE codigo = ?', ['PRJ-PROG-' + pid]); var r = i && w.Ind && Ind.situacao ? Ind.situacao(i.id) : null; return SIT_PESO[r] ? r : null; } catch (e) { return null; }
  }
  function carregaProjs(sql, args) { return q1(sql, args).map(function (p) { p.sit = sitProjeto(p.id); return p; }); }
  var COLS_P = 'SELECT id, codigo, nome, status, progresso FROM projetos ';
  function projsDaIni(iid) { return carregaProjs(COLS_P + 'WHERE iniciativa_id = ? ORDER BY codigo, nome', [iid]); }
  function projsSemIni(aid) { return carregaProjs(COLS_P + 'WHERE acao_id = ? AND (iniciativa_id IS NULL OR iniciativa_id = 0) ORDER BY codigo, nome', [aid]); }
  function projsSemAcao(oe) { return carregaProjs(COLS_P + 'WHERE objetivo_id = ? AND (acao_id IS NULL OR acao_id = 0 OR acao_id NOT IN (SELECT id FROM acoes_estrategicas WHERE objetivo_id = ?)) ORDER BY codigo, nome', [oe, oe]); }
  /** Pior situação entre os projetos da iniciativa e progresso médio. */
  function resumoIni(projs) {
    var pior = null, soma = 0;
    projs.forEach(function (p) { soma += +p.progresso || 0; if (p.sit && (!pior || SIT_PESO[p.sit] > SIT_PESO[pior])) pior = p.sit; });
    return { sit: pior || 'nd', media: projs.length ? Math.round(soma / projs.length) : 0, n: projs.length };
  }
  function dadosTabela(m) {
    return persps(m.id).map(function (p) {
      var ts = temas(p.id), os = objs(p.id), ordem = [];
      ts.forEach(function (t) { os.forEach(function (x) { if (x.tema_id === t.id) ordem.push(x); }); });
      os.forEach(function (x) { if (!x.tema_id || !ts.some(function (t) { return t.id === x.tema_id; })) ordem.push(x); });
      return { persp: p, objetivos: ordem.map(function (ob) {
        var blocos = acoesDoOe(ob.oe_id).map(function (a) {
          var linhas = q1('SELECT * FROM iniciativas_estrategicas WHERE acao_id = ? ORDER BY ordem, id', [a.id]).map(function (i) { var ps = projsDaIni(i.id); return { ini: i, projs: ps, res: resumoIni(ps) }; });
          var sem = projsSemIni(a.id); if (sem.length) linhas.push({ ini: null, projs: sem, res: resumoIni(sem), rotulo: '(projetos sem iniciativa vinculada)' });
          return { acao: a, linhas: linhas.length ? linhas : [{ ini: null, projs: [], vazia: true }] };
        });
        var sa = projsSemAcao(ob.oe_id); if (sa.length) blocos.push({ acao: null, linhas: [{ ini: null, projs: sa, res: resumoIni(sa), rotulo: '(projetos sem ação vinculada)' }] });
        return { obj: ob, blocos: blocos };
      }) };
    });
  }
  function nomeProj(p) { return (p.codigo ? p.codigo + ' — ' : '') + p.nome; }
  function pct(p) { return Math.round(+p.progresso || 0) + '%'; }
  function selo(t, c, extra) { return '<span class="ag-b" style="background:' + c[0] + ';color:' + c[1] + ';margin-left:0;margin-right:5px"' + (extra || '') + '>' + h(t) + '</span>'; }
  function btnI(ic, dica, acao, cls) { return '<button type="button" class="btn btn-sm btn-link p-0 ms-1 no-print ' + (cls || 'text-secondary') + '" title="' + h(dica) + '" onclick="' + acao + '"><i class="bi ' + ic + '"></i></button>'; }

  function htmlTabela(q) {
    var m = mapaAtual(q); if (!m) return '<div class="pagina"><div class="cartao"><div class="vazio">Nenhum mapa estratégico criado.</div></div></div>';
    var D = dadosTabela(m), nO = 0, nA = 0, nI = 0, nP = 0;
    D.forEach(function (g) { g.objetivos.forEach(function (o) { nO++; o.blocos.forEach(function (b) { if (b.acao) nA++; b.linhas.forEach(function (l) { if (l.ini) nI++; nP += l.projs.length; }); }); }); });
    var o = '<div class="pagina cva-host"><div class="d-flex flex-wrap align-items-center mb-2 no-print"><h1 class="h4 mb-0 me-auto"><i class="bi bi-table"></i> Ações e iniciativas estratégicas</h1>' +
      '<a class="btn btn-outline-secondary btn-sm" style="margin-right:6px" href="#/estrategia?mapa=' + m.id + '"><i class="bi bi-arrow-left"></i> Voltar ao mapa</a>' +
      '<button class="btn btn-sm btn-outline-danger" style="margin-right:6px" onclick="Mapa.tabelaPdf(' + m.id + ')"><i class="bi bi-filetype-pdf"></i> PDF</button>' +
      '<button class="btn btn-sm btn-outline-secondary" onclick="Mapa.imprimir()"><i class="bi bi-printer"></i> Imprimir</button></div>' +
      '<div class="cartao"><h2><span class="me-auto"><i class="bi bi-diagram-2"></i> ' + h(m.nome) + '</span><span class="small fw-normal text-muted">' + nO + ' objetivo(s) · ' + nA + ' ação(ões) · ' + nI + ' iniciativa(s) · ' + nP + ' projeto(s)</span></h2><div class="corpo">' +
      '<p class="ajuda no-print">Desdobramento do mapa: <b>objetivo estratégico → ação estratégica → iniciativa estratégica → projetos</b>. Use <b>+ Ação</b> em cada objetivo e <b>+ Iniciativa</b> em cada ação. Os projetos são vinculados à iniciativa no cadastro do projeto. A barra de cada iniciativa mostra o progresso médio dos projetos e a cor da <b>pior situação</b> entre eles (indicador de progresso de cada projeto).</p>' +
      '<div class="ag-leg mb-2 no-print"><span style="margin-right:6px"><b>Situação:</b></span>' + ['ok', 'atencao', 'critico', 'nd'].map(function (k) { return selo(SIT[k][2], SIT[k]); }).join('') + '</div>';
    if (!nO) return o + '<div class="vazio">O mapa ainda não tem objetivos estratégicos.</div></div></div></div>';
    o += '<div class="table-responsive"><table class="met-tab"><thead><tr><th>Objetivo estratégico</th><th>Ações estratégicas</th><th>Iniciativas estratégicas (progresso)</th><th>Projetos vinculados</th></tr></thead><tbody>';
    D.forEach(function (g) {
      if (!g.objetivos.length) return;
      o += '<tr class="met-p"><td colspan="4">' + h(g.persp.nome) + '</td></tr>';
      g.objetivos.forEach(function (ob) {
        var tot = ob.blocos.reduce(function (s2, b) { return s2 + b.linhas.length; }, 0) || 1, primeiro = true;
        var btnAcao = '<button type="button" class="btn btn-sm btn-outline-primary mt-1 no-print" onclick="Mapa.acao(' + m.id + ',' + ob.obj.oe_id + ',0)"><i class="bi bi-plus-lg"></i> Ação</button>';
        var celO = '<td class="met-o" rowspan="' + tot + '"><small>' + h(ob.obj.codigo || '') + '</small>' + h(ob.obj.nome) + '<div>' + btnAcao + '</div></td>';
        if (!ob.blocos.length) { o += '<tr>' + celO + '<td colspan="3" class="met-vazio">Nenhuma ação estratégica — use “+ Ação” para iniciar o desdobramento deste objetivo.</td></tr>'; return; }
        ob.blocos.forEach(function (b) {
          b.linhas.forEach(function (l, i) {
            o += '<tr>' + (primeiro ? celO : '');
            if (i === 0) {
              o += '<td rowspan="' + b.linhas.length + '">' + (b.acao ? '<b>' + h(b.acao.codigo ? b.acao.codigo + ' — ' : '') + '</b>' + h(b.acao.nome) +
                btnI('bi-pencil', 'Editar ação', 'Mapa.acao(' + m.id + ',' + ob.obj.oe_id + ',' + b.acao.id + ')') + btnI('bi-trash', 'Excluir ação', 'Mapa.acaoDel(' + m.id + ',' + b.acao.id + ')', 'text-danger') +
                '<div><button type="button" class="btn btn-sm btn-outline-primary mt-1 no-print" onclick="Mapa.ini(' + m.id + ',' + b.acao.id + ',0)"><i class="bi bi-plus-lg"></i> Iniciativa</button></div>' : '<span class="met-vazio">(sem ação)</span>') + '</td>';
            }
            primeiro = false;
            // iniciativa
            o += '<td>';
            if (l.ini) {
              var c = SIT[l.res.sit];
              o += '<b>' + h(l.ini.codigo ? l.ini.codigo + ' — ' : '') + '</b>' + h(l.ini.nome) + btnI('bi-pencil', 'Editar iniciativa', 'Mapa.ini(' + m.id + ',' + b.acao.id + ',' + l.ini.id + ')') + btnI('bi-trash', 'Excluir iniciativa', 'Mapa.iniDel(' + m.id + ',' + l.ini.id + ')', 'text-danger');
              o += '<div class="met-prog" title="Pior situação entre os projetos vinculados"><div class="met-bar"><i style="width:' + Math.max(l.res.media, 2) + '%;background:' + c[0] + '"></i></div><span>' + (l.res.n ? l.res.media + '%' : '—') + '</span>' + selo(c[2], c) + '</div>';
            } else if (l.vazia) o += '<span class="met-vazio">Nenhuma iniciativa — use “+ Iniciativa” na ação.</span>';
            else o += '<span class="met-vazio">' + h(l.rotulo || '') + '</span>';
            o += '</td><td>';
            if (!l.projs.length) o += '<span class="met-vazio">' + (l.ini ? 'Nenhum projeto vinculado' : '—') + '</span>';
            l.projs.forEach(function (p) { var c2 = SIT[p.sit || 'nd']; o += '<div class="met-ini"><span class="met-dot" style="background:' + c2[0] + '" title="' + h(c2[2]) + '"></span><a href="#/projeto?id=' + p.id + '">' + h(nomeProj(p)) + '</a><small class="text-muted" style="margin-left:6px">' + h(p.status || '') + ' · ' + pct(p) + '</small></div>'; });
            o += '</td></tr>';
          });
        });
      });
    });
    return o + '</tbody></table></div></div></div></div>';
  }

  /** Formulário de ação (oe = objetivo estratégico; id = 0 para nova). */
  function formAcao(mid, oe, id) {
    var a = id ? DB.one('SELECT * FROM acoes_estrategicas WHERE id = ?', [id]) : { codigo: '', nome: '', descricao: '' }, ob = DB.one('SELECT codigo, nome FROM objetivos_estrategicos WHERE id = ?', [oe]) || {};
    if (!id) { var n = DB.one('SELECT COUNT(*) AS n FROM acoes_estrategicas WHERE objetivo_id = ?', [oe]).n + 1; a.codigo = 'AE-' + (ob.codigo ? String(ob.codigo).replace(/^OE-?/i, '') + '.' : '') + n; }
    Mdl(id ? 'Editar ação estratégica' : 'Nova ação estratégica',
      '<p class="small text-muted mb-2">Objetivo: <b>' + h((ob.codigo ? ob.codigo + ' — ' : '') + (ob.nome || '')) + '</b></p>' +
      '<div class="mb-2"><label class="form-label">Ação estratégica *</label><textarea class="form-control" id="an" rows="2">' + h(a.nome || '') + '</textarea></div>' +
      '<div class="mb-2"><label class="form-label">Código</label><input class="form-control" id="ac" maxlength="20" value="' + h(a.codigo || '') + '"></div>' +
      '<div class="mb-0"><label class="form-label">Descrição (opcional)</label><textarea class="form-control" id="ad" rows="2">' + h(a.descricao || '') + '</textarea></div>',
      function (d) {
        var nome = v(d, '#an').trim(); if (!nome) throw new Error('Informe a ação estratégica.');
        DB.tx(function () {
          if (id) DB.run('UPDATE acoes_estrategicas SET codigo=?, nome=?, descricao=? WHERE id=?', [v(d, '#ac').trim(), nome, v(d, '#ad').trim(), id]);
          else DB.run('INSERT INTO acoes_estrategicas (objetivo_id,codigo,nome,descricao,ordem) VALUES (?,?,?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM acoes_estrategicas WHERE objetivo_id=?))', [oe, v(d, '#ac').trim(), nome, v(d, '#ad').trim(), oe]);
        });
        Nav.ir('#/estrategia-tabela?mapa=' + mid);
      }, id ? 'Salvar' : 'Adicionar');
  }
  function formIni(mid, acaoId, id) {
    var i = id ? DB.one('SELECT * FROM iniciativas_estrategicas WHERE id = ?', [id]) : { codigo: '', nome: '', descricao: '' }, ac = DB.one('SELECT codigo, nome FROM acoes_estrategicas WHERE id = ?', [acaoId]) || {};
    if (!id) { var n = DB.one('SELECT COUNT(*) AS n FROM iniciativas_estrategicas WHERE acao_id = ?', [acaoId]).n + 1; i.codigo = 'IE-' + (ac.codigo ? String(ac.codigo).replace(/^AE-?/i, '') + '.' : '') + n; }
    Mdl(id ? 'Editar iniciativa estratégica' : 'Nova iniciativa estratégica',
      '<p class="small text-muted mb-2">Ação: <b>' + h((ac.codigo ? ac.codigo + ' — ' : '') + (ac.nome || '')) + '</b></p>' +
      '<div class="mb-2"><label class="form-label">Iniciativa estratégica *</label><textarea class="form-control" id="in" rows="2"></textarea></div>' +
      '<div class="mb-2"><label class="form-label">Código</label><input class="form-control" id="ic" maxlength="20" value="' + h(i.codigo || '') + '"></div>' +
      '<div class="mb-0"><label class="form-label">Descrição (opcional)</label><textarea class="form-control" id="id" rows="2">' + h(i.descricao || '') + '</textarea></div>' +
      '<div class="form-text mt-2">Uma iniciativa pode ser desdobrada em um ou mais <b>projetos</b>; vincule-os ao criar ou editar o projeto.</div>',
      function (d) {
        var nome = v(d, '#in').trim(); if (!nome) throw new Error('Informe a iniciativa estratégica.');
        DB.tx(function () {
          if (id) DB.run('UPDATE iniciativas_estrategicas SET codigo=?, nome=?, descricao=? WHERE id=?', [v(d, '#ic').trim(), nome, v(d, '#id').trim(), id]);
          else DB.run('INSERT INTO iniciativas_estrategicas (acao_id,codigo,nome,descricao,ordem) VALUES (?,?,?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM iniciativas_estrategicas WHERE acao_id=?))', [acaoId, v(d, '#ic').trim(), nome, v(d, '#id').trim(), acaoId]);
        });
        Nav.ir('#/estrategia-tabela?mapa=' + mid);
      }, id ? 'Salvar' : 'Adicionar');
    setTimeout(function () { var t = document.querySelector('.modal.show #in'); if (t) t.value = i.nome || ''; }, 30);
  }
  function excluirAcao(mid, id) {
    var a = DB.one('SELECT * FROM acoes_estrategicas WHERE id = ?', [id]); if (!a) return;
    var ni = DB.one('SELECT COUNT(*) AS n FROM iniciativas_estrategicas WHERE acao_id = ?', [id]).n;
    if (!confirm('Excluir a ação "' + a.nome + '"?' + (ni ? '\nAs ' + ni + ' iniciativa(s) dela também serão excluídas.' : '') + '\nOs projetos vinculados não são excluídos: apenas perdem o vínculo com a ação e a iniciativa.')) return;
    DB.tx(function () { semVinculo('acao_id = ' + (+id)); DB.run('DELETE FROM iniciativas_estrategicas WHERE acao_id = ?', [id]); DB.run('DELETE FROM acoes_estrategicas WHERE id = ?', [id]); });
    Nav.ir('#/estrategia-tabela?mapa=' + mid);
  }
  function excluirIni(mid, id) {
    var i = DB.one('SELECT * FROM iniciativas_estrategicas WHERE id = ?', [id]); if (!i) return;
    if (!confirm('Excluir a iniciativa "' + i.nome + '"?\nOs projetos vinculados não são excluídos: apenas perdem o vínculo com a iniciativa.')) return;
    DB.tx(function () { try { DB.run('UPDATE projetos SET iniciativa_id = NULL WHERE iniciativa_id = ?', [id]); } catch (e) {} DB.run('DELETE FROM iniciativas_estrategicas WHERE id = ?', [id]); });
    Nav.ir('#/estrategia-tabela?mapa=' + mid);
  }
  function semVinculo(cond) { try { DB.run('UPDATE projetos SET iniciativa_id = NULL, acao_id = NULL WHERE ' + cond); } catch (e) {} }

  function tabelaPdf(mid) {
    if (!w.jspdf || !w.jspdf.jsPDF) return alert('Biblioteca PDF não disponível. Recarregue o aplicativo.');
    var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [mid]), D = dadosTabela(m), T = Arvore.pdfTxt;
    var doc = new w.jspdf.jsPDF({ unit: 'pt', format: 'a4', orientation: 'landscape' }), M = 32, PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight(), y = M, LH = 10.5;
    var TW = PW - 2 * M, cw = [TW * 0.24, TW * 0.24, TW * 0.24, TW * 0.28], cx = [M, M + cw[0], M + cw[0] + cw[1], M + cw[0] + cw[1] + cw[2]];
    function rgb(hx) { return [parseInt(hx.slice(1, 3), 16), parseInt(hx.slice(3, 5), 16), parseInt(hx.slice(5, 7), 16)]; }
    function f(est, tam, c) { doc.setFont('helvetica', est); doc.setFontSize(tam); c = c || [30, 41, 59]; doc.setTextColor(c[0], c[1], c[2]); }
    function cab() { doc.setFillColor(11, 36, 71); doc.rect(M, y, TW, 18, 'F'); f('bold', 8, [255, 255, 255]); ['OBJETIVO ESTRATÉGICO', 'AÇÕES ESTRATÉGICAS', 'INICIATIVAS ESTRATÉGICAS', 'PROJETOS VINCULADOS'].forEach(function (t, i) { doc.text(T(t), cx[i] + 5, y + 12); }); y += 18; }
    function quebrar(t, i) { return doc.splitTextToSize(T(t), cw[i] - 10); }
    f('normal', 8, [100, 116, 139]); doc.text('Valor-E - Gestão e Realização Estratégica', M, y + 6); y += 22;
    f('bold', 15, [11, 36, 71]); doc.text(T('Ações e iniciativas estratégicas — ' + m.nome), M, y); y += 8;
    f('normal', 8, [100, 116, 139]); doc.text(T('Emitido em ' + E.dataBr(E.hoje()) + '  |  Barra da iniciativa: progresso médio dos projetos; cor = pior situação entre eles.'), M, y + 10); y += 22;
    cab();
    D.forEach(function (g) {
      if (!g.objetivos.length) return;
      if (y + 50 > PH - M - 16) { doc.addPage(); y = M; cab(); }
      doc.setFillColor(232, 241, 251); doc.rect(M, y, TW, 15, 'F'); f('bold', 8.5, [11, 36, 71]); doc.text(T(g.persp.nome), M + 5, y + 10.5); y += 15;
      g.objetivos.forEach(function (ob) {
        var tOb = (ob.obj.codigo ? ob.obj.codigo + '  ' : '') + ob.obj.nome, first = true, yIni = y;
        function cabObj(cont) { f('bold', 8, [15, 23, 42]); var ls = quebrar(tOb + (cont ? ' (cont.)' : ''), 0); doc.text(ls, cx[0] + 5, y + 10); }
        var blocos = ob.blocos.length ? ob.blocos : [{ acao: null, linhas: [{ ini: null, projs: [], vazia: true, semAcoes: true }] }];
        blocos.forEach(function (b) {
          var semAc = b.linhas.length === 1 && b.linhas[0].semAcoes, txA = quebrar(b.acao ? (b.acao.codigo ? b.acao.codigo + ' - ' : '') + b.acao.nome : (semAc ? 'Nenhuma ação estratégica cadastrada' : '(projetos sem ação vinculada)'), 1);
          b.linhas.forEach(function (l, li) {
            f('normal', 8);
            var txI = l.ini ? quebrar((l.ini.codigo ? l.ini.codigo + ' - ' : '') + l.ini.nome, 2) : quebrar(l.semAcoes ? '-' : (l.vazia ? 'Nenhuma iniciativa cadastrada' : (l.rotulo || '')), 2);
            var pr = l.projs.length ? l.projs.map(function (p) { return quebrar(nomeProj(p) + '  [' + (p.status || '-') + ', ' + pct(p) + ']', 3); }) : [['-']];
            var hP = pr.reduce(function (s2, x) { return s2 + x.length * LH + 2; }, 0);
            var hI = txI.length * LH + (l.ini ? 12 : 0), rh = Math.max(hP, hI, li === 0 ? txA.length * LH : 0, first ? quebrar(tOb, 0).length * LH : 0) + 8;
            if (y + rh > PH - M - 14) { doc.addPage(); y = M; cab(); yIni = y; first = true; }
            if (first) { doc.setFillColor(248, 250, 252); cabObj(y !== yIni); }
            first = false;
            if (li === 0) { f('normal', 8); doc.text(txA, cx[1] + 5, y + 10); }
            f('normal', 8); doc.text(txI, cx[2] + 5, y + 10);
            if (l.ini) {
              var c = rgb(SIT[l.res.sit][0]), by = y + 10 + txI.length * LH - 5;
              doc.setFillColor(226, 232, 240); doc.roundedRect(cx[2] + 5, by, cw[2] - 100, 5, 2, 2, 'F'); doc.setFillColor(c[0], c[1], c[2]); doc.roundedRect(cx[2] + 5, by, Math.max(4, (cw[2] - 100) * l.res.media / 100), 5, 2, 2, 'F');
              f('bold', 7, [51, 65, 85]); doc.text((l.res.n ? l.res.media + '%' : '-') + ' ' + T(SIT[l.res.sit][2]), cx[2] + cw[2] - 90, by + 5);
            }
            var yy = y + 10; pr.forEach(function (ls2, k) { var p = l.projs[k]; if (p) { var cc = rgb(SIT[p.sit || 'nd'][0]); doc.setFillColor(cc[0], cc[1], cc[2]); doc.circle(cx[3] + 7, yy - 2.5, 2.4, 'F'); } f('normal', 8); doc.text(ls2, cx[3] + 14, yy); yy += ls2.length * LH + 2; });
            doc.setDrawColor(211, 223, 235); doc.setLineWidth(0.5); doc.line(cx[1], y + rh, M + TW, y + rh); y += rh;
          });
        });
        doc.setDrawColor(150, 170, 195); doc.line(M, y, M + TW, y);
      });
    });
    var n = doc.internal.getNumberOfPages();
    for (var pg = 1; pg <= n; pg++) { doc.setPage(pg); f('normal', 7.5, [140, 150, 165]); doc.text('Página ' + pg + ' de ' + n, PW - M, PH - 14, { align: 'right' }); doc.text('Valor-E - Ações e iniciativas estratégicas', M, PH - 14); }
    doc.save(T('acoes-e-iniciativas-' + String(m.nome).replace(/[^A-Za-z0-9_-]+/g, '_')) + '.pdf');
  }
  w.Mapa.acao = formAcao; w.Mapa.acaoDel = excluirAcao; w.Mapa.ini = formIni; w.Mapa.iniDel = excluirIni;
  w.Mapa.tabelaPdf = tabelaPdf;
  w.Mapa.tabela = function (mid) { Nav.ir('#/estrategia-tabela?mapa=' + mid); };

  // ---------- tela ----------
  function html(q) {
    limpar();
    var m = mapaAtual(q), todos = mapas();
    if (!m) return '<div class="pagina"><h1 class="h4"><i class="bi bi-diagram-2"></i> Mapa Estratégico (BSC)</h1><div class="cartao"><div class="vazio">Nenhum mapa estratégico criado. O mapa organiza os <b>objetivos estratégicos</b> em perspectivas (padrão Balanced Scorecard) e alimenta a lista de objetivos do módulo Valor Estratégico.<br><br><button class="btn btn-success" onclick="Mapa.novo()"><i class="bi bi-plus-lg"></i> Criar mapa estratégico</button></div></div></div>';
    var o = '<div class="pagina cva-host"><div class="d-flex flex-wrap align-items-center mb-2"><h1 class="h4 mb-0 me-auto"><i class="bi bi-diagram-2"></i> Mapa Estratégico (BSC)</h1>' +
      '<select class="form-select form-select-sm" style="width:260px;margin-right:6px" onchange="Nav.ir(\'#/estrategia?mapa=\'+this.value)">' + todos.map(function (x) { return '<option value="' + x.id + '"' + (x.id === m.id ? ' selected' : '') + '>' + h(x.nome) + '</option>'; }).join('') + '</select>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="Mapa.dados(' + m.id + ')"><i class="bi bi-pencil"></i> Mapa</button><button class="btn btn-success btn-sm" onclick="Mapa.novo()"><i class="bi bi-plus-lg"></i> Novo mapa</button></div>';
    o += '<div class="cartao"><h2><span class="me-auto"><i class="bi bi-image"></i> Mapa estratégico — edite direto na imagem</span><span class="no-print"><button class="btn btn-sm btn-outline-secondary" onclick="Mapa.svg(' + m.id + ',\'png\')"><i class="bi bi-filetype-png"></i> PNG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Mapa.svg(' + m.id + ',\'svg\')"><i class="bi bi-filetype-svg"></i> SVG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Mapa.imprimir()"><i class="bi bi-printer"></i> Imprimir</button> <button class="btn btn-sm btn-outline-primary" onclick="Mapa.tabela(' + m.id + ')" title="Objetivos, ações estratégicas e projetos (iniciativas) vinculados"><i class="bi bi-table"></i> Ações e iniciativas</button></span></h2><div class="corpo cva-img mapa-img"><div class="ajuda no-print" style="margin-bottom:6px">Use <b>+</b> para incluir objetivos, o ícone tracejado para criar um <b>tema</b> (agrupador) e o <b>lápis</b> para renomear, mover ou excluir perspectivas, temas, objetivos, missão e visão. Os ícones não saem na imagem exportada.</div>' + svgMapa(m, true) + '</div></div>';
    var fora = DB.all("SELECT * FROM objetivos_estrategicos WHERE status = 'ativo' AND id NOT IN (SELECT oe_id FROM me_objetivos) ORDER BY codigo"), ps = persps(m.id);
    if (fora.length && ps.length) o += '<div class="cartao"><h2><i class="bi bi-bullseye"></i> Objetivos do Valor Estratégico ainda fora do mapa</h2><div class="corpo">' + fora.map(function (x) { return '<div class="cva-item"><div class="me-auto"><b>' + h(x.codigo) + '</b> — ' + h(x.nome) + '</div><button class="btn btn-sm btn-outline-success" onclick="Mapa.obj(' + m.id + ',' + ps[0].id + ',0,0,' + x.id + ')"><i class="bi bi-plus-lg"></i> Incluir no mapa</button></div>'; }).join('') + '</div></div>';
    return o + '</div>';
  }
  Modulos.registrar('/estrategia', { ativo: 'mapa', titulo: 'Mapa Estratégico', html: html });
  Modulos.registrar('/estrategia-tabela', { ativo: 'mapa', titulo: 'Ações e iniciativas estratégicas', html: htmlTabela });
})(window);
