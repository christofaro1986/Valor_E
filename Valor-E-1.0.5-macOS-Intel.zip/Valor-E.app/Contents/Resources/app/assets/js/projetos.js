/* projetos.js — Módulo Projetos: estrutura de tarefas, cronograma, caminho crítico, recursos,
 * custos, linha de base, dependências, sobrecarga, valor do trabalho, riscos e progresso. */
(function (w) {
  'use strict';
  var h = E.esc;
  var TIPOS_DEP = ['FS', 'SS', 'FF', 'SF'];
  var ROTULO_DEP = { FS: 'Término → Início', SS: 'Início → Início', FF: 'Término → Término', SF: 'Início → Término' };
  var ROTULO_DEP_CURTO = { FS: 'TI', SS: 'II', FF: 'TT', SF: 'IT' };

  DB.extras.push(function () {
    DB.db.run("CREATE TABLE IF NOT EXISTS projetos (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, codigo TEXT DEFAULT '', descricao TEXT DEFAULT '', cadeia TEXT DEFAULT '', mapa_id INTEGER, inicio TEXT, fim TEXT, status TEXT DEFAULT 'Em andamento', responsavel TEXT DEFAULT '', progresso REAL DEFAULT 0, orcado REAL DEFAULT 0, criado_em TEXT DEFAULT CURRENT_TIMESTAMP, atualizado_em TEXT DEFAULT CURRENT_TIMESTAMP)");
    DB.db.run("CREATE TABLE IF NOT EXISTS proj_tarefas (id INTEGER PRIMARY KEY AUTOINCREMENT, projeto_id INTEGER NOT NULL, parent_id INTEGER, nome TEXT NOT NULL, inicio TEXT, fim TEXT, duracao INTEGER DEFAULT 1, progresso REAL DEFAULT 0, ordem INTEGER DEFAULT 0, responsavel TEXT DEFAULT '', recurso_id INTEGER, custo REAL DEFAULT 0, notas TEXT DEFAULT '', criado_em TEXT DEFAULT CURRENT_TIMESTAMP)");
    DB.db.run("CREATE TABLE IF NOT EXISTS proj_deps (id INTEGER PRIMARY KEY AUTOINCREMENT, pred_id INTEGER NOT NULL, succ_id INTEGER NOT NULL, tipo TEXT DEFAULT 'FS', lag INTEGER DEFAULT 0, UNIQUE(pred_id, succ_id))");
    DB.db.run("CREATE TABLE IF NOT EXISTS proj_recursos (id INTEGER PRIMARY KEY AUTOINCREMENT, projeto_id INTEGER NOT NULL, nome TEXT NOT NULL, tipo TEXT DEFAULT 'Pessoa', custo_hora REAL DEFAULT 0, capacidade REAL DEFAULT 1, calendario TEXT DEFAULT 'padrão', notas TEXT DEFAULT '')");
    DB.db.run("CREATE TABLE IF NOT EXISTS proj_baseline (id INTEGER PRIMARY KEY AUTOINCREMENT, projeto_id INTEGER NOT NULL, nome TEXT DEFAULT 'Linha de base', salvo_em TEXT DEFAULT CURRENT_TIMESTAMP, dados_json TEXT NOT NULL)");
    try {
      var colsP = DB.all('PRAGMA table_info(projetos)').map(function (c) { return c.name; });
      if (colsP.indexOf('orcado') < 0) DB.db.run('ALTER TABLE projetos ADD COLUMN orcado REAL DEFAULT 0');
      if (colsP.indexOf('macro_id') < 0) DB.db.run('ALTER TABLE projetos ADD COLUMN macro_id INTEGER');
      if (colsP.indexOf('objetivo_id') < 0) DB.db.run('ALTER TABLE projetos ADD COLUMN objetivo_id INTEGER');
      var colsT = DB.all('PRAGMA table_info(proj_tarefas)').map(function (c) { return c.name; });
      if (colsT.indexOf('recurso_id') < 0) DB.db.run('ALTER TABLE proj_tarefas ADD COLUMN recurso_id INTEGER');
      if (colsT.indexOf('custo') < 0) DB.db.run('ALTER TABLE proj_tarefas ADD COLUMN custo REAL DEFAULT 0');
      var colsR = DB.all('PRAGMA table_info(proj_recursos)').map(function (c) { return c.name; });
      if (colsR.indexOf('capacidade') < 0) DB.db.run('ALTER TABLE proj_recursos ADD COLUMN capacidade REAL DEFAULT 1');
    } catch (e) {}
    DB.db.run("CREATE INDEX IF NOT EXISTS idx_proj_tar_proj ON proj_tarefas(projeto_id)");
    DB.db.run("CREATE INDEX IF NOT EXISTS idx_proj_tar_parent ON proj_tarefas(parent_id)");
    DB.db.run("CREATE INDEX IF NOT EXISTS idx_proj_rec_proj ON proj_recursos(projeto_id)");
  });

  function hoje() { return E.hoje(); }
  function addDias(iso, n) {
    if (!iso) return null;
    var d = new Date(iso + 'T12:00:00');
    d.setDate(d.getDate() + (n || 0));
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }
  function diasEntre(a, b) {
    if (!a || !b) return 0;
    return Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000);
  }
  function statusCls(s) {
    if (s === 'Concluído') return 'success';
    if (s === 'Cancelado' || s === 'Suspenso') return 'secondary';
    if (s === 'Atrasado') return 'danger';
    return 'primary';
  }
  function fmtMoney(v) {
    if (v == null || v === '') return '—';
    return Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
  function macrosOpts(sel) {
    var ms = [];
    try {
      ms = DB.all("SELECT m.id, m.nome, m.tipo, COALESCE(c.nome,'') AS ciclo FROM macroprocessos m LEFT JOIN cva_ciclos c ON c.id = m.ciclo_id ORDER BY c.nome, m.ordem, m.nome");
    } catch (e) { ms = []; }
    return '<option value="">— nenhum —</option>' + ms.map(function (m) {
      var rot = (m.tipo ? m.tipo + ': ' : '') + m.nome + (m.ciclo ? ' (' + m.ciclo + ')' : '');
      return '<option value="' + m.id + '"' + (String(sel) === String(m.id) ? ' selected' : '') + '>' + h(rot) + '</option>';
    }).join('');
  }
  function objetivosOpts(sel) {
    var os = [];
    try {
      os = DB.all("SELECT id, codigo, nome FROM objetivos_estrategicos WHERE COALESCE(status,'ativo') = 'ativo' ORDER BY codigo, nome");
    } catch (e) {
      try { os = DB.all("SELECT id, codigo, nome FROM objetivos_estrategicos ORDER BY codigo, nome"); } catch (e2) { os = []; }
    }
    return '<option value="">— nenhum —</option>' + os.map(function (o) {
      var rot = (o.codigo ? o.codigo + ' — ' : '') + (o.nome || '');
      return '<option value="' + o.id + '"' + (String(sel) === String(o.id) ? ' selected' : '') + '>' + h(rot) + '</option>';
    }).join('');
  }
  function recursosOpts(pid, sel) {
    var rs = DB.all('SELECT id, nome FROM proj_recursos WHERE projeto_id = ? ORDER BY nome', [pid]);
    return '<option value="">— nenhum —</option>' + rs.map(function (r) {
      return '<option value="' + r.id + '"' + (String(sel) === String(r.id) ? ' selected' : '') + '>' + h(r.nome) + '</option>';
    }).join('');
  }
  function tipoDepOpts(sel) {
    return TIPOS_DEP.map(function (k) {
      return '<option value="' + k + '"' + (sel === k ? ' selected' : '') + '>' + (ROTULO_DEP[k] || k) + '</option>';
    }).join('');
  }

  function listar(f) {
    f = f || {};
    var wh = [], p = [];
    if (f.macro) { wh.push('macro_id = ?'); p.push(parseInt(f.macro, 10)); }
    if (f.objetivo) { wh.push('objetivo_id = ?'); p.push(parseInt(f.objetivo, 10)); }
    if (f.status) { wh.push('status = ?'); p.push(f.status); }
    if (f.q) { var q = '%' + f.q + '%'; wh.push('(nome LIKE ? OR codigo LIKE ? OR descricao LIKE ? OR responsavel LIKE ?)'); p.push(q, q, q, q); }
    return DB.all('SELECT p.*, (SELECT COUNT(*) FROM proj_tarefas t WHERE t.projeto_id = p.id) AS n_tarefas,' +
      ' (SELECT nome FROM macroprocessos m WHERE m.id = p.macro_id) AS macro_nome,' +
      ' (SELECT CASE WHEN o.codigo IS NOT NULL AND o.codigo != \'\' THEN o.codigo || \' — \' || o.nome ELSE o.nome END FROM objetivos_estrategicos o WHERE o.id = p.objetivo_id) AS objetivo_nome,' +
      ' (SELECT COALESCE(SUM(custo),0) FROM proj_tarefas t WHERE t.projeto_id = p.id) AS custo_real FROM projetos p' +
      (wh.length ? ' WHERE ' + wh.join(' AND ') : '') + ' ORDER BY COALESCE(inicio, criado_em) DESC, id DESC', p);
  }
  function carregar(id) { return DB.one('SELECT * FROM projetos WHERE id = ?', [id]); }
  function tarefasDoProjeto(pid) {
    return DB.all('SELECT t.*, r.nome AS recurso_nome FROM proj_tarefas t LEFT JOIN proj_recursos r ON r.id = t.recurso_id WHERE t.projeto_id = ? ORDER BY t.ordem, t.id', [pid]);
  }
  function depsDoProjeto(pid) {
    return DB.all('SELECT d.* FROM proj_deps d JOIN proj_tarefas t ON t.id = d.succ_id WHERE t.projeto_id = ?', [pid]);
  }
  function recursosDoProjeto(pid) {
    return DB.all('SELECT * FROM proj_recursos WHERE projeto_id = ? ORDER BY nome', [pid]);
  }
  function baselinesDoProjeto(pid) {
    return DB.all('SELECT id, nome, salvo_em, dados_json FROM proj_baseline WHERE projeto_id = ? ORDER BY id DESC', [pid]);
  }
  function arvore(tarefas) {
    var byP = {}, roots = [];
    tarefas.forEach(function (t) { t.filhos = []; byP[t.id] = t; });
    tarefas.forEach(function (t) {
      if (t.parent_id && byP[t.parent_id]) byP[t.parent_id].filhos.push(t);
      else roots.push(t);
    });
    return roots;
  }
  function flatComNivel(nodes, nivel, out) {
    nivel = nivel || 0; out = out || [];
    nodes.forEach(function (n) {
      n._nivel = nivel;
      out.push(n);
      if (n.filhos && n.filhos.length) flatComNivel(n.filhos, nivel + 1, out);
    });
    return out;
  }
  function recalcularProgresso(pid) {
    var ts = tarefasDoProjeto(pid);
    if (!ts.length) { DB.run('UPDATE projetos SET progresso = 0, atualizado_em = ? WHERE id = ?', [hoje(), pid]); return 0; }
    var folhas = ts.filter(function (t) { return !ts.some(function (x) { return x.parent_id === t.id; }); });
    var sum = 0, n = folhas.length || 1;
    folhas.forEach(function (t) { sum += (t.progresso || 0); });
    var p = Math.round((sum / n) * 10) / 10;
    DB.run('UPDATE projetos SET progresso = ?, atualizado_em = ? WHERE id = ?', [p, hoje(), pid]);
    try { sincronizarIndProgresso(pid, p); } catch (e) {}
    return p;
  }


  /** Indicador de progresso do projeto (disponível no Valor Estratégico). */
  function codigoIndProgresso(pid) { return 'PRJ-PROG-' + pid; }
  function garantirIndProgresso(pid) {
    var proj = carregar(pid); if (!proj) return null;
    var cod = codigoIndProgresso(pid);
    var ind = DB.one('SELECT * FROM indicadores WHERE codigo = ?', [cod]);
    var nome = 'Progresso do projeto: ' + (proj.codigo ? proj.codigo + ' — ' : '') + proj.nome;
    if (!ind) {
      try {
        DB.run("INSERT INTO indicadores (codigo, nome, polaridade, tipo, unidade, item_nome, observacao, om_responsavel, usuario_cadastro, responsavel, periodicidade, status) VALUES (?,?,?,?,?,?,?,?,?,?, 'mensal', 'ativo')",
          [cod, nome, 'maior_melhor', 'simples', '%', 'Progresso', 'Indicador automático do módulo Projetos. Atualizado conforme o progresso das tarefas. Pode ser vinculado a dimensões no Valor Estratégico.', proj.responsavel || '', 'Valor-E Projetos', proj.responsavel || '']);
        ind = DB.one('SELECT * FROM indicadores WHERE codigo = ?', [cod]);
      } catch (e) {
        // schema mínimo
        try {
          DB.run("INSERT INTO indicadores (codigo, nome, polaridade, unidade, status) VALUES (?,?,?,?, 'ativo')", [cod, nome, 'maior_melhor', '%']);
          ind = DB.one('SELECT * FROM indicadores WHERE codigo = ?', [cod]);
        } catch (e2) { return null; }
      }
    } else {
      DB.run('UPDATE indicadores SET nome = ? WHERE id = ?', [nome, ind.id]);
    }
    return ind;
  }
  function sincronizarIndProgresso(pid, progresso) {
    var ind = garantirIndProgresso(pid);
    if (!ind) return;
    var mes = hoje().slice(0, 7); // YYYY-MM
    try {
      var existe = DB.one('SELECT id FROM lanc_ind WHERE indicador_id = ? AND mes_ano = ?', [ind.id, mes]);
      if (existe) DB.run('UPDATE lanc_ind SET valor = ?, observacao = ? WHERE id = ?', [progresso, 'Sincronizado do módulo Projetos', existe.id]);
      else DB.run('INSERT INTO lanc_ind (indicador_id, mes_ano, valor, observacao) VALUES (?,?,?,?)', [ind.id, mes, progresso, 'Sincronizado do módulo Projetos']);
    } catch (e) {}
    // meta 100 no ciclo vigente simples
    try {
      var cic = DB.one('SELECT id FROM ind_ciclos WHERE indicador_id = ? ORDER BY id DESC', [ind.id]);
      if (!cic) {
        var ini = hoje().slice(0, 4) + '-01-01', fim = hoje().slice(0, 4) + '-12-31';
        DB.run('INSERT INTO ind_ciclos (indicador_id, data_inicio, data_fim, meta) VALUES (?,?,?,?)', [ind.id, ini, fim, 100]);
      } else {
        DB.run('UPDATE ind_ciclos SET meta = 100 WHERE id = ?', [cic.id]);
      }
    } catch (e) {}
  }

  function caminhoCritico(pid) {
    var ts = tarefasDoProjeto(pid);
    var deps = depsDoProjeto(pid);
    if (!ts.length) return { critica: {}, folga: {}, es: {}, ef: {}, ls: {}, lf: {}, ancora: hoje(), fimProj: 0 };
    var byId = {};
    ts.forEach(function (t) {
      byId[t.id] = t;
      if (!t.inicio && t.fim && t.duracao) t.inicio = addDias(t.fim, 1 - (t.duracao || 1));
      if (!t.fim && t.inicio) t.fim = addDias(t.inicio, (t.duracao || 1) - 1);
      if (!t.duracao || t.duracao < 1) t.duracao = Math.max(1, diasEntre(t.inicio || hoje(), t.fim || hoje()) + 1);
    });
    var succs = {}, preds = {};
    ts.forEach(function (t) { succs[t.id] = []; preds[t.id] = []; });
    deps.forEach(function (d) {
      if (byId[d.pred_id] && byId[d.succ_id]) {
        succs[d.pred_id].push({ id: d.succ_id, lag: d.lag || 0, tipo: d.tipo || 'FS' });
        preds[d.succ_id].push({ id: d.pred_id, lag: d.lag || 0, tipo: d.tipo || 'FS' });
      }
    });
    var ancora = null;
    ts.forEach(function (t) { if (t.inicio && (!ancora || t.inicio < ancora)) ancora = t.inicio; });
    if (!ancora) ancora = hoje();
    function dia(iso) { return diasEntre(ancora, iso || ancora); }
    var ES = {}, EF = {}, LS = {}, LF = {};
    var ordem = [], indeg = {};
    ts.forEach(function (t) { indeg[t.id] = preds[t.id].length; });
    var fila = ts.filter(function (t) { return indeg[t.id] === 0; }).map(function (t) { return t.id; });
    while (fila.length) {
      var u = fila.shift();
      ordem.push(u);
      (succs[u] || []).forEach(function (s) { indeg[s.id]--; if (indeg[s.id] === 0) fila.push(s.id); });
    }
    if (ordem.length < ts.length) ordem = ts.map(function (t) { return t.id; });
    ordem.forEach(function (id) {
      var t = byId[id], dur = t.duracao || 1;
      var es = 0, ef = dur;
      if (t.inicio) { es = dia(t.inicio); ef = es + dur; }
      (preds[id] || []).forEach(function (p) {
        var pes = ES[p.id] != null ? ES[p.id] : 0;
        var pef = EF[p.id] != null ? EF[p.id] : pes + (byId[p.id].duracao || 1);
        var lag = p.lag || 0, tipo = p.tipo || 'FS';
        var candES = es;
        if (tipo === 'FS') candES = pef + lag;
        else if (tipo === 'SS') candES = pes + lag;
        else if (tipo === 'FF') candES = pef + lag - dur;
        else if (tipo === 'SF') candES = pes + lag - dur;
        if (candES > es) { es = candES; ef = es + dur; }
      });
      if (es < 0) { ef -= es; es = 0; }
      ES[id] = es; EF[id] = ef;
    });
    var fimProj = 0;
    ordem.forEach(function (id) { if (EF[id] > fimProj) fimProj = EF[id]; });
    for (var i = ordem.length - 1; i >= 0; i--) {
      var id = ordem[i], t = byId[id], dur = t.duracao || 1;
      var lf = fimProj, ls = lf - dur;
      if ((succs[id] || []).length) {
        lf = Infinity; ls = Infinity;
        (succs[id] || []).forEach(function (s) {
          var ses = LS[s.id] != null ? LS[s.id] : fimProj;
          var sef = LF[s.id] != null ? LF[s.id] : ses + (byId[s.id].duracao || 1);
          var lag = s.lag || 0, tipo = s.tipo || 'FS';
          var candLF = lf;
          if (tipo === 'FS') candLF = ses - lag;
          else if (tipo === 'SS') candLF = ses - lag + dur;
          else if (tipo === 'FF') candLF = sef - lag;
          else if (tipo === 'SF') candLF = sef - lag + dur;
          if (candLF < lf) { lf = candLF; ls = lf - dur; }
        });
      }
      LF[id] = lf; LS[id] = ls;
    }
    var critica = {}, folga = {};
    ordem.forEach(function (id) {
      var f = (LS[id] != null && ES[id] != null) ? (LS[id] - ES[id]) : 0;
      folga[id] = f;
      if (f <= 0) critica[id] = true;
    });
    return { critica: critica, folga: folga, es: ES, ef: EF, ls: LS, lf: LF, ancora: ancora, fimProj: fimProj };
  }

  function overAllocation(pid) {
    var ts = tarefasDoProjeto(pid);
    var recs = recursosDoProjeto(pid);
    var byRec = {};
    recs.forEach(function (r) { byRec[r.id] = { nome: r.nome, cap: r.capacidade || 1, dias: {} }; });
    ts.forEach(function (t) {
      if (!t.recurso_id || !byRec[t.recurso_id] || !t.inicio) return;
      var ini = t.inicio, fim = t.fim || addDias(t.inicio, (t.duracao || 1) - 1);
      var d = ini;
      while (d <= fim) {
        byRec[t.recurso_id].dias[d] = (byRec[t.recurso_id].dias[d] || 0) + 1;
        d = addDias(d, 1);
      }
    });
    var alertas = [];
    Object.keys(byRec).forEach(function (rid) {
      var r = byRec[rid], max = 0, diasOver = 0;
      Object.keys(r.dias).forEach(function (d) {
        if (r.dias[d] > r.cap) { diasOver++; if (r.dias[d] > max) max = r.dias[d]; }
      });
      if (diasOver > 0) alertas.push({ id: +rid, nome: r.nome, dias: diasOver, pico: max, cap: r.cap });
    });
    return alertas;
  }

  /** Valor do trabalho (análise de valor agregado):
   *  planejado = orçamento × % do prazo decorrido
   *  agregado  = orçamento × % de progresso (trabalho feito valorizado a preço de orçamento)
   *  custo real = soma dos custos lançados nas tarefas
   *  desemp. prazo = agregado ÷ planejado
   *  desemp. custo = agregado ÷ custo real
   */
  function eva(pid) {
    var p = carregar(pid);
    var ts = tarefasDoProjeto(pid);
    var orcado = p.orcado || 0;
    var ac = ts.reduce(function (s, t) { return s + (t.custo || 0); }, 0);
    if (p.custo_real != null && p.custo_real > 0) ac = p.custo_real;
    var prog = (p.progresso || 0) / 100;
    var pctTempo = 0;
    if (p.inicio && p.fim) {
      var total = diasEntre(p.inicio, p.fim) + 1;
      var decorrido = diasEntre(p.inicio, hoje()) + 1;
      if (total > 0) pctTempo = Math.max(0, Math.min(1, decorrido / total));
    } else pctTempo = prog;
    var pv = orcado * pctTempo;
    var ev = orcado * prog;
    var spi = pv > 0 ? ev / pv : null;
    var cpi = ac > 0 ? ev / ac : null;
    return { pv: pv, ev: ev, ac: ac, spi: spi, cpi: cpi, sv: ev - pv, cv: ev - ac, pctTempo: pctTempo, prog: prog, orcado: orcado };
  }

  function lista(q) {
    q = q || {};
    var l = listar({ q: q.q, macro: q.macro, objetivo: q.objetivo, status: q.status });
    var macros = []; try { macros = DB.all("SELECT id, nome FROM macroprocessos ORDER BY nome"); } catch (e) {}
    var objs = []; try { objs = DB.all("SELECT id, codigo, nome FROM objetivos_estrategicos ORDER BY codigo, nome"); } catch (e) {}
    var o = '<div class="pagina"><div class="d-flex flex-wrap align-items-center mb-3 gap-2">' +
      '<h1 class="h4 mb-0 me-auto"><i class="bi bi-kanban"></i> Projetos</h1>' +
      '<form class="filtros d-flex flex-wrap align-items-center gap-1" style="margin:0">' +
      '<input class="form-control form-control-sm" name="q" value="' + h(q.q || '') + '" placeholder="Buscar…" style="width:160px">' +
      (macros.length ? '<select class="form-select form-select-sm" name="macro" style="width:180px"><option value="">Todos os macroprocessos</option>' + macros.map(function (m) { return '<option value="' + m.id + '"' + (String(q.macro) === String(m.id) ? ' selected' : '') + '>' + h(m.nome) + '</option>'; }).join('') + '</select>' : '') +
      (objs.length ? '<select class="form-select form-select-sm" name="objetivo" style="width:200px"><option value="">Todos os objetivos</option>' + objs.map(function (x) { return '<option value="' + x.id + '"' + (String(q.objetivo) === String(x.id) ? ' selected' : '') + '>' + h((x.codigo ? x.codigo + ' — ' : '') + x.nome) + '</option>'; }).join('') + '</select>' : '') +
      '<select class="form-select form-select-sm" name="status" style="width:140px"><option value="">Todo status</option>' +
      ['Em andamento', 'Planejado', 'Concluído', 'Suspenso', 'Cancelado'].map(function (s) { return '<option' + (q.status === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select>' +
      '<button class="btn btn-sm btn-outline-secondary">Filtrar</button></form>' +
      '<button class="btn btn-sm btn-success" onclick="Proj.novo()"><i class="bi bi-plus-lg"></i> Novo projeto</button></div>';
    if (!l.length) {
      o += '<div class="card"><p class="vazio mb-0">' + (DB.one('SELECT COUNT(*) n FROM projetos').n ? 'Nenhum projeto corresponde ao filtro.' : 'Nenhum projeto cadastrado.') + '</p></div>';
    } else {
      o += '<div class="table-responsive"><table class="table table-sm table-hover align-middle"><thead><tr><th>Código</th><th>Projeto</th><th>Macroprocesso</th><th>Objetivo estratégico</th><th>Início</th><th>Fim</th><th>Progresso</th><th>Custo</th><th>Status</th><th>Tarefas</th><th></th></tr></thead><tbody>';
      l.forEach(function (p) {
        var bar = '<div class="progress" style="height:8px;min-width:80px"><div class="progress-bar bg-' + statusCls(p.status) + '" style="width:' + (p.progresso || 0) + '%"></div></div> <small>' + (p.progresso || 0) + '%</small>';
        o += '<tr><td><b>' + h(p.codigo || '—') + '</b></td><td><a class="fw-semibold text-decoration-none" href="#/projeto?id=' + p.id + '">' + h(p.nome) + '</a></td><td>' + h(p.macro_nome || '—') + '</td><td>' + h(p.objetivo_nome || '—') + '</td><td>' + (p.inicio ? h(E.dataBr(p.inicio)) : '—') + '</td><td>' + (p.fim ? h(E.dataBr(p.fim)) : '—') + '</td><td>' + bar + '</td><td class="small">' + fmtMoney(p.custo_real) + '</td><td><span class="badge text-bg-' + statusCls(p.status) + '">' + h(p.status) + '</span></td><td class="text-center">' + (p.n_tarefas || 0) + '</td><td class="text-end"><a class="btn btn-sm btn-outline-primary" href="#/projeto?id=' + p.id + '"><i class="bi bi-box-arrow-up-right"></i></a> <button class="btn btn-sm btn-outline-danger" onclick="Proj.excluir(' + p.id + ',' + h(JSON.stringify(p.nome)) + ')"><i class="bi bi-trash"></i></button></td></tr>';
      });
      o += '</tbody></table></div>';
    }
    o += '<p class="ajuda mt-3 mb-0"><i class="bi bi-info-circle"></i> Riscos do projeto, indicador de progresso (Valor Estratégico), dependências, valor do trabalho e linha de base.</p></div>';
    return o;
  }

  function detalhe(q) {
    var id = parseInt(q.id, 10);
    var p = carregar(id);
    if (!p) return '<div class="pagina"><p class="text-danger">Projeto não encontrado.</p><a href="#/projetos">Voltar</a></div>';
    var ts = tarefasDoProjeto(id);
    var flat = flatComNivel(arvore(ts));
    var deps = depsDoProjeto(id);
    var depMap = {};
    deps.forEach(function (d) { if (!depMap[d.succ_id]) depMap[d.succ_id] = []; depMap[d.succ_id].push(d); });
    var cpm = caminhoCritico(id);
    var recursos = recursosDoProjeto(id);
    var baselines = baselinesDoProjeto(id);
    var overs = overAllocation(id);
    var e = eva(id);
    var custoTotal = ts.reduce(function (s, t) { return s + (t.custo || 0); }, 0);
    var blTarefas = {};
    if (q.baseline) {
      var b = DB.one('SELECT * FROM proj_baseline WHERE id = ? AND projeto_id = ?', [parseInt(q.baseline, 10), id]);
      if (b) { try { var blAtual = JSON.parse(b.dados_json); (blAtual.tarefas || []).forEach(function (t) { blTarefas[t.id] = t; }); } catch (err) {} }
    }
    var minD = p.inicio, maxD = p.fim;
    flat.forEach(function (t) {
      if (t.inicio && (!minD || t.inicio < minD)) minD = t.inicio;
      if (t.fim && (!maxD || t.fim > maxD)) maxD = t.fim;
      var bl = blTarefas[t.id];
      if (bl) { if (bl.inicio && (!minD || bl.inicio < minD)) minD = bl.inicio; if (bl.fim && (!maxD || bl.fim > maxD)) maxD = bl.fim; }
    });
    if (cpm.ancora && (!minD || cpm.ancora < minD)) minD = cpm.ancora;
    if (cpm.fimProj != null && cpm.ancora) { var fimCpm = addDias(cpm.ancora, cpm.fimProj); if (!maxD || fimCpm > maxD) maxD = fimCpm; }
    if (!minD) minD = hoje();
    if (!maxD || maxD < minD) maxD = addDias(minD, 30);
    var totalDias = Math.max(1, diasEntre(minD, maxD) + 1);

    var o = '<div class="pagina"><div class="d-flex flex-wrap align-items-center mb-3 gap-2">' +
      '<a class="btn btn-outline-secondary btn-sm" href="#/projetos"><i class="bi bi-arrow-left"></i> Projetos</a>' +
      '<h1 class="h4 mb-0 flex-grow-1">' + h(p.codigo ? p.codigo + ' — ' : '') + h(p.nome) + '</h1>' +
      '<span class="badge text-bg-' + statusCls(p.status) + '">' + h(p.status) + '</span>' +
      '<button class="btn btn-sm btn-outline-primary" onclick="Proj.editar(' + id + ')"><i class="bi bi-pencil"></i> Dados</button>' +
      '<button class="btn btn-sm btn-outline-secondary" onclick="Proj.recursos(' + id + ')"><i class="bi bi-people"></i> Recursos</button>' +
      '<a class="btn btn-sm btn-outline-dark" href="#/projeto-relatorio?id=' + id + '"><i class="bi bi-file-earmark-text"></i> Relatório</a>' +
      '<button class="btn btn-sm btn-outline-secondary" onclick="Proj.baseline(' + id + ')"><i class="bi bi-flag"></i> Linha de base</button>' +
      '<button class="btn btn-sm btn-success" onclick="Proj.novaTarefa(' + id + ',0)"><i class="bi bi-plus-lg"></i> Tarefa</button></div>';

    o += '<div class="row g-2 mb-3">' +
      '<div class="col-6 col-md-2"><div class="card card-body py-2"><small class="text-muted">Macroprocesso</small><div>' + h((DB.one('SELECT nome FROM macroprocessos WHERE id=?', [p.macro_id]) || {}).nome || '—') + '</div></div></div>' +
      '<div class="col-6 col-md-2"><div class="card card-body py-2"><small class="text-muted">Objetivo estratégico</small><div>' + h((function () { var o = DB.one('SELECT codigo, nome FROM objetivos_estrategicos WHERE id=?', [p.objetivo_id]); return o ? ((o.codigo ? o.codigo + ' — ' : '') + (o.nome || '')) : '—'; })()) + '</div></div></div>' +
      '<div class="col-6 col-md-2"><div class="card card-body py-2"><small class="text-muted">Prazo</small><div>' + (p.inicio ? h(E.dataBr(p.inicio)) : '—') + ' → ' + (p.fim ? h(E.dataBr(p.fim)) : '—') + '</div></div></div>' +
      '<div class="col-6 col-md-2"><div class="card card-body py-2"><small class="text-muted">Progresso</small><div class="progress mt-1" style="height:10px"><div class="progress-bar" style="width:' + (p.progresso || 0) + '%"></div></div> ' + (p.progresso || 0) + '%</div></div>' +
      '<div class="col-6 col-md-2"><div class="card card-body py-2"><small class="text-muted">Custo real / orçado</small><div>' + fmtMoney(custoTotal) + ' / ' + fmtMoney(p.orcado) + '</div></div></div>' +
      '<div class="col-6 col-md-2"><div class="card card-body py-2"><small class="text-muted">Caminho crítico</small><div>' + Object.keys(cpm.critica).length + ' tarefa(s) · ' + (cpm.fimProj || 0) + ' d</div></div></div></div>';

    var indProg = DB.one('SELECT id, codigo, nome FROM indicadores WHERE codigo = ?', [codigoIndProgresso(id)]);
    if (indProg) o += '<p class="small mb-2"><i class="bi bi-graph-up-arrow"></i> Indicador de progresso (Valor Estratégico): <a href="#/indicador?id=' + indProg.id + '">' + h(indProg.codigo) + ' — ' + h(indProg.nome) + '</a>. Use Vincular indicadores nas dimensões para incluí-lo no ICV.</p>';
    o += '<div class="card mb-3"><div class="card-header py-2"><strong><i class="bi bi-graph-up"></i> Valor do trabalho</strong></div><div class="card-body py-2">' +
      '<div class="row g-2 text-center small">' +
      '<div class="col"><div class="text-muted">Valor planejado</div><div class="fw-semibold">' + fmtMoney(e.pv) + '</div><div class="text-muted" style="font-size:10px">orçamento × % do prazo</div></div>' +
      '<div class="col"><div class="text-muted">Valor agregado</div><div class="fw-semibold">' + fmtMoney(e.ev) + '</div><div class="text-muted" style="font-size:10px">orçamento × % de progresso</div></div>' +
      '<div class="col"><div class="text-muted">Custo real</div><div class="fw-semibold">' + fmtMoney(e.ac) + '</div><div class="text-muted" style="font-size:10px">soma dos custos das tarefas</div></div>' +
      '<div class="col"><div class="text-muted">Variação de prazo</div><div class="fw-semibold ' + (e.sv >= 0 ? 'text-success' : 'text-danger') + '">' + fmtMoney(e.sv) + '</div><div class="text-muted" style="font-size:10px">agregado − planejado</div></div>' +
      '<div class="col"><div class="text-muted">Variação de custo</div><div class="fw-semibold ' + (e.cv >= 0 ? 'text-success' : 'text-danger') + '">' + fmtMoney(e.cv) + '</div><div class="text-muted" style="font-size:10px">agregado − custo real</div></div>' +
      '<div class="col"><div class="text-muted">Desemp. de prazo</div><div class="fw-semibold ' + (e.spi == null ? '' : e.spi >= 1 ? 'text-success' : 'text-danger') + '">' + (e.spi != null ? e.spi.toFixed(2) : '—') + '</div><div class="text-muted" style="font-size:10px">agregado ÷ planejado</div></div>' +
      '<div class="col"><div class="text-muted">Desemp. de custo</div><div class="fw-semibold ' + (e.cpi == null ? '' : e.cpi >= 1 ? 'text-success' : 'text-danger') + '">' + (e.cpi != null ? e.cpi.toFixed(2) : '—') + '</div><div class="text-muted" style="font-size:10px">agregado ÷ custo real</div></div>' +
      '</div><p class="ajuda mb-0 mt-2"><b>Desempenho de prazo</b> = valor agregado ÷ valor planejado (≥ 1: adiantado). <b>Desempenho de custo</b> = valor agregado ÷ custo real (≥ 1: abaixo do orçamento). O valor agregado é o “trabalho já feito” em valor de orçamento — não se confunde com o custo real pago.</p></div></div>';

    if (overs.length) {
      o += '<div class="alert alert-warning py-2 small"><i class="bi bi-exclamation-triangle"></i> <b>Sobrecarga de recursos:</b> ' +
        overs.map(function (a) { return h(a.nome) + ' (' + a.dias + ' d, pico ' + a.pico + '× / cap. ' + a.cap + ')'; }).join('; ') + '.</div>';
    }
    if (p.descricao) o += '<p class="text-muted small">' + h(p.descricao) + '</p>';
    if (recursos.length) {
      o += '<div class="mb-2 small"><i class="bi bi-people"></i> ' + recursos.map(function (r) {
        return '<span class="badge text-bg-light border me-1">' + h(r.nome) + (r.custo_hora ? ' (' + fmtMoney(r.custo_hora) + '/h)' : '') + (r.capacidade != 1 ? ' · cap.' + r.capacidade : '') + '</span>';
      }).join('') + '</div>';
    }
    if (baselines.length) {
      o += '<div class="mb-2 d-flex flex-wrap align-items-center gap-2 small"><i class="bi bi-flag"></i> Comparar com linha de base: <select class="form-select form-select-sm" style="width:auto" onchange="Nav.ir(\'#/projeto?id=' + id + '\'+(this.value?\'&baseline=\'+this.value:\'\'))"><option value="">— nenhuma —</option>' +
        baselines.map(function (b) { return '<option value="' + b.id + '"' + (String(q.baseline) === String(b.id) ? ' selected' : '') + '>' + h(b.nome) + '</option>'; }).join('') +
        '</select> <button class="btn btn-link btn-sm p-0" onclick="Proj.baseline(' + id + ')">gerenciar</button></div>';
    }

    
    // Riscos do projeto
    var riscosProj = [];
    try { riscosProj = E.riscosListar({ projeto_id: id }); } catch (e) { riscosProj = DB.all('SELECT * FROM riscos WHERE projeto_id = ? ORDER BY id DESC', [id]); }
    o += '<div class="card mb-3"><div class="card-header d-flex align-items-center flex-wrap gap-2 py-2"><strong><i class="bi bi-exclamation-triangle"></i> Riscos do projeto</strong>' +
      '<button class="btn btn-sm btn-outline-danger ms-auto" onclick="Proj.novoRisco(' + id + ')"><i class="bi bi-plus-lg"></i> Novo risco</button></div><div class="card-body py-2">';
    if (!riscosProj.length) {
      o += '<p class="vazio mb-0 small">Nenhum risco vinculado a este projeto. Use <b>+ Novo risco</b> para registrar ameaças ao cronograma, escopo ou recursos.</p>';
    } else {
      o += '<div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Código</th><th>Risco</th><th>Nível</th><th>Status</th><th></th></tr></thead><tbody>';
      riscosProj.forEach(function (r) {
        o += '<tr><td><b>' + h(r.codigo || '') + '</b></td><td><a href="#/risco?id=' + r.id + '">' + h(r.nome) + '</a></td>' +
          '<td>' + (function (n) { n = n || '—'; if (n === '—') return '<span class="text-muted">—</span>'; return '<span class="nv ' + h(String(n).replace(/ /g, '-')) + '">' + h(n) + '</span>'; })(r.nivel_res || r.nivel_medio) + '</td><td>' + h(r.status || '') + '</td>' +
          '<td class="text-end"><a class="btn btn-sm btn-outline-primary" href="#/risco?id=' + r.id + '"><i class="bi bi-pencil"></i></a></td></tr>';
      });
      o += '</tbody></table></div>';
    }
    o += '</div></div>';


    o += '<div class="card"><div class="card-header d-flex align-items-center flex-wrap gap-2"><strong>Estrutura de tarefas e cronograma</strong><span class="ms-auto ajuda">' + flat.length + ' tarefa(s)' +
      (Object.keys(cpm.critica).length ? ' · <span class="text-danger">caminho crítico em vermelho</span>' : '') +
      (Object.keys(blTarefas).length ? ' · <span style="color:#64748b">linha de base em cinza</span>' : '') + '</span></div>';
    if (!flat.length) {
      o += '<div class="card-body"><p class="vazio mb-0">Nenhuma tarefa.</p></div>';
    } else {
      o += '<div class="table-responsive"><table class="table table-sm align-middle mb-0" style="min-width:1040px"><thead><tr><th style="width:22%">Tarefa</th><th style="width:78px">Início</th><th style="width:78px">Fim</th><th style="width:44px">D</th><th style="width:44px">%</th><th style="width:48px">Folga (dias)</th><th style="width:90px">Recurso</th><th style="width:72px">Custo</th><th>Cronograma</th><th style="width:130px"></th></tr></thead><tbody>';
      flat.forEach(function (t) {
        var pad = (t._nivel || 0) * 14;
        var ini = t.inicio || minD;
        var fim = t.fim || (t.inicio && t.duracao ? addDias(t.inicio, (t.duracao || 1) - 1) : null) || ini;
        if (cpm.es[t.id] != null && cpm.ancora) { ini = addDias(cpm.ancora, cpm.es[t.id]); fim = addDias(cpm.ancora, (cpm.ef[t.id] || cpm.es[t.id] + 1) - 1); }
        var left = Math.max(0, diasEntre(minD, ini)) / totalDias * 100;
        var width = Math.max(1.5, (diasEntre(ini, fim) + 1) / totalDias * 100);
        var isCrit = !!cpm.critica[t.id];
        var folga = cpm.folga[t.id];
        var predTxt = (depMap[t.id] || []).map(function (d) { return '#' + d.pred_id + (d.tipo && d.tipo !== 'FS' ? ' ' + (ROTULO_DEP_CURTO[d.tipo] || d.tipo) : '') + (d.lag ? ' +' + d.lag + 'd' : ''); }).join(', ');
        var barColor = isCrit ? 'linear-gradient(90deg,#b91c1c,#ef4444)' : 'linear-gradient(90deg,#0a6fc2,#3b82f6)';
        var blBar = '';
        var bl = blTarefas[t.id];
        if (bl && bl.inicio) {
          var bIni = bl.inicio, bFim = bl.fim || addDias(bl.inicio, (bl.duracao || 1) - 1);
          var bLeft = Math.max(0, diasEntre(minD, bIni)) / totalDias * 100;
          var bWidth = Math.max(1.2, (diasEntre(bIni, bFim) + 1) / totalDias * 100);
          blBar = '<div title="Linha de base" style="position:absolute;left:' + bLeft + '%;width:' + bWidth + '%;height:6px;bottom:0;background:#94a3b8;border-radius:2px;opacity:.7"></div>';
        }
        o += '<tr class="' + (isCrit ? 'table-danger' : '') + '"><td style="padding-left:' + (6 + pad) + 'px">' + (t._nivel ? '<span class="text-muted">↳ </span>' : '') +
          (isCrit ? '<i class="bi bi-lightning-fill text-danger"></i> ' : '') + '<b>#' + t.id + '</b> ' + h(t.nome) +
          (predTxt ? ' <small class="text-muted">← ' + predTxt + '</small>' : '') + '</td>' +
          '<td>' + (t.inicio ? h(E.dataBr(t.inicio)) : '—') + '</td><td>' + (t.fim ? h(E.dataBr(t.fim)) : '—') + '</td>' +
          '<td class="text-center">' + (t.duracao || '—') + '</td><td class="text-center">' + (t.progresso || 0) + '</td>' +
          '<td class="text-center ' + (folga != null && folga <= 0 ? 'text-danger fw-semibold' : '') + '">' + (folga != null ? folga : '—') + '</td>' +
          '<td class="small">' + h(t.recurso_nome || t.responsavel || '—') + '</td><td class="small">' + fmtMoney(t.custo) + '</td>' +
          '<td><div style="position:relative;height:20px;background:#f0f2f5;border-radius:3px">' + blBar +
          '<div style="position:absolute;left:' + left + '%;width:' + width + '%;height:14px;top:0;background:' + barColor + ';border-radius:3px;opacity:.92"></div></div></td>' +
          '<td class="text-end text-nowrap">' +
          '<button class="btn btn-sm btn-outline-secondary py-0 px-1" title="Subir" onclick="Proj.mover(' + t.id + ',-1)"><i class="bi bi-arrow-up"></i></button> ' +
          '<button class="btn btn-sm btn-outline-secondary py-0 px-1" title="Descer" onclick="Proj.mover(' + t.id + ',1)"><i class="bi bi-arrow-down"></i></button> ' +
          '<button class="btn btn-sm btn-outline-secondary py-0 px-1" title="Subtarefa" onclick="Proj.novaTarefa(' + id + ',' + t.id + ')"><i class="bi bi-diagram-3"></i></button> ' +
          '<button class="btn btn-sm btn-outline-primary py-0 px-1" onclick="Proj.editarTarefa(' + t.id + ')"><i class="bi bi-pencil"></i></button> ' +
          '<button class="btn btn-sm btn-outline-danger py-0 px-1" onclick="Proj.excluirTarefa(' + t.id + ')"><i class="bi bi-trash"></i></button></td></tr>';
      });
      o += '</tbody></table></div>';
      o += '<div class="px-3 py-2 small text-muted">Escala: ' + h(E.dataBr(minD)) + ' → ' + h(E.dataBr(maxD)) + ' (' + totalDias + ' d). Ligações TI/II/TT/IT + intervalo. ↑↓ reordena. Linha de base = barra cinza.</div>';
    }
    o += '</div></div>';
    return o;
  }

  function mdl(titulo, corpo, onOk, okTxt) {
    if (w.Mdl) return w.Mdl(titulo, corpo, onOk, okTxt || 'Salvar');
    var html = '<div class="modal fade show" style="display:block;background:rgba(0,0,0,.4)" id="_pm"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">' + titulo + '</h5><button type="button" class="btn-close" onclick="document.getElementById(\'_pm\').remove()"></button></div><div class="modal-body">' + corpo + '</div><div class="modal-footer"><button class="btn btn-secondary" onclick="document.getElementById(\'_pm\').remove()">Cancelar</button><button class="btn btn-primary" id="_pok">' + (okTxt || 'Salvar') + '</button></div></div></div></div>';
    document.body.insertAdjacentHTML('beforeend', html);
    document.getElementById('_pok').onclick = function () {
      try { onOk(document.getElementById('_pm')); document.getElementById('_pm').remove(); } catch (e) { alert(e.message || e); }
    };
  }
  function v(d, sel) { var el = d.querySelector(sel); return el ? el.value : ''; }

  var Proj = w.Proj = {
    novo: function () {
      var q = (location.hash.split('?')[1] || '');
      var params = {}; q.split('&').forEach(function (p) { var kv = p.split('='); if (kv[0]) params[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || ''); });
      mdl('Novo projeto',
        '<div class="mb-2"><label class="form-label">Nome *</label><input class="form-control" id="pn"></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Código</label><input class="form-control" id="pc"></div><div class="col"><label class="form-label">Status</label><select class="form-select" id="ps"><option>Planejado</option><option selected>Em andamento</option><option>Suspenso</option><option>Concluído</option><option>Cancelado</option></select></div></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Macroprocesso</label><select class="form-select" id="pmacro">' + macrosOpts(params.macro || '') + '</select></div><div class="col"><label class="form-label">Objetivo estratégico</label><select class="form-select" id="pobj">' + objetivosOpts(params.objetivo || '') + '</select></div></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="pi" value="' + hoje() + '"></div><div class="col"><label class="form-label">Fim</label><input type="date" class="form-control" id="pf"></div><div class="col"><label class="form-label">Orçamento</label><input type="number" step="0.01" class="form-control" id="po" value="0"></div></div>' +
        '<div class="mb-2"><label class="form-label">Responsável</label><input class="form-control" id="pr"></div><div class="mb-0"><label class="form-label">Descrição</label><textarea class="form-control" id="pd" rows="2"></textarea></div>',
        function (d) {
          var nome = v(d, '#pn').trim(); if (!nome) throw new Error('Informe o nome.');
          var id = DB.tx(function () {
            DB.run('INSERT INTO projetos (nome,codigo,descricao,macro_id,objetivo_id,inicio,fim,status,responsavel,orcado) VALUES (?,?,?,?,?,?,?,?,?,?)',
              [nome, v(d, '#pc').trim(), v(d, '#pd').trim(), parseInt(v(d, '#pmacro'), 10) || null, parseInt(v(d, '#pobj'), 10) || null, v(d, '#pi') || null, v(d, '#pf') || null, v(d, '#ps') || 'Em andamento', v(d, '#pr').trim(), parseFloat(v(d, '#po')) || 0]);
            var nid = DB.lastId(); try { garantirIndProgresso(nid); sincronizarIndProgresso(nid, 0); } catch (e) {} return nid;
          });
          Nav.ir('#/projeto?id=' + id);
        }, 'Criar projeto');
    },
    editar: function (id) {
      var p = carregar(id); if (!p) return;
      mdl('Dados do projeto',
        '<div class="mb-2"><label class="form-label">Nome *</label><input class="form-control" id="pn" value="' + h(p.nome) + '"></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Código</label><input class="form-control" id="pc" value="' + h(p.codigo || '') + '"></div><div class="col"><label class="form-label">Status</label><select class="form-select" id="ps">' + ['Planejado', 'Em andamento', 'Suspenso', 'Concluído', 'Cancelado'].map(function (s) { return '<option' + (p.status === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></div></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Macroprocesso</label><select class="form-select" id="pmacro">' + macrosOpts(p.macro_id || '') + '</select></div><div class="col"><label class="form-label">Objetivo estratégico</label><select class="form-select" id="pobj">' + objetivosOpts(p.objetivo_id || '') + '</select></div></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="pi" value="' + h(p.inicio || '') + '"></div><div class="col"><label class="form-label">Fim</label><input type="date" class="form-control" id="pf" value="' + h(p.fim || '') + '"></div><div class="col"><label class="form-label">Orçamento</label><input type="number" step="0.01" class="form-control" id="po" value="' + (p.orcado || 0) + '"></div></div>' +
        '<div class="mb-2"><label class="form-label">Responsável</label><input class="form-control" id="pr" value="' + h(p.responsavel || '') + '"></div><div class="mb-0"><label class="form-label">Descrição</label><textarea class="form-control" id="pd" rows="2">' + h(p.descricao || '') + '</textarea></div>',
        function (d) {
          var nome = v(d, '#pn').trim(); if (!nome) throw new Error('Informe o nome.');
          DB.tx(function () {
            DB.run('UPDATE projetos SET nome=?, codigo=?, descricao=?, macro_id=?, objetivo_id=?, inicio=?, fim=?, status=?, responsavel=?, orcado=?, atualizado_em=? WHERE id=?',
              [nome, v(d, '#pc').trim(), v(d, '#pd').trim(), parseInt(v(d, '#pmacro'), 10) || null, parseInt(v(d, '#pobj'), 10) || null, v(d, '#pi') || null, v(d, '#pf') || null, v(d, '#ps'), v(d, '#pr').trim(), parseFloat(v(d, '#po')) || 0, hoje(), id]);
            try { garantirIndProgresso(id); sincronizarIndProgresso(id, (carregar(id) || {}).progresso || 0); } catch (e) {}
          });
          Nav.ir('#/projeto?id=' + id);
        });
    },
    excluir: function (id, nome) {
      var nRiscos = 0;
      try { nRiscos = (DB.one('SELECT COUNT(*) AS n FROM riscos WHERE projeto_id=?', [id]) || {}).n || 0; } catch (e) { nRiscos = 0; }
      var msg = 'Excluir o projeto "' + nome + '"?';
      if (nRiscos) msg += '\n\nSerão excluídos também ' + nRiscos + ' risco(s) vinculado(s) a este projeto (e seus fatores, controles, planos e monitoramentos).';
      msg += '\nEsta ação não pode ser desfeita.';
      if (!confirm(msg)) return;
      DB.tx(function () {
        var riscoIds = DB.all('SELECT id FROM riscos WHERE projeto_id=?', [id]).map(function (x) { return x.id; });
        if (riscoIds.length) {
          var inList = riscoIds.join(',');
          var fatorIds = DB.all('SELECT id FROM fatores WHERE risco_id IN (' + inList + ')').map(function (x) { return x.id; });
          if (fatorIds.length) DB.run('DELETE FROM controles WHERE fator_id IN (' + fatorIds.join(',') + ')');
          DB.run('DELETE FROM planos WHERE risco_id IN (' + inList + ')');
          DB.run('DELETE FROM monitoramentos WHERE risco_id IN (' + inList + ')');
          DB.run('DELETE FROM revisoes WHERE risco_id IN (' + inList + ')');
          DB.run('DELETE FROM fatores WHERE risco_id IN (' + inList + ')');
          DB.run('DELETE FROM riscos WHERE projeto_id=?', [id]);
        }
        var ids = DB.all('SELECT id FROM proj_tarefas WHERE projeto_id=?', [id]).map(function (x) { return x.id; });
        if (ids.length) {
          DB.run('DELETE FROM proj_deps WHERE pred_id IN (' + ids.join(',') + ') OR succ_id IN (' + ids.join(',') + ')');
          DB.run('DELETE FROM proj_tarefas WHERE projeto_id=?', [id]);
        }
        DB.run('DELETE FROM proj_recursos WHERE projeto_id=?', [id]);
        DB.run('DELETE FROM proj_baseline WHERE projeto_id=?', [id]);
        try { DB.run("DELETE FROM indicadores WHERE codigo = ?", ['PRJ-PROG-' + id]); } catch (e) {}
        DB.run('DELETE FROM projetos WHERE id=?', [id]);
      });
      Nav.ir('#/projetos');
    },
    novaTarefa: function (pid, parentId) {
      var predOpts = tarefasDoProjeto(pid).map(function (t) { return '<option value="' + t.id + '">#' + t.id + ' — ' + h(t.nome) + '</option>'; }).join('');
      mdl(parentId ? 'Nova subtarefa' : 'Nova tarefa',
        '<div class="mb-2"><label class="form-label">Nome *</label><input class="form-control" id="tn"></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ti" value="' + hoje() + '"></div><div class="col"><label class="form-label">Duração</label><input type="number" class="form-control" id="td" value="5" min="1"></div><div class="col"><label class="form-label">Progresso %</label><input type="number" class="form-control" id="tp" value="0" min="0" max="100"></div></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Recurso</label><select class="form-select" id="trec">' + recursosOpts(pid, '') + '</select></div><div class="col"><label class="form-label">Responsável</label><input class="form-control" id="tr"></div><div class="col"><label class="form-label">Custo</label><input type="number" step="0.01" class="form-control" id="tc" value="0"></div></div>' +
        (predOpts ? '<div class="row g-2 mb-2"><div class="col-6"><label class="form-label">Antecessora</label><select class="form-select" id="tpred"><option value="">— nenhum —</option>' + predOpts + '</select></div><div class="col-3"><label class="form-label">Tipo</label><select class="form-select" id="ttipo">' + tipoDepOpts('FS') + '</select></div><div class="col-3"><label class="form-label">Intervalo (dias)</label><input type="number" class="form-control" id="tlag" value="0"></div></div>' : '') +
        '<div class="mb-0"><label class="form-label">Notas</label><textarea class="form-control" id="tnot" rows="2"></textarea></div>',
        function (d) {
          var nome = v(d, '#tn').trim(); if (!nome) throw new Error('Informe o nome.');
          var dur = parseInt(v(d, '#td'), 10) || 1, ini = v(d, '#ti') || hoje(), fim = addDias(ini, dur - 1);
          DB.tx(function () {
            var ord = (DB.one('SELECT COALESCE(MAX(ordem),0)+1 AS n FROM proj_tarefas WHERE projeto_id=?', [pid]) || {}).n || 1;
            DB.run('INSERT INTO proj_tarefas (projeto_id,parent_id,nome,inicio,fim,duracao,progresso,ordem,responsavel,recurso_id,custo,notas) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
              [pid, parentId || null, nome, ini, fim, dur, parseFloat(v(d, '#tp')) || 0, ord, v(d, '#tr').trim(), parseInt(v(d, '#trec'), 10) || null, parseFloat(v(d, '#tc')) || 0, v(d, '#tnot').trim()]);
            var tid = DB.lastId(), pred = parseInt(v(d, '#tpred'), 10);
            if (pred) DB.run('INSERT OR IGNORE INTO proj_deps (pred_id,succ_id,tipo,lag) VALUES (?,?,?,?)', [pred, tid, v(d, '#ttipo') || 'FS', parseInt(v(d, '#tlag'), 10) || 0]);
            recalcularProgresso(pid);
          });
          Nav.ir('#/projeto?id=' + pid);
        }, 'Adicionar');
    },
    editarTarefa: function (tid) {
      var t = DB.one('SELECT * FROM proj_tarefas WHERE id=?', [tid]); if (!t) return;
      var dep = DB.one('SELECT * FROM proj_deps WHERE succ_id=?', [tid]);
      var predOpts = tarefasDoProjeto(t.projeto_id).filter(function (x) { return x.id !== tid; }).map(function (x) {
        return '<option value="' + x.id + '"' + (dep && dep.pred_id === x.id ? ' selected' : '') + '>#' + x.id + ' — ' + h(x.nome) + '</option>';
      }).join('');
      mdl('Editar tarefa #' + tid,
        '<div class="mb-2"><label class="form-label">Nome *</label><input class="form-control" id="tn" value="' + h(t.nome) + '"></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ti" value="' + h(t.inicio || '') + '"></div><div class="col"><label class="form-label">Fim</label><input type="date" class="form-control" id="tf" value="' + h(t.fim || '') + '"></div><div class="col"><label class="form-label">Duração</label><input type="number" class="form-control" id="td" value="' + (t.duracao || 1) + '" min="1"></div></div>' +
        '<div class="row g-2 mb-2"><div class="col"><label class="form-label">Progresso %</label><input type="number" class="form-control" id="tp" value="' + (t.progresso || 0) + '" min="0" max="100"></div><div class="col"><label class="form-label">Recurso</label><select class="form-select" id="trec">' + recursosOpts(t.projeto_id, t.recurso_id) + '</select></div><div class="col"><label class="form-label">Custo</label><input type="number" step="0.01" class="form-control" id="tc" value="' + (t.custo || 0) + '"></div></div>' +
        '<div class="mb-2"><label class="form-label">Responsável</label><input class="form-control" id="tr" value="' + h(t.responsavel || '') + '"></div>' +
        (predOpts ? '<div class="row g-2 mb-2"><div class="col-6"><label class="form-label">Antecessora</label><select class="form-select" id="tpred"><option value="">— nenhum —</option>' + predOpts + '</select></div><div class="col-3"><label class="form-label">Tipo</label><select class="form-select" id="ttipo">' + tipoDepOpts(dep ? dep.tipo : 'FS') + '</select></div><div class="col-3"><label class="form-label">Intervalo (dias)</label><input type="number" class="form-control" id="tlag" value="' + (dep ? dep.lag || 0 : 0) + '"></div></div>' : '') +
        '<div class="mb-0"><label class="form-label">Notas</label><textarea class="form-control" id="tnot" rows="2">' + h(t.notas || '') + '</textarea></div>',
        function (d) {
          var nome = v(d, '#tn').trim(); if (!nome) throw new Error('Informe o nome.');
          var ini = v(d, '#ti') || null, fim = v(d, '#tf') || null, dur = parseInt(v(d, '#td'), 10) || 1;
          if (ini && !fim) fim = addDias(ini, dur - 1);
          if (ini && fim) dur = Math.max(1, diasEntre(ini, fim) + 1);
          DB.tx(function () {
            DB.run('UPDATE proj_tarefas SET nome=?, inicio=?, fim=?, duracao=?, progresso=?, responsavel=?, recurso_id=?, custo=?, notas=? WHERE id=?',
              [nome, ini, fim, dur, parseFloat(v(d, '#tp')) || 0, v(d, '#tr').trim(), parseInt(v(d, '#trec'), 10) || null, parseFloat(v(d, '#tc')) || 0, v(d, '#tnot').trim(), tid]);
            DB.run('DELETE FROM proj_deps WHERE succ_id=?', [tid]);
            var pred = parseInt(v(d, '#tpred'), 10);
            if (pred) DB.run('INSERT OR IGNORE INTO proj_deps (pred_id,succ_id,tipo,lag) VALUES (?,?,?,?)', [pred, tid, v(d, '#ttipo') || 'FS', parseInt(v(d, '#tlag'), 10) || 0]);
            recalcularProgresso(t.projeto_id);
          });
          Nav.ir('#/projeto?id=' + t.projeto_id);
        });
    },
    excluirTarefa: function (tid) {
      var t = DB.one('SELECT * FROM proj_tarefas WHERE id=?', [tid]); if (!t) return;
      if (!confirm('Excluir a tarefa "' + t.nome + '"?')) return;
      function coletar(id, acc) { acc.push(id); DB.all('SELECT id FROM proj_tarefas WHERE parent_id=?', [id]).forEach(function (x) { coletar(x.id, acc); }); return acc; }
      var ids = coletar(tid, []);
      DB.tx(function () {
        DB.run('DELETE FROM proj_deps WHERE pred_id IN (' + ids.join(',') + ') OR succ_id IN (' + ids.join(',') + ')');
        DB.run('DELETE FROM proj_tarefas WHERE id IN (' + ids.join(',') + ')');
        recalcularProgresso(t.projeto_id);
      });
      Nav.ir('#/projeto?id=' + t.projeto_id);
    },
    mover: function (tid, dir) {
      var t = DB.one('SELECT * FROM proj_tarefas WHERE id=?', [tid]); if (!t) return;
      var siblings = DB.all('SELECT id, ordem FROM proj_tarefas WHERE projeto_id=? AND ' + (t.parent_id == null ? 'parent_id IS NULL' : 'parent_id=?') + ' ORDER BY ordem, id',
        t.parent_id == null ? [t.projeto_id] : [t.projeto_id, t.parent_id]);
      var idx = -1;
      siblings.forEach(function (s, i) { if (s.id === tid) idx = i; });
      var j = idx + dir;
      if (idx < 0 || j < 0 || j >= siblings.length) return;
      DB.tx(function () {
        var ordered = siblings.slice();
        var tmp = ordered[idx]; ordered[idx] = ordered[j]; ordered[j] = tmp;
        ordered.forEach(function (s, i) { DB.run('UPDATE proj_tarefas SET ordem=? WHERE id=?', [i + 1, s.id]); });
      });
      var hash = '#/projeto?id=' + t.projeto_id;
      if (location.hash.indexOf('baseline=') > 0) {
        var m = /baseline=(\d+)/.exec(location.hash);
        if (m) hash += '&baseline=' + m[1];
      }
      Nav.ir(hash);
    },
    novoRisco: function (pid) {
      var p = carregar(pid); if (!p) return;
      var nome = prompt('Nome do evento de risco:', 'Risco do projeto ' + (p.codigo || p.nome));
      if (nome == null) return;
      nome = String(nome).trim(); if (!nome) return alert('Informe o nome do risco.');
      try {
        var id = E.riscoSalvar({
          nome: nome,
          ambiente: p.nome,
          projeto_id: pid,
          categoria: 'Projeto',
          status: 'Identificado',
          responsavel: p.responsavel || '',
          descricao: 'Risco registrado a partir do projeto ' + (p.codigo ? p.codigo + ' — ' : '') + p.nome,
          fatores: []
        });
        Nav.ir('#/risco?id=' + id);
      } catch (e) { alert(e.message || e); }
    },
    recursos: function (pid) {
      var rs = recursosDoProjeto(pid);
      var corpo = '<p class="small text-muted">Capacidade = tarefas simultâneas (padrão 1). A sobrecarga de recursos é detectada automaticamente.</p><div class="table-responsive mb-3"><table class="table table-sm"><thead><tr><th>Nome</th><th>Tipo</th><th>Custo/h</th><th>Cap.</th><th></th></tr></thead><tbody>';
      rs.forEach(function (r) {
        corpo += '<tr><td>' + h(r.nome) + '</td><td>' + h(r.tipo) + '</td><td>' + fmtMoney(r.custo_hora) + '</td><td>' + (r.capacidade || 1) + '</td><td><button class="btn btn-sm btn-outline-danger" type="button" data-del="' + r.id + '"><i class="bi bi-trash"></i></button></td></tr>';
      });
      if (!rs.length) corpo += '<tr><td colspan="5" class="text-muted">Nenhum recurso.</td></tr>';
      corpo += '</tbody></table></div><div class="border-top pt-2"><b>Novo recurso</b><div class="row g-2 mt-1"><div class="col"><input class="form-control form-control-sm" id="rn" placeholder="Nome *"></div><div class="col-2"><select class="form-select form-select-sm" id="rt"><option>Pessoa</option><option>Equipe</option><option>Equipamento</option><option>Material</option></select></div><div class="col-2"><input type="number" step="0.01" class="form-control form-control-sm" id="rc" placeholder="R$/h" value="0"></div><div class="col-2"><input type="number" step="0.1" class="form-control form-control-sm" id="rca" value="1" title="Capacidade"></div></div></div>';
      mdl('Recursos do projeto', corpo, function (d) {
        var nome = v(d, '#rn').trim();
        if (!nome) { Nav.ir('#/projeto?id=' + pid); return; }
        DB.tx(function () { DB.run('INSERT INTO proj_recursos (projeto_id,nome,tipo,custo_hora,capacidade) VALUES (?,?,?,?,?)', [pid, nome, v(d, '#rt') || 'Pessoa', parseFloat(v(d, '#rc')) || 0, parseFloat(v(d, '#rca')) || 1]); });
        Nav.ir('#/projeto?id=' + pid);
      }, 'Adicionar / Fechar');
      setTimeout(function () {
        var root = document.getElementById('_pm') || document;
        Array.prototype.forEach.call(root.querySelectorAll('[data-del]'), function (btn) {
          btn.addEventListener('click', function () {
            if (!confirm('Remover?')) return;
            var rid = parseInt(btn.getAttribute('data-del'), 10);
            DB.tx(function () { DB.run('UPDATE proj_tarefas SET recurso_id = NULL WHERE recurso_id = ?', [rid]); DB.run('DELETE FROM proj_recursos WHERE id = ?', [rid]); });
            btn.closest('tr').remove();
          });
        });
      }, 50);
    },
    baseline: function (pid) {
      var bs = baselinesDoProjeto(pid);
      var corpo = '<p class="small text-muted">Instantâneo para comparar no cronograma (barra cinza).</p>';
      if (bs.length) {
        corpo += '<ul class="list-group mb-3">';
        bs.forEach(function (b) {
          corpo += '<li class="list-group-item d-flex justify-content-between align-items-center"><span><b>' + h(b.nome) + '</b> <small class="text-muted">' + h(b.salvo_em) + '</small></span><span><a class="btn btn-sm btn-outline-primary" href="#/projeto?id=' + pid + '&baseline=' + b.id + '">Comparar</a> <button type="button" class="btn btn-sm btn-outline-danger" data-bdel="' + b.id + '"><i class="bi bi-trash"></i></button></span></li>';
        });
        corpo += '</ul>';
      } else corpo += '<p class="text-muted">Nenhuma linha de base salva.</p>';
      corpo += '<div class="mb-0"><label class="form-label">Nome</label><input class="form-control" id="bn" value="Linha de base ' + (bs.length + 1) + '"></div>';
      mdl('Baselines', corpo, function (d) {
        var nome = v(d, '#bn').trim() || ('Linha de base ' + (bs.length + 1));
        var ts = tarefasDoProjeto(pid);
        var snap = { projeto: carregar(pid), tarefas: ts.map(function (t) { return { id: t.id, nome: t.nome, inicio: t.inicio, fim: t.fim, duracao: t.duracao, progresso: t.progresso, custo: t.custo, parent_id: t.parent_id }; }), cpm: caminhoCritico(pid) };
        DB.tx(function () { DB.run('INSERT INTO proj_baseline (projeto_id,nome,dados_json) VALUES (?,?,?)', [pid, nome, JSON.stringify(snap)]); });
        Nav.ir('#/projeto?id=' + pid);
      }, 'Salvar linha de base');
      setTimeout(function () {
        var root = document.getElementById('_pm') || document;
        Array.prototype.forEach.call(root.querySelectorAll('[data-bdel]'), function (btn) {
          btn.addEventListener('click', function () {
            if (!confirm('Excluir?')) return;
            DB.run('DELETE FROM proj_baseline WHERE id = ?', [parseInt(btn.getAttribute('data-bdel'), 10)]);
            btn.closest('li').remove();
          });
        });
      }, 50);
    }
  };


  function relatorio(q) {
    var id = parseInt(q.id, 10);
    var p = carregar(id);
    if (!p) return '<div class="pagina"><p class="text-danger">Projeto não encontrado.</p><a href="#/projetos">Voltar</a></div>';
    var ts = tarefasDoProjeto(id);
    var flat = flatComNivel(arvore(ts));
    var deps = depsDoProjeto(id);
    var depMap = {};
    deps.forEach(function (d) { if (!depMap[d.succ_id]) depMap[d.succ_id] = []; depMap[d.succ_id].push(d); });
    var cpm = caminhoCritico(id);
    var recursos = recursosDoProjeto(id);
    var e = eva(id);
    var riscos = DB.all('SELECT * FROM riscos WHERE projeto_id = ? ORDER BY id', [id]);
    var mapaNome = p.mapa_id ? ((DB.one('SELECT nome FROM me_mapas WHERE id = ?', [p.mapa_id]) || {}).nome || '') : '';
    var prog = (p.progresso != null ? p.progresso : recalcularProgresso(id));

    var o = '<div class="pagina" id="prj_relatorio">';
    o += '<div class="d-flex flex-wrap align-items-center mb-3 gap-2 no-print">' +
      '<a class="btn btn-outline-secondary btn-sm" href="#/projeto?id=' + id + '"><i class="bi bi-arrow-left"></i> Voltar ao projeto</a>' +
      '<h1 class="h4 mb-0 flex-grow-1">Relatório do projeto</h1>' +
      '<button type="button" class="btn btn-sm btn-success" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir / salvar em PDF</button>' +
      '<button type="button" class="btn btn-sm btn-outline-primary" onclick="Proj.exportarPdf(' + id + ')"><i class="bi bi-filetype-pdf"></i> Exportar PDF</button></div>';

    o += '<div class="card mb-3"><div class="card-body">' +
      '<div class="d-flex justify-content-between align-items-start flex-wrap gap-2">' +
      '<div><div class="text-muted small">Valor-E · Relatório de projeto</div>' +
      '<h2 class="h4 mb-1">' + h(p.codigo ? p.codigo + ' — ' : '') + h(p.nome) + '</h2>' +
      '<div class="small text-muted">Emitido em ' + h(E.dataBr(hoje())) + ' · Status: <b>' + h(p.status) + '</b></div></div>' +
      '<div class="text-end"><div class="display-6 fw-semibold" style="line-height:1">' + Math.round(prog) + '%</div>' +
      '<div class="small text-muted">Progresso</div></div></div>' +
      '<hr><div class="row g-2 small">' +
      '<div class="col-md-3"><div class="text-muted">Início</div><b>' + (p.inicio ? h(E.dataBr(p.inicio)) : '—') + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Término</div><b>' + (p.fim ? h(E.dataBr(p.fim)) : '—') + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Macroprocesso</div><b>' + h((DB.one('SELECT nome FROM macroprocessos WHERE id=?', [p.macro_id]) || {}).nome || '—') + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Objetivo estratégico</div><b>' + h((function () { var o = DB.one('SELECT codigo, nome FROM objetivos_estrategicos WHERE id=?', [p.objetivo_id]); return o ? ((o.codigo ? o.codigo + ' — ' : '') + (o.nome || '')) : '—'; })()) + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Responsável</div><b>' + h(p.responsavel || '—') + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Orçado</div><b>' + fmtMoney(p.orcado) + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Custo real</div><b>' + fmtMoney(p.custo_real) + '</b></div>' +
      '<div class="col-md-3"><div class="text-muted">Tarefas</div><b>' + flat.length + '</b></div></div>' +
      (p.descricao ? '<div class="mt-3 small"><div class="text-muted">Descrição</div>' + h(p.descricao) + '</div>' : '') +
      '</div></div>';

    // EVA
    o += '<div class="card mb-3"><div class="card-header py-2"><strong>1. Valor do trabalho</strong></div><div class="card-body py-2">' +
      '<div class="row g-2 text-center">' +
      '<div class="col"><div class="small text-muted">Valor planejado</div><div class="fs-5 fw-semibold">' + fmtMoney(e.pv) + '</div></div>' +
      '<div class="col"><div class="small text-muted">Valor agregado</div><div class="fs-5 fw-semibold">' + fmtMoney(e.ev) + '</div></div>' +
      '<div class="col"><div class="small text-muted">Custo real</div><div class="fs-5 fw-semibold">' + fmtMoney(e.ac) + '</div></div>' +
      '<div class="col"><div class="small text-muted">Desemp. de prazo</div><div class="fs-5 fw-semibold">' + (e.spi == null ? '—' : e.spi.toFixed(2)) + '</div><div class="text-muted" style="font-size:10px">agregado ÷ planejado</div></div>' +
      '<div class="col"><div class="small text-muted">Desemp. de custo</div><div class="fs-5 fw-semibold">' + (e.cpi == null ? '—' : e.cpi.toFixed(2)) + '</div><div class="text-muted" style="font-size:10px">agregado ÷ custo real</div></div>' +
      '</div><p class="small text-muted mb-0 mt-2">Desempenho de prazo &lt; 1: atraso · Desempenho de custo &lt; 1: estouro de orçamento.</p></div></div>';

    // Critical path summary
    o += '<div class="card mb-3"><div class="card-header py-2"><strong>2. Caminho crítico</strong></div><div class="card-body py-2 small">' +
      (cpm.fimProj != null ? '<p class="mb-2">Duração do caminho crítico: <b>' + cpm.fimProj + ' dia(s)</b>' + (cpm.ancora ? ' a partir de ' + h(E.dataBr(cpm.ancora)) : '') + '.</p>' : '<p class="mb-2 text-muted">Sem datas suficientes para calcular o caminho crítico.</p>') +
      '<table class="table table-sm table-bordered mb-0"><thead class="table-light"><tr><th>Tarefa</th><th>Início</th><th>Fim</th><th>Duração</th><th>Folga</th><th>Crítica?</th></tr></thead><tbody>';
    flat.forEach(function (t) {
      var crit = !!cpm.critica[t.id];
      var folga = cpm.folga[t.id];
      o += '<tr' + (crit ? ' class="table-warning"' : '') + '><td>' + h(t.nome) + '</td><td>' + (t.inicio ? h(E.dataBr(t.inicio)) : '—') + '</td><td>' + (t.fim ? h(E.dataBr(t.fim)) : '—') + '</td><td>' + (t.duracao != null ? t.duracao + ' d' : '—') + '</td><td>' + (folga != null ? folga + ' d' : '—') + '</td><td>' + (crit ? '<b>Sim</b>' : 'Não') + '</td></tr>';
    });
    o += '</tbody></table></div></div>';

    // Tasks full
    o += '<div class="card mb-3"><div class="card-header py-2"><strong>3. Tarefas e dependências</strong></div><div class="card-body py-2 small">' +
      '<table class="table table-sm table-bordered mb-0"><thead class="table-light"><tr><th>#</th><th>Tarefa</th><th>Início</th><th>Fim</th><th>%</th><th>Recurso</th><th>Custo</th><th>Dependências</th></tr></thead><tbody>';
    flat.forEach(function (t, i) {
      var depTxt = (depMap[t.id] || []).map(function (d) {
        var pred = ts.filter(function (x) { return x.id === d.pred_id; })[0];
        return (pred ? pred.nome : '#' + d.pred_id) + ' (' + (ROTULO_DEP[d.tipo] || d.tipo) + (d.lag ? ' +' + d.lag + 'd' : '') + ')';
      }).join('; ') || '—';
      var rec = t.recurso_id ? ((recursos.filter(function (r) { return r.id === t.recurso_id; })[0] || {}).nome || '') : '';
      o += '<tr><td>' + (i + 1) + '</td><td style="padding-left:' + (8 + (t._nivel || 0) * 12) + 'px">' + h(t.nome) + '</td><td>' + (t.inicio ? h(E.dataBr(t.inicio)) : '—') + '</td><td>' + (t.fim ? h(E.dataBr(t.fim)) : '—') + '</td><td>' + (t.pct != null ? t.pct + '%' : '—') + '</td><td>' + h(rec || '—') + '</td><td>' + fmtMoney(t.custo) + '</td><td>' + h(depTxt) + '</td></tr>';
    });
    o += '</tbody></table></div></div>';

    // Resources
    o += '<div class="card mb-3"><div class="card-header py-2"><strong>4. Recursos</strong></div><div class="card-body py-2 small">';
    if (!recursos.length) o += '<p class="text-muted mb-0">Nenhum recurso cadastrado.</p>';
    else {
      o += '<table class="table table-sm table-bordered mb-0"><thead class="table-light"><tr><th>Nome</th><th>Tipo</th><th>Custo/hora</th><th>Capacidade</th></tr></thead><tbody>';
      recursos.forEach(function (r) {
        o += '<tr><td>' + h(r.nome) + '</td><td>' + h(r.tipo || '—') + '</td><td>' + fmtMoney(r.custo_hora) + '</td><td>' + (r.capacidade != null ? r.capacidade : '—') + '</td></tr>';
      });
      o += '</tbody></table>';
    }
    o += '</div></div>';

    // Risks
    o += '<div class="card mb-3"><div class="card-header py-2"><strong>5. Riscos do projeto</strong></div><div class="card-body py-2 small">';
    if (!riscos.length) o += '<p class="text-muted mb-0">Nenhum risco vinculado a este projeto.</p>';
    else {
      o += '<table class="table table-sm table-bordered mb-0"><thead class="table-light"><tr><th>Código</th><th>Evento / nome</th><th>Nível</th><th>Status</th></tr></thead><tbody>';
      riscos.forEach(function (r) {
        var nv = r.nivel_res || r.nivel_medio || '—';
        o += '<tr><td>' + h(r.codigo || '—') + '</td><td>' + h(r.nome || r.evento || '—') + '</td><td>' + h(nv) + '</td><td>' + h(r.status || '—') + '</td></tr>';
      });
      o += '</tbody></table>';
    }
    o += '</div></div>';

    o += '<p class="small text-muted">Valor-E ' + (w.UI && UI.APP_VERSAO ? UI.APP_VERSAO : '') + ' · Relatório gerado localmente · ' + h(E.dataBr(hoje())) + '</p>';
    o += '</div>';
    return o;
  }

  function exportarPdf(id) {
    id = parseInt(id, 10);
    var p = carregar(id);
    if (!p) { alert('Projeto não encontrado.'); return; }
    if (!w.jspdf || !w.jspdf.jsPDF) {
      alert('Biblioteca de PDF não carregada. Use o botão Imprimir / salvar em PDF do navegador.');
      window.print();
      return;
    }
    var ts = tarefasDoProjeto(id);
    var flat = flatComNivel(arvore(ts));
    var cpm = caminhoCritico(id);
    var e = eva(id);
    var recursos = recursosDoProjeto(id);
    var riscos = DB.all('SELECT * FROM riscos WHERE projeto_id = ? ORDER BY id', [id]);
    var prog = (p.progresso != null ? p.progresso : recalcularProgresso(id));
    var doc = new w.jspdf.jsPDF({ unit: 'pt', format: 'a4' });
    var margin = 40, y = margin, pageW = doc.internal.pageSize.getWidth(), maxW = pageW - margin * 2;
    function linha(txt, size, bold) {
      doc.setFontSize(size || 10);
      doc.setFont('helvetica', bold ? 'bold' : 'normal');
      var lines = doc.splitTextToSize(String(txt || ''), maxW);
      lines.forEach(function (ln) {
        if (y > doc.internal.pageSize.getHeight() - 50) { doc.addPage(); y = margin; }
        doc.text(ln, margin, y);
        y += (size || 10) + 4;
      });
    }
    function gap(n) { y += n || 8; }
    linha('Valor-E — Relatório de projeto', 14, true);
    linha((p.codigo ? p.codigo + ' — ' : '') + p.nome, 12, true);
    linha('Emitido em ' + E.dataBr(hoje()) + ' · Status: ' + (p.status || '—') + ' · Progresso: ' + Math.round(prog) + '%', 9);
    gap(6);
    var macroN = (DB.one('SELECT nome FROM macroprocessos WHERE id=?', [p.macro_id]) || {}).nome || '—';
    var objN = (function () { var o = DB.one('SELECT codigo, nome FROM objetivos_estrategicos WHERE id=?', [p.objetivo_id]); return o ? ((o.codigo ? o.codigo + ' — ' : '') + (o.nome || '')) : '—'; })();
    linha('Início: ' + (p.inicio ? E.dataBr(p.inicio) : '—') + ' · Término: ' + (p.fim ? E.dataBr(p.fim) : '—') + ' · Macroprocesso: ' + macroN, 9);
    linha('Objetivo estratégico: ' + objN, 9);
    linha('Orçado: ' + fmtMoney(p.orcado) + ' · Custo real: ' + fmtMoney(p.custo_real) + ' · Responsável: ' + (p.responsavel || '—'), 9);
    gap(10);
    linha('1. Valor do trabalho', 11, true);
    linha('Valor planejado: ' + fmtMoney(e.pv) + ' · Valor agregado: ' + fmtMoney(e.ev) + ' · Custo real: ' + fmtMoney(e.ac), 9);
    linha('Desemp. de prazo (agregado÷planejado): ' + (e.spi == null ? '—' : e.spi.toFixed(2)) + ' · Desemp. de custo (agregado÷custo real): ' + (e.cpi == null ? '—' : e.cpi.toFixed(2)), 9);
    gap(8);
    linha('2. Tarefas (' + flat.length + ')', 11, true);
    flat.forEach(function (t, i) {
      var pad = '';
      for (var k = 0; k < (t._nivel || 0); k++) pad += '  ';
      var crit = cpm.critica[t.id] ? ' [crítica]' : '';
      linha((i + 1) + '. ' + pad + t.nome + crit + ' · ' + (t.inicio ? E.dataBr(t.inicio) : '?') + ' → ' + (t.fim ? E.dataBr(t.fim) : '?') + ' · ' + (t.progresso != null ? t.progresso + '%' : '—') + ' · ' + fmtMoney(t.custo), 8);
    });
    gap(8);
    linha('3. Recursos (' + recursos.length + ')', 11, true);
    if (!recursos.length) linha('Nenhum recurso cadastrado.', 9);
    else recursos.forEach(function (r) { linha('• ' + r.nome + ' (' + (r.tipo || '—') + ') · ' + fmtMoney(r.custo_hora) + '/h · cap. ' + (r.capacidade != null ? r.capacidade : '—'), 9); });
    gap(8);
    linha('4. Riscos (' + riscos.length + ')', 11, true);
    if (!riscos.length) linha('Nenhum risco vinculado.', 9);
    else riscos.forEach(function (r) { linha('• ' + (r.codigo || '') + ' ' + (r.nome || r.evento || '') + ' · Nível: ' + (r.nivel_res || r.nivel_medio || '—') + ' · ' + (r.status || ''), 9); });
    gap(12);
    linha('Documento gerado localmente pelo Valor-E.', 8);
    var nome = 'projeto-' + (p.codigo || id) + '-' + new Date().toISOString().slice(0, 10) + '.pdf';
    doc.save(nome.replace(/[^\w.\-]+/g, '_'));
  }


    Modulos.registrar('/projetos', { ativo: 'projetos', titulo: 'Projetos', html: function (q) { return lista(q); } });
  Modulos.registrar('/projeto', { ativo: 'projetos', titulo: 'Projeto', html: function (q) { return detalhe(q); } });
  Modulos.registrar('/projeto-relatorio', { ativo: 'projetos', titulo: 'Relatório do projeto', html: function (q) { return relatorio(q); } });

  w.Proj = w.Proj || {};
  w.Proj.exportarPdf = exportarPdf;
})(window);
