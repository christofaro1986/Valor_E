/* telas_processos.js — módulo Processos: lista, novo, importar Folha, exclusão sincronizada com riscos e indicadores. */
(function (w) {
  'use strict';
  var h = E.esc;
  function macrosAgrupados(sel, cadeia) {
    var l = DB.all("SELECT m.id, m.nome, m.tipo, c.cadeia FROM macroprocessos m JOIN cva_ciclos c ON c.id = m.ciclo_id WHERE c.status = 'Vigente'" + (cadeia ? ' AND c.cadeia = ?' : '') + " ORDER BY c.cadeia, m.tipo, m.ordem, m.nome", cadeia ? [cadeia] : []);
    if (!l.length) l = DB.all('SELECT m.id, m.nome, m.tipo, c.cadeia FROM macroprocessos m JOIN cva_ciclos c ON c.id = m.ciclo_id ORDER BY c.cadeia, m.tipo, m.ordem, m.nome');
    var varias = (w.Cva && Cva.cadeias ? Cva.cadeias().length : 1) > 1, g = {}, ord = [], o = '';
    l.forEach(function (m) { var k = (varias ? (m.cadeia || 'Principal') + ' › ' : '') + m.tipo + 's'; if (!g[k]) { g[k] = []; ord.push(k); } g[k].push(m); });
    ord.forEach(function (k) { o += '<optgroup label="' + h(k) + '">' + g[k].map(function (m) { return '<option value="' + m.id + '"' + (String(sel) === String(m.id) ? ' selected' : '') + '>' + h(m.nome) + '</option>'; }).join('') + '</optgroup>'; });
    return o;
  }
  w.macrosAgrupados = macrosAgrupados;

  function html(q) {
    var l = E.processosListar({ q: q.q || '', macro: q.macro || '', cadeia: q.cadeia || '' }), cads = (w.Cva && Cva.cadeias) ? Cva.cadeias() : [];
    var tem = DB.one('SELECT COUNT(*) AS n FROM processos').n;
    var o = '<div class="pagina"><div class="d-flex flex-wrap align-items-center mb-3"><h1 class="h4 mb-0 me-auto"><i class="bi bi-diagram-3"></i> Processos</h1>' +
      '<form class="filtros d-flex flex-wrap align-items-center" style="margin-right:8px"><input class="form-control form-control-sm" name="q" value="' + h(q.q || '') + '" placeholder="Buscar processo…" style="width:200px;margin-right:6px">' +
      (cads.length > 1 ? '<select class="form-select form-select-sm" name="cadeia" title="Cadeia de valor" style="width:190px;margin-right:6px"><option value="">Todas as cadeias</option>' + cads.map(function (x) { return '<option value="' + h(x) + '"' + (q.cadeia === x ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select>' : '') + '<select class="form-select form-select-sm" name="macro" style="width:200px;margin-right:6px"><option value="">Todos os macroprocessos</option>' + macrosAgrupados(q.macro, q.cadeia) + '</select><button class="btn btn-sm btn-outline-secondary">Filtrar</button></form>' +
      '<a class="btn btn-sm btn-outline-dark me-1" href="#/processos-relatorio" title="Relatório preliminar"><i class="bi bi-file-earmark-bar-graph"></i> Relatório preliminar</a>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="document.getElementById(\'impFolha\').click()"><i class="bi bi-upload"></i> Importar Folha (.xml)</button><input type="file" id="impFolha" accept=".xml" hidden>' +
      '<button class="btn btn-success btn-sm" onclick="Proc.novo()"><i class="bi bi-plus-lg"></i> Novo processo</button></div>';
    if (!l.length) o += '<div class="cartao"><div class="vazio">' + (tem ? 'Nenhum processo encontrado com o filtro.' : 'Nenhum processo cadastrado. Clique em <b>Novo processo</b> para preencher a Folha de dados e gerar o diagrama BPMN, onde você marca os riscos nas atividades.') + '</div></div>';
    else {
      o += '<div class="cartao"><div class="table-responsive"><table class="tabela"><thead><tr><th>Processo</th><th>Macroprocesso</th><th>Status</th><th class="text-center" title="Bandeiras de risco no diagrama">Bandeiras</th><th class="text-center">Riscos</th><th class="text-center">Indicadores</th><th>Atualizado</th><th></th></tr></thead><tbody>';
      l.forEach(function (c) {
        o += '<tr><td><a href="#/folha?id=' + c.id + '"><b>' + h(c.nome) + '</b></a></td><td>' + (c.macro_nome ? h(c.macro_nome) + (cads.length > 1 && c.cadeia ? ' <small class="text-muted">· ' + h(c.cadeia) + '</small>' : '') : '<span class="text-muted">—</span>') + '</td><td>' + h(c.status || '') + '</td>' +
          '<td class="text-center">' + c.n_flags + '</td><td class="text-center">' + (c.n_riscos ? '<a href="#/riscos?processo=' + c.id + '">' + c.n_riscos + '</a>' : 0) + '</td><td class="text-center">' + (c.n_ind ? '<a href="#/indicadores?processo=' + c.id + '">' + c.n_ind + '</a>' : 0) + '</td>' +
          '<td>' + h(E.dataBr(String(c.atualizado_em || '').slice(0, 10))) + '</td><td class="text-end text-nowrap">' +
          '<a class="btn btn-sm btn-outline-success" href="#/folha?id=' + c.id + '" title="Folha de dados"><i class="bi bi-file-earmark-text"></i> Folha</a> ' +
          '<a class="btn btn-sm btn-outline-success" href="#/diagrama?id=' + c.id + '" title="Diagrama BPMN e riscos"><i class="bi bi-diagram-3"></i> Diagrama</a> ' +
          '<a class="btn btn-sm btn-outline-primary" href="#/indicador?novo=1&processo=' + c.id + '" title="Novo indicador deste processo"><i class="bi bi-graph-up-arrow"></i> Indicador</a> ' +
          '<button class="btn btn-sm btn-outline-secondary" onclick="Proc.exportar(' + c.id + ')" title="Exportar Folha (.xml)"><i class="bi bi-download"></i></button> ' +
          '<button class="btn btn-sm btn-outline-danger" onclick="Proc.excluir(' + c.id + ')" title="Excluir"><i class="bi bi-trash"></i></button></td></tr>';
      });
      o += '</tbody></table></div></div>';
    }
    return o + '</div>';
  }
  function apos() {
    var f = document.getElementById('impFolha');
    if (f) f.addEventListener('change', function (e) {
      var a = e.target.files[0]; if (!a) return;
      var fr = new FileReader(); fr.onload = function () {
        var r = API.acao('importar_xml', { xml: String(fr.result) });
        if (!r.ok) return alert(r.erro);
        if (r.avisos && r.avisos.length) alert('Importado com avisos:\n' + r.avisos.join('\n'));
        Nav.ir('#/folha?id=' + r.id);
      };
      fr.readAsText(a);
    });
  }

  function rotuloTipoMacro(tipo) {
    var map = {
      'Finalístico': 'Macroprocessos finalísticos',
      'Gerencial': 'Macroprocessos gerenciais',
      'Apoio': 'Macroprocessos de apoio'
    };
    return map[tipo] || ((tipo || 'Macroprocesso') + (tipo ? '' : 's'));
  }
  function dadosRelatorio() {
    var macros = DB.all("SELECT m.*, c.nome AS ciclo_nome, c.cadeia FROM macroprocessos m LEFT JOIN cva_ciclos c ON c.id = m.ciclo_id ORDER BY c.cadeia, CASE m.tipo WHEN 'Finalístico' THEN 1 WHEN 'Gerencial' THEN 2 WHEN 'Apoio' THEN 3 ELSE 4 END, m.ordem, m.nome");
    var blocos = [];
    macros.forEach(function (m) {
      var procs = DB.all('SELECT * FROM processos WHERE macro_id = ? ORDER BY nome COLLATE NOCASE', [m.id]);
      var itens = procs.map(function (p) {
        var inds = [], riscos = [];
        try { inds = DB.all('SELECT id, codigo, nome FROM indicadores WHERE processo_id = ? ORDER BY codigo, nome', [p.id]); } catch (e) {}
        try { riscos = DB.all('SELECT id, codigo, nome FROM riscos WHERE processo_id = ? ORDER BY codigo, nome', [p.id]); } catch (e) {}
        return { processo: p, indicadores: inds, riscos: riscos };
      });
      blocos.push({ macro: m, itens: itens });
    });
    var orfaos = DB.all('SELECT * FROM processos WHERE macro_id IS NULL OR macro_id NOT IN (SELECT id FROM macroprocessos) ORDER BY nome COLLATE NOCASE');
    return { blocos: blocos, orfaos: orfaos };
  }
  function htmlRelatorio(q) {
    var d = dadosRelatorio();
    var o = '<div class="pagina rel-proc">' +
      '<div class="d-flex flex-wrap align-items-center mb-3 gap-2 no-print">' +
      '<h1 class="h4 mb-0 me-auto"><i class="bi bi-file-earmark-bar-graph"></i> Relatório preliminar de processos</h1>' +
      '<a class="btn btn-sm btn-outline-secondary" href="#/processos"><i class="bi bi-arrow-left"></i> Voltar</a>' +
      '<button class="btn btn-sm btn-outline-danger" onclick="Proc.exportarRelatorioPdf()"><i class="bi bi-filetype-pdf"></i> Exportar PDF</button>' +
      '</div>';
    o += '<p class="text-muted small no-print mb-3">Visão consolidada: macroprocessos da CVA, processos vinculados e seus indicadores e riscos.</p>';
    if (!d.blocos.length) {
      o += '<div class="cartao"><div class="vazio">Nenhum macroprocesso cadastrado na CVA.</div></div></div>';
      return o;
    }

    // totais
    var totP = 0, totI = 0, totR = 0;
    d.blocos.forEach(function (b) {
      totP += b.itens.length;
      b.itens.forEach(function (it) { totI += it.indicadores.length; totR += it.riscos.length; });
    });
    o += '<div class="row g-2 mb-4 no-print">' +
      '<div class="col-auto"><span class="badge text-bg-primary fs-6">' + d.blocos.length + ' macroprocessos</span></div>' +
      '<div class="col-auto"><span class="badge text-bg-secondary fs-6">' + totP + ' processos</span></div>' +
      '<div class="col-auto"><span class="badge text-bg-info fs-6">' + totI + ' indicadores</span></div>' +
      '<div class="col-auto"><span class="badge text-bg-warning fs-6">' + totR + ' riscos</span></div></div>';

    var cadeiaAtual = null, tipoAtual = null;
    var corTipo = { 'Finalístico': '#1f6f54', 'Gerencial': '#2f5d8a', 'Apoio': '#8a6d1f' };

    d.blocos.forEach(function (b) {
      var m = b.macro;
      var cad = m.cadeia || 'Principal';
      if (cad !== cadeiaAtual) {
        cadeiaAtual = cad;
        tipoAtual = null;
        o += '<div class="rel-cadeia">' + h(cadeiaAtual) + '</div>';
      }
      if (m.tipo !== tipoAtual) {
        tipoAtual = m.tipo;
        var cor = corTipo[tipoAtual] || '#1d4f91';
        o += '<div class="rel-nivel" style="border-left-color:' + cor + ';color:' + cor + '">' + h(rotuloTipoMacro(tipoAtual)) + '</div>';
      }

      o += '<section class="rel-macro">' +
        '<header class="rel-macro-h">' +
        '<div class="rel-macro-title">' + h(m.nome) + '</div>' +
        '<div class="rel-macro-meta">' +
        (m.ciclo_nome ? '<span class="rel-chip">' + h(m.ciclo_nome) + '</span>' : '') +
        '<span class="rel-chip rel-chip-soft">' + b.itens.length + ' processo(s)</span>' +
        '</div></header>';

      if (!b.itens.length) {
        o += '<div class="rel-empty">Nenhum processo vinculado a este macroprocesso.</div>';
      } else {
        o += '<div class="rel-lista">';
        b.itens.forEach(function (it) {
          var p = it.processo;
          o += '<article class="rel-proc-item">' +
            '<div class="rel-proc-top">' +
            '<a class="rel-proc-nome" href="#/folha?id=' + p.id + '">' + h(p.nome) + '</a>' +
            (p.status ? '<span class="rel-status">' + h(p.status) + '</span>' : '') +
            '<div class="rel-proc-acoes no-print">' +
            '<a class="btn btn-sm btn-outline-secondary" href="#/folha?id=' + p.id + '">Folha</a> ' +
            '<a class="btn btn-sm btn-outline-success" href="#/diagrama?id=' + p.id + '">Diagrama</a>' +
            '</div></div>';
          o += '<div class="rel-proc-grid">' +
            '<div class="rel-box"><div class="rel-box-t">Indicadores <span class="rel-n">' + it.indicadores.length + '</span></div>';
          if (!it.indicadores.length) o += '<div class="rel-muted">Nenhum indicador</div>';
          else o += '<ul class="rel-ul">' + it.indicadores.map(function (i) {
            return '<li><a href="#/indicador?id=' + i.id + '">' + h((i.codigo ? i.codigo + ' — ' : '') + i.nome) + '</a></li>';
          }).join('') + '</ul>';
          o += '</div><div class="rel-box"><div class="rel-box-t">Riscos <span class="rel-n">' + it.riscos.length + '</span></div>';
          if (!it.riscos.length) o += '<div class="rel-muted">Nenhum risco</div>';
          else o += '<ul class="rel-ul">' + it.riscos.map(function (r) {
            return '<li><a href="#/risco?id=' + r.id + '">' + h((r.codigo ? r.codigo + ' — ' : '') + r.nome) + '</a></li>';
          }).join('') + '</ul>';
          o += '</div></div></article>';
        });
        o += '</div>';
      }
      o += '</section>';
    });

    if (d.orfaos && d.orfaos.length) {
      o += '<div class="rel-nivel" style="border-left-color:#888;color:#555">Processos sem macroprocesso</div>';
      o += '<section class="rel-macro"><div class="rel-lista">';
      d.orfaos.forEach(function (p) {
        o += '<article class="rel-proc-item"><a class="rel-proc-nome" href="#/folha?id=' + p.id + '">' + h(p.nome) + '</a></article>';
      });
      o += '</div></section>';
    }

    o += '<style>' +
      '.rel-cadeia{font-size:1.2rem;font-weight:700;color:#0b2447;border-bottom:2px solid #0b2447;padding-bottom:.4rem;margin:1.5rem 0 .75rem}' +
      '.rel-nivel{font-size:1rem;font-weight:700;background:linear-gradient(90deg,#eef3f9,#f8fafc);border-left:5px solid #1d4f91;padding:.5rem .85rem;margin:1.25rem 0 .75rem;border-radius:0 8px 8px 0;letter-spacing:.01em}' +
      '.rel-macro{background:#fff;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:1rem;overflow:hidden;box-shadow:0 1px 2px rgba(15,23,42,.04)}' +
      '.rel-macro-h{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;padding:.75rem 1rem;background:#f8fafc;border-bottom:1px solid #eef2f7}' +
      '.rel-macro-title{font-weight:700;font-size:1.05rem;color:#0b2447;flex:1 1 auto}' +
      '.rel-macro-meta{display:flex;gap:.35rem;flex-wrap:wrap}' +
      '.rel-chip{display:inline-block;background:#e8eef6;color:#1d4f91;border-radius:999px;padding:.15rem .55rem;font-size:.75rem;font-weight:600}' +
      '.rel-chip-soft{background:#f1f5f9;color:#475569}' +
      '.rel-empty{padding:1rem;color:#64748b;font-size:.9rem}' +
      '.rel-lista{padding:.5rem}' +
      '.rel-proc-item{border:1px solid #eef2f7;border-radius:8px;padding:.75rem .9rem;margin:.5rem;background:#fff}' +
      '.rel-proc-top{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;margin-bottom:.55rem}' +
      '.rel-proc-nome{font-weight:600;color:#0b2447;text-decoration:none;flex:1 1 200px}' +
      '.rel-proc-nome:hover{color:#0a6fc2;text-decoration:underline}' +
      '.rel-status{font-size:.72rem;background:#e2e8f0;color:#334155;border-radius:6px;padding:.1rem .45rem}' +
      '.rel-proc-acoes{margin-left:auto}' +
      '.rel-proc-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}' +
      '@media (max-width:720px){.rel-proc-grid{grid-template-columns:1fr}}' +
      '.rel-box{background:#f8fafc;border:1px solid #eef2f7;border-radius:8px;padding:.55rem .7rem}' +
      '.rel-box-t{font-size:.72rem;text-transform:uppercase;letter-spacing:.04em;color:#64748b;font-weight:700;margin-bottom:.35rem}' +
      '.rel-n{display:inline-block;background:#e2e8f0;color:#334155;border-radius:999px;padding:0 .4rem;font-size:.7rem;margin-left:.25rem}' +
      '.rel-ul{margin:0;padding-left:1.1rem;font-size:.88rem}' +
      '.rel-ul a{color:#1d4f91;text-decoration:none}' +
      '.rel-ul a:hover{text-decoration:underline}' +
      '.rel-muted{color:#94a3b8;font-size:.85rem}' +
      '@media print{.no-print{display:none!important}.rel-macro{break-inside:avoid;box-shadow:none}}' +
      '</style></div>';
    return o;
  }
  var Proc = w.Proc = {
    exportarRelatorioPdf: function () {
      try {
        function pdfTxt(s) {
          s = String(s == null ? '' : s);
          s = s.replace(/[\u00A0\u2013\u2014\u2018\u2019\u201C\u201D\u2022\u25C6\u25CB\u25CF\u25A0\u2192\u00B7]/g, function (ch) {
            var map = {'\u00A0':' ','\u2013':'-','\u2014':'-','\u2018':"'",'\u2019':"'",'\u201C':'"','\u201D':'"','\u2022':'-','\u25C6':'*','\u25CB':'-','\u25CF':'*','\u25A0':'*','\u2192':'->','\u00B7':'-'};
            return map[ch] || ' ';
          });
          // fix accidental double-escape in map key - handled below
          return s.replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, '');
        }
        if (!w.jspdf || !w.jspdf.jsPDF) {
          alert('Biblioteca PDF (jsPDF) não está disponível. Recarregue o aplicativo e tente novamente.');
          return;
        }
        var d = dadosRelatorio();
        var doc = new w.jspdf.jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });
        var margin = 40;
        var pageW = doc.internal.pageSize.getWidth();
        var pageH = doc.internal.pageSize.getHeight();
        var maxW = pageW - margin * 2;
        var y = margin;
        var footerH = 28;

        // colunas da tabela de processos
        var colProc = margin;
        var colStatus = margin + 200;
        var colInd = margin + 270;
        var colRisco = margin + 420;
        var wProc = colStatus - colProc - 6;
        var wStatus = colInd - colStatus - 6;
        var wInd = colRisco - colInd - 6;
        var wRisco = pageW - margin - colRisco;

        function novaPagina() {
          doc.addPage();
          y = margin;
        }
        function precisa(h) {
          if (y + h > pageH - footerH - margin) novaPagina();
        }
        function setF(estilo, size, cor) {
          doc.setFont('helvetica', estilo || 'normal');
          doc.setFontSize(size || 10);
          if (cor) doc.setTextColor(cor[0], cor[1], cor[2]);
          else doc.setTextColor(30, 30, 30);
        }
        function texto(str, x, yy, size, estilo, cor, maxWidth) {
          setF(estilo, size, cor);
          var lines = doc.splitTextToSize(pdfTxt(str), maxWidth || maxW);
          doc.text(lines, x, yy);
          return lines.length * ((size || 10) + 2);
        }

        // ----- cabeçalho -----
        setF('normal', 8, [110, 110, 110]);
        doc.text(pdfTxt('Valor-E — Gestão e Realização Estratégica'), margin, y);
        y += 16;
        setF('bold', 16, [11, 36, 71]);
        doc.text(pdfTxt('Relatório preliminar de processos'), margin, y);
        y += 16;
        var dataEm = (E.dataBr ? E.dataBr(new Date().toISOString().slice(0, 10)) : new Date().toLocaleDateString('pt-BR'));
        setF('normal', 9, [100, 100, 100]);
        doc.text(pdfTxt('Emitido em ' + dataEm), margin, y);
        y += 10;
        doc.setDrawColor(11, 36, 71);
        doc.setLineWidth(1.2);
        doc.line(margin, y, pageW - margin, y);
        y += 14;

        // ----- totais -----
        var totP = 0, totI = 0, totR = 0;
        d.blocos.forEach(function (b) {
          totP += b.itens.length;
          b.itens.forEach(function (it) { totI += it.indicadores.length; totR += it.riscos.length; });
        });
        setF('normal', 9, [50, 50, 50]);
        doc.text(pdfTxt(d.blocos.length + ' macroprocessos  |  ' + totP + ' processos  |  ' + totI + ' indicadores  |  ' + totR + ' riscos'), margin, y);
        y += 16;

        if (!d.blocos.length) {
          setF('italic', 11, [120, 120, 120]);
          doc.text(pdfTxt('Nenhum macroprocesso cadastrado na CVA.'), margin, y);
        }

        var coresTipo = {
          'Finalístico': [31, 111, 84],
          'Gerencial': [47, 93, 138],
          'Apoio': [138, 109, 31]
        };
        var cadeiaAtual = null, tipoAtual = null;

        function cabecalhoTabela() {
          precisa(16);
          doc.setFillColor(238, 242, 247);
          doc.rect(margin, y - 10, maxW, 16, 'F');
          setF('bold', 8, [70, 70, 70]);
          doc.text('Processo', colProc + 2, y);
          doc.text('Status', colStatus + 2, y);
          doc.text('Indicadores', colInd + 2, y);
          doc.text('Riscos', colRisco + 2, y);
          y += 10;
          doc.setDrawColor(200, 200, 200);
          doc.setLineWidth(0.4);
          doc.line(margin, y, pageW - margin, y);
          y += 8;
        }

        d.blocos.forEach(function (b) {
          var m = b.macro;
          var cad = m.cadeia || 'Principal';

          // cadeia
          if (cad !== cadeiaAtual) {
            cadeiaAtual = cad;
            tipoAtual = null;
            y += 8;
            precisa(22);
            setF('bold', 12, [11, 36, 71]);
            doc.text(pdfTxt('Cadeia de valor: ' + cad), margin, y);
            y += 4;
            doc.setDrawColor(11, 36, 71);
            doc.setLineWidth(1);
            doc.line(margin, y, pageW - margin, y);
            y += 12;
          }

          // nível (finalístico / gerencial / apoio)
          if (m.tipo !== tipoAtual) {
            tipoAtual = m.tipo;
            y += 4;
            precisa(24);
            var cor = coresTipo[tipoAtual] || [29, 79, 145];
            doc.setFillColor(236, 241, 247);
            doc.rect(margin, y - 11, maxW, 18, 'F');
            doc.setDrawColor(cor[0], cor[1], cor[2]);
            doc.setLineWidth(3.5);
            doc.line(margin, y - 11, margin, y + 7);
            setF('bold', 11, cor);
            doc.text(pdfTxt(rotuloTipoMacro(tipoAtual)), margin + 10, y + 1);
            y += 16;
          }

          // macroprocesso
          precisa(20);
          setF('bold', 10, [20, 40, 70]);
          var tituloM = m.nome + (m.ciclo_nome ? '  (' + m.ciclo_nome + ')' : '');
          var hTit = texto(tituloM, margin, y, 10, 'bold', [20, 40, 70], maxW);
          y += Math.max(12, hTit) + 2;

          if (!b.itens.length) {
            setF('italic', 9, [130, 130, 130]);
            doc.text(pdfTxt('Nenhum processo vinculado a este macroprocesso.'), margin + 8, y);
            y += 14;
            return;
          }

          cabecalhoTabela();

          b.itens.forEach(function (it, idx) {
            var p = it.processo;
            var indList = it.indicadores.length
              ? it.indicadores.map(function (i) { return (i.codigo ? i.codigo + ' - ' : '') + i.nome; })
              : ['—'];
            var risList = it.riscos.length
              ? it.riscos.map(function (r) { return (r.codigo ? r.codigo + ' - ' : '') + r.nome; })
              : ['—'];

            setF('normal', 8, [30, 30, 30]);
            var linesProc = doc.splitTextToSize(pdfTxt(p.nome || ''), wProc);
            var linesStatus = doc.splitTextToSize(pdfTxt(p.status || '—'), wStatus);
            var linesInd = [];
            indList.forEach(function (s) {
              linesInd = linesInd.concat(doc.splitTextToSize(pdfTxt(s), wInd));
            });
            var linesRisco = [];
            risList.forEach(function (s) {
              linesRisco = linesRisco.concat(doc.splitTextToSize(pdfTxt(s), wRisco));
            });
            var nLinhas = Math.max(linesProc.length, linesStatus.length, linesInd.length, linesRisco.length, 1);
            var hLinha = nLinhas * 10 + 8;
            precisa(hLinha + 4);

            if (idx % 2 === 1) {
              doc.setFillColor(248, 250, 252);
              doc.rect(margin, y - 9, maxW, hLinha, 'F');
            }

            setF('bold', 8, [25, 40, 65]);
            doc.text(linesProc, colProc + 2, y);
            setF('normal', 8, [50, 50, 50]);
            doc.text(linesStatus, colStatus + 2, y);
            doc.text(linesInd, colInd + 2, y);
            doc.text(linesRisco, colRisco + 2, y);
            y += hLinha;
          });
          y += 8;
        });

        // órfãos
        if (d.orfaos && d.orfaos.length) {
          y += 6;
          precisa(24);
          doc.setFillColor(236, 241, 247);
          doc.rect(margin, y - 11, maxW, 18, 'F');
          setF('bold', 11, [80, 80, 80]);
          doc.text(pdfTxt('Processos sem macroprocesso'), margin + 10, y + 1);
          y += 16;
          d.orfaos.forEach(function (p) {
            precisa(12);
            setF('normal', 9, [40, 40, 40]);
            doc.text(pdfTxt('- ' + p.nome), margin + 8, y);
            y += 12;
          });
        }

        // rodapé
        var nPag = doc.internal.getNumberOfPages();
        for (var i = 1; i <= nPag; i++) {
          doc.setPage(i);
          doc.setDrawColor(210, 210, 210);
          doc.setLineWidth(0.5);
          doc.line(margin, pageH - 22, pageW - margin, pageH - 22);
          setF('normal', 8, [140, 140, 140]);
          doc.text(pdfTxt('Valor-E — Relatório preliminar de processos'), margin, pageH - 12);
          doc.text(pdfTxt('Página ' + i + ' de ' + nPag), pageW - margin, pageH - 12, { align: 'right' });
        }
        doc.save('relatorio-preliminar-processos-' + new Date().toISOString().slice(0, 10) + '.pdf');
      } catch (e) {
        console.error(e);
        alert('Erro ao gerar o PDF: ' + (e.message || e));
      }
    },
    novo: function () {
      var nome = prompt('Nome do novo processo:'); if (nome === null) return;
      try { var id = E.processoSalvar({ nome: nome }); Nav.ir('#/folha?id=' + id); } catch (e) { alert(e.message); }
    },
    exportar: function (id) { var r = API.acao('exportar_xml', { id: id }); if (r.ok) Common.baixar(r.nome, r.texto, r.tipo); else alert(r.erro); },
    excluir: function (id) {
      var c = E.processoCarregar(id); if (!c) return;
      var nr = DB.one('SELECT COUNT(*) AS n FROM riscos WHERE processo_id = ?', [id]).n, modo = 'riscos';
      if (!confirm('Excluir o processo "' + c.nome + '" (Folha de dados e diagrama)?')) return;
      if (nr) modo = confirm(nr + ' risco(s) estão vinculados a este processo.\n\nOK = excluir também esses riscos.\nCancelar = manter os riscos (sem vínculo, com o ambiente preservado).') ? 'riscos' : 'manter';
      E.processoExcluir(id, modo);
      if (w.Ind && Ind.excluirVinculoProcesso) Ind.excluirVinculoProcesso(id);
      Nav.ir('#/processos');
    }
  };
  Modulos.registrar('/processos', { ativo: 'processos', titulo: 'Processos', html: html, apos: apos });
  Modulos.registrar('/processos-relatorio', { ativo: 'processos', titulo: 'Relatório preliminar de processos', html: htmlRelatorio });
})(window);
