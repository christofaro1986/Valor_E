/* diagrama.js — visualização/edição do diagrama BPMN gerado */
(function () {
  'use strict';
  var esc = Common.esc;
  Common.pagina('diagrama', function () {
    var ID = Common.id(), p = API.buscar(ID);
    if (!p) { Common.ir('#/processos'); return; }
    if (!p.bpmn_xml) { Common.ir('#/folha?id=' + ID); return; }
    var NOME = p.nome, XML = p.bpmn_xml, slug = NOME.replace(/[^A-Za-z0-9À-ÿ_-]+/g, '_');
    var ativ = JSON.parse(p.atividades_json || '[]') || [], op = JSON.parse(p.opcoes_json || '{}') || {};
    var hashOk = !p.bpmn_hash || String(p.bpmn_hash).indexOf('n1:') !== 0 || p.bpmn_hash === API.hash(ativ, op);
    var desat = p.bpmn_origem === 'gerado' && !hashOk, desatEdit = p.bpmn_origem === 'editado' && !hashOk;
    document.title = 'Diagrama — ' + NOME;
    document.getElementById('fraiz').innerHTML =
      '<div class="diag-wrap"><div class="ftopbar no-print">'
      + '<a class="marca" href="#/folha?id=' + ID + '"><i class="bi bi-arrow-left-circle"></i> Folha de dados</a>'
      + '<div class="titulo"><i class="bi bi-diagram-3"></i> ' + esc(NOME) + '</div><span class="status-salvo" id="st">Pronto</span>'
      + '<div class="btn-group btn-group-sm"><button class="btn btn-outline-light" id="bZi" title="Aumentar"><i class="bi bi-zoom-in"></i></button><button class="btn btn-outline-light" id="bZo" title="Diminuir"><i class="bi bi-zoom-out"></i></button><button class="btn btn-outline-light" id="bFit" title="Ajustar à tela"><i class="bi bi-arrows-fullscreen"></i></button></div>'
      + '<div class="btn-group btn-group-sm"><button class="btn btn-outline-light dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-box-arrow-up"></i> Exportar</button><ul class="dropdown-menu dropdown-menu-end">'
      + '<li><a class="dropdown-item" href="#" id="eBpmn">BPMN 2.0 (.bpmn)</a></li><li><a class="dropdown-item" href="#" id="eSvg">Imagem vetorial (.svg)</a></li><li><a class="dropdown-item" href="#" id="ePng">Imagem (.png)</a></li><li><a class="dropdown-item" href="#" id="ePdf">PDF</a></li></ul></div>'
      + '<button class="btn btn-outline-light btn-sm" id="bImp" title="Abre um arquivo BPMN 2.0 (.bpmn/.xml) gerado no bpmn.io ou em outra ferramenta"><i class="bi bi-box-arrow-in-down"></i> Importar .bpmn</button><input type="file" id="fImp" accept=".bpmn,.xml,application/xml,text/xml" hidden>'
      + '<button class="btn btn-outline-light btn-sm" id="bReg" title="Descarta alterações manuais e refaz a partir do item 7"><i class="bi bi-arrow-repeat"></i> Regenerar da folha</button>'
      + '<button class="btn btn-warning btn-sm fw-semibold" id="bSalvar"><i class="bi bi-save"></i> Salvar diagrama</button></div>'
      + ((desat || desatEdit) ? '<div class="aviso-bar no-print"><i class="bi bi-exclamation-triangle"></i> O item 7 da folha foi alterado depois que este diagrama foi gerado. ' + (desatEdit ? 'Este diagrama tem edições manuais — regenerar as descartará.' : '') + ' <a href="#" id="aReg">Regenerar agora</a></div>' : '')
      + '<div id="bpmn-canvas"></div></div>';

    var $ = function (s) { return document.querySelector(s); };
    var m = null, st = function (t) { $('#st').textContent = t; };
    function ajustar() { try { var c = m.get('canvas'); c.zoom('fit-viewport'); } catch (e) { console.warn(e); } }
    function zoomD(f) { var c = m.get('canvas'); c.zoom(c.zoom() * f); }

    // ---------------- bandeiras de risco ----------------
    function nomeElem(id) { var e = m && m._diagram && m._diagram.elements && m._diagram.elements[id]; return e ? (e.name || '') : ''; }
    function atualizarFlags() {
      var mapa = {}; E.flagsDoProcesso(ID).forEach(function (f) {
        var t = f.riscos.map(function (r) { return (r.codigo ? r.codigo + ' — ' : '') + r.nome; }).join('\n');
        if (m._diagram.elements[f.elemento]) mapa[f.elemento] = { n: f.riscos.length, titulo: (f.riscos.length ? f.riscos.length + ' risco(s):\n' + t : 'Sem riscos ainda') + '\n(clique para abrir)' };
      });
      m._diagram.setFlags(mapa);
    }
    function avisoOrfas(orf) {
      var b = $('#avOrf'); if (b) b.remove();
      if (!orf || !orf.length) return;
      var d = document.createElement('div'); d.id = 'avOrf'; d.className = 'aviso-bar no-print';
      d.innerHTML = '<i class="bi bi-flag"></i> ' + orf.length + ' bandeira(s) apontam para atividades que não existem neste diagrama. Os riscos continuam no módulo de riscos. <a href="#" id="aOrf">Remover essas bandeiras (mantendo os riscos)</a>';
      $('#bpmn-canvas').parentNode.insertBefore(d, $('#bpmn-canvas'));
      $('#aOrf').onclick = function (e) { e.preventDefault(); orf.forEach(function (f) { E.flagExcluir(f.id, 'manter'); }); d.remove(); atualizarFlags(); };
    }
    function modalRisco(elId) {
      var nome = nomeElem(elId), fid = E.flagDoElemento(ID, elId, nome); atualizarFlags();
      var F = E.flagCarregar(fid), edit = 0, M, box = document.createElement('div');
      box.className = 'modal fade'; box.tabIndex = -1;
      box.innerHTML = '<div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h6 class="modal-title"><i class="bi bi-flag-fill text-danger"></i> Riscos da atividade: <b id="mrNome"></b></h6><button class="btn-close" data-bs-dismiss="modal"></button></div>'
        + '<div class="modal-body"><div id="mrLista" class="mb-3"></div><div class="cartao mb-0"><h2 id="mrTit" style="font-size:13px"></h2><div class="corpo"><div class="row g-2">'
        + '<div class="col-md-2 campo"><label>Código</label><input class="form-control" id="mrCod" maxlength="20"></div>'
        + '<div class="col-md-6 campo"><label>Nome do risco *</label><input class="form-control" id="mrNomeR" maxlength="500" placeholder="Evento de risco"></div>'
        + '<div class="col-md-4 campo"><label>Categoria</label><select class="form-select" id="mrCat"></select></div></div>'
        + '<div class="text-danger small mt-2" id="mrErro"></div></div></div></div>'
        + '<div class="modal-footer"><button class="btn btn-outline-danger btn-sm me-auto" id="mrDelFlag"><i class="bi bi-trash"></i> Remover bandeira</button><button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Fechar</button><button class="btn btn-success btn-sm" id="mrSalvar"><i class="bi bi-plus-lg"></i> Salvar risco</button></div></div></div>';
      document.body.appendChild(box);
      var q = function (s) { return box.querySelector(s); };
      q('#mrNome').textContent = F.tarefa || nome || elId;
      q('#mrCat').innerHTML = '<option value="">— selecione —</option>' + E.CATEGORIAS.map(function (c) { return '<option>' + esc(c) + '</option>'; }).join('');
      function formNovo() { edit = 0; q('#mrTit').textContent = 'Novo risco nesta atividade'; q('#mrCod').value = E.proximoCodigoRisco(); q('#mrNomeR').value = ''; q('#mrCat').value = ''; q('#mrSalvar').innerHTML = '<i class="bi bi-plus-lg"></i> Salvar risco'; q('#mrErro').textContent = ''; }
      function lista() {
        var rs = E.flagsDoProcesso(ID).filter(function (f) { return f.id === fid; })[0].riscos;
        q('#mrLista').innerHTML = rs.length ? '<table class="tabela"><thead><tr><th>Código</th><th>Risco</th><th>Categoria</th><th>Nível</th><th></th></tr></thead><tbody>' + rs.map(function (r) {
          var nv = r.nivel_res || r.nivel_medio; return '<tr><td><b>' + esc(r.codigo || '') + '</b></td><td>' + esc(r.nome) + '</td><td>' + esc(r.categoria || '—') + '</td><td>' + (nv ? '<span class="nv ' + esc(nv.replace(/ /g, '-')) + '">' + esc(nv) + '</span>' : '<span class="nv nd">—</span>') + '</td>'
            + '<td class="text-end text-nowrap"><button class="btn btn-sm btn-outline-secondary" data-ed="' + r.id + '" title="Editar código, nome e categoria"><i class="bi bi-pencil"></i></button> <a class="btn btn-sm btn-outline-success" href="#/risco?id=' + r.id + '" data-bs-dismiss="modal" title="Abrir no módulo de riscos (causas, controles, planos)"><i class="bi bi-box-arrow-up-right"></i></a> <button class="btn btn-sm btn-outline-danger" data-ex="' + r.id + '" title="Excluir o risco"><i class="bi bi-trash"></i></button></td></tr>';
        }).join('') + '</tbody></table>' : '<div class="ajuda">Nenhum risco nesta atividade ainda. Preencha o formulário abaixo.</div>';
        Array.prototype.forEach.call(q('#mrLista').querySelectorAll('[data-ed]'), function (b) { b.onclick = function () {
          var id = +b.getAttribute('data-ed'), r = rs.filter(function (x) { return x.id === id; })[0]; edit = id; q('#mrTit').textContent = 'Editar risco ' + (r.codigo || ''); q('#mrCod').value = r.codigo || ''; q('#mrNomeR').value = r.nome; q('#mrCat').value = r.categoria || ''; q('#mrSalvar').innerHTML = '<i class="bi bi-check-lg"></i> Salvar alterações'; q('#mrNomeR').focus(); }; });
        Array.prototype.forEach.call(q('#mrLista').querySelectorAll('[data-ex]'), function (b) { b.onclick = function () { if (!confirm('Excluir este risco? Ele também será excluído do módulo de riscos (com causas, controles e planos).')) return; E.riscoExcluir(+b.getAttribute('data-ex')); formNovo(); lista(); atualizarFlags(); }; });
      }
      q('#mrSalvar').onclick = function () {
        try {
          var d = { codigo: q('#mrCod').value, nome: q('#mrNomeR').value, categoria: q('#mrCat').value };
          if (edit) E.riscoEditarBasico(edit, d); else E.flagRiscoAdicionar(fid, d);
          formNovo(); lista(); atualizarFlags(); q('#mrNomeR').focus();
        } catch (e) { q('#mrErro').textContent = e.message || String(e); }
      };
      q('#mrNomeR').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); q('#mrSalvar').click(); } });
      q('#mrDelFlag').onclick = function () {
        var n = E.flagsDoProcesso(ID).filter(function (f) { return f.id === fid; })[0].riscos.length;
        if (!confirm(n ? 'Remover a bandeira e os ' + n + ' risco(s) dela? Os riscos também serão excluídos do módulo de riscos.' : 'Remover a bandeira desta atividade?')) return;
        E.flagExcluir(fid, 'riscos'); M.hide();
      };
      M = new bootstrap.Modal(box); box.addEventListener('hidden.bs.modal', function () { M.dispose(); box.remove(); atualizarFlags(); });
      formNovo(); lista(); M.show(); box.addEventListener('shown.bs.modal', function () { q('#mrNomeR').focus(); });
    }
    function salvarD() {
      st('Salvando…');
      return Promise.all([m.saveXML({ format: true }), m.saveSVG()]).then(function (r) {
        var res = API.acao('salvar_bpmn', { id: ID, xml: r[0].xml, svg: r[1].svg });
        if (res.ok) { var orf = E.flagsSincronizar(ID); atualizarFlags(); st('Diagrama salvo ✓' + (orf.length ? ' — ' + orf.length + ' bandeira(s) sem atividade correspondente' : '')); avisoOrfas(orf); } else { st('Erro ao salvar'); alert(res.erro); }
      });
    }
    function regenerar() {
      if (!confirm('Regenerar o diagrama a partir do item 7? Edições manuais feitas no diagrama serão descartadas.')) return;
      var r = API.acao('gerar', { id: ID });
      if (r.ok) Common.recarregar(); else alert(r.erro);
    }
    // Converte o SVG do diagrama em canvas. Funciona nos navegadores embutidos (WKWebView/WebView2/WebKitGTK):
    // usa data URI (blob de SVG falha em alguns WebKit), fixa fontes e dimensões e tenta um segundo caminho se o primeiro falhar.
    function svgParaCanvas(svg, cb) {
      svg = String(svg).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
      var d = new DOMParser().parseFromString(svg, 'image/svg+xml'), raiz = d.documentElement;
      if (!raiz || d.getElementsByTagName('parsererror').length) { alert('Falha ao renderizar a imagem: o diagrama contém caracteres inválidos.'); return; }
      var vb = (raiz.getAttribute('viewBox') || '').split(/[\s,]+/).map(Number), lw = parseFloat(raiz.getAttribute('width')) || vb[2] || 1000, lh = parseFloat(raiz.getAttribute('height')) || vb[3] || 600;
      raiz.setAttribute('width', lw); raiz.setAttribute('height', lh);
      raiz.setAttribute('style', 'background:#fff;font-family:Helvetica,Arial,sans-serif');
      raiz.setAttribute('font-family', 'Helvetica, Arial, sans-serif');
      var txt = new XMLSerializer().serializeToString(raiz);
      var utf8 = unescape(encodeURIComponent(txt)), tentativas = [
        function () { return 'data:image/svg+xml;base64,' + btoa(utf8); },
        function () { return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(txt); },
        function () { return URL.createObjectURL(new Blob([txt], { type: 'image/svg+xml;charset=utf-8' })); }
      ];
      function tentar(i) {
        if (i >= tentativas.length) { alert('Falha ao renderizar a imagem. Use a exportação em SVG (.svg) ou BPMN.'); return; }
        var img = new Image(), u = tentativas[i]();
        img.onload = function () {
          try {
            var esc_ = Math.min(2, 4000 / lw), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(lw * esc_)); c.height = Math.max(1, Math.round(lh * esc_));
            var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
            c.toDataURL('image/png'); // falha (SecurityError) se o canvas ficou marcado
            if (u.indexOf('blob:') === 0) URL.revokeObjectURL(u);
            cb(c);
          } catch (e) { tentar(i + 1); }
        };
        img.onerror = function () { if (u.indexOf('blob:') === 0) URL.revokeObjectURL(u); tentar(i + 1); };
        img.src = u;
      }
      tentar(0);
    }
    function canvasBlob(c, cb) {
      if (c.toBlob) { try { c.toBlob(function (b) { if (b) cb(b); else cb(dataUrlBlob(c.toDataURL('image/png'))); }, 'image/png'); return; } catch (e) { } }
      cb(dataUrlBlob(c.toDataURL('image/png')));
    }
    function dataUrlBlob(u) { var p = u.split(','), bin = atob(p[1]), a = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: 'image/png' }); }
    $('#bZi').onclick = function () { zoomD(1.2); }; $('#bZo').onclick = function () { zoomD(1 / 1.2); }; $('#bFit').onclick = ajustar;
    $('#bImp').onclick = function () { $('#fImp').click(); };
    $('#fImp').onchange = function () {
      var f = this.files[0]; this.value = ''; if (!f) return;
      var r = new FileReader(); r.onload = function () {
        var txt = String(r.result);
        if (!/<(\w+:)?definitions\b/.test(txt)) { alert('O arquivo não parece ser um diagrama BPMN 2.0 (elemento definitions não encontrado).'); return; }
        Promise.resolve(m.importXML(txt)).then(function (res) { setTimeout(ajustar, 50); atualizarFlags(); var orf = E.flagsDoProcesso(ID).filter(function (f) { return !m._diagram.elements[f.elemento]; }); avisoOrfas(orf); var av = (res && res.warnings || []).length; st('Importado de ' + f.name + (av ? ' (' + av + ' aviso(s))' : '') + ' — clique em Salvar diagrama para gravar'); })
          .catch(function (e) { alert('Não foi possível importar o arquivo: ' + (e.message || e)); });
      }; r.readAsText(f);
    };
    $('#bSalvar').onclick = salvarD; $('#bReg').onclick = regenerar;
    if ($('#aReg')) $('#aReg').onclick = function (e) { e.preventDefault(); regenerar(); };
    $('#eBpmn').onclick = function (e) { e.preventDefault(); m.saveXML({ format: true }).then(function (x) { Common.baixar(slug + '.bpmn', x.xml, 'application/xml'); st('Exportado (.bpmn) ✓'); }); };
    $('#eSvg').onclick = function (e) { e.preventDefault(); m.saveSVG().then(function (s) { Common.baixar(slug + '.svg', s.svg, 'image/svg+xml'); st('Exportado (.svg) ✓'); }); };
    $('#ePng').onclick = function (e) { e.preventDefault(); m.saveSVG().then(function (s) { svgParaCanvas(s.svg, function (c) { canvasBlob(c, function (b) { Common.baixar(slug + '.png', b); st('Exportado (.png) ✓'); }); }); }); };
    $('#ePdf').onclick = function (e) {
      e.preventDefault();
      m.saveSVG().then(function (s) { svgParaCanvas(s.svg, function (c) {
        var d = new window.jspdf.jsPDF({ orientation: c.width > c.height ? 'landscape' : 'portrait', unit: 'px', format: [c.width, c.height], compress: true });
        d.addImage(c.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, c.width, c.height, undefined, 'FAST'); Common.baixar(slug + '.pdf', d.output('blob')); st('Exportado (PDF) ✓');
      }); });
    };
    document.addEventListener('keydown', function (e) { if (!document.getElementById('st')) return; if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') { e.preventDefault(); salvarD(); } });
    window.addEventListener('resize', function () { if (m && document.getElementById('bpmn-canvas')) ajustar(); });

    m = new BpmnJS({ container: '#bpmn-canvas' });
    window.__m = m;
    m.on('flag.drop', function (e) { modalRisco(e.elementId); });
    m.on('flag.click', function (e) { modalRisco(e.elementId); });
    m.on('flag.invalid', function () { st('Solte a bandeira sobre uma atividade, evento ou decisão do diagrama.'); });
    return Promise.resolve(m.importXML(XML)).then(function () { setTimeout(ajustar, 50); atualizarFlags(); avisoOrfas(E.flagsSincronizar(ID)); atualizarFlags(); st('Diagrama carregado ✓'); })
      .catch(function (e) { st('Erro ao carregar: ' + e.message); alert('Não foi possível abrir o diagrama: ' + e.message); });
  });
})();
