/* mapa.js — Mapa Estratégico (padrão BSC): perspectivas, temas e objetivos editados direto na imagem.
   Os objetivos são os mesmos "objetivos estratégicos" do módulo Valor Estratégico (vínculo nos dois sentidos). */
(function (w) {
  'use strict';
  var h = E.esc, Mdl = function () { return w.Mdl.apply(null, arguments); };
  var CORES = ['#0f6b8f', '#1b8a6b', '#0a6fc2', '#6d4bd8', '#b45309', '#be185d'];
  var PADRAO = ['Sociedade e clientes', 'Processos internos', 'Aprendizado e recursos'];

  DB.extras.push(function () {
    DB.db.run("CREATE TABLE IF NOT EXISTS me_mapas (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, missao TEXT DEFAULT '', visao TEXT DEFAULT '', criado_em TEXT DEFAULT CURRENT_TIMESTAMP)");
    DB.db.run("CREATE TABLE IF NOT EXISTS me_perspectivas (id INTEGER PRIMARY KEY AUTOINCREMENT, mapa_id INTEGER NOT NULL, nome TEXT NOT NULL, ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE TABLE IF NOT EXISTS me_temas (id INTEGER PRIMARY KEY AUTOINCREMENT, perspectiva_id INTEGER NOT NULL, nome TEXT NOT NULL, ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE TABLE IF NOT EXISTS me_objetivos (id INTEGER PRIMARY KEY AUTOINCREMENT, perspectiva_id INTEGER NOT NULL, tema_id INTEGER, oe_id INTEGER NOT NULL, ordem INTEGER DEFAULT 0)");
    DB.db.run("CREATE TABLE IF NOT EXISTS acoes_estrategicas (id INTEGER PRIMARY KEY AUTOINCREMENT, objetivo_id INTEGER NOT NULL, codigo TEXT DEFAULT '', nome TEXT NOT NULL, descricao TEXT DEFAULT '', ordem INTEGER DEFAULT 0, status TEXT DEFAULT 'ativo')");
    DB.db.run("CREATE INDEX IF NOT EXISTS idx_acoes_oe ON acoes_estrategicas(objetivo_id)");
  });

  // ---------- dados ----------
  function mapas() { return DB.all('SELECT * FROM me_mapas ORDER BY id'); }
  function mapaAtual(q) { var id = parseInt(q && q.mapa, 10); return (id && DB.one('SELECT * FROM me_mapas WHERE id = ?', [id])) || DB.one('SELECT * FROM me_mapas ORDER BY id LIMIT 1'); }
  function persps(mid) { return DB.all('SELECT * FROM me_perspectivas WHERE mapa_id = ? ORDER BY ordem, id', [mid]); }
  function temas(pid) { return DB.all('SELECT * FROM me_temas WHERE perspectiva_id = ? ORDER BY ordem, id', [pid]); }
  function objs(pid) {
    return DB.all('SELECT mo.id, mo.perspectiva_id, mo.tema_id, mo.oe_id, mo.ordem, o.codigo, o.nome, o.descricao FROM me_objetivos mo JOIN objetivos_estrategicos o ON o.id = mo.oe_id WHERE mo.perspectiva_id = ? ORDER BY mo.ordem, mo.id', [pid]);
  }
  function limpar() { DB.run('DELETE FROM me_objetivos WHERE oe_id NOT IN (SELECT id FROM objetivos_estrategicos)'); }
  function proxCodigo() { var n = DB.one('SELECT COUNT(*) AS n FROM objetivos_estrategicos').n + 1, c; do { c = 'OE-' + (n < 10 ? '0' : '') + n; n++; } while (DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(codigo) = ?', [c.toLowerCase()])); return c; }
  function nCaps(oe) { return DB.one('SELECT COUNT(*) AS n FROM objetivo_capacidades WHERE objetivo_id = ?', [oe]).n; }
  function acoesDoOe(oe) { try { return DB.all("SELECT * FROM acoes_estrategicas WHERE objetivo_id = ? AND COALESCE(status,'ativo') <> 'inativo' ORDER BY ordem, id", [oe]); } catch (e) { return []; } }
  function nAcoes(oe) { try { return DB.one('SELECT COUNT(*) AS n FROM acoes_estrategicas WHERE objetivo_id = ?', [oe]).n; } catch (e) { return 0; } }
  function reordenar(tab, filtroSql, args, ids) { ids.forEach(function (id, k) { DB.run('UPDATE ' + tab + ' SET ordem = ? WHERE id = ?', [k + 1, id]); }); }
  function v(d, s) { return d.querySelector(s).value; }
  function fecha(d) { var m = bootstrap.Modal.getInstance(d.closest ? d.closest('.modal') : d); if (m) m.hide(); }

  // ---------- imagem ----------
  function quebra(t, max) { return w.SvgUtil.quebra(t, max); }
  function tx(x, y, linhas, cor, size, anc, peso) {
    var o = '<text x="' + x + '" y="' + (y - (linhas.length - 1) * size * 0.6) + '" text-anchor="' + (anc || 'middle') + '" font-family="Arial,Helvetica,sans-serif" font-size="' + size + '" fill="' + cor + '" font-weight="' + (peso || 600) + '">';
    linhas.forEach(function (l, i) { o += '<tspan x="' + x + '" dy="' + (i ? size * 1.22 : 0) + '">' + h(l) + '</tspan>'; });
    return o + '</text>';
  }
  function ic(x, y, acao, dica, tipo) {
    var g = tipo === '+' ? '<path d="M-4 0H4M0-4V4" stroke="#0a6fc2" stroke-width="2" stroke-linecap="round"/>' :
      tipo === 't' ? '<rect x="-5" y="-5" width="10" height="10" rx="2" fill="none" stroke="#0a6fc2" stroke-width="1.3" stroke-dasharray="2 1.6"/><path d="M-2 0H2M0-2V2" stroke="#0a6fc2" stroke-width="1.4"/>' :
      '<path d="M-4.5 4.5L-4 1.5L2.5-5L5-2.5L-1.5 4Z" fill="none" stroke="#0a6fc2" stroke-width="1.4" stroke-linejoin="round"/>';
    return '<g class="ic" onclick="' + acao + '" transform="translate(' + x + ',' + y + ')"><title>' + h(dica) + '</title><circle r="10" fill="#fff" stroke="#0a6fc2" stroke-width="1.5"/>' + g + '</g>';
  }
  function barra(rotulo, texto, y, ed, acao, dica) {
    if (!texto && !ed) return { s: '', h: 0 };
    var linhas = quebra(rotulo + ' ' + (texto || '(clique no lápis para informar)'), 150).slice(0, 2), hh = 14 + linhas.length * 17;
    var o = '<rect x="30" y="' + y + '" width="1040" height="' + hh + '" rx="8" fill="#12304f"/><text x="550" y="' + (y + 20) + '" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="13" fill="#fff">';
    linhas.forEach(function (l, i) {
      var t = h(l);
      if (i === 0 && l.indexOf(rotulo) === 0) t = '<tspan font-weight="700" fill="#f9d56e">' + h(rotulo) + '</tspan>' + h(l.slice(rotulo.length));
      o += '<tspan x="550" dy="' + (i ? 17 : 0) + '">' + t + '</tspan>';
    });
    o += '</text>';
    if (ed) o += ic(1052, y + hh / 2, acao, dica);
    return { s: o, h: hh };
  }
  function svgMapa(m, ed) {
    var W = 1100, L = 30, y = 14, o = '', ps = persps(m.id);
    o += '<text x="550" y="' + (y + 18) + '" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="22" font-weight="700" fill="#12304f">' + h(m.nome) + '</text>';
    y += 36;
    var b = barra('Missão:', m.missao, y, ed, "Mapa.texto(" + m.id + ",'missao')", 'Editar a missão'); o += b.s; y += b.h + (b.h ? 8 : 0);
    b = barra('Visão:', m.visao, y, ed, "Mapa.texto(" + m.id + ",'visao')", 'Editar a visão'); o += b.s; y += b.h + (b.h ? 12 : 0);
    y += 6;
    ps.forEach(function (p, pi) {
      var cor = CORES[pi % CORES.length], ts = temas(p.id), os = objs(p.id);
      var grupos = ts.map(function (t) { return { t: t, os: os.filter(function (x) { return x.tema_id === t.id; }) }; });
      var soltos = os.filter(function (x) { return !x.tema_id || !ts.some(function (t) { return t.id === x.tema_id; }); });
      if (soltos.length || !grupos.length) grupos.push({ t: null, os: soltos });
      grupos.forEach(function (g) { g.cols = g.os.length >= 2 ? 2 : 1; g.rows = Math.max(1, Math.ceil(g.os.length / g.cols)); });
      var cx = L + 58, cw = W - L - 14 - cx, gap = 14, soma = grupos.reduce(function (a, g) { return a + g.cols; }, 0);
      var util = cw - gap * (grupos.length - 1), BH = 72, BG = 10;
      var gh = Math.max.apply(null, grupos.map(function (g) { return (g.t ? 34 : 6) + g.rows * (BH + BG) + 2; }));
      var ph = Math.max(gh + 40, 104), x0 = L, w0 = W - 2 * L;
      o += '<rect x="' + x0 + '" y="' + y + '" width="' + w0 + '" height="' + ph + '" rx="12" fill="#fbfcfe" stroke="#0a6fc2" stroke-width="1.5" stroke-dasharray="6 4"/>';
      var ln = quebra(p.nome, Math.max(8, Math.floor((ph - 16) / 8.4))).slice(0, 2);
      o += '<text transform="translate(' + (x0 + (ln.length > 1 ? 24 : 29)) + ',' + (y + ph / 2) + ') rotate(-90)" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="14" font-weight="700" fill="#12304f">' + ln.map(function (t, k) { return '<tspan x="0" dy="' + (k ? 17 : 0) + '">' + h(t) + '</tspan>'; }).join('') + '</text>';
      if (ed) {
        o += ic(x0 + w0 - 18, y + 16, 'Mapa.persp(' + m.id + ',' + p.id + ')', 'Editar, mover ou excluir a perspectiva "' + p.nome + '"');
        o += ic(x0 + w0 - 44, y + 16, 'Mapa.obj(' + m.id + ',' + p.id + ',0,0)', 'Novo objetivo em "' + p.nome + '"', '+');
        o += ic(x0 + w0 - 70, y + 16, 'Mapa.tema(' + m.id + ',' + p.id + ',0)', 'Novo tema (agrupador) em "' + p.nome + '"', 't');
      }
      var gx = cx;
      grupos.forEach(function (g) {
        var gw = util * g.cols / soma, gy = y + 30, bw = (gw - 16 - 10 * (g.cols - 1)) / g.cols;
        if (g.t) {
          o += '<rect x="' + gx + '" y="' + gy + '" width="' + gw + '" height="' + (ph - 40) + '" rx="9" fill="#fff" stroke="' + cor + '" stroke-width="1.3" stroke-dasharray="5 3"/>' + tx(gx + gw / 2, gy + 17, [g.t.nome], '#12304f', 12, 'middle', 700);
          if (ed) { o += ic(gx + gw - 14, gy + 13, 'Mapa.tema(' + m.id + ',' + p.id + ',' + g.t.id + ')', 'Editar o tema "' + g.t.nome + '"'); o += ic(gx + gw - 38, gy + 13, 'Mapa.obj(' + m.id + ',' + p.id + ',' + g.t.id + ',0)', 'Novo objetivo no tema "' + g.t.nome + '"', '+'); }
        }
        var top = gy + (g.t ? 30 : 4);
        if (!g.os.length && ed) o += tx(gx + gw / 2, top + 24, [g.t ? '(sem objetivos)' : '(sem objetivos — use +)'], '#8a96a3', 11, 'middle', 400);
        g.os.forEach(function (ob, k) {
          var col = k % g.cols, row = Math.floor(k / g.cols), bx = gx + 8 + col * (bw + 10), by = top + row * (BH + BG);
          var acs = acoesDoOe(ob.oe_id), na = acs.length;
          var nomeLinhas = quebra(ob.nome, Math.max(10, Math.floor((bw - 26) / 6.4))).slice(0, na ? 2 : 3);
          o += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + BH + '" rx="6" fill="' + cor + '"/>' +
            tx(bx + bw / 2, by + (na ? 18 : BH / 2 + 4), nomeLinhas, '#fff', 12);
          if (na) {
            var rotA = na === 1 ? ('Ação: ' + acs[0].nome) : (na + ' ações estratégicas');
            o += tx(bx + bw / 2, by + BH - 12, quebra(rotA, Math.max(12, Math.floor((bw - 20) / 5.6))).slice(0, 1), '#dcecff', 10);
          }
          if (ed) o += ic(bx + bw - 12, by + 12, 'Mapa.obj(' + m.id + ',' + p.id + ',' + (ob.tema_id || 0) + ',' + ob.id + ')', 'Editar ou excluir: ' + ob.nome);
        });
        gx += gw + gap;
      });
      y += ph;
      if (pi < ps.length - 1) { o += '<polygon points="550,' + (y + 4) + ' 574,' + (y + 22) + ' 560,' + (y + 22) + ' 560,' + (y + 30) + ' 540,' + (y + 30) + ' 540,' + (y + 22) + ' 526,' + (y + 22) + '" fill="#1d4f91"/>'; y += 34; }
    });
    if (ed) { y += 14; o += ic(550, y + 4, 'Mapa.persp(' + m.id + ',0)', 'Nova perspectiva', '+') + tx(570, y + 8, ['Nova perspectiva'], '#0a6fc2', 12, 'start', 600); y += 24; }
    var H = y + 12;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '"><rect width="' + W + '" height="' + H + '" fill="#ffffff"/>' + o + '</svg>';
  }

  // ---------- ações ----------
  function sel(id, opcoes, atual) { return '<select class="form-select" id="' + id + '">' + opcoes.map(function (o) { return '<option value="' + o[0] + '"' + (String(o[0]) === String(atual) ? ' selected' : '') + '>' + h(o[1]) + '</option>'; }).join('') + '</select>'; }
  function volta(mid) { Nav.ir('#/estrategia?mapa=' + mid); }
  function extra(dlg, html, ligacoes) {
    var bd = dlg.querySelector('.modal-body'), ex = document.createElement('div'); ex.className = 'd-flex flex-wrap gap-2 mt-3 pt-2 border-top'; ex.innerHTML = html; bd.appendChild(ex);
    Object.keys(ligacoes).forEach(function (s) { Array.prototype.forEach.call(ex.querySelectorAll(s), function (b) { b.onclick = function () { ligacoes[s](b); }; }); });
  }
  var Mapa = w.Mapa = {
    novo: function () {
      Mdl('Novo mapa estratégico', '<label class="form-label">Nome do mapa *</label><input class="form-control" id="mn" value="' + h('Mapa Estratégico ' + new Date().getFullYear()) + '"><div class="form-text">Serão criadas as perspectivas padrão, que você pode renomear, reordenar, incluir ou excluir.</div>', function (d) {
        var n = v(d, '#mn').trim(); if (!n) throw new Error('Informe o nome do mapa.');
        var id = DB.tx(function () { DB.run('INSERT INTO me_mapas (nome) VALUES (?)', [n]); var mid = DB.lastId(); PADRAO.forEach(function (p, i) { DB.run('INSERT INTO me_perspectivas (mapa_id,nome,ordem) VALUES (?,?,?)', [mid, p, i + 1]); }); return mid; });
        volta(id);
      }, 'Criar mapa');
    },
    dados: function (mid) {
      var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [mid]);
      var dlg = Mdl('Dados do mapa', '<label class="form-label">Nome do mapa *</label><input class="form-control" id="mn" value="' + h(m.nome) + '">', function (d) {
        var n = v(d, '#mn').trim(); if (!n) throw new Error('Informe o nome.'); DB.tx(function () { DB.run('UPDATE me_mapas SET nome = ? WHERE id = ?', [n, mid]); }); volta(mid);
      });
      extra(dlg, '<button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir este mapa</button>', { '[data-x]': function () {
        if (!confirm('Excluir o mapa "' + m.nome + '" com suas perspectivas e temas? Os objetivos estratégicos continuam no módulo Valor Estratégico.')) return;
        fecha(dlg); DB.tx(function () { persps(mid).forEach(function (p) { DB.run('DELETE FROM me_objetivos WHERE perspectiva_id = ?', [p.id]); DB.run('DELETE FROM me_temas WHERE perspectiva_id = ?', [p.id]); }); DB.run('DELETE FROM me_perspectivas WHERE mapa_id = ?', [mid]); DB.run('DELETE FROM me_mapas WHERE id = ?', [mid]); }); Nav.ir('#/estrategia');
      } });
    },
    texto: function (mid, campo) {
      var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [mid]), rot = campo === 'missao' ? 'Missão' : 'Visão';
      Mdl('Editar — ' + rot, '<label class="form-label">' + rot + '</label><textarea class="form-control" id="tx" rows="4">' + h(m[campo] || '') + '</textarea>', function (d) {
        DB.tx(function () { DB.run('UPDATE me_mapas SET ' + (campo === 'missao' ? 'missao' : 'visao') + ' = ? WHERE id = ?', [v(d, '#tx').trim(), mid]); }); volta(mid);
      });
    },
    persp: function (mid, id) {
      var p = id ? DB.one('SELECT * FROM me_perspectivas WHERE id = ?', [id]) : { nome: '' };
      var dlg = Mdl(id ? 'Editar perspectiva' : 'Nova perspectiva', '<label class="form-label">Nome da perspectiva *</label><input class="form-control" id="pn" value="' + h(p.nome) + '" placeholder="Ex.: Sociedade, Processos internos, Recursos…">', function (d) {
        var n = v(d, '#pn').trim(); if (!n) throw new Error('Informe o nome da perspectiva.');
        DB.tx(function () { if (id) DB.run('UPDATE me_perspectivas SET nome = ? WHERE id = ?', [n, id]); else DB.run('INSERT INTO me_perspectivas (mapa_id,nome,ordem) VALUES (?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM me_perspectivas WHERE mapa_id = ?))', [mid, n, mid]); });
        volta(mid);
      }, id ? 'Salvar' : 'Adicionar');
      if (!id) return;
      extra(dlg, '<button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-up"></i> Subir</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1"><i class="bi bi-arrow-down"></i> Descer</button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir</button>', {
        '[data-mv]': function (b) { var l = persps(mid), i = l.findIndex(function (x) { return x.id === id; }), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= l.length) return; fecha(dlg); DB.tx(function () { l.splice(j, 0, l.splice(i, 1)[0]); reordenar('me_perspectivas', '', [], l.map(function (x) { return x.id; })); }); volta(mid); },
        '[data-x]': function () {
          var n = DB.one('SELECT COUNT(*) AS n FROM me_objetivos WHERE perspectiva_id = ?', [id]).n;
          if (n) { alert('Esta perspectiva tem ' + n + ' objetivo(s). Mova ou exclua os objetivos antes de excluí-la.'); return; }
          if (!confirm('Excluir a perspectiva "' + p.nome + '"?')) return;
          fecha(dlg); DB.tx(function () { DB.run('DELETE FROM me_temas WHERE perspectiva_id = ?', [id]); DB.run('DELETE FROM me_perspectivas WHERE id = ?', [id]); }); volta(mid);
        } });
    },
    tema: function (mid, pid, id) {
      var t = id ? DB.one('SELECT * FROM me_temas WHERE id = ?', [id]) : { nome: '', perspectiva_id: pid };
      var dlg = Mdl(id ? 'Editar tema' : 'Novo tema', '<div class="mb-2"><label class="form-label">Nome do tema (agrupador) *</label><input class="form-control" id="tn" value="' + h(t.nome) + '" placeholder="Ex.: Gestão de pessoas, Eficiência operacional…"></div><div><label class="form-label">Perspectiva</label>' + sel('tp', persps(mid).map(function (p) { return [p.id, p.nome]; }), t.perspectiva_id) + '</div>', function (d) {
        var n = v(d, '#tn').trim(); if (!n) throw new Error('Informe o nome do tema.'); var np = +v(d, '#tp');
        DB.tx(function () {
          if (id) { DB.run('UPDATE me_temas SET nome = ?, perspectiva_id = ? WHERE id = ?', [n, np, id]); if (np !== t.perspectiva_id) DB.run('UPDATE me_objetivos SET perspectiva_id = ? WHERE tema_id = ?', [np, id]); }
          else DB.run('INSERT INTO me_temas (perspectiva_id,nome,ordem) VALUES (?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM me_temas WHERE perspectiva_id = ?))', [np, n, np]);
        }); volta(mid);
      }, id ? 'Salvar' : 'Adicionar');
      if (!id) return;
      extra(dlg, '<button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-left"></i> Mover</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1">Mover <i class="bi bi-arrow-right"></i></button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir tema</button>', {
        '[data-mv]': function (b) { var l = temas(t.perspectiva_id), i = l.findIndex(function (x) { return x.id === id; }), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= l.length) return; fecha(dlg); DB.tx(function () { l.splice(j, 0, l.splice(i, 1)[0]); reordenar('me_temas', '', [], l.map(function (x) { return x.id; })); }); volta(mid); },
        '[data-x]': function () { if (!confirm('Excluir o tema "' + t.nome + '"? Os objetivos dele permanecem na perspectiva, sem agrupador.')) return; fecha(dlg); DB.tx(function () { DB.run('UPDATE me_objetivos SET tema_id = NULL WHERE tema_id = ?', [id]); DB.run('DELETE FROM me_temas WHERE id = ?', [id]); }); volta(mid); } });
    },
    /** id = vínculo do mapa; oe = objetivo já existente no Valor (ainda fora do mapa). */
    obj: function (mid, pid, tid, id, oe) {
      var r = id ? DB.one('SELECT mo.*, o.codigo, o.nome, o.descricao FROM me_objetivos mo JOIN objetivos_estrategicos o ON o.id = mo.oe_id WHERE mo.id = ?', [id])
        : (oe ? (function () { var o = DB.one('SELECT * FROM objetivos_estrategicos WHERE id = ?', [oe]); return { perspectiva_id: pid, tema_id: tid || null, oe_id: oe, codigo: o.codigo, nome: o.nome, descricao: o.descricao || '' }; })()
          : { perspectiva_id: pid, tema_id: tid || null, oe_id: 0, codigo: proxCodigo(), nome: '', descricao: '' });
      var ps = persps(mid), pAtual = r.perspectiva_id || pid;
      function opTemas(p, atual) { return '<option value="">— sem tema —</option>' + temas(p).map(function (t) { return '<option value="' + t.id + '"' + (String(t.id) === String(atual) ? ' selected' : '') + '>' + h(t.nome) + '</option>'; }).join(''); }
      var acoesHtml = '';
      if (r.oe_id) {
        var listaA = acoesDoOe(r.oe_id);
        acoesHtml = '<div class="mt-3 pt-2 border-top" id="bloco-acoes"><div class="d-flex align-items-center mb-2"><strong class="me-auto"><i class="bi bi-lightning-charge"></i> Ações estratégicas</strong>' +
          '<button type="button" class="btn btn-sm btn-success" id="btnNovaAcao"><i class="bi bi-plus-lg"></i> Nova ação</button></div>' +
          '<p class="small text-muted mb-2">Desdobramento do objetivo. Projetos podem ser vinculados a uma ação específica.</p>';
        if (!listaA.length) acoesHtml += '<p class="small text-muted" id="acoesVazio">Nenhuma ação cadastrada ainda.</p><div id="listaAcoes"></div>';
        else {
          acoesHtml += '<div id="listaAcoes"><ul class="list-group list-group-flush mb-0">';
          listaA.forEach(function (a) {
            acoesHtml += '<li class="list-group-item px-0 d-flex align-items-start gap-2" data-acao-id="' + a.id + '">' +
              '<div class="me-auto"><b>' + h(a.codigo ? a.codigo + ' — ' : '') + h(a.nome) + '</b>' +
              (a.descricao ? '<div class="small text-muted">' + h(a.descricao) + '</div>' : '') + '</div>' +
              '<button type="button" class="btn btn-sm btn-outline-secondary btn-edit-acao" data-id="' + a.id + '"><i class="bi bi-pencil"></i></button>' +
              '<button type="button" class="btn btn-sm btn-outline-danger btn-del-acao" data-id="' + a.id + '"><i class="bi bi-trash"></i></button></li>';
          });
          acoesHtml += '</ul></div>';
        }
        acoesHtml += '</div>';
      } else {
        acoesHtml = '<div class="form-text mt-2">Após salvar o objetivo, abra-o novamente para cadastrar as <b>ações estratégicas</b> de desdobramento.</div>';
      }
      var dlg = Mdl(id ? 'Editar objetivo estratégico' : 'Novo objetivo estratégico',
        '<div class="mb-2"><label class="form-label">Objetivo estratégico *</label><textarea class="form-control" id="on" rows="2" placeholder="Ex.: Assegurar um atendimento ágil e confiável ao cidadão">' + h(r.nome) + '</textarea></div>' +
        '<div class="row g-2 mb-2"><div class="col-4"><label class="form-label">Código</label><input class="form-control" id="oc" maxlength="20" value="' + h(r.codigo) + '"></div><div class="col-8"><label class="form-label">Perspectiva</label>' + sel('op', ps.map(function (p) { return [p.id, p.nome]; }), pAtual) + '</div></div>' +
        '<div class="mb-2"><label class="form-label">Tema (agrupador, opcional)</label><select class="form-select" id="ot">' + opTemas(pAtual, r.tema_id) + '</select></div>' +
        '<div><label class="form-label">Descrição (opcional)</label><textarea class="form-control" id="od" rows="2">' + h(r.descricao || '') + '</textarea></div>' +
        '<div class="form-text mt-2">Este objetivo fica disponível, com o mesmo código, na lista de escolha do módulo <b>Valor Estratégico</b> (nova capacidade).</div>' + acoesHtml,
        function (d) {
          var nome = v(d, '#on').trim(), cod = v(d, '#oc').trim(), np = +v(d, '#op'), nt = v(d, '#ot') ? +v(d, '#ot') : null, desc = v(d, '#od').trim();
          if (!nome) throw new Error('Informe o objetivo estratégico.'); if (!cod) throw new Error('Informe o código.');
          if (DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(codigo) = ? AND id <> ?', [cod.toLowerCase(), r.oe_id || 0])) throw new Error('Já existe um objetivo com esse código.');
          DB.tx(function () {
            var oeId = r.oe_id;
            if (oeId) DB.run('UPDATE objetivos_estrategicos SET codigo=?, nome=?, descricao=? WHERE id=?', [cod, nome, desc, oeId]);
            else { DB.run("INSERT INTO objetivos_estrategicos (codigo,nome,descricao,status) VALUES (?,?,?,'ativo')", [cod, nome, desc]); oeId = DB.lastId(); }
            if (id) DB.run('UPDATE me_objetivos SET perspectiva_id=?, tema_id=? WHERE id=?', [np, nt, id]);
            else DB.run('INSERT INTO me_objetivos (perspectiva_id,tema_id,oe_id,ordem) VALUES (?,?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM me_objetivos WHERE perspectiva_id = ?))', [np, nt, oeId, np]);
          });
          volta(mid);
        }, id ? 'Salvar' : 'Adicionar');
      try { dlg.querySelector('.modal-dialog').classList.add('modal-lg'); } catch (e) {}
      dlg.querySelector('#op').addEventListener('change', function () { dlg.querySelector('#ot').innerHTML = opTemas(+this.value, ''); });
      if (r.oe_id) {
        function formAcao(acao) {
          acao = acao || { id: 0, codigo: '', nome: '', descricao: '' };
          Mdl(acao.id ? 'Editar ação estratégica' : 'Nova ação estratégica',
            '<div class="mb-2"><label class="form-label">Nome da ação *</label><input class="form-control" id="an" value="' + h(acao.nome || '') + '"></div>' +
            '<div class="mb-2"><label class="form-label">Código</label><input class="form-control" id="ac" maxlength="20" value="' + h(acao.codigo || '') + '"></div>' +
            '<div class="mb-2"><label class="form-label">Descrição</label><textarea class="form-control" id="ad" rows="2">' + h(acao.descricao || '') + '</textarea></div>',
            function (d2) {
              var nomeA = v(d2, '#an').trim(), codA = v(d2, '#ac').trim(), descA = v(d2, '#ad').trim();
              if (!nomeA) throw new Error('Informe o nome da ação.');
              DB.tx(function () {
                if (acao.id) DB.run('UPDATE acoes_estrategicas SET codigo=?, nome=?, descricao=? WHERE id=?', [codA, nomeA, descA, acao.id]);
                else DB.run('INSERT INTO acoes_estrategicas (objetivo_id,codigo,nome,descricao,ordem) VALUES (?,?,?,?, (SELECT COALESCE(MAX(ordem),0)+1 FROM acoes_estrategicas WHERE objetivo_id=?))', [r.oe_id, codA, nomeA, descA, r.oe_id]);
              });
              fecha(dlg); Mapa.obj(mid, pid, tid, id, oe);
            }, 'Salvar');
        }
        var btnNova = dlg.querySelector('#btnNovaAcao');
        if (btnNova) btnNova.onclick = function () { formAcao(null); };
        Array.prototype.forEach.call(dlg.querySelectorAll('.btn-edit-acao'), function (b) {
          b.onclick = function () {
            var a = DB.one('SELECT * FROM acoes_estrategicas WHERE id=?', [+b.getAttribute('data-id')]);
            if (a) formAcao(a);
          };
        });
        Array.prototype.forEach.call(dlg.querySelectorAll('.btn-del-acao'), function (b) {
          b.onclick = function () {
            if (!confirm('Excluir esta ação estratégica?')) return;
            DB.tx(function () { DB.run('DELETE FROM acoes_estrategicas WHERE id=?', [+b.getAttribute('data-id')]); });
            fecha(dlg); Mapa.obj(mid, pid, tid, id, oe);
          };
        });
      }
      if (!id) return;
      var n = nCaps(r.oe_id);
      extra(dlg, '<a class="btn btn-sm btn-outline-secondary" href="#/valor/objetivos" data-bs-dismiss="modal"><i class="bi bi-bullseye"></i> ' + n + ' capacidade(s) no Valor Estratégico</a><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-left"></i> Mover</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1">Mover <i class="bi bi-arrow-right"></i></button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-x><i class="bi bi-trash"></i> Excluir</button>', {
        '[data-mv]': function (b) {
          var l = objs(r.perspectiva_id).filter(function (x) { return (x.tema_id || null) === (r.tema_id || null); }), i = l.findIndex(function (x) { return x.id === id; }), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= l.length) return;
          fecha(dlg); DB.tx(function () { var all = objs(r.perspectiva_id), a = all.findIndex(function (x) { return x.id === l[i].id; }), c = all.findIndex(function (x) { return x.id === l[j].id; }); all.splice(c, 0, all.splice(a, 1)[0]); reordenar('me_objetivos', '', [], all.map(function (x) { return x.id; })); }); volta(mid);
        },
        '[data-x]': function () {
          if (n) { alert('Este objetivo tem ' + n + ' capacidade(s) no módulo Valor Estratégico. Reatribua ou exclua essas capacidades antes de excluí-lo.'); return; }
          if (!confirm('Excluir o objetivo estratégico "' + r.nome + '"? Ele também sai do módulo Valor Estratégico.')) return;
          fecha(dlg); DB.tx(function () {
            try { DB.run('DELETE FROM acoes_estrategicas WHERE objetivo_id = ?', [r.oe_id]); } catch (e) {}
            DB.run('DELETE FROM me_objetivos WHERE id = ?', [id]);
            DB.run('DELETE FROM objetivos_estrategicos WHERE id = ?', [r.oe_id]);
          }); volta(mid);
        } });
    },
    svg: function (id, fmt) {
      var m = DB.one('SELECT * FROM me_mapas WHERE id = ?', [id]), s = svgMapa(m, false), n = 'mapa-estrategico-' + String(m.nome).replace(/[^A-Za-z0-9_-]+/g, '_');
      if (fmt === 'png') w.SvgUtil.png(s, n + '.png'); else Mapris.baixar(n + '.svg', s, 'image/svg+xml');
    },
    imprimir: function () { document.body.classList.add('imp-cva'); window.print(); setTimeout(function () { document.body.classList.remove('imp-cva'); }, 500); },
    /** Lista de escolha do módulo Valor Estratégico: objetivos do mapa, agrupados por perspectiva. */
    objetivosParaEscolha: function () {
      var res = [];
      DB.all('SELECT p.nome AS pn, mm.nome AS mn, o.codigo, o.nome FROM me_objetivos mo JOIN me_perspectivas p ON p.id = mo.perspectiva_id JOIN me_mapas mm ON mm.id = p.mapa_id JOIN objetivos_estrategicos o ON o.id = mo.oe_id ORDER BY p.mapa_id, p.ordem, mo.ordem').forEach(function (x) { res.push({ grupo: (DB.one('SELECT COUNT(*) AS n FROM me_mapas').n > 1 ? x.mn + ' › ' : '') + x.pn, codigo: x.codigo, nome: x.nome }); });
      DB.all("SELECT codigo, nome FROM objetivos_estrategicos WHERE status = 'ativo' AND id NOT IN (SELECT oe_id FROM me_objetivos) ORDER BY codigo").forEach(function (x) { res.push({ grupo: 'Fora do mapa estratégico', codigo: x.codigo, nome: x.nome }); });
      return res;
    },
    resumo: function () { var m = mapaAtual({}); return m ? { nome: m.nome, objetivos: DB.one('SELECT COUNT(*) AS n FROM me_objetivos WHERE perspectiva_id IN (SELECT id FROM me_perspectivas WHERE mapa_id = ?)', [m.id]).n } : null; }
  };

  // ---------- tela ----------
  function html(q) {
    limpar();
    var m = mapaAtual(q), todos = mapas();
    if (!m) return '<div class="pagina"><h1 class="h4"><i class="bi bi-diagram-2"></i> Mapa Estratégico (BSC)</h1><div class="cartao"><div class="vazio">Nenhum mapa estratégico criado. O mapa organiza os <b>objetivos estratégicos</b> em perspectivas (padrão Balanced Scorecard) e alimenta a lista de objetivos do módulo Valor Estratégico.<br><br><button class="btn btn-success" onclick="Mapa.novo()"><i class="bi bi-plus-lg"></i> Criar mapa estratégico</button></div></div></div>';
    var o = '<div class="pagina cva-host"><div class="d-flex flex-wrap align-items-center mb-2"><h1 class="h4 mb-0 me-auto"><i class="bi bi-diagram-2"></i> Mapa Estratégico (BSC)</h1>' +
      '<select class="form-select form-select-sm" style="width:260px;margin-right:6px" onchange="Nav.ir(\'#/estrategia?mapa=\'+this.value)">' + todos.map(function (x) { return '<option value="' + x.id + '"' + (x.id === m.id ? ' selected' : '') + '>' + h(x.nome) + '</option>'; }).join('') + '</select>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="Mapa.dados(' + m.id + ')"><i class="bi bi-pencil"></i> Mapa</button><button class="btn btn-success btn-sm" onclick="Mapa.novo()"><i class="bi bi-plus-lg"></i> Novo mapa</button></div>';
    o += '<div class="cartao"><h2><span class="me-auto"><i class="bi bi-image"></i> Mapa estratégico — edite direto na imagem</span><span class="no-print"><button class="btn btn-sm btn-outline-secondary" onclick="Mapa.svg(' + m.id + ',\'png\')"><i class="bi bi-filetype-png"></i> PNG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Mapa.svg(' + m.id + ',\'svg\')"><i class="bi bi-filetype-svg"></i> SVG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Mapa.imprimir()"><i class="bi bi-printer"></i> Imprimir</button></span></h2><div class="corpo cva-img"><div class="ajuda no-print" style="margin-bottom:6px">Use <b>+</b> para incluir objetivos, o ícone tracejado para criar um <b>tema</b> (agrupador) e o <b>lápis</b> para renomear, mover ou excluir perspectivas, temas, objetivos, missão e visão. Os ícones não saem na imagem exportada.</div>' + svgMapa(m, true) + '</div></div>';
    var fora = DB.all("SELECT * FROM objetivos_estrategicos WHERE status = 'ativo' AND id NOT IN (SELECT oe_id FROM me_objetivos) ORDER BY codigo"), ps = persps(m.id);
    if (fora.length && ps.length) o += '<div class="cartao"><h2><i class="bi bi-bullseye"></i> Objetivos do Valor Estratégico ainda fora do mapa</h2><div class="corpo">' + fora.map(function (x) { return '<div class="cva-item"><div class="me-auto"><b>' + h(x.codigo) + '</b> — ' + h(x.nome) + '</div><button class="btn btn-sm btn-outline-success" onclick="Mapa.obj(' + m.id + ',' + ps[0].id + ',0,0,' + x.id + ')"><i class="bi bi-plus-lg"></i> Incluir no mapa</button></div>'; }).join('') + '</div></div>';
    return o + '</div>';
  }
  Modulos.registrar('/estrategia', { ativo: 'mapa', titulo: 'Mapa Estratégico', html: html });
})(window);
