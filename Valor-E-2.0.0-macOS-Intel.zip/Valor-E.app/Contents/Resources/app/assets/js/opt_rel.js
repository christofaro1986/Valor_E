(function (DB) {
/* relatorio.js — OPTIMUS: relatório único (resultado + painéis + diagnóstico + plano de ação)
   Organização: objetivo estratégico → capacidades → dimensões → indicadores. Tela e PDF (ABNT) usam o mesmo modelo. */
(function (w) {
  'use strict';
  var RPT = w.RPT = {};
  var U = function () { return w.UI._u; };
  function h(s) { return U().h(s); }
  function labelObj(o) {
    if (!o) return '';
    var nome = o.nome || '', cod = o.codigo || '';
    if (!nome || nome.toLowerCase() === cod.toLowerCase()) return cod;
    return cod + ' — ' + nome;
  }
  function nz(v, c) { return v == null || isNaN(v) ? '—' : (+v).toFixed(c == null ? 2 : c).replace('.', ','); }
  function pc(v, c) { return v == null || isNaN(v) ? '—' : (v * 100).toFixed(c == null ? 1 : c).replace('.', ',') + '%'; }
  function fdata(iso) { return w.MET.fmtData(iso); }
  var SITUACOES = ['planejada', 'em execução', 'concluída', 'cancelada'];

  /* ================= MODELO ================= */
  function pior(a) { return a == null ? 'não avaliado' : w.MET.ROTULO[w.MET.classe(a)].toLowerCase(); }
  function textoIndicador(I) {
    var t = [], M = w.MET;
    if (I.pct == null) t.push('O indicador não pôde ser avaliado: ' + (I.meta == null ? 'não há ciclo de meta definido' : 'não há registro de valor válido') + '.');
    else {
      t.push('O último valor apurado é ' + nz(I.valor, 2) + (I.unidade ? ' ' + I.unidade : '') + (I.mes ? ' (' + M.fmtMes(I.mes) + ')' : '') + ', para meta de ' + nz(I.meta, 2) + ', o que corresponde a ' + pc(I.pct, 0) + ' da meta. Situação: ' + M.ROTULO[I.status].toLowerCase() + '; grau de risco: ' + M.RISCO[I.status].toLowerCase() + '.');
      if (I.desvio != null) t.push(I.desvio > 0 ? 'O desvio (distância) da meta é de ' + nz(I.desvio, 2) + '.' : 'A meta foi alcançada ou superada.');
      if (I.d != null) t.push('Déficit ponderado de ' + nz(I.d, 3) + (I.abc ? ' (classe ' + I.abc + ' da curva ABC' + (I.part != null ? ', ' + pc(I.part, 0) + ' do déficit da capacidade' : '') + ')' : '') + '.');
    }
    if (I.essencial && I.status === 'critico') t.push('Atenção: a dimensão é essencial e está comprometida; exige prioridade independentemente da participação no déficit.');
    if (I.disp) t.push('Análise de dispersão (exploratória, ' + I.disp.n + ' registros): média ' + nz(I.disp.media, 2) + ', desvio-padrão ' + nz(I.disp.desvio, 2) + ' e distância desfavorável à meta de ' + nz(I.disp.z, 2) + ' desvios-padrão.');
    if (!I.plano && I.status !== 'ok' && I.status !== 'sem-dados') t.push('Não há plano de ação registrado para este indicador.');
    return t.join(' ');
  }
  function textoCapacidade(C) {
    var t = [], M = w.MET;
    if (C.ihc == null) return 'A capacidade não foi avaliada: não há indicador ativo com registro e meta válidos.';
    t.push('O IHC é de ' + pc(C.ihc) + ' (' + M.ROTULO[C.status].toLowerCase() + '; risco ' + M.RISCO[C.status].toLowerCase() + '), com cobertura de ' + pc(C.cobertura, 0) + (C.parcial ? ' (resultado parcial: dimensões sem dados foram desconsideradas)' : '') + '.');
    var A = C.itensABC.filter(function (i) { return i.classe_abc === 'A' && i.d > 0.0001; });
    t.push(A.length ? 'Indicadores prioritários (classe A da curva ABC): ' + A.map(function (i) { return i.codigo; }).join(', ') + '.' : 'Não há déficit relevante entre os indicadores avaliados.');
    if (C.semDados.length) t.push('Sem dados válidos: ' + C.semDados.join(', ') + '.');
    if (C.essenciaisCrit.length) t.push('Alerta: dimensão essencial comprometida — ' + C.essenciaisCrit.join('; ') + '.');
    return t.join(' ');
  }
  function textoObjetivo(O) {
    var M = w.MET;
    if (O.icv == null) return 'Nenhuma capacidade vinculada possui IHC apurado; o objetivo não pôde ser avaliado.';
    var cic = O.ciclo ? ' no ciclo estratégico ' + O.ciclo.nome + ', com meta de ' + pc(O.meta, 0) + (O.metaDefinida ? '' : ' (meta padrão, não definida no ciclo)') : ', com meta de 100% (nenhum ciclo estratégico definido)';
    return 'O ICV é de ' + pc(O.icv) + cic + ', correspondendo a situação \u201c' + M.ROTULO[O.status].toLowerCase() + '\u201d pela Curva ABC. O desvio em relação à meta é de ' + pc(O.desvio) + ' (' + (O.sigma ? M.SIGMA_ROT[O.sigma].toLowerCase() + ': ' + M.SIGMA_TXT[O.sigma].charAt(0).toLowerCase() + M.SIGMA_TXT[O.sigma].slice(1).replace(/\.$/, '') : 'sem classificação') + '), com cobertura de ' + pc(O.cobertura, 0) + (O.parcial ? ' (resultado parcial)' : '') + (O.pesoDefinido ? '' : '; os pesos das capacidades ainda não foram calculados por AHP e foram considerados iguais') + '. O ICV não representa valor financeiro nem relação causal; a efetividade estratégica deve ser verificada por evidências próprias.';
  }

  RPT.montar = function (oeId) {
    var MET = w.MET;
    var org = DB.one('SELECT nome FROM organizacoes ORDER BY id LIMIT 1') || {};
    var objs = DB.rows("SELECT * FROM objetivos_estrategicos WHERE status='ativo' AND id IN (SELECT objetivo_id FROM objetivo_capacidades)" + (oeId ? ' AND id=' + (+oeId) : '') + ' ORDER BY codigo');
    var M = { org: org.nome || '', gerado: new Date(), objetivos: [], lim: { semMeta: 0, semDados: 0, parciais: 0, capsNaoAval: 0, inds: 0 } };
    objs.forEach(function (oe) {
      var res = MET.icvObjetivo(oe.id);
      var O = { oe: oe, icv: res.icv, status: res.status, risco: res.risco, ciclo: res.ciclo, meta: res.meta, metaDefinida: res.metaDefinida, desvio: res.desvio, sigma: res.sigma, cobertura: res.cobertura, parcial: res.parcial, pesoDefinido: res.pesoDefinido, caps: [], defEstr: { itens: res.caps.filter(function (x) { return x.ihc != null && x.d > 0.0001; }).sort(function (a, b) { return b.d - a.d; }).map(function (x) { return { codigo: x.c.codigo, nome: x.c.nome, d: x.d, classe_abc: x.abc }; }) } };
      res.caps.forEach(function (x) {
        var r = x.res, mapa = {}; r.itens.forEach(function (it) { mapa[it.id] = it; });
        var C = { cap: x.c, wc: x.wc, wcEf: x.wcN != null ? x.wcN : null, ihc: r.ihc, status: r.status, cobertura: r.cobertura, parcial: r.parcial, itensABC: r.itens, fatores: [], semDados: [], essenciaisCrit: r.essenciaisCrit.slice() };
        r.dims.forEach(function (d) {
          var F = { id: d.f.id, codigo: d.f.codigo, nome: d.f.nome, essencial: !!d.f.essencial, status: d.status, inds: [] };
          d.ativos.forEach(function (e) {
            var it = mapa[e.id], ind = e.ind;
            var I = { row: ind, id: e.id, codigo: ind.codigo, nome: ind.nome, tipo: e.tipo, unidade: ind.unidade, polaridade: e.polaridade, a: e.a, pct: e.pct, valor: e.valor, meta: e.meta, mes: e.mes, status: e.status, risco: e.risco, desvio: e.desvio, serie: e.serie, itens: e.tipo === 'multiplo' ? e.itens : [], ciclos: e.ciclos,
              grh: it ? it.grh : null, d: it ? it.d : null, abc: it ? it.classe_abc : null, part: it ? it.participacao : null, essencial: !!d.f.essencial, plano: w.SisrelHtml.texto(ind.plano_html), analise: w.SisrelHtml.texto(ind.analise_html), planoHtml: ind.plano_html, analiseHtml: ind.analise_html };
            I.disp = e.tipo === 'multiplo' ? null : MET.dispersao(e);
            I.texto = textoIndicador(I);
            M.lim.inds++; if (e.meta == null) M.lim.semMeta++; if (e.pct == null) { M.lim.semDados++; C.semDados.push(ind.codigo); }
            F.inds.push(I);
          });
          if (F.inds.length) C.fatores.push(F);
        });
        if (C.ihc == null) M.lim.capsNaoAval++;
        C.texto = textoCapacidade(C);
        O.caps.push(C);
      });
      O.texto = textoObjetivo(O);
      M.objetivos.push(O);
    });
    M.validacao = MET.validar();
    M.ahp = DB.rows('SELECT * FROM ahp_registros ORDER BY id DESC LIMIT 40');
    M.historico = DB.rows('SELECT * FROM historico ORDER BY id DESC LIMIT 40');
    return M;
  };

  /* ================= GRÁFICOS ================= */
  RPT.dadosInd = function (I) {
    var ser = I.serie || [];
    return {
      labels: ser.map(function (s) { return w.MET.fmtMes(s.mes); }),
      valores: ser.map(function (s) { return s.valor; }),
      metas: ser.map(function (s) { return s.meta; }),
      titulo: I.nome + (I.unidade ? ' (' + I.unidade + ')' : ''),
      labelValor: I.tipo === 'multiplo' ? 'Valor composto' : 'Valor apurado'
    };
  };
  RPT._pend = [];
  function desenharTela() {
    var P = RPT._pend; RPT._pend = [];
    try { if (w.OPTCharts && w.OPTCharts.destroyAll) w.OPTCharts.destroyAll(); } catch (e) {}
    function um(p) {
      try {
        var cv = document.getElementById(p.id); if (!cv) return;
        var box = cv.parentNode;
        if (box && (!box.style.height || box.clientHeight < 40)) {
          box.style.minHeight = (p.tipo === 'ind' ? '240px' : '200px');
          box.style.position = box.style.position || 'relative';
        }
        if (p.tipo === 'ind') {
          var d = p.dados || {};
          if (!d.valores || !d.valores.length) { box.innerHTML = '<p class="vazio" style="padding:40px 0">Sem registros de valor.</p>'; return; }
          w.OPTCharts.evolucao(p.id, d.labels || [], d.valores, d.metas || [], { titulo: d.titulo, labelValor: d.labelValor, labelMeta: 'Meta' });
        } else {
          w.OPTCharts.barras(p.id, p.labels || [], p.valores || [], { titulo: p.titulo, label: p.label });
        }
      } catch (err) {
        try { var el = document.getElementById(p.id); if (el && el.parentNode) el.parentNode.innerHTML = '<p class="muted" style="padding:20px 0">Não foi possível desenhar este gráfico.</p>'; } catch (e2) {}
      }
    }
    var i = 0;
    function lote() {
      var fim = Math.min(i + 8, P.length);
      for (; i < fim; i++) um(P[i]);
      if (i < P.length) setTimeout(lote, 0);
    }
    lote();
  }
  function stTxt(I) { return w.MET.ROTULO[I.status]; }

  /* ================= TELA ================= */
  RPT.tela = function (q) {
    var u = U(), MET = w.MET;
    var objs = DB.rows("SELECT * FROM objetivos_estrategicos WHERE status='ativo' AND id IN (SELECT objetivo_id FROM objetivo_capacidades) ORDER BY codigo");
    var oeId = q && q.oe ? parseInt(q.oe, 10) : 0;
    var sel = '<option value="0">Todos os objetivos</option>' + objs.map(function (o) { return '<option value="' + o.id + '"' + (o.id === oeId ? ' selected' : '') + '>' + h(labelObj(o)) + '</option>'; }).join('');
    var html = '<div class="card"><div class="toolbar"><a class="btn btn-outline btn-sm" href="#/valor">← Dashboard</a><h2 style="margin:0 0 0 6px">Relatório de desempenho</h2><div class="sp"></div><button class="btn" onclick="RPT.exportarPdf()">Exportar PDF</button></div>' +
      (u.cadeiaValor ? u.cadeiaValor() : '') + u.ajuda('Relatório único, organizado por <b>objetivo estratégico → capacidades → dimensões → indicadores</b>, com situação, grau de risco, análise crítica e plano de ação de cada indicador. O PDF segue as normas ABNT.') +
      '<div class="campo" style="max-width:520px"><label>Objetivo estratégico</label><select id="rel_oe" onchange="location.hash=\'#/valor/relatorio?oe=\'+this.value">' + sel + '</select></div></div>';
    if (!objs.length) return html + '<div class="card"><p class="vazio">Nenhum objetivo estratégico possui capacidades vinculadas. Cadastre capacidades em Valor Estratégico; só objetivos com capacidades entram no relatório.</p></div>';
    var M = RPT.montar(oeId);
    RPT._pend = [];
    html += '<div class="card"><p class="muted" style="margin:0">Apuração em ' + M.gerado.toLocaleDateString('pt-BR') + ' · critérios de cálculo da metodologia (conformidade ≥ ' + Math.round(MET.LIM.conf * 100) + '% da meta; atenção ≥ ' + Math.round(MET.LIM.aten * 100) + '%)</p>' +
      (M.lim.semMeta || M.lim.semDados || M.lim.capsNaoAval ? '<p class="muted" style="margin:6px 0 0"><b>Limitações dos dados:</b> ' + M.lim.semMeta + ' indicador(es) sem meta; ' + M.lim.semDados + ' sem registro válido; ' + M.lim.capsNaoAval + ' capacidade(s) não avaliada(s).</p>' : '') + '</div>';
    var n = 0, chartSeq = 0;
    function nextCid(p) { return p + (chartSeq++); }
    M.objetivos.forEach(function (O) {
      var k = n++, oid = nextCid('g_oe');
      html += '<div class="rel-oe"><h2>' + h(labelObj(O.oe)) + '</h2>' + (O.oe.descricao ? '<p class="muted">' + h(O.oe.descricao) + '</p>' : '') +
        '<div class="kpi-grid">' + u.kpi('ICV', pc(O.icv), 'Σ Wc × IHC' + (O.parcial ? ' · parcial' : ''), O.icv == null ? '' : ({ ok: 'ok', atencao: 'warn', critico: 'err' }[O.status])) +
        u.kpi('Situação', u.chip(O.status), '') + u.kpi('Desvio Six Sigma', h(O.sigma ? MET.SIGMA_ROT[O.sigma] : '—'), O.desvio == null ? '' : pc(O.desvio) + ' da meta') + u.kpi('Capacidades', String(O.caps.length), '') + '</div><div class="rel-diag">' + h(O.texto) + '</div>';
      if (O.caps.length) {
        html += '<div class="chart-box" style="height:220px"><canvas id="' + oid + '"></canvas></div>';
        RPT._pend.push({ tipo: 'bar', id: oid, labels: O.caps.map(function (c) { return c.cap.codigo; }), valores: O.caps.map(function (c) { return c.ihc; }), titulo: 'IHC (%) por capacidade', label: 'IHC' });
        html += '<table class="tabela-compacta rel-tab"><thead><tr><th class="col-item">Capacidade</th><th class="num">Peso</th><th class="num">Peso efetivo</th><th class="num">IHC</th><th class="col-st">Situação</th><th class="col-st">Risco</th></tr></thead><tbody>' +
          O.caps.map(function (c) { var s = c.status; return '<tr><td>' + h(c.cap.codigo + ' — ' + c.cap.nome) + '</td><td class="num">' + pc(c.wc, 0) + '</td><td class="num">' + (c.wcEf == null ? '—' : pc(c.wcEf, 0)) + '</td><td class="num">' + pc(c.ihc) + '</td><td class="txt-' + s + '">' + (c.ihc == null ? 'não avaliada' : h(MET.ROTULO_F[s])) + '</td><td class="txt-' + s + '">' + h(MET.RISCO[s]) + '</td></tr>'; }).join('') + '</tbody></table>';
        if (O.defEstr.itens.length) html += '<h4 style="margin:12px 0 4px">Curva ABC das capacidades (déficit Wc × (1 − IHC))</h4><table class="tabela-compacta rel-tab"><thead><tr><th class="col-item">Capacidade</th><th class="num">Déficit</th><th>ABC</th></tr></thead><tbody>' +
          O.defEstr.itens.map(function (i) { return '<tr><td>' + h(i.codigo + ' — ' + i.nome) + '</td><td class="num">' + nz(i.d, 3) + '</td><td>' + u.badgeAbc(i.classe_abc) + '</td></tr>'; }).join('') + '</tbody></table>';
      }
      O.caps.forEach(function (C, ci) {
        var cid = nextCid('g_cap');
        html += '<div class="rel-cap"><h3 style="margin:0 0 4px"><a href="#/valor/capacidade?id=' + C.cap.id + '">' + h(C.cap.codigo + ' — ' + C.cap.nome) + '</a> <span class="muted" style="font-weight:400">· IHC ' + pc(C.ihc) + ' · ' + h(MET.ROTULO_F[C.status]) + ' · risco ' + h(MET.RISCO[C.status].toLowerCase()) + '</span></h3><div class="rel-diag">' + h(C.texto) + '</div>';
        var inds = []; C.fatores.forEach(function (f) { f.inds.forEach(function (i) { inds.push(i); }); });
        if (inds.length) { html += '<div class="chart-box" style="height:200px"><canvas id="' + cid + '"></canvas></div>'; RPT._pend.push({ tipo: 'bar', id: cid, labels: inds.map(function (i) { return i.codigo; }), valores: inds.map(function (i) { return i.a; }), titulo: '% da meta dos indicadores', label: '% da meta' }); }
        C.fatores.forEach(function (F) {
          html += '<div class="rel-fat"><h4 style="margin:8px 0 2px">Dimensão ' + h(F.codigo + ' — ' + F.nome) + (F.essencial ? ' <span class="badge badge-warn">essencial</span>' : '') + '</h4>' +
            '<table class="tabela-compacta rel-tab"><thead><tr><th class="col-item">Indicador</th><th class="num">Valor</th><th class="num">Meta</th><th class="num col-n">% meta</th><th class="num col-n">Desvio</th><th class="col-st">Situação</th><th class="col-st">Risco</th></tr></thead><tbody>' +
            F.inds.map(function (I) { return '<tr><td><a href="#/indicador?id=' + I.id + '">' + h(I.nome) + '</a></td><td class="num">' + (I.tipo === 'multiplo' ? 'composto' : nz(I.valor)) + '</td><td class="num">' + nz(I.meta) + '</td><td class="num">' + pc(I.pct, 0) + '</td><td class="num">' + (I.desvio == null ? '—' : nz(I.desvio)) + '</td><td class="txt-' + I.status + '">' + h(stTxt(I)) + '</td><td class="txt-' + I.status + '">' + h(MET.RISCO[I.status]) + '</td></tr>'; }).join('') + '</tbody></table>';
          F.inds.forEach(function (I) {
            var iid = nextCid('g_ind');
            html += '<div class="rel-ind"><h5>' + h(I.nome) + ' ' + (I.abc ? u.badgeAbc(I.abc) : '') + '</h5><div class="rel-chart"><canvas id="' + iid + '"></canvas></div><div class="rel-diag">' + h(I.texto) + '</div>' +
              (I.analiseHtml ? '<h6>Análise crítica</h6><div class="sr-rich">' + w.SisrelHtml.seguro(I.analiseHtml) + '</div>' : '') + (I.planoHtml ? '<h6>Plano de ação</h6><div class="sr-rich">' + w.SisrelHtml.seguro(I.planoHtml) + '</div>' : '') + '</div>';
            RPT._pend.push({ tipo: 'ind', id: iid, dados: RPT.dadosInd(I) });
          });
          html += '</div>';
        });
        html += '</div>';
      });
      html += '</div>';
    });
    setTimeout(desenharTela, 150);
    return html;
  };

  /* ================= PDF (ABNT) ================= */
  var PW = 595.28, PH = 841.89, ML = 85.04, MT = 85.04, MR = 56.69, MB = 56.69, TW = PW - ML - MR, BOTTOM = PH - MB;
  var FS = 12, LH = 20.7, SFS = 10, SLH = 12;
  function tx(s) {
    return String(s == null ? '' : s).replace(/→/g, '->').replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/[✔✓]/g, 'OK').replace(/[✖✗]/g, 'X')
      .replace(/ /g, ' ').replace(/Σ/g, 'soma').replace(/σ/g, 'desvio').replace(/μ/g, 'media').replace(/−/g, '-').replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/[^\x09\x0a\x0d\x20-\x7e¡-ÿ–—•…]/g, '');
  }
  function imgChart(fn, wpx, hpx) {
    var box = document.createElement('div');
    box.style.cssText = 'position:fixed;left:-20000px;top:0;width:' + wpx + 'px;height:' + hpx + 'px;background:#fff';
    var cv = document.createElement('canvas'); cv.id = 'pdfcv'; box.appendChild(cv); document.body.appendChild(box);
    var url = null;
    try { var ch = fn('pdfcv'); if (ch) { ch.options.animation = false; ch.resize(wpx, hpx); ch.update('none'); url = cv.toDataURL('image/png'); } } catch (e) { url = null; }
    try { w.OPTCharts.destroy('pdfcv'); } catch (e) {}
    box.remove(); return url;
  }

  function Doc(M, tocPages, tocEntries) {
    var jsPDF = w.jspdf.jsPDF;
    var doc = new jsPDF({ unit: 'pt', format: 'a4', compress: true });
    var S = { doc: doc, y: MT, page: 1, heads: [], cnt: [0, 0, 0, 0, 0], tab: 0, fig: 0 };
    doc.setFont('times', 'normal'); doc.setFontSize(FS);
    function numero() { if (S.page > 1) { doc.setFont('times', 'normal'); doc.setFontSize(SFS); doc.text(String(S.page), PW - MR, 56.69 + 8, { align: 'right' }); doc.setFontSize(FS); } }
    S.nova = function () { doc.addPage(); S.page++; S.y = MT; numero(); };
    S.ensure = function (hh) { if (S.y + hh > BOTTOM) S.nova(); };
    S.fonte = function (st, size) { doc.setFont('times', st || 'normal'); doc.setFontSize(size || FS); };
    S.linhas = function (t, wd, size, st) { S.fonte(st, size); return doc.splitTextToSize(tx(t), wd); };

    S.para = function (t, o) {
      o = o || {}; var ind = o.ind === false ? 0 : 35.4, st = o.st || 'normal', size = o.size || FS, lh = o.lh || LH;
      var lines = S.linhas(t, TW, size, st);
      // 1ª linha recuada: refaz o quebra considerando o recuo
      if (ind) { S.fonte(st, size); var first = doc.splitTextToSize(tx(t), TW - ind)[0] || ''; var rest = tx(t).slice(first.length).replace(/^\s+/, ''); lines = [first].concat(rest ? doc.splitTextToSize(rest, TW) : []); }
      if (lines.length <= 4) S.ensure(lines.length * lh); else S.ensure(2 * lh);
      lines.forEach(function (ln, i) {
        S.ensure(lh); S.fonte(st, size);
        var x = ML + (i === 0 ? ind : 0), wd = TW - (i === 0 ? ind : 0), base = S.y + size + (lh - size) / 2 - 1, ult = i === lines.length - 1;
        var words = ln.split(' ').filter(function (z) { return z.length; });
        if (!ult && !o.esq && words.length > 1) {
          var tw = words.reduce(function (a, z) { return a + doc.getTextWidth(z); }, 0), esp = (wd - tw) / (words.length - 1), cx = x;
          words.forEach(function (z) { doc.text(z, cx, base); cx += doc.getTextWidth(z) + esp; });
        } else doc.text(ln, x, base);
        S.y += lh;
      });
    };
    S.titulo = function (nivel, texto, o) {
      o = o || {};
      if (nivel === 1) { if (S.y > MT + 1) S.nova(); }
      var label = '';
      if (!o.semNum) { S.cnt[nivel]++; for (var i = nivel + 1; i < S.cnt.length; i++) S.cnt[i] = 0; label = S.cnt.slice(1, nivel + 1).join('.') + ' '; }
      var full = label + (nivel === 1 ? String(texto).toUpperCase() : texto), st = nivel === 1 || nivel === 2 ? 'bold' : (nivel === 3 ? 'normal' : 'italic');
      if (nivel === 3) st = 'bold';
      var lines = S.linhas(full, TW, FS, st);
      S.ensure(lines.length * LH + LH * 5);
      if (S.y > MT + 1 && nivel > 1) S.y += LH * 0.5;
      lines.forEach(function (ln) { S.fonte(st, FS); doc.text(ln, o.centro ? PW / 2 : ML, S.y + FS + (LH - FS) / 2 - 1, o.centro ? { align: 'center' } : undefined); S.y += LH; });
      S.y += LH * 0.25;
      if (nivel <= 3 && !o.semToc) S.heads.push({ nivel: nivel, texto: full, pagina: S.page });
    };
    S.tabela = function (titulo, cols, rows, fonte, o) {
      o = o || {}; S.tab++; if (S.y > MT + 1) S.y += 6;
      var ww = cols.map(function (c) { return c.w * TW; }), pad = 3, cab = cols.map(function (c, i) { return S.linhas(c.t, ww[i] - 2 * pad, SFS, 'bold'); });
      var hCab = Math.max.apply(null, cab.map(function (l) { return l.length; })) * SLH + 2 * pad;
      var rl = rows.map(function (r) { return r.map(function (c, i) { return S.linhas(c, ww[i] - 2 * pad, SFS, 'normal'); }); });
      var rh = rl.map(function (r) { return Math.max.apply(null, r.map(function (l) { return l.length; })) * SLH + 2 * pad; });
      var tl = S.linhas('Tabela ' + S.tab + ' – ' + titulo, TW, SFS, 'bold'), hTit = tl.length * SLH + 4, fl = fonte ? S.linhas(fonte, TW, SFS, 'normal') : [], hFon = fl.length ? fl.length * SLH + 4 : 0;
      var total = hTit + hCab + rh.reduce(function (a, b) { return a + b; }, 0) + hFon + 8;
      if (total <= BOTTOM - MT - 10) S.ensure(total); else S.ensure(hTit + hCab + (rh[0] || 0) + 10);
      S.fonte('bold', SFS); tl.forEach(function (ln) { doc.text(ln, ML, S.y + SFS); S.y += SLH; }); S.y += 4;
      function cabeca() {
        S.ensure(hCab + (rh[0] || 0));
        doc.setLineWidth(0.9); doc.line(ML, S.y, ML + TW, S.y);
        var x = ML; cab.forEach(function (l, i) { S.fonte('bold', SFS); l.forEach(function (ln, k) { var tx0 = cols[i].al === 'r' ? x + ww[i] - pad : x + pad; doc.text(ln, tx0, S.y + pad + SFS + k * SLH - 1, cols[i].al === 'r' ? { align: 'right' } : undefined); }); x += ww[i]; });
        S.y += hCab; doc.setLineWidth(0.5); doc.line(ML, S.y, ML + TW, S.y);
      }
      cabeca();
      rows.forEach(function (r, ri) {
        if (S.y + rh[ri] > BOTTOM) { S.nova(); cabeca(); }
        var x = ML; rl[ri].forEach(function (l, i) { S.fonte('normal', SFS); l.forEach(function (ln, k) { var tx0 = cols[i].al === 'r' ? x + ww[i] - pad : x + pad; doc.text(ln, tx0, S.y + pad + SFS + k * SLH - 1, cols[i].al === 'r' ? { align: 'right' } : undefined); }); x += ww[i]; });
        S.y += rh[ri];
        if (ri < rows.length - 1) { doc.setDrawColor(200); doc.setLineWidth(0.25); doc.line(ML, S.y, ML + TW, S.y); doc.setDrawColor(0); }
      });
      doc.setLineWidth(0.9); doc.line(ML, S.y, ML + TW, S.y);
      S.y += 2;
      if (fl.length) { S.fonte('normal', SFS); fl.forEach(function (ln) { doc.text(ln, ML, S.y + SFS); S.y += SLH; }); S.y += 2; }
      S.y += 8;
    };
    S.figura = function (titulo, url, hpt, fonte) {
      S.fig++; if (S.y > MT + 1) S.y += 6;
      var tl = S.linhas('Figura ' + S.fig + ' – ' + titulo, TW, SFS, 'bold'), fl = S.linhas(fonte || '', TW, SFS, 'normal');
      var total = tl.length * SLH + 4 + hpt + fl.length * SLH + 12;
      S.ensure(total);
      S.fonte('bold', SFS); tl.forEach(function (ln) { doc.text(ln, ML, S.y + SFS); S.y += SLH; }); S.y += 4;
      if (url) doc.addImage(url, 'PNG', ML, S.y, TW, hpt, undefined, 'FAST');
      S.y += hpt + 2;
      S.fonte('normal', SFS); fl.forEach(function (ln) { doc.text(ln, ML, S.y + SFS); S.y += SLH; });
      S.y += 10;
    };
    return S;
  }

  function nomeFonte(M) { return 'Fonte: Valor-E, apuração em ' + M.gerado.toLocaleDateString('pt-BR') + '.'; }

  function drawToc(S, tocEntries, tocPages) {
    var doc = S.doc;
    doc.setFont('times', 'bold'); doc.setFontSize(12); doc.text('SUM\u00c1RIO', PW / 2, MT + 12, { align: 'center' }); S.y = MT + 12 + LH;
    (tocEntries || []).forEach(function (e) {
      if (S.y + SLH * 1.6 > BOTTOM) S.nova();
      var ind = (e.nivel - 1) * 14, st = e.nivel === 1 ? 'bold' : 'normal';
      S.fonte(st, SFS + 1);
      var pg = String(e.pagina + tocPages - 1), room = TW - ind - doc.getTextWidth(pg) - 8, lines = doc.splitTextToSize(tx(e.texto), room);
      lines.forEach(function (ln) { doc.text(ln, ML + ind, S.y + SFS, undefined); S.y += SLH + 1; });
      var last = S.y - (SLH + 1) + SFS, wl = doc.getTextWidth(lines[lines.length - 1]), wp = doc.getTextWidth(pg);
      var avail = TW - ind - wl - wp - 8; S.fonte('normal', SFS + 1);
      if (avail > 10) { var dw = doc.getTextWidth('.'); doc.text(new Array(Math.floor(avail / dw)).join('.'), ML + ind + wl + 4, last); }
      S.fonte(st, SFS + 1); doc.text(pg, ML + TW, last, { align: 'right' });
      S.y += 3;
    });
  }
  function tocPaginas(M, entries) { var S = Doc(M, 0, []); S.nova(); var n = S.page; drawToc(S, entries, 1); return S.page - n + 1; }

  function montarPdf(M, tocPages, tocEntries) {
    var S = Doc(M, tocPages, tocEntries), doc = S.doc, F = nomeFonte(M), MET = w.MET;
    var dataTxt = M.gerado.toLocaleDateString('pt-BR'), cf = Math.round(MET.LIM.conf * 100), at = Math.round(MET.LIM.aten * 100);
    function sit(st, fem) { return st === 'sem-dados' ? 'não avaliada' : (fem ? MET.ROTULO_F : MET.ROTULO)[st].toLowerCase(); }
    // ---- capa ----
    doc.setFont('times', 'bold'); doc.setFontSize(14);
    if (w.LOGO_PDF) { var lw = 300, lh = lw * w.LOGO_PDF.h / w.LOGO_PDF.w; doc.addImage(w.LOGO_PDF.png, 'PNG', (PW - lw) / 2, 120, lw, lh); }
    doc.setFontSize(20); var tt = doc.splitTextToSize('RELATÓRIO DE DESEMPENHO BASEADO EM CAPACIDADES', TW); doc.text(tt, PW / 2, 330, { align: 'center' });
    doc.setFont('times', 'normal'); doc.setFontSize(12);
    doc.text(tx('Data de apuração: ' + dataTxt), PW / 2, 700, { align: 'center' });
    doc.text('Critérios de cálculo: metodologia de desempenho baseado em capacidades', PW / 2, 718, { align: 'center' });
    doc.text('Emitido pelo sistema Valor-E', PW / 2, 736, { align: 'center' });
    // ---- sumário ----
    S.nova();
    var n0 = S.page;
    drawToc(S, tocEntries, tocPages);
    while (S.page - n0 + 1 < tocPages) { S.nova(); }
    S.heads = []; S.cnt = [0, 0, 0, 0, 0];
    // ---- 1 identificação ----
    S.nova(); S.y = MT;
    S.titulo(1, 'Identificação e escopo');
    S.titulo(2, 'Critérios de avaliação');
    S.para('Este relatório apresenta o desempenho apurado em ' + dataTxt + ', conforme o Valor Estratégico Baseado em Capacidades (VEB-C), que relaciona objetivos estratégicos, capacidades, dimensões (fatores determinantes) e indicadores, e utiliza o Índice de Habilitação da Capacidade (IHC) e o Índice de Captura de Valor (ICV).');
    S.titulo(2, 'Cadeia de formação do valor estratégico');
    S.para('O valor estratégico da organização decorre do desdobramento indicador → capacidade → objetivo estratégico. Os indicadores representam as entregas dos processos e dos projetos que habilitam as capacidades; as capacidades habilitadas geram os resultados (captura de valor) que buscam atingir o objetivo estratégico e, assim, o valor estratégico da organização.');
    S.titulo(2, 'Organização do relatório');
    S.para('O relatório está organizado por objetivo estratégico, seguido das capacidades que o integram, das dimensões e dos indicadores. Cada indicador é apresentado com sua situação, o grau de risco, a série de registros, o gráfico de evolução (com meta, tendência, média móvel e projeção), o diagnóstico, a análise crítica e o plano de ação.');
    S.titulo(2, 'Situação e grau de risco');
    S.para('O percentual da meta de cada indicador compara o valor apurado com a meta do ciclo vigente no mês do registro. São considerados em conformidade (risco baixo) os indicadores com ' + cf + '% ou mais da meta; em atenção (risco médio) os situados entre ' + at + '% e ' + cf + '%; e críticos (risco alto) os inferiores a ' + at + '%. A situação da capacidade e da dimensão corresponde ao pior estado entre seus indicadores ativos. O IHC é classificado pela mesma escala. O ICV do objetivo estratégico é apurado contra a meta do objetivo no ciclo estratégico (C = IHC ÷ meta) e classificado pela Curva ABC (acima de 95% em conformidade; de 75% a 95% em atenção; abaixo de 75% estado crítico), complementada pelo desvio em relação à meta segundo o parâmetro Six Sigma (abaixo de 5% risco baixo; de 5% a 25% risco médio; acima de 25% risco alto). A curva ABC classifica os elementos pela participação acumulada no déficit ponderado (classe A até 80%, B até 95% e C acima de 95%), e a análise de dispersão, inspirada no Six Sigma, expressa a distância à meta em desvios-padrão da série.');
    S.titulo(2, 'Limitações dos dados');
    S.para('Foram avaliados ' + M.lim.inds + ' indicador(es) ativo(s), dos quais ' + M.lim.semMeta + ' sem ciclo de meta e ' + M.lim.semDados + ' sem registro de valor válido. ' + M.lim.capsNaoAval + ' capacidade(s) não pôde(ram) ser avaliada(s). A ausência de dados não é tratada como desempenho zero. O ICV não representa valor financeiro nem relação causal; a efetividade estratégica deve ser verificada por evidências próprias.');

    // ---- objetivos ----
    M.objetivos.forEach(function (O) {
      S.titulo(1, 'Objetivo estratégico ' + labelObj(O.oe).replace(' — ', ' – '));
      if (O.oe.descricao) S.para(O.oe.descricao);
      S.para(O.texto);
      var PL = []; try { PL = w.DB.all('SELECT * FROM va_planos WHERE objetivo_id=? ORDER BY id', [O.oe.id]); } catch (e) { PL = []; }
      if (PL.length) {
        S.titulo(2, 'Plano de ação do objetivo ' + O.oe.codigo + ' (5W2H)');
        PL.forEach(function (p) {
          var T = w.SisrelHtml.texto;
          S.para('Ação: ' + (p.titulo || '') + ' [' + (p.status || 'Planejada') + ']. O quê: ' + (T(p.o_que) || '-') + ' Por quê: ' + (T(p.por_que) || '-') + ' Onde: ' + (p.onde || '-') + '. Quando: ' + (p.quando_inicio || p.quando_fim ? MET.fmtData(p.quando_inicio) + ' a ' + MET.fmtData(p.quando_fim) : '-') + '. Quem: ' + (p.quem || '-') + '. Como: ' + (T(p.como) || '-') + ' Quanto: ' + (p.quanto || '-') + '.');
        });
      }
      if (O.caps.length) {
        S.tabela('Capacidades do objetivo ' + O.oe.codigo + ' (IHC, situação e risco)',
          [{ t: 'Capacidade', w: 0.36 }, { t: 'Peso', w: 0.09, al: 'r' }, { t: 'Peso efetivo', w: 0.13, al: 'r' }, { t: 'IHC', w: 0.1, al: 'r' }, { t: 'Situação', w: 0.18 }, { t: 'Risco', w: 0.14 }],
          O.caps.map(function (C) { return [C.cap.codigo + ' – ' + C.cap.nome, pc(C.wc, 0), C.wcEf == null ? '—' : pc(C.wcEf, 0), pc(C.ihc), sit(C.status, true), C.ihc == null ? '—' : MET.RISCO[C.status].toLowerCase()]; }), F);
        var u1 = imgChart(function (id) { return w.OPTCharts.barras(id, O.caps.map(function (C) { return C.cap.codigo; }), O.caps.map(function (C) { return C.ihc; }), { titulo: 'IHC (%) por capacidade', label: 'IHC' }); }, 1000, 420);
        if (u1) S.figura('IHC por capacidade no objetivo ' + O.oe.codigo + ' (cores segundo a escala de situação)', u1, TW * 0.42, F);
        if (O.defEstr.itens.length) S.tabela('Curva ABC das capacidades do objetivo ' + O.oe.codigo,
          [{ t: 'Capacidade', w: 0.62 }, { t: 'Déficit (Wc x (1 - IHC))', w: 0.26, al: 'r' }, { t: 'ABC', w: 0.12 }],
          O.defEstr.itens.map(function (i) { return [i.codigo + ' – ' + i.nome, nz(i.d, 3), i.classe_abc || '']; }), F);
      }
      O.caps.forEach(function (C) {
        S.titulo(2, 'Capacidade ' + C.cap.codigo + ' – ' + C.cap.nome);
        S.para('Peso no objetivo: ' + pc(C.wc, 0) + (C.wcEf != null && Math.abs(C.wcEf - C.wc) > 0.005 ? ' (peso efetivo no ICV: ' + pc(C.wcEf, 0) + ', porque capacidades sem dados foram desconsideradas)' : '') + '. ' + C.texto);
        var inds = []; C.fatores.forEach(function (f) { f.inds.forEach(function (i) { inds.push({ i: i, f: f }); }); });
        if (inds.length) {
          S.tabela('Indicadores da capacidade ' + C.cap.codigo + ' (situação e risco)',
            [{ t: 'Dim.', w: 0.06 }, { t: 'Indicador', w: 0.35 }, { t: 'Valor', w: 0.1, al: 'r' }, { t: 'Meta', w: 0.08, al: 'r' }, { t: '% meta', w: 0.08, al: 'r' }, { t: 'Desvio', w: 0.09, al: 'r' }, { t: 'Situação', w: 0.15 }, { t: 'Risco', w: 0.09 }],
            inds.map(function (x) { var I = x.i; return [x.f.codigo || '', I.nome, I.tipo === 'multiplo' ? 'composto' : nz(I.valor), nz(I.meta), pc(I.pct, 0), I.desvio == null ? '—' : nz(I.desvio), sit(I.status, false), MET.RISCO[I.status].toLowerCase()]; }),
            F + ' Desvio = distância à meta (positivo: meta não alcançada).');
          var u2 = imgChart(function (id) { return w.OPTCharts.barras(id, inds.map(function (x) { return x.i.codigo; }), inds.map(function (x) { return x.i.a; }), { titulo: '% da meta dos indicadores', label: '% da meta' }); }, 1000, 400);
          if (u2) S.figura('Percentual da meta dos indicadores da capacidade ' + C.cap.codigo, u2, TW * 0.4, F);
        }
        C.fatores.forEach(function (Fa) {
          S.titulo(3, 'Dimensão ' + (Fa.codigo || '') + ' – ' + (Fa.nome || '') + (Fa.essencial ? ' (essencial)' : ''));
          Fa.inds.forEach(function (I) {
            S.titulo(4, 'Indicador ' + I.nome);
            var fr = I.row;
            S.tabela('Ficha e desempenho do indicador ' + I.codigo,
              [{ t: 'Campo', w: 0.2 }, { t: 'Valor', w: 0.3 }, { t: 'Campo', w: 0.2 }, { t: 'Valor', w: 0.3 }],
              [['Tipo', I.tipo === 'multiplo' ? 'múltiplo' : 'simples', 'Polaridade', I.polaridade === 'menor_melhor' ? 'menor é melhor' : 'maior é melhor'],
               ['Item / unidade', I.tipo === 'multiplo' ? '—' : (fr.item_nome || '—') + ' / ' + (I.unidade || '—'), 'Meta vigente', nz(I.meta)],
               ['Último valor', (I.tipo === 'multiplo' ? 'composto ' + nz(I.valor) : nz(I.valor)) + (I.mes ? ' (' + MET.fmtMes(I.mes) + ')' : ''), '% da meta', pc(I.pct, 0)],
               ['Situação', sit(I.status, false), 'Grau de risco', MET.RISCO[I.status].toLowerCase()],
               ['Peso (GRH)', I.grh != null ? pc(I.grh, 0) : '—', 'Déficit / ABC', (I.d != null ? nz(I.d, 3) : '—') + (I.abc ? ' / ' + I.abc : '')],
               ['Organização responsável', fr.om_responsavel || '—', 'Cadastro', fr.usuario_cadastro || '—'],
               ['Ciclos de metas', I.ciclos.map(function (c) { return MET.fmtMes(String(c.data_inicio).slice(0, 7)) + ' a ' + MET.fmtMes(String(c.data_fim).slice(0, 7)) + ': ' + nz(c.meta); }).join('; ') || '—', '', '']].concat(I.itens.length ? [['Itens', I.itens.map(function (i) { return i.nome + ' (' + (i.pct == null ? 'n/d' : pc(i.pct, 0)) + ')'; }).join('; '), '', '']] : []), F);
            if (I.serie.length && I.serie.length <= 36) S.tabela('Série de registros do indicador ' + I.codigo,
              [{ t: 'Referência', w: 0.28 }, { t: I.tipo === 'multiplo' ? 'Valor composto' : 'Valor', w: 0.24, al: 'r' }, { t: 'Meta do mês', w: 0.24, al: 'r' }, { t: '% da meta', w: 0.24, al: 'r' }],
              I.serie.map(function (x) { return [MET.fmtMes(x.mes), nz(x.valor), nz(x.meta), pc(x.pct, 0)]; }), F);
            var d = RPT.dadosInd(I);
            if (d.valores.length) {
              var u3 = imgChart(function (id) { return w.OPTCharts.evolucao(id, d.labels, d.valores, d.metas, { titulo: d.titulo, labelValor: d.labelValor, labelMeta: 'Meta' }); }, 1000, 440);
              if (u3) S.figura('Evolução do indicador ' + I.codigo + ' (valor, meta, tendência, média móvel e projeção)', u3, TW * 0.44, F);
            }
            S.para('Diagnóstico. ' + I.texto);
            if (I.analise) S.para('Análise crítica. ' + I.analise);
            if (I.plano) S.para('Plano de ação. ' + I.plano);
          });
        });
      });
    });

    // ---- síntese ----
    S.titulo(1, 'Prioridades');
    var prio = [];
    M.objetivos.forEach(function (O) { O.caps.forEach(function (C) { C.fatores.forEach(function (Fa) { Fa.inds.forEach(function (I) { if ((I.abc === 'A' && I.d > 0.0001) || I.status === 'critico') prio.push([O.oe.codigo, C.cap.codigo, I.nome, pc(I.pct, 0), sit(I.status, false), I.abc || '—']); }); }); }); });
    if (prio.length) { S.para('Indicadores críticos ou de classe A da curva ABC (maior participação no déficit) devem orientar a priorização das intervenções; a combinação crítico e classe A indica prioridade máxima.'); S.tabela('Indicadores prioritários', [{ t: 'Obj.', w: 0.1 }, { t: 'Cap.', w: 0.12 }, { t: 'Indicador', w: 0.4 }, { t: '% meta', w: 0.11, al: 'r' }, { t: 'Situação', w: 0.17 }, { t: 'ABC', w: 0.1 }], prio, F); }
    else S.para('Não há indicadores críticos ou em déficit relevante (classe A) entre os avaliados.');

    // ---- anexos ----
    S.titulo(1, 'Anexo A – Verificação antes da apuração', { semNum: true });
    S.tabela('Verificação dos critérios de cálculo', [{ t: 'Critério', w: 0.5 }, { t: 'Resultado', w: 0.14 }, { t: 'Detalhe', w: 0.36 }],
      M.validacao.map(function (v) { return [v.titulo, v.ok ? 'atendido' : 'pendente', v.ok ? v.detalhe : v.problemas.slice(0, 3).join(' ') + (v.problemas.length > 3 ? ' (+' + (v.problemas.length - 3) + ')' : '')]; }), F);
    S.titulo(1, 'Anexo B – Registro dos pesos (AHP)', { semNum: true });
    if (M.ahp.length) S.tabela('Pesos registrados (consistência e versão dos critérios)', [{ t: 'Data', w: 0.16 }, { t: 'Escopo', w: 0.24 }, { t: 'Pesos', w: 0.4 }, { t: 'RC', w: 0.08, al: 'r' }, { t: 'Versão', w: 0.12 }],
      M.ahp.map(function (a) { var rot = [], pes = []; try { rot = JSON.parse(a.rotulos_json || '[]'); pes = JSON.parse(a.pesos_json || '[]'); } catch (e) {} return [fdata(String(a.criado_em || '').slice(0, 10)), a.escopo, rot.map(function (r, i) { return String(r).split(' — ')[0] + '=' + pc(pes[i], 1); }).join('; '), a.rc != null ? nz(a.rc, 3) : '—', String(a.versao || 'Metodologia 2.0').replace(/SD\u0042C/g, 'Metodologia')]; }), F);
    else S.para('Não há registros de ponderação AHP.');
    S.titulo(1, 'Anexo C – Histórico de alterações', { semNum: true });
    if (M.historico.length) S.tabela('Alterações de pesos', [{ t: 'Data', w: 0.16 }, { t: 'Tipo', w: 0.12 }, { t: 'Descrição', w: 0.72 }], M.historico.map(function (hh) { return [fdata(String(hh.em || '').slice(0, 10)), hh.tipo || '', hh.descricao || '']; }), F);
    else S.para('Não há alterações registradas.');
    return S;
  }

  function b64(buf) { var b = new Uint8Array(buf), s = '', i, n = b.length; for (i = 0; i < n; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s); }
  RPT.gerarPdf = function (M) {
    var Ch = w.Chart, oldA = Ch && Ch.defaults.animation, oldD = Ch && Ch.defaults.devicePixelRatio;
    if (Ch) { Ch.defaults.animation = false; Ch.defaults.devicePixelRatio = 1.5; }
    try {
      var S0 = montarPdf(M, 0, []), ent = S0.heads.slice();
      var tocPages = tocPaginas(M, ent);
      var S = montarPdf(M, tocPages, ent);
      return S.doc;
    } finally { if (Ch) { Ch.defaults.animation = oldA; Ch.defaults.devicePixelRatio = oldD; } }
  };
  RPT.exportarPdf = function () {
        var oeEl = document.getElementById('rel_oe'), oe = oeEl ? parseInt(oeEl.value, 10) || 0 : 0;
    var av = document.createElement('div'); av.id = 'pdf_aviso'; av.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:99999;display:flex;align-items:center;justify-content:center;color:#fff;font:600 18px system-ui';
    av.textContent = 'Gerando o relatório em PDF…'; document.body.appendChild(av);
    setTimeout(function () {
      try {
        var M = RPT.montar(oe), doc = RPT.gerarPdf(M);
        var nome = 'relatorio-valore-' + new Date().toISOString().slice(0, 10) + '.pdf';
        var buf = doc.output('arraybuffer'), hb = w.__maprisHost;
        if (hb && hb.invocar) hb.invocar('salvar', JSON.stringify({ nome: nome, b64: b64(buf) }));
        else { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([buf], { type: 'application/pdf' })); a.download = nome; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
      } catch (e) { alert('Falha ao gerar o PDF: ' + (e && e.message || e)); }
      finally { av.remove(); }
    }, 60);
  };
})(window);

})(window.DB);
