/* folha.js — Folha de Dados do Processo (seções 1–13) + construtor do item 7 */
(function () {
  'use strict';
  Common.pagina('folha', function () {
  var p = API.buscar(Common.id());
  if (!p) { Common.ir('#/processos'); return; }
  var D = API.dados(p), F = D.folha, A = D.atividades;
  document.title = D.nome + ' — Folha';
  document.getElementById('fraiz').innerHTML = window.FOLHA_HTML(D);
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var el = function (tag, attrs, kids) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'html') e.innerHTML = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] !== null && attrs[k] !== undefined) e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  };
  var uid = function () { return 'r' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3); };

  // ---------------- salvar ----------------
  var sujo = false, timer = null, salvando = false;
  function marcar() {
    sujo = true; $('#status').textContent = 'Alterações não salvas…';
    clearTimeout(timer); timer = setTimeout(function () { salvar(false); }, 1800);
  }
  function payload() { return { id: D.id, nome: $('#nome').value.trim() || D.nome, folha: F, atividades: A, opcoes: D.opcoes }; }
  function salvar(manual) {
    if (!document.getElementById('status')) { clearTimeout(timer); return Promise.resolve(); }   // a tela já foi fechada (a saída já gravou o que estava pendente)
    if (salvando) { clearTimeout(timer); timer = setTimeout(function () { salvar(manual); }, 600); return Promise.resolve(); }
    salvando = true; $('#status').textContent = 'Salvando…';
    return API.call('salvar', payload())
      .then(function (r) {
        salvando = false;
        if (!r.ok) { $('#status').textContent = 'Erro ao salvar'; alert('Erro ao salvar: ' + r.erro); return; }
        sujo = false; $('#status').textContent = 'Salvo ✓';
        atualizarStatusDiag(r.desatualizado);
      }).catch(function (e) { salvando = false; $('#status').textContent = 'Erro ao salvar'; });
  }
  window.Folha = window.Folha || {}; window.Folha.salvar = salvar;
  (function () {
    var ms = document.getElementById('macroSel'); if (!ms) return;
    var c = E.processoCarregar(D.id) || {};
    ms.innerHTML = '<option value="">— sem macroprocesso —</option>' + window.macrosAgrupados(c.macro_id);
    ms.addEventListener('change', function () { E.processoMacro(D.id, ms.value); $('#status').textContent = 'Salvo ✓'; });
  })();
  window.addEventListener('pagehide', function () { if (sujo && document.getElementById('nome')) salvar(false); });
  $('#bXml').addEventListener('click', function (e) { e.preventDefault(); salvar(false).then(function () { var r = API.acao('exportar_xml', { id: D.id }); if (r.ok) Common.baixar(r.nome, r.texto, r.tipo); else alert(r.erro); }); });
  Common.antes = function () { return sujo ? salvar(false) : null; };
  document.addEventListener('keydown', function (e) { if (!document.getElementById('nome')) return; if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') { e.preventDefault(); salvar(true); } });
  $('#nome').addEventListener('input', marcar);

  function atualizarStatusDiag(desat) {
    var s = $('#stDiag');
    if (!D.temDiagrama) s.innerHTML = '<span class="badge text-bg-secondary">ainda não gerado</span>';
    else if (desat) s.innerHTML = '<span class="badge text-bg-warning">desatualizado em relação ao item 7</span>';
    else s.innerHTML = '<span class="badge text-bg-success">atualizado</span>';
  }
  atualizarStatusDiag(false);

  // ---------------- campos simples ----------------
  /** Campos de texto da folha com editor rico (TipTap): negrito, listas, cores, recuos, links. */
  function editorRico(ta, chave) {
    var host = document.createElement('div'); host.className = 'folha-rico';
    ta.parentNode.insertBefore(host, ta); ta.style.display = 'none';
    window.SisrelEditor.criar(host, {
      barra: 'simples', minAltura: 84, placeholder: ta.getAttribute('placeholder') || '',
      dados: F[chave] || '',
      aoMudar: function (html) { F[chave] = html; marcar(); }
    });
  }
  document.querySelectorAll('[data-f]').forEach(function (i) {
    if (window.SisrelEditor) { editorRico(i, i.dataset.f); return; }
    i.value = F[i.dataset.f] || '';
    i.addEventListener('input', function () { F[i.dataset.f] = i.value; marcar(); });
  });

  // ---------------- listas de texto ----------------
  document.querySelectorAll('[data-lista]').forEach(function (box) {
    var k = box.dataset.lista, ph = box.dataset.ph || '';
    if (!Array.isArray(F[k])) F[k] = [];
    function draw() {
      box.innerHTML = '';
      F[k].forEach(function (v, i) {
        var inp = el('input', { type: 'text', class: 'form-control form-control-sm', placeholder: ph });
        inp.value = v; inp.addEventListener('input', function () { F[k][i] = inp.value; marcar(); if (k === 'gestor' || k === 'executores') refDl(); });
        box.appendChild(el('div', { class: 'lista-item' }, [inp, el('button', { class: 'btn-mini del', title: 'Remover', html: '<i class="bi bi-x-lg"></i>', onclick: function () { F[k].splice(i, 1); draw(); marcar(); } })]));
      });
      box.appendChild(el('button', { class: 'btn btn-outline-success btn-sm', html: '<i class="bi bi-plus-lg"></i> Adicionar', onclick: function () { F[k].push(''); draw(); marcar(); var ins = box.querySelectorAll('input'); if (ins.length) ins[ins.length - 1].focus(); } }));
    }
    draw();
  });

  // ---------------- tabelas repetíveis ----------------
  var TABS = {
    siglas: { cols: [['sigla', 'Sigla', 'text', 140], ['definicao', 'Definição', 'area']] },
    fornecedores: { cols: [['area', 'Área/Processo', 'area'], ['entradas', 'Entradas', 'area'], ['requisitos', 'Requisitos', 'area']] },
    clientes: { cols: [['area', 'Área/Processo', 'area'], ['saidas', 'Saídas', 'area'], ['requisitos', 'Requisitos', 'area']] },
    competencias: { cols: [['funcao', 'Função', 'area'], ['educacao', 'Educação', 'area'], ['treinamento', 'Treinamento', 'area'], ['experiencia', 'Experiência', 'area'], ['habilidades', 'Habilidades', 'area'], ['atitudes', 'Atitudes', 'area']] },
    registros: { num: true, cols: [['titulo', 'Título', 'area'], ['meio', 'Meio', 'text'], ['sistema', 'Proteção: sistema', 'area'], ['acesso', 'Acesso', 'area'], ['local', 'Recuperação: local', 'area'], ['indexacao', 'Indexação', 'area'], ['corrente', 'Retenção corrente', 'text'], ['intermediario', 'Intermediário', 'text'], ['disposicao', 'Disposição', 'area']] },
    alertas: { cols: [['ponto', 'Ponto de alerta', 'area'], ['descricao', 'Descrição', 'area']] },
    indicadores: { cols: [['tipo', 'Tipo de indicador', 'text'], ['indicador', 'Indicador', 'area'], ['formula', 'Fórmula de cálculo', 'area'], ['frequencia', 'Frequência de apuração', 'text'], ['fonte', 'Fonte dos dados', 'area'], ['polaridade', 'Polaridade', 'text'], ['responsavel', 'Responsável', 'text']] },
    ambientais: { cols: [['variavel', 'Variável a ser controlada', 'text'], ['minimo', 'Mínimo', 'text', 110], ['maximo', 'Máximo', 'text', 110]] },
    alteracoes: { cols: [['versao', 'Identificação', 'text', 150], ['descricao', 'Descrição da alteração', 'area']] }
  };
  document.querySelectorAll('[data-tab]').forEach(function (box) {
    var k = box.dataset.tab, T = TABS[k];
    if (!Array.isArray(F[k])) F[k] = [];
    function draw() {
      box.innerHTML = '';
      var tb = el('table', { class: 'tab-rep' });
      var hr = el('tr'); if (T.num) hr.appendChild(el('th', { text: 'Item', style: 'width:44px' }));
      T.cols.forEach(function (c) { hr.appendChild(el('th', { text: c[1], style: c[3] ? 'width:' + c[3] + 'px' : '' })); });
      hr.appendChild(el('th', { text: '' }));
      tb.appendChild(el('thead', {}, [hr]));
      var body = el('tbody');
      F[k].forEach(function (row, i) {
        var tr = el('tr');
        if (T.num) tr.appendChild(el('td', { text: String(i + 1), style: 'text-align:center;font-weight:600' }));
        T.cols.forEach(function (c) {
          var inp = c[2] === 'area' ? el('textarea', { rows: 2 }) : el('input', { type: 'text' });
          inp.value = row[c[0]] || '';
          inp.addEventListener('input', function () { row[c[0]] = inp.value; marcar(); });
          tr.appendChild(el('td', {}, [inp]));
        });
        tr.appendChild(el('td', { class: 'acao' }, [el('button', { class: 'btn-mini del', title: 'Remover linha', html: '<i class="bi bi-x-lg"></i>', onclick: function () { F[k].splice(i, 1); draw(); marcar(); } })]));
        body.appendChild(tr);
      });
      tb.appendChild(body);
      var wrap = el('div', { style: 'overflow-x:auto' }, [tb]);
      box.appendChild(wrap);
      box.appendChild(el('button', { class: 'btn btn-outline-success btn-sm mt-2', html: '<i class="bi bi-plus-lg"></i> Adicionar linha', onclick: function () { F[k].push({}); draw(); marcar(); } }));
    }
    draw();
  });

  // ---------------- nav lateral ----------------
  var links = [].slice.call(document.querySelectorAll('#nav a'));
  function spy() {
    var atual = null;
    document.querySelectorAll('.secao').forEach(function (s) { if (s.getBoundingClientRect().top < 120) atual = s.id; });
    links.forEach(function (a) { a.classList.toggle('ativo', a.getAttribute('href') === '#' + atual); });
  }
  links.forEach(function (a) {
    a.addEventListener('click', function (e) { // não altera o endereço (#): o roteador do app sairia da Folha
      e.preventDefault(); var alvo = document.getElementById((a.getAttribute('href') || '').slice(1));
      if (alvo) { var y = alvo.getBoundingClientRect().top + window.pageYOffset - 112; window.scrollTo({ top: y, behavior: 'smooth' }); }
    });
  });
  window.addEventListener('scroll', spy); spy();

  // =====================================================================
  //   ITEM 7 — formulário de atividades (lista + painel de edição)
  // =====================================================================
  if (typeof D.opcoes.auto_inicio_fim === 'undefined') D.opcoes.auto_inicio_fim = true;
  $('#autoIF').checked = !!D.opcoes.auto_inicio_fim;
  $('#autoIF').addEventListener('change', function () { D.opcoes.auto_inicio_fim = this.checked; marcar(); });

  function maxOrdem() { var max = 0; A.forEach(function (r) { var n = parseFloat(r.ordem); if (isFinite(n) && n > max) max = n; }); return Math.floor(max); }
  function novaLinha() { return { uid: uid(), tipo: '', ordem: maxOrdem() + 1, entrada: '', descricao: '', saida: '', responsavel: '', seq: {}, anexos: [] }; }
  A.forEach(function (r) { if (!r.uid) r.uid = uid(); r.seq = r.seq || {}; r.anexos = r.anexos || []; });
  var sel = A.length ? A[0].uid : null;

  function porUid(u) { return A.filter(function (r) { return r.uid === u; })[0]; }
  function ordenadas() { return A.slice().sort(function (a, b) { return (parseFloat(a.ordem) || 0) - (parseFloat(b.ordem) || 0); }); }
  function ordNum(r) { var n = parseFloat(r.ordem); return isFinite(n) ? n : 0; }
  function resumo(r, n) { var d = (r.descricao || '').replace(/\s+/g, ' ').trim(); if (d.length > n) d = d.slice(0, n - 1) + '…'; return d; }
  function rotuloAtiv(r) { return (r.ordem !== '' && r.ordem !== null ? r.ordem + ' · ' : '') + (resumo(r, 38) || '(' + (BPMN_ROTULO[r.tipo] || 'sem descrição') + ')'); }

  // opções de destino. modo: 'frente' (somente nº maior que o da atividade atual) | 'todas'
  function fillOpts(sel_, atual, origem, autoTxt, modo) {
    sel_.innerHTML = '';
    sel_.appendChild(el('option', { value: '', text: autoTxt }));
    ordenadas().forEach(function (r) {
      if (r.uid === origem.uid || BPMN_CAT(r.tipo) === 'artefato') return;
      if (modo === 'frente' && !(ordNum(r) > ordNum(origem))) return;
      var o = el('option', { value: r.uid, text: rotuloAtiv(r) }); if (r.uid === atual) o.selected = true; sel_.appendChild(o);
    });
    sel_.value = atual || '';
  }
  function selAlvo(obj, chave, origem, autoTxt, modo, onchg) {
    var s_ = el('select', { title: 'Destino' });
    var refaz = function () { fillOpts(s_, obj[chave], origem, autoTxt, typeof modo === 'function' ? modo() : modo); };
    refaz(); s_.addEventListener('focus', refaz); s_.addEventListener('mousedown', refaz);
    s_.addEventListener('change', function () { obj[chave] = s_.value; marcar(); if (onchg) onchg(); });
    return s_;
  }
  function grupo(rotulo, conteudo, dica) {
    var g = el('div', { class: 'fgrp' }, [el('label', { text: rotulo }), conteudo]); if (dica) g.appendChild(el('div', { class: 'dica', text: dica })); return g;
  }
  function campoTexto(r, chave, linhas, ph) {
    var ta = el('textarea', { rows: linhas, placeholder: ph || '' }); ta.value = r[chave] || '';
    ta.addEventListener('input', function () { r[chave] = ta.value; marcar(); if (chave === 'descricao') atualizaItemLista(r); });
    return ta;
  }

  // ----- painel "Sequência" (coluna 6) -----
  function painelSeq(r) {
    var cat = BPMN_CAT(r.tipo), s_ = r.seq, box = el('div', { class: 'painel-seq' });
    box.appendChild(el('h4', { html: '<i class="bi bi-signpost-split"></i> Sequência / conexões' }));
    if (!r.tipo) { box.appendChild(el('div', { class: 'dica', text: 'Escolha o tipo de elemento para definir a sequência.' })); return box; }
    if (/^bpmn:EndEvent/.test(r.tipo)) { box.appendChild(el('div', { class: 'dica', text: 'Evento de fim: o fluxo termina aqui.' })); return box; }
    if (cat === 'artefato') {
      var o = { assoc: s_.assoc || '' };
      box.appendChild(grupo('Associar à atividade', selAlvo(o, 'assoc', r, '(solto — sem ligação)', 'todas', function () { s_.assoc = o.assoc; }), 'O artefato é desenhado acima da atividade escolhida.'));
      return box;
    }
    if (cat === 'gateway') {
      if (!s_.modo) s_.modo = 'divergente';
      var modo = el('select', {}, [el('option', { value: 'divergente', text: 'Divergência — decisão / separação de caminhos' }), el('option', { value: 'convergente', text: 'Junção — reúne caminhos e segue em frente' })]);
      modo.value = s_.modo; modo.addEventListener('change', function () { s_.modo = modo.value; marcar(); renderForm(); });
      box.appendChild(grupo('Função do gateway', modo));
      if (s_.modo === 'convergente') {
        if (!s_.proxima) s_.proxima = { alvo: '', via: 'fluxo', nome: '' };
        box.appendChild(grupo('Segue para', selAlvo(s_.proxima, 'alvo', r, '(automático: atividade seguinte)', 'frente')));
      } else if (r.tipo === 'bpmn:ExclusiveGateway') {
        if (!s_.sim) s_.sim = { alvo: '', via: 'fluxo', nome: '' };
        if (!s_.nao) s_.nao = { alvo: '', via: 'mensagem', nome: '' };
        // SIM — sempre uma nova atividade (à frente), por fluxo
        s_.sim.via = 'fluxo';
        var rs = el('div', { class: 'ramo sim' }, [el('div', { class: 'rt', text: 'SIM →' }),
          selAlvo(s_.sim, 'alvo', r, '(automático: atividade seguinte)', 'frente'),
          el('div', { class: 'dica', text: 'O SIM sempre segue para uma nova atividade, por linha de fluxo.' })]);
        box.appendChild(rs);
        // NÃO — retorno por mensagem/documento (sem linha) ou fluxo para nova atividade
        var viaSel = el('select', {}, [el('option', { value: 'mensagem', text: 'Retorna por MENSAGEM (sem linha de conexão)' }), el('option', { value: 'dados', text: 'Retorna por DOCUMENTO (sem linha de conexão)' }), el('option', { value: 'fluxo', text: 'Segue por FLUXO para uma nova atividade (à frente)' })]);
        viaSel.value = s_.nao.via || 'mensagem';
        var alvoWrap = el('div'), nomeIn = el('input', { type: 'text', placeholder: 'Nome da mensagem / documento (ex.: Devolução para ajustes)' }); nomeIn.value = s_.nao.nome || '';
        nomeIn.addEventListener('input', function () { s_.nao.nome = nomeIn.value; marcar(); });
        var dicaN = el('div', { class: 'dica' });
        function desenhaNao() {
          s_.nao.via = viaSel.value; alvoWrap.innerHTML = '';
          var fluxo = viaSel.value === 'fluxo';
          alvoWrap.appendChild(el('div', { class: 'flbl', style: 'margin-top:6px', text: fluxo ? 'Segue para' : 'Atividade de retorno' }));
          alvoWrap.appendChild(selAlvo(s_.nao, 'alvo', r, fluxo ? '— escolha a atividade —' : '— escolha a atividade de retorno —', fluxo ? 'frente' : 'todas'));
          nomeIn.style.display = fluxo ? 'none' : '';
          dicaN.className = 'dica alerta'; dicaN.textContent = fluxo ? 'Linha de fluxo normal até a nova atividade.' : 'Nenhuma linha é desenhada até a atividade de retorno: o vínculo aparece como ' + (viaSel.value === 'dados' ? 'documento' : 'mensagem') + ' ligada à decisão, com o texto "NÃO … retorna à atividade N".';
        }
        viaSel.addEventListener('change', function () { s_.nao.alvo = ''; desenhaNao(); marcar(); });
        desenhaNao();
        box.appendChild(el('div', { class: 'ramo nao' }, [el('div', { class: 'rt', text: 'NÃO →' }), viaSel, alvoWrap, el('div', { style: 'margin-top:6px' }, [nomeIn]), dicaN]));
      } else {
        if (!Array.isArray(s_.ramos) || !s_.ramos.length) s_.ramos = [{ alvo: '', rotulo: '', via: 'fluxo', nome: '' }, { alvo: '', rotulo: '', via: 'fluxo', nome: '' }];
        s_.ramos.forEach(function (rm, k) {
          rm.via = 'fluxo';
          var rot = el('input', { type: 'text', placeholder: 'Rótulo do ramo (opcional)', style: 'margin-bottom:4px' }); rot.value = rm.rotulo || '';
          rot.addEventListener('input', function () { rm.rotulo = rot.value; marcar(); });
          var cab = el('div', { class: 'rt d-flex justify-content-between' }, [el('span', { text: 'RAMO ' + (k + 1) }), s_.ramos.length > 2 ? el('button', { class: 'btn-mini del', type: 'button', html: '<i class="bi bi-x-lg"></i>', onclick: function () { s_.ramos.splice(k, 1); marcar(); renderForm(); } }) : null]);
          box.appendChild(el('div', { class: 'ramo' }, [cab, rot, selAlvo(rm, 'alvo', r, '— escolha a atividade —', 'frente')]));
        });
        box.appendChild(el('button', { type: 'button', class: 'btn btn-outline-secondary btn-sm', html: '<i class="bi bi-plus"></i> Adicionar ramo', onclick: function () { s_.ramos.push({ alvo: '', rotulo: '', via: 'fluxo', nome: '' }); marcar(); renderForm(); } }));
      }
      return box;
    }
    if (!s_.proxima) s_.proxima = { alvo: '', via: 'fluxo', nome: '' };
    s_.proxima.via = 'fluxo';
    box.appendChild(grupo('Segue para', selAlvo(s_.proxima, 'alvo', r, '(automático: atividade seguinte)', 'todas'), 'Se escolher uma atividade anterior, o retorno é indicado por mensagem, sem linha de conexão.'));
    return box;
  }

  // ----- seletor de tipo (24px) -----
  var pop = $('#tipo-pop'), popCb = null, popBtn = null;
  (function montarPop() {
    BPMN_GRUPOS.forEach(function (g) {
      pop.appendChild(el('div', { class: 'grp', text: g.g }));
      g.itens.forEach(function (i) {
        pop.appendChild(el('div', { class: 'it', 'data-t': i[0], html: BPMN_ICON(i[0]) + '<span>' + i[1] + '</span>', onclick: function () { var cb = popCb; fechaPop(); if (cb) cb(i[0]); } }));
      });
    });
  })();
  function abrePop(btn, atual, cb) {
    popCb = cb; popBtn = btn;
    pop.querySelectorAll('.it').forEach(function (i) { i.classList.toggle('sel', i.dataset.t === atual); });
    pop.style.display = 'block'; posPop();
  }
  function posPop() {
    if (!popBtn || !popBtn.isConnected) { fechaPop(); return; }
    var rc = popBtn.getBoundingClientRect();
    var h = pop.offsetHeight, top = rc.bottom + 2;
    if (top + h > window.innerHeight - 8) top = Math.max(8, window.innerHeight - h - 8);
    pop.style.top = top + 'px'; pop.style.left = Math.max(8, Math.min(rc.left, window.innerWidth - 300)) + 'px';
  }
  function fechaPop() { pop.style.display = 'none'; popCb = null; }
  document.addEventListener('mousedown', function (e) { if (pop.style.display === 'block' && !pop.contains(e.target) && !e.target.closest('.tipo-btn')) fechaPop(); });
  window.addEventListener('scroll', function (e) { if (pop.contains(e.target)) return; if (pop.style.display === 'block') posPop(); }, true);

  function respSugestoes() {
    var set = {};
    (F.gestor || []).concat(F.executores || []).forEach(function (t) { t = (t || '').trim(); if (t && t.length < 60) set[t] = 1; });
    A.forEach(function (r) { var t = (r.responsavel || '').trim(); if (t) set[t] = 1; });
    return Object.keys(set);
  }
  function refDl() { var dl = $('#dlResp'); dl.innerHTML = ''; respSugestoes().forEach(function (t) { dl.appendChild(el('option', { value: t })); }); }

  // ----- lista lateral -----
  function itemLista(r) {
    var it = el('div', { class: 'it7' + (r.uid === sel ? ' sel' : '') + (r.tipo ? '' : ' vz'), 'data-uid': r.uid, onclick: function () { sel = r.uid; renderLista(); renderForm(); } }, [
      el('div', { class: 'n', text: r.ordem === '' ? '–' : String(r.ordem) }),
      el('div', { html: r.tipo ? BPMN_ICON(r.tipo) : '<svg width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="3" fill="#fff4e5" stroke="#d98a2b" stroke-dasharray="3 2"/></svg>' }),
      el('div', { class: 't' }, [el('b', { text: resumo(r, 40) || (r.tipo ? BPMN_ROTULO[r.tipo] : 'Nova atividade') }), el('small', { text: (r.responsavel || 'sem responsável') })])
    ]);
    return it;
  }
  function renderLista() {
    var box = $('#s7Lista'); box.innerHTML = '';
    if (!A.length) { box.appendChild(el('div', { class: 'dica', style: 'padding:8px', text: 'Nenhuma atividade ainda.' })); return; }
    ordenadas().forEach(function (r) { box.appendChild(itemLista(r)); });
  }
  function atualizaItemLista(r) {
    var old = $('#s7Lista [data-uid="' + r.uid + '"]'); if (old) old.replaceWith(itemLista(r));
  }

  // ----- anexos inline -----
  var KINDS = [['dados', 'Dados / documento'], ['sistema', 'Sistema (armazenamento)'], ['mensagem', 'Mensagem'], ['subprocesso', 'Subprocesso'], ['anotacao', 'Anotação'], ['normativo', 'Normativo']];
  function painelAnexos(r) {
    var box = el('div', { class: 'painel-seq' });
    box.appendChild(el('h4', { html: '<i class="bi bi-paperclip"></i> Anexos (documentos, sistemas, mensagens, subprocessos…)' }));
    if (!r.anexos.length) box.appendChild(el('div', { class: 'dica', text: 'Nenhum anexo.' }));
    r.anexos.forEach(function (a, i) {
      var k = el('select', {}); KINDS.forEach(function (x) { k.appendChild(el('option', { value: x[0], text: x[1] })); }); k.value = a.kind || 'dados';
      var dir = el('select', {}, [el('option', { value: 'saida', text: 'Saída (gera)' }), el('option', { value: 'entrada', text: 'Entrada (usa)' })]); dir.value = a.direcao || 'saida';
      var nm = el('input', { type: 'text', placeholder: 'Nome / identificação' }); nm.value = a.nome || '';
      var alvo = el('select', { title: 'Atividade de origem/destino da mensagem (opcional)' });
      fillOpts(alvo, a.alvo, r, '(sem atividade indicada)', 'todas');
      alvo.addEventListener('mousedown', function () { fillOpts(alvo, a.alvo, r, '(sem atividade indicada)', 'todas'); });
      alvo.addEventListener('change', function () { a.alvo = alvo.value; marcar(); });
      function vis() { var kk = k.value; dir.style.visibility = (kk === 'dados' || kk === 'sistema' || kk === 'mensagem') ? 'visible' : 'hidden'; alvo.style.visibility = kk === 'mensagem' ? 'visible' : 'hidden'; }
      k.addEventListener('change', function () { a.kind = k.value; vis(); marcar(); });
      dir.addEventListener('change', function () { a.direcao = dir.value; marcar(); });
      nm.addEventListener('input', function () { a.nome = nm.value; marcar(); });
      a.kind = a.kind || 'dados'; vis();
      box.appendChild(el('div', { class: 'anx-it' }, [k, dir, nm, alvo, el('button', { type: 'button', class: 'btn btn-outline-danger btn-sm', title: 'Remover anexo', html: '<i class="bi bi-trash"></i>', onclick: function () { r.anexos.splice(i, 1); marcar(); renderForm(); } })]));
    });
    box.appendChild(el('button', { type: 'button', class: 'btn btn-outline-success btn-sm', html: '<i class="bi bi-plus-lg"></i> Adicionar anexo', onclick: function () { r.anexos.push({ kind: 'dados', direcao: 'saida', nome: '' }); marcar(); renderForm(); } }));
    return box;
  }

  // ----- formulário da atividade selecionada -----
  function renderForm() {
    var f = $('#s7Form'); f.innerHTML = ''; refDl();
    var r = porUid(sel);
    if (!r) { f.appendChild(el('div', { class: 'vazio text-center text-muted', html: '<i class="bi bi-ui-checks" style="font-size:36px"></i><p class="mt-2 mb-3">Nenhuma atividade selecionada.</p>' })); f.lastChild.appendChild(el('button', { class: 'btn btn-success', html: '<i class="bi bi-plus-lg"></i> Nova atividade', onclick: function () { window.addLinha(); } })); return; }
    var btn = el('button', { type: 'button', class: 'tipo-btn' + (r.tipo ? '' : ' vazio-t'), html: r.tipo ? BPMN_ICON(r.tipo) + '<span class="rot">' + BPMN_ROTULO[r.tipo] + '</span><i class="bi bi-chevron-down"></i>' : '<span class="rot">Escolher o tipo de elemento…</span><i class="bi bi-chevron-down"></i>' });
    btn.addEventListener('click', function () {
      abrePop(btn, r.tipo, function (t) { var antiga = BPMN_CAT(r.tipo); r.tipo = t; if (antiga !== BPMN_CAT(t)) r.seq = {}; marcar(); renderLista(); renderForm(); });
    });
    var ord = el('input', { type: 'number', step: 'any' }); ord.value = r.ordem;
    ord.addEventListener('input', function () { r.ordem = ord.value === '' ? '' : parseFloat(ord.value); marcar(); });
    ord.addEventListener('change', function () { renderLista(); });
    var rp = el('input', { type: 'text', list: 'dlResp', placeholder: 'Quem executa (define a raia)' }); rp.value = r.responsavel || '';
    rp.addEventListener('input', function () { r.responsavel = rp.value; marcar(); atualizaItemLista(r); }); rp.addEventListener('change', refDl);

    var l1 = el('div', { class: 'row g-3' }, [
      el('div', { class: 'col-md-5' }, [grupo('1. Tipo de elemento', btn)]),
      el('div', { class: 'col-md-2' }, [grupo('2. Nº de ordem', ord)]),
      el('div', { class: 'col-md-5' }, [grupo('Responsável (raia)', rp)])]);
    f.appendChild(l1);
    f.appendChild(el('div', { class: 'row g-3' }, [
      el('div', { class: 'col-md-6' }, [grupo('3. Entrada', campoTexto(r, 'entrada', 3, 'O que a atividade recebe'))]),
      el('div', { class: 'col-md-6' }, [grupo('5. Saída', campoTexto(r, 'saida', 3, 'O que a atividade produz'))])]));
    f.appendChild(grupo('4. Descrição da atividade', campoTexto(r, 'descricao', 3, 'Texto que aparece no diagrama')));
    f.appendChild(painelSeq(r));
    f.appendChild(painelAnexos(r));

    var idx = ordenadas().map(function (x) { return x.uid; }).indexOf(r.uid);
    var ord_ = ordenadas();
    f.appendChild(el('div', { class: 'd-flex gap-2 flex-wrap justify-content-between mt-2 pt-2', style: 'border-top:1px solid #e3e4e5' }, [
      el('div', { class: 'd-flex gap-2' }, [
        el('button', { class: 'btn btn-outline-secondary btn-sm', type: 'button', html: '<i class="bi bi-chevron-left"></i> Anterior', disabled: idx <= 0 ? 'disabled' : null, onclick: function () { sel = ord_[idx - 1].uid; renderLista(); renderForm(); } }),
        el('button', { class: 'btn btn-outline-secondary btn-sm', type: 'button', html: 'Próxima <i class="bi bi-chevron-right"></i>', disabled: idx >= ord_.length - 1 ? 'disabled' : null, onclick: function () { sel = ord_[idx + 1].uid; renderLista(); renderForm(); } }),
        el('button', { class: 'btn btn-success btn-sm', type: 'button', html: '<i class="bi bi-plus-lg"></i> Salvar e nova atividade', onclick: function () { window.addLinha(); } })]),
      el('div', { class: 'd-flex gap-2' }, [
        el('button', { class: 'btn btn-outline-secondary btn-sm', type: 'button', html: '<i class="bi bi-files"></i> Duplicar', onclick: function () { dup(r); } }),
        el('button', { class: 'btn btn-outline-danger btn-sm', type: 'button', html: '<i class="bi bi-trash"></i> Excluir', onclick: function () { excluir(r); } })])]));
  }

  function dup(r) {
    var c = JSON.parse(JSON.stringify(r)); c.uid = uid(); c.ordem = maxOrdem() + 1; A.push(c); sel = c.uid; marcar(); renderLista(); renderForm();
  }
  function excluir(r) {
    if ((r.descricao || r.entrada || r.saida) && !confirm('Excluir a atividade "' + rotuloAtiv(r) + '"?')) return;
    var o = ordenadas(), i = o.indexOf(r);
    A.splice(A.indexOf(r), 1);
    A.forEach(function (x) { limpaRef(x.seq, r.uid); (x.anexos || []).forEach(function (a) { if (a.alvo === r.uid) a.alvo = ''; }); });
    var viz = o[i + 1] || o[i - 1]; sel = viz && viz !== r ? viz.uid : (A[0] && A[0].uid) || null;
    marcar(); renderLista(); renderForm();
  }
  function limpaRef(o, u) { if (!o || typeof o !== 'object') return; Object.keys(o).forEach(function (k) { if (o[k] === u && (k === 'alvo' || k === 'assoc')) o[k] = ''; else limpaRef(o[k], u); }); }
  window.Folha.addLinha = function () { var n = novaLinha(); A.push(n); sel = n.uid; marcar(); renderLista(); renderForm(); var b = $('#s7Form .tipo-btn'); if (b) { b.scrollIntoView({ block: 'center' }); b.click(); } };
  window.Folha.ordenar = function () { A.sort(function (a, b) { return ordNum(a) - ordNum(b); }); marcar(); renderLista(); };
  window.Folha.renumerar = function () { window.Folha.ordenar(); A.forEach(function (r, i) { r.ordem = i + 1; }); marcar(); renderLista(); renderForm(); };

  // ---------------- gerar diagrama ----------------
  window.Folha.gerar = function () {
    var btns = document.querySelectorAll('[onclick="Folha.gerar()"]'); btns.forEach(function (b) { b.disabled = true; });
    API.call('gerar', payload())
      .then(function (r) {
        btns.forEach(function (b) { b.disabled = false; });
        if (!r.ok) { alert('Erro: ' + r.erro); return; }
        sujo = false; D.temDiagrama = true; $('#status').textContent = 'Salvo ✓'; atualizarStatusDiag(false);
        $('#btnVer').classList.remove('disabled');
        if (r.avisos && r.avisos.length) {
          var ul = $('#avLista'); ul.innerHTML = ''; r.avisos.forEach(function (t) { ul.appendChild(el('li', { text: t })); });
          $('#avAbrir').href = '#/diagrama?id=' + D.id; new bootstrap.Modal($('#mAvisos')).show();
        } else { Common.ir('#/diagrama?id=' + D.id); }
      }).catch(function (e) { btns.forEach(function (b) { b.disabled = false; }); alert('Erro ao gerar: ' + e); });
  };

  renderLista(); renderForm();
  });
})();
