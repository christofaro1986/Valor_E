/* charts.js — OPTIMUS: Chart.js + tendência + projeção (modelo SISREL) */
(function (w) {
  'use strict';
  var ChartLib = w.Chart;
  var instances = {};

  function calcularLinhaTendencia(valores) {
    var n = (valores || []).length;
    if (n === 0) return [];
    if (n === 1) return [valores[0]];
    var somaX = 0, somaY = 0, somaXY = 0, somaX2 = 0, qtd = 0;
    for (var i = 0; i < n; i++) {
      var y = valores[i];
      if (y === null || y === undefined || isNaN(y)) continue;
      somaX += i; somaY += y; somaXY += i * y; somaX2 += i * i; qtd++;
    }
    if (qtd < 2) return valores.map(function (v) { return (v !== null && !isNaN(v) ? v : null); });
    var denom = (qtd * somaX2 - somaX * somaX);
    var b = denom !== 0 ? (qtd * somaXY - somaX * somaY) / denom : 0;
    var a = (somaY - b * somaX) / qtd;
    return valores.map(function (_, i) { return a + b * i; });
  }

  function calcularMediaMovel(valores, janela) {
    janela = janela || 3;
    var n = (valores || []).length, out = [];
    for (var i = 0; i < n; i++) {
      var ini = Math.max(0, i - janela + 1), soma = 0, qtd = 0;
      for (var j = ini; j <= i; j++) {
        var v = valores[j];
        if (v !== null && v !== undefined && !isNaN(v)) { soma += v; qtd++; }
      }
      out.push(qtd > 0 ? soma / qtd : null);
    }
    return out;
  }

  /** Série histórica: valores + meta + tendência + média móvel + projeção */
  function graficoEvolucao(canvasId, labels, valores, metas, opts) {
    opts = opts || {};
    if (!ChartLib) {
      var el = document.getElementById(canvasId);
      if (el) el.parentNode.innerHTML = '<p class="muted">Biblioteca de gráficos indisponível.</p>';
      return null;
    }
    var canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    if (instances[canvasId]) { try { instances[canvasId].destroy(); } catch (e) {} delete instances[canvasId]; }

    var n = (valores || []).length;
    var tendencia = calcularLinhaTendencia(valores);
    var mediaMovel = calcularMediaMovel(valores, 3);
    var projLabels = [], projData = [];
    if (n >= 2) {
      var pts = mediaMovel.filter(function (v) { return v !== null && !isNaN(v); });
      var ritmo = 0;
      if (pts.length >= 2) {
        var nR = Math.min(3, pts.length - 1), somaDelta = 0;
        for (var k = pts.length - nR; k < pts.length; k++) somaDelta += pts[k] - pts[k - 1];
        ritmo = somaDelta / nR;
      }
      var base = pts.length ? pts[pts.length - 1] : valores[n - 1];
      for (var k = 1; k <= 3; k++) {
        var pv = base + ritmo * k;
        if (valores.length && Math.min.apply(null, valores.filter(function (v) { return v != null; })) >= 0)
          pv = Math.max(0, pv);
        projData.push(pv);
        projLabels.push('Proj. +' + k);
      }
    }
    var labelsExt = (labels || []).concat(projLabels);
    var valoresExt = valores.concat(projLabels.map(function () { return null; }));
    var ultimaMeta = metas && metas.length ? metas[metas.length - 1] : null;
    var metasExt = (metas || []).concat(projLabels.map(function () { return ultimaMeta; }));
    var mmExt = mediaMovel.concat(projLabels.map(function () { return null; }));
    var tendExt = tendencia.slice();
    if (n >= 2 && projLabels.length) {
      var sx = 0, sy = 0, sxy = 0, sx2 = 0, q = 0;
      for (var i = 0; i < n; i++) {
        var y = valores[i];
        if (y === null || y === undefined || isNaN(y)) continue;
        sx += i; sy += y; sxy += i * y; sx2 += i * i; q++;
      }
      var denom = (q * sx2 - sx * sx);
      var b = (q >= 2 && denom !== 0) ? (q * sxy - sx * sy) / denom : 0;
      var a = q > 0 ? (sy - b * sx) / q : 0;
      for (var k = 0; k < projLabels.length; k++) tendExt.push(a + b * (n + k));
    }
    var projExt = valores.map(function () { return null; }).concat(projData);
    // connect projection start
    if (projData.length && n > 0) {
      projExt[n - 1] = valores[n - 1];
    }

    var datasets = [
      {
        label: opts.labelValor || 'Valor',
        data: valoresExt,
        borderColor: '#1d5fd0',
        backgroundColor: 'rgba(47,93,75,0.12)',
        borderWidth: 2.5,
        pointRadius: 4,
        pointBackgroundColor: '#1d5fd0',
        tension: 0.25,
        fill: false,
        spanGaps: false
      }
    ];
    if (metas && metas.length) {
      datasets.push({
        label: opts.labelMeta || 'Meta',
        data: metasExt,
        borderColor: '#c47a00',
        borderWidth: 2,
        borderDash: [6, 4],
        pointRadius: 0,
        fill: false,
        tension: 0
      });
    }
    if (n >= 2) {
      datasets.push({
        label: 'Tendência',
        data: tendExt,
        borderColor: '#1565c0',
        borderWidth: 1.5,
        borderDash: [4, 4],
        pointRadius: 0,
        fill: false,
        tension: 0
      });
      datasets.push({
        label: 'Média móvel (3)',
        data: mmExt,
        borderColor: '#6b7a70',
        borderWidth: 1.5,
        pointRadius: 0,
        fill: false,
        tension: 0.3
      });
    }
    if (projData.length) {
      datasets.push({
        label: 'Projeção',
        data: projExt,
        borderColor: '#9c27b0',
        borderWidth: 2,
        borderDash: [2, 3],
        pointRadius: 3,
        pointStyle: 'triangle',
        fill: false,
        spanGaps: true,
        tension: 0.2
      });
    }

    var chart = new ChartLib(canvas.getContext('2d'), {
      type: 'line',
      data: { labels: labelsExt, datasets: datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } },
          title: opts.titulo ? { display: true, text: opts.titulo, font: { size: 13, weight: '600' } } : { display: false },
          tooltip: {
            callbacks: {
              label: function (ctx) {
                var v = ctx.parsed.y;
                if (v == null || isNaN(v)) return ctx.dataset.label + ': —';
                return ctx.dataset.label + ': ' + (Math.round(v * 100) / 100);
              }
            }
          }
        },
        scales: {
          x: { ticks: { maxRotation: 45, font: { size: 10 } }, grid: { color: 'rgba(0,0,0,0.04)' } },
          y: {
            type: opts.logScale ? 'logarithmic' : 'linear',
            beginAtZero: !opts.logScale,
            grid: { color: 'rgba(0,0,0,0.06)' },
            ticks: { font: { size: 10 } }
          }
        }
      }
    });
    instances[canvasId] = chart;
    return chart;
  }

  function graficoBarras(canvasId, labels, valores, opts) {
    opts = opts || {};
    if (!ChartLib) return null;
    var canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    if (instances[canvasId]) { try { instances[canvasId].destroy(); } catch (e) {} delete instances[canvasId]; }
    var metaRef = opts.metaCiclo != null ? +opts.metaCiclo : null;
    if (metaRef != null && metaRef > 1) metaRef = metaRef / 100;
    var cores = opts.cores || (valores || []).map(function (v) {
      if (v == null) return '#9e9e9e';
      if (metaRef != null) {
        if (v + 1e-9 >= metaRef) return '#2e7d46';
        if (v + 1e-9 >= metaRef * 0.8) return '#c47a00';
        return '#c62828';
      }
      if (v + 1e-9 >= MET.LIM.conf) return '#2e7d46';
      if (v + 1e-9 >= MET.LIM.aten) return '#c47a00';
      return '#c62828';
    });
    var chart = new ChartLib(canvas.getContext('2d'), {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          clip: false,
          label: opts.label || 'Índice',
          data: valores.map(function (v) { return v == null ? null : +(v * 100).toFixed(1); }),
          backgroundColor: cores,
          borderRadius: 6,
          maxBarThickness: 48
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: { top: 14 } },
        plugins: {
          legend: { display: false },
          title: opts.titulo ? { display: true, text: opts.titulo, font: { size: 13, weight: '600' } } : { display: false },
          tooltip: { callbacks: { label: function (c) { return (c.parsed.y != null ? c.parsed.y + '%' : '—'); } } }
        },
        scales: {
          y: { beginAtZero: true, max: 100, ticks: { callback: function (v) { return v + '%'; } } }
        }
      }
    });
    instances[canvasId] = chart;
    return chart;
  }


  /* ---------- gráficos do painel de monitoramento ---------- */
  var COR = { ok: '#2e7d46', atencao: '#c47a00', critico: '#c62828', 'sem-dados': '#9e9e9e' };
  function corDe(v) { return v == null ? COR['sem-dados'] : (v + 1e-9 >= MET.LIM.conf ? COR.ok : (v + 1e-9 >= MET.LIM.aten ? COR.atencao : COR.critico)); }
  function limpa(id) { if (instances[id]) { try { instances[id].destroy(); } catch (e) {} delete instances[id]; } }
  var plugFaixas = {
    id: 'faixas',
    beforeDatasetsDraw: function (ch, a, o) {
      var sc = ch.scales[o.eixo || 'x'], ca = ch.chartArea, ctx = ch.ctx; if (!sc || !o.on) return;
      var horiz = (o.eixo || 'x') === 'x', p = function (v) { return sc.getPixelForValue(v); };
      var c = MET.LIM.conf * 100, t = MET.LIM.aten * 100;
      function faixa(v0, v1, cor) { ctx.fillStyle = cor; if (horiz) ctx.fillRect(p(v0), ca.top, p(v1) - p(v0), ca.bottom - ca.top); else ctx.fillRect(ca.left, p(v1), ca.right - ca.left, p(v0) - p(v1)); }
      ctx.save(); faixa(0, t, 'rgba(198,40,40,.07)'); faixa(t, c, 'rgba(196,122,0,.08)'); faixa(c, 100, 'rgba(46,125,70,.07)');
      ctx.setLineDash([4, 4]); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(60,60,60,.45)'; ctx.fillStyle = 'rgba(60,60,60,.75)'; ctx.font = '11px sans-serif';
      [[t, Math.round(t) + '%'], [c, Math.round(c) + '%']].forEach(function (L) {
        ctx.beginPath(); if (horiz) { ctx.moveTo(p(L[0]), ca.top); ctx.lineTo(p(L[0]), ca.bottom); } else { ctx.moveTo(ca.left, p(L[0])); ctx.lineTo(ca.right, p(L[0])); } ctx.stroke();
      });
      ctx.restore();
    }
  };
  var plugRotulos = {
    id: 'rotulosValor',
    afterDatasetsDraw: function (ch, a, o) {
      if (!o.on) return; var ctx = ch.ctx, ds = ch.getDatasetMeta(0), d = ch.data.datasets[0].data;
      ctx.save(); ctx.font = 'bold 12px sans-serif'; ctx.textBaseline = 'middle';
      ds.data.forEach(function (el, i) {
        var v = d[i], txt = v == null ? 'sem dados' : v.toFixed(1).replace('.', ',') + '%', pos = el.tooltipPosition();
        if (o.horizontal) { ctx.textAlign = 'left'; ctx.fillStyle = '#1c2a24'; ctx.fillText(txt, Math.max(el.x, ch.scales.x.getPixelForValue(0)) + 6, el.y); }
        else { ctx.textAlign = 'center'; ctx.fillStyle = '#1c2a24'; ctx.fillText(txt, el.x, el.y - 10); }
      });
      ctx.restore();
    }
  };

  /** Quebra rótulo longo em linhas (máx. 3) para caber no eixo, sem cortar. */
  function quebra(t, max) {
    t = String(t == null ? '' : t); if (t.length <= max) return t;
    var ps = t.split(/\s+/), ln = [], cur = '';
    ps.forEach(function (p) { if (cur && (cur + ' ' + p).length > max) { ln.push(cur); cur = p; } else cur = cur ? cur + ' ' + p : p; });
    if (cur) ln.push(cur);
    if (ln.length > 3) { ln = ln.slice(0, 3); ln[2] = ln[2].slice(0, max - 1) + '…'; }
    return ln;
  }

  /** Barras horizontais (0–100%) com faixas de situação, rótulos e clique. vals em fração (0–1) ou null. */
  function barrasH(id, labels, vals, o) {
    o = o || {}; var canvas = document.getElementById(id); if (!ChartLib || !canvas) return null; limpa(id);
    var completos = labels.slice(); labels = labels.map(function (l) { return quebra(l, o.quebra || 26); });
    var dados = vals.map(function (v) { return v == null ? null : +(v * 100).toFixed(1); });
    var cores = vals.map(function (v, i) { var b = corDe(v); return o.sel === i ? b : b + 'cc'; });
    var ch = new ChartLib(canvas.getContext('2d'), {
      type: 'bar', plugins: [plugFaixas, plugRotulos],
      data: { labels: labels, datasets: [{ clip: false, label: o.label || '%', data: dados, backgroundColor: cores, borderRadius: 5, barPercentage: .72, categoryPercentage: .86,
        borderColor: vals.map(function (v, i) { return o.sel === i ? '#0b2447' : 'transparent'; }), borderWidth: vals.map(function (v, i) { return o.sel === i ? 2.5 : 0; }) }] },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false, layout: { padding: { right: 70, left: 4, top: 6, bottom: 2 } },
        onClick: function (e, els) { if (o.onClick && els.length) o.onClick(els[0].index); },
        onHover: function (e, els) { e.native.target.style.cursor = (o.onClick && els.length) ? 'pointer' : 'default'; },
        plugins: { legend: { display: false }, faixas: { on: true, eixo: 'x' }, rotulosValor: { on: true, horizontal: true },
          tooltip: { callbacks: { title: function (it) { return it.length ? completos[it[0].dataIndex] : ''; }, label: function (c) { return c.parsed.x != null ? (o.label || '') + ' ' + c.parsed.x.toFixed(1).replace('.', ',') + '%' : 'sem dados'; } } } },
        scales: { x: { min: 0, max: 100, ticks: { callback: function (v) { return v + '%'; } }, grid: { display: false } }, y: { grid: { display: false }, ticks: { font: { size: 12 }, autoSkip: false } } }
      }
    });
    instances[id] = ch; return ch;
  }

  /** Rosca de situação com total no centro. */
  function rosca(id, labels, vals, cores, centro) {
    var canvas = document.getElementById(id); if (!ChartLib || !canvas) return null; limpa(id);
    var plug = { id: 'centroTxt', afterDraw: function (ch) {
      var m = ch.getDatasetMeta(0).data[0]; if (!m) return; var ctx = ch.ctx; ctx.save(); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#0b2447'; ctx.font = 'bold 30px sans-serif'; ctx.fillText(centro.valor, m.x, m.y - 8); ctx.fillStyle = '#5c6b63'; ctx.font = '12px sans-serif'; ctx.fillText(centro.rotulo, m.x, m.y + 16); ctx.restore(); } };
    var ch = new ChartLib(canvas.getContext('2d'), { type: 'doughnut', plugins: [plug],
      data: { labels: labels, datasets: [{ data: vals, backgroundColor: cores, borderColor: '#fff', borderWidth: 3, hoverOffset: 6 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '68%', plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 14 } } } } });
    instances[id] = ch; return ch;
  }

  /** Radar do desempenho por dimensão (0–100%). */
  function radar(id, labels, vals) {
    var canvas = document.getElementById(id); if (!ChartLib || !canvas) return null; limpa(id);
    var ch = new ChartLib(canvas.getContext('2d'), { type: 'radar',
      data: { labels: labels, datasets: [
        { label: 'Desempenho', data: vals.map(function (v) { return v == null ? 0 : +(v * 100).toFixed(1); }), backgroundColor: 'rgba(47,93,75,.22)', borderColor: '#1d5fd0', borderWidth: 2.5, pointBackgroundColor: vals.map(corDe), pointRadius: 5 },
        { label: 'Meta de conformidade (' + Math.round(MET.LIM.conf * 100) + '%)', data: vals.map(function () { return MET.LIM.conf * 100; }), borderColor: 'rgba(46,125,70,.7)', borderDash: [5, 4], borderWidth: 1.5, pointRadius: 0, fill: false } ] },
      options: { responsive: true, maintainAspectRatio: false, scales: { r: { min: 0, max: 100, ticks: { stepSize: 25, backdropColor: 'transparent', callback: function (v) { return v + '%'; } }, pointLabels: { font: { size: 12, weight: '600' } } } },
        plugins: { legend: { position: 'bottom', labels: { usePointStyle: true } } } } });
    instances[id] = ch; return ch;
  }

  /** Pareto do déficit: barras (participação %) + linha acumulada. itens: [{nome, part, classe}] */
  function pareto(id, itens) {
    var canvas = document.getElementById(id); if (!ChartLib || !canvas) return null; limpa(id);
    var acum = 0, cum = itens.map(function (i) { acum += i.part; return +(Math.min(1, acum) * 100).toFixed(1); });
    var corC = { A: '#c62828', B: '#c47a00', C: '#9e9e9e' };
    var ch = new ChartLib(canvas.getContext('2d'), { data: { labels: itens.map(function (i) { return i.nome; }), datasets: [
        { type: 'bar', label: 'Participação no déficit (%)', data: itens.map(function (i) { return +(i.part * 100).toFixed(1); }), backgroundColor: itens.map(function (i) { return corC[i.classe] || '#9e9e9e'; }), borderRadius: 5, yAxisID: 'y', order: 2 },
        { type: 'line', clip: false, label: 'Acumulado (%)', data: cum, borderColor: '#0b2447', backgroundColor: '#0b2447', tension: .25, pointRadius: 4, yAxisID: 'y1', order: 1 } ] },
      options: { responsive: true, maintainAspectRatio: false, layout: { padding: { top: 12, right: 6 } }, interaction: { mode: 'index', intersect: false },
        plugins: { legend: { position: 'bottom', labels: { usePointStyle: true } } },
        scales: { y: { min: 0, ticks: { callback: function (v) { return v + '%'; } }, title: { display: true, text: 'Participação' } }, y1: { position: 'right', min: 0, max: 100, grid: { display: false }, ticks: { callback: function (v) { return v + '%'; } }, title: { display: true, text: 'Acumulado' } }, x: { grid: { display: false }, ticks: { maxRotation: 35, minRotation: 0 } } } } });
    instances[id] = ch; return ch;
  }

  /** Evolução histórica (0–100%) de vários índices (ICV/IHC) com faixas de situação. series: [{nome, vals(fração|null)}] */
  var PAL = ['#1d5fd0', '#1565c0', '#8e24aa', '#ef6c00', '#00897b', '#6d4c41', '#d81b60', '#546e7a'];
  function lineHist(id, labels, series) {
    var canvas = document.getElementById(id); if (!ChartLib || !canvas) return null; limpa(id);
    var ch = new ChartLib(canvas.getContext('2d'), { type: 'line', plugins: [plugFaixas],
      data: { labels: labels, datasets: series.map(function (s, i) { var cor = PAL[i % PAL.length];
        return { clip: false, label: s.nome, data: s.vals.map(function (v) { return v == null ? null : +(v * 100).toFixed(1); }), borderColor: cor, backgroundColor: cor, borderWidth: 2.5, tension: .25, pointRadius: 4, pointHoverRadius: 6, spanGaps: true }; }) },
      options: { responsive: true, maintainAspectRatio: false, layout: { padding: { top: 12, right: 14, left: 4 } }, interaction: { mode: 'index', intersect: false },
        plugins: { legend: { position: 'bottom', labels: { usePointStyle: true } }, faixas: { on: true, eixo: 'y' }, tooltip: { callbacks: { label: function (c) { return c.dataset.label + ': ' + (c.parsed.y == null ? '—' : c.parsed.y.toFixed(1).replace('.', ',') + '%'); } } } },
        scales: { y: { min: 0, max: 100, ticks: { callback: function (v) { return v + '%'; } } }, x: { grid: { display: false } } } } });
    instances[id] = ch; return ch;
  }

  w.OPTCharts = {
    lineHist: lineHist,
    barrasH: barrasH, rosca: rosca, radar: radar, pareto: pareto,
    evolucao: graficoEvolucao,
    barras: graficoBarras,
    tendencia: calcularLinhaTendencia,
    mediaMovel: calcularMediaMovel,
    destroy: function (id) { if (instances[id]) { try { instances[id].destroy(); } catch (e) {} delete instances[id]; } },
    destroyAll: function () {
      Object.keys(instances).forEach(function (k) {
        try { instances[k].destroy(); } catch (e) {}
        delete instances[k];
      });
    }
  };
})(window);
