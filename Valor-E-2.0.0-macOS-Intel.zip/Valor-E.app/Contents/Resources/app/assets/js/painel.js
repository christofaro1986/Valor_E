/* painel.js — Painel geral do Valor-E: visão integrada e verificação das relações entre módulos (duplo sentido). */
(function (w) {
  'use strict';
  var h = E.esc;
  function n(sql, p) { try { return DB.one(sql, p).n; } catch (e) { return 0; } }
  function card(ic, titulo, grande, sub, href, cor) {
    return '<a class="pn-card" href="' + href + '" style="border-top-color:' + cor + '"><div class="pn-ic" style="color:' + cor + '"><i class="bi ' + ic + '"></i></div><div class="pn-t">' + titulo + '</div><div class="pn-v">' + grande + '</div><div class="pn-s">' + sub + '</div></a>';
  }
  function lacuna(qtd, txt, href) { return qtd ? '<a class="pn-gap" href="' + href + '"><b>' + qtd + '</b> ' + txt + '</a>' : ''; }
  function html() {
    var P = E.painelDados(''), AL = E.alertasTodos(''), AC = E.alertasContagem(AL), I = (w.Ind && w.Ind.resumo) ? w.Ind.resumo() : {}, V = (w.Val && w.Val.resumo) ? w.Val.resumo() : {}, C = (w.Cva && w.Cva.resumo) ? w.Cva.resumo() : null;
    I = I || {}; V = V || { capacidades: 0, objetivos: 0, indicadores: 0 };
    var nProc = n('SELECT COUNT(*) AS n FROM processos'), nMacro = n('SELECT COUNT(*) AS n FROM macroprocessos'), nInd = I.total, nDim = n('SELECT COUNT(*) AS n FROM fatores_determinantes');
    var nProj = n('SELECT COUNT(*) AS n FROM projetos'), nTar = n('SELECT COUNT(*) AS n FROM proj_tarefas'), nProjAnd = n("SELECT COUNT(*) AS n FROM projetos WHERE status = 'Em andamento'");
    var niv = P.niveis || {}, ext = (niv['Extremo'] || 0) + (niv['Alto'] || 0);
    var o = '<div class="pagina"><div class="d-flex align-items-center mb-3"><h1 class="h4 mb-0 me-auto">Painel de gestão organizacional</h1>' + (w.Org ? Org.seletor() : '') + (w.Exportar ? Exportar.botoes() : '') + '<span class="text-muted small ms-3">' + E.dataBr(E.hoje()) + '</span></div><div class="pn-grid">' +
      card('bi-bezier2', 'Cadeia de valor', C ? C.macros : 0, C ? h(C.ciclo) + ' — ' + h(C.validade) : 'Cadastre o ciclo da CVA', '#/cva', '#0ea5c6') +
      card('bi-diagram-2', 'Mapa Estratégico', (w.Mapa && w.Mapa.resumo()) ? w.Mapa.resumo().objetivos : 0, (w.Mapa && w.Mapa.resumo()) ? h(w.Mapa.resumo().nome) : 'Crie o mapa estratégico (BSC)', '#/estrategia', '#1d4f91') +
      card('bi-diagram-3', 'Processos', nProc, nMacro + ' macroprocesso(s) na CVA', '#/processos', '#0a6fc2') +
      card('bi-kanban', 'Projetos', nProj, nProjAnd + ' em andamento · ' + nTar + ' tarefa(s)', '#/projetos', '#0f766e') +
      card('bi-graph-up-arrow', 'Indicadores', nInd, I.vermelho + ' críticos · ' + I.amarelo + ' em atenção · ' + I.verde + ' em conformidade', '#/indicadores', '#7c3aed') +
      card('bi-exclamation-triangle', 'Riscos', P.total, ext + ' alto/extremo · ' + (AC.critico || 0) + ' alerta(s) crítico(s)', '#/painelrisco', '#f59e0b') +
      card('bi-bullseye', 'Valor Estratégico', V.icv == null ? '—' : (V.icv * 100).toFixed(1).replace('.', ',') + '%', V.objetivos + ' objetivo(s) · ' + V.capacidades + ' capacidade(s) · ' + nDim + ' dimensão(ões)', '#/valor', '#10b981') + '</div>';
    var avCopia = w.Pontos ? Pontos.avisoCopia() : '';
    if (avCopia) o += '<div class="alert alert-warning mt-3 mb-0 py-2 small"><i class="bi bi-hdd"></i> ' + h(avCopia) + ' <a href="#/dados">Abrir</a></div>';
    // relações
    var gaps = [
      lacuna(n('SELECT COUNT(*) AS n FROM processos WHERE macro_id IS NULL'), 'processo(s) sem macroprocesso vinculante', '#/processos'),
      lacuna(n('SELECT COUNT(*) AS n FROM processos p WHERE NOT EXISTS (SELECT 1 FROM indicadores i WHERE i.processo_id = p.id)'), 'processo(s) sem indicador', '#/processos'),
      lacuna(n('SELECT COUNT(*) AS n FROM processos p WHERE NOT EXISTS (SELECT 1 FROM riscos r WHERE r.processo_id = p.id)'), 'processo(s) sem risco identificado', '#/processos'),
      lacuna(n('SELECT COUNT(*) AS n FROM projetos p WHERE NOT EXISTS (SELECT 1 FROM proj_tarefas t WHERE t.projeto_id = p.id)'), 'projeto(s) sem tarefas', '#/projetos'),
      lacuna(n("SELECT COUNT(*) AS n FROM projetos WHERE status = 'Em andamento' AND progresso < 100"), 'projeto(s) em andamento', '#/projetos'),
      lacuna(n('SELECT COUNT(*) AS n FROM indicadores WHERE processo_id IS NULL'), 'indicador(es) sem processo vinculado', '#/indicadores'),
      lacuna(n('SELECT COUNT(*) AS n FROM indicadores i WHERE NOT EXISTS (SELECT 1 FROM indicador_fatores x WHERE x.indicador_id = i.id)'), 'indicador(es) não usados em nenhuma dimensão', '#/indicadores'),
      lacuna(n('SELECT COUNT(*) AS n FROM fatores_determinantes f WHERE NOT EXISTS (SELECT 1 FROM indicador_fatores x WHERE x.fator_id = f.id)'), 'dimensão(ões) sem indicador', '#/valor'),
      lacuna(n('SELECT COUNT(*) AS n FROM capacidades c WHERE NOT EXISTS (SELECT 1 FROM objetivo_capacidades x WHERE x.capacidade_id = c.id)'), 'capacidade(s) sem objetivo estratégico', '#/valor'),
      lacuna(n('SELECT COUNT(*) AS n FROM riscos WHERE processo_id IS NULL AND projeto_id IS NULL'), 'risco(s) sem processo nem projeto (ambiente livre)', '#/riscos'),
      lacuna(n('SELECT COUNT(*) AS n FROM projetos p WHERE NOT EXISTS (SELECT 1 FROM riscos r WHERE r.projeto_id = p.id)'), 'projeto(s) sem risco identificado', '#/projetos')
    ].join('');
    o += '<div class="row g-3 mt-1"><div class="col-lg-7"><div class="cartao"><h2><i class="bi bi-link-45deg"></i> Cadeia de relações</h2><div class="corpo"><div class="pn-cadeia">' +
      [['bi-bezier2', 'Macroprocesso', nMacro], ['bi-diagram-3', 'Processo', nProc], ['bi-kanban', 'Projeto', nProj], ['bi-graph-up-arrow', 'Indicador', nInd], ['bi-layers', 'Dimensão', nDim], ['bi-stars', 'Capacidade', V.capacidades], ['bi-bullseye', 'Objetivo', V.objetivos]].map(function (x) { return '<div class="pn-no"><i class="bi ' + x[0] + '"></i><b>' + x[2] + '</b><span>' + x[1] + '</span></div>'; }).join('<div class="pn-seta">→</div>') +
      '</div><div class="pn-cadeia" style="margin-top:10px"><div class="pn-no"><i class="bi bi-diagram-3"></i><b>' + nProc + '</b><span>Processo</span></div><div class="pn-seta">⇄</div><div class="pn-no"><i class="bi bi-flag-fill"></i><b>' + n('SELECT COUNT(*) AS n FROM flags') + '</b><span>Bandeira</span></div><div class="pn-seta">⇄</div><div class="pn-no"><i class="bi bi-exclamation-triangle"></i><b>' + n('SELECT COUNT(*) AS n FROM riscos WHERE processo_id IS NOT NULL') + '</b><span>Risco do processo</span></div></div>' +
      '<p class="ajuda mt-2 mb-0">Todas as relações têm duplo sentido: o que se cadastra de um lado aparece e pode ser aberto do outro.</p></div></div></div>' +
      '<div class="col-lg-5"><div class="cartao"><h2><i class="bi bi-shield-check"></i> Integridade das relações</h2><div class="corpo">' + (gaps || '<div class="text-success"><i class="bi bi-check-circle-fill"></i> Todas as relações estão completas.</div>') + '</div></div></div></div>';
    var top = (P.top || []).slice(0, 5);
    if (top.length) o += '<div class="cartao"><h2><i class="bi bi-fire"></i> Riscos mais críticos</h2><div class="corpo"><table class="tabela"><tbody>' + top.map(function (r) { return '<tr><td><b>' + h(r.codigo || '') + '</b></td><td><a href="#/risco?id=' + r.id + '">' + h(r.nome) + '</a></td><td>' + h(r.ambiente) + '</td><td><span class="nv ' + h(String(r.nivel_res || r.nivel_medio).replace(/ /g, '-')) + '">' + h(r.nivel_res || r.nivel_medio) + '</span></td></tr>'; }).join('') + '</tbody></table></div></div>';
    return o + '</div>';
  }
  Modulos.registrar('/', { ativo: 'painel', titulo: 'Painel', html: html });
})(window);
