/* app.js — inicialização */
(function (w) {
  'use strict';
  var avisou = false;
  DB.erroGravar = function (m) { if (avisou) return; avisou = true; alert('Não foi possível gravar os dados no disco: ' + m + '\nExporte um backup pelo menu "Mais" assim que possível.'); };
  DB.iniciar().then(function () {
    if (window.SEC) { SEC.installActivityWatchers(); SEC.touch(); SEC.audit('inicio', 'aplicativo'); }
    Rota();
  }).catch(function (e) {
    document.getElementById('raiz').innerHTML = '<div style="padding:40px;font-family:sans-serif;color:#b71c1c"><h3>Não foi possível abrir o banco de dados</h3><pre style="white-space:pre-wrap">' + String(e && (e.stack || e.message) || e).replace(/</g, '&lt;') + '\n\n' + navigator.userAgent + '</pre></div>';
  });
})(window);
