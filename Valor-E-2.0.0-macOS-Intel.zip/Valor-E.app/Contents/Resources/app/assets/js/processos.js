/* processos.js — processos (Folha de dados + diagrama BPMN), flags de risco no diagrama e o vínculo flag ↔ riscos.
 * Regra central: a flag marca uma atividade (elemento) do diagrama do processo; cada risco identificado nela é um risco completo
 * do módulo de riscos (mesmo registro, mesmo id). Não há cópia: editar ou excluir de um lado vale para o outro. */
(function (w) {
  'use strict';
  var E = w.E;
  function S(v, max) { v = String(v == null ? '' : v).trim(); return Array.from(v).slice(0, max || 4000).join(''); }

  E.STATUS_PROCESSO = ['Ativo', 'Em revisão', 'Arquivado'];
  E.rotuloItem = function () { return 'Atividade'; };

  // ---------- processos ----------
  E.processosListar = function (f) {
    f = f || {}; var w = [], p = [];
    if (f.macro) { w.push('c.macro_id = ?'); p.push(f.macro); }
    if (f.cadeia) { w.push('c.macro_id IN (SELECT m.id FROM macroprocessos m JOIN cva_ciclos cc ON cc.id = m.ciclo_id WHERE cc.cadeia = ?)'); p.push(f.cadeia); }
    if (f.q) { w.push('(c.nome LIKE ? OR c.descricao LIKE ? OR c.responsavel LIKE ?)'); var q = '%' + f.q + '%'; p.push(q, q, q); }
    return DB.all("SELECT c.*, (SELECT m.nome FROM macroprocessos m WHERE m.id = c.macro_id) AS macro_nome, (SELECT cc.cadeia FROM macroprocessos m JOIN cva_ciclos cc ON cc.id = m.ciclo_id WHERE m.id = c.macro_id) AS cadeia, " +
      "(SELECT COUNT(*) FROM flags WHERE processo_id = c.id) AS n_flags, " +
      "(SELECT COUNT(*) FROM riscos WHERE processo_id = c.id) AS n_riscos, " +
      (E.tabelaExiste('indicadores') ? "(SELECT COUNT(*) FROM indicadores WHERE processo_id = c.id)" : "0") + " AS n_ind FROM processos c" +
      (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY c.nome COLLATE NOCASE', p);
  };
  E.processoCarregar = function (id) { return DB.one('SELECT * FROM processos WHERE id = ?', [id]); };

  E.processoSalvar = function (d) {
    var nome = S(d.nome, 300);
    if (nome === '') throw new Error('Informe o nome do processo.');
    var id = parseInt(d.id, 10) || 0;
    if (DB.one('SELECT 1 AS x FROM processos WHERE nome = ? COLLATE NOCASE AND id != ?', [nome, id])) throw new Error('Já existe um processo com este nome.');
    var macro = parseInt(d.macro_id, 10) || null;
    return DB.tx(function () {
      if (id > 0 && DB.one('SELECT 1 AS x FROM processos WHERE id = ?', [id])) {
        DB.run("UPDATE processos SET nome=?,macro_id=?,descricao=?,responsavel=?,status=?,atualizado_em=CURRENT_TIMESTAMP WHERE id=?",
          [nome, macro, S(d.descricao), S(d.responsavel, 300), S(d.status || 'Ativo', 40), id]);
        DB.run('UPDATE riscos SET ambiente = ? WHERE processo_id = ?', [nome, id]);   // o ambiente de análise dos riscos acompanha o nome
      } else {
        DB.run('INSERT INTO processos (nome,macro_id,descricao,responsavel,status,folha_json) VALUES (?,?,?,?,?,?)',
          [nome, macro, S(d.descricao), S(d.responsavel, 300), S(d.status || 'Ativo', 40), JSON.stringify(w.API ? w.API.folhaPadrao() : {})]);
        id = DB.lastId();
      }
      return id;
    });
  };
  E.processoMacro = function (id, macroId) { DB.tx(function () { DB.run('UPDATE processos SET macro_id = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?', [parseInt(macroId, 10) || null, id]); }); };

  /** Exclui o processo, suas flags e os riscos vinculados a ele (os indicadores ficam, sem processo). */
  E.tabelaExiste = function (t) { return !!DB.one("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?", [t]); };
  /** modo: 'riscos' (padrão) exclui também os riscos do processo; 'manter' mantém os riscos, sem vínculo e com o ambiente preservado. */
  E.processoExcluir = function (id, modo) {
    DB.tx(function () {
      if (modo === 'manter') DB.run('UPDATE riscos SET processo_id = NULL, flag_id = NULL WHERE processo_id = ?', [id]);
      else DB.run('DELETE FROM riscos WHERE processo_id = ?', [id]);
      DB.run('DELETE FROM flags WHERE processo_id = ?', [id]);
      if (E.tabelaExiste('indicadores')) DB.run('UPDATE indicadores SET processo_id = NULL WHERE processo_id = ?', [id]);
      DB.run('DELETE FROM processos WHERE id = ?', [id]);
    });
  };

  /** Elementos do diagrama (atividades, eventos, decisões…) que aceitam flag de risco, lidos do BPMN do processo. */
  var NAO_ALVO = /^(participant|lane|laneSet|process|collaboration|definitions|messageFlow|sequenceFlow|association|group|textAnnotation)$/;
  E.processoElementos = function (id) {
    var p = typeof id === 'object' ? id : E.processoCarregar(id); if (!p || !p.bpmn_xml) return [];
    var d = new DOMParser().parseFromString(p.bpmn_xml, 'application/xml'), tipo = {}, nome = {}, todos = d.getElementsByTagName('*'), out = [];
    for (var i = 0; i < todos.length; i++) { var e = todos[i], eid = e.getAttribute('id'); if (eid) { tipo[eid] = e.localName; nome[eid] = e.getAttribute('name') || ''; } }
    var sh = d.getElementsByTagNameNS('*', 'BPMNShape');
    for (var j = 0; j < sh.length; j++) { var be = sh[j].getAttribute('bpmnElement'); if (be && tipo[be] && !NAO_ALVO.test(tipo[be])) out.push({ id: be, tipo: tipo[be], nome: nome[be] || '' }); }
    return out;
  };

  // ---------- flags (uma por elemento do diagrama) ----------
  E.flagsDoProcesso = function (procId) {
    var fl = DB.all('SELECT * FROM flags WHERE processo_id = ? ORDER BY id', [procId]);
    fl.forEach(function (f, i) {
      f.n = i + 1;
      f.riscos = DB.all('SELECT id, codigo, nome, categoria, status, nivel_medio, nivel_res, indice_medio, indice_res FROM riscos WHERE flag_id = ? ORDER BY id', [f.id]);
      var ord = 0; f.riscos.forEach(function (r) { var o = E.nivelOrdem(r.nivel_res || r.nivel_medio); if (o > ord) { ord = o; f.nivel = r.nivel_res || r.nivel_medio; } });
      if (!ord) f.nivel = null;
    });
    return fl;
  };
  E.flagCarregar = function (id) { return DB.one('SELECT * FROM flags WHERE id = ?', [id]); };
  E.flagDoElemento = function (procId, elemento, tarefa) {
    var f = DB.one('SELECT id FROM flags WHERE processo_id = ? AND elemento = ?', [procId, elemento]);
    if (f) { if (tarefa != null) E.flagTarefa(f.id, tarefa); return f.id; }
    if (!E.processoCarregar(procId)) throw new Error('Processo não encontrado.');
    return DB.tx(function () { DB.run('INSERT INTO flags (processo_id,elemento,tarefa) VALUES (?,?,?)', [procId, S(elemento, 200), S(tarefa, 500)]); return DB.lastId(); });
  };
  E.flagTarefa = function (id, tarefa) { DB.tx(function () { DB.run('UPDATE flags SET tarefa = ? WHERE id = ?', [S(tarefa, 500), id]); }); };
  E.flagsSincronizar = function (procId) {    // o nome da flag acompanha o nome da atividade no diagrama; devolve as flags órfãs
    var els = {}; E.processoElementos(procId).forEach(function (e) { els[e.id] = e; });
    var orf = [];
    E.flagsDoProcesso(procId).forEach(function (f) { var e = els[f.elemento]; if (!e) orf.push(f); else if (e.nome !== f.tarefa) E.flagTarefa(f.id, e.nome); });
    return orf;
  };
  /** Exclui a flag. modo 'riscos' (padrão): exclui também os riscos vinculados; 'manter': os riscos ficam, sem vínculo à tarefa. */
  E.flagExcluir = function (id, modo) {
    DB.tx(function () {
      if (modo === 'manter') DB.run('UPDATE riscos SET flag_id = NULL WHERE flag_id = ?', [id]);
      else DB.run('DELETE FROM riscos WHERE flag_id = ?', [id]);
      DB.run('DELETE FROM flags WHERE id = ?', [id]);
    });
  };

  // ---------- riscos ligados ao processo ----------
  E.proximoCodigoRisco = function () {
    var m = (DB.one("SELECT MAX(CAST(SUBSTR(codigo,2) AS INTEGER)) AS m FROM riscos WHERE codigo GLOB 'R[0-9]*'") || {}).m || 0;
    return 'R' + (m + 1);
  };
  E.codigoRiscoLivre = function (cod, exceto) { return !DB.one('SELECT 1 AS x FROM riscos WHERE codigo = ? COLLATE NOCASE AND id != ?', [cod, exceto || 0]); };
  /** Identifica um risco na flag: cria o registro (sem causas ainda) no módulo de riscos, com ambiente = nome do processo. */
  E.flagRiscoAdicionar = function (flagId, d) {
    var f = E.flagCarregar(flagId); if (!f) throw new Error('Flag não encontrada.');
    var c = E.processoCarregar(f.processo_id), nome = S(d.nome, 500); if (nome === '') throw new Error('Informe o nome do risco.');
    var cod = S(d.codigo, 20) || E.proximoCodigoRisco();
    if (!E.codigoRiscoLivre(cod)) throw new Error('O código ' + cod + ' já está em uso por outro risco.');
    return E.riscoSalvar({
      codigo: cod, nome: nome, ambiente: c.nome, processo_id: c.id, flag_id: f.id, status: 'Identificado',
      categoria: S(d.categoria, 100),
      descricao: 'Risco identificado na atividade "' + (f.tarefa || f.elemento) + '" do processo "' + c.nome + '".', fatores: []
    });
  };
  /** Edita código / nome / categoria do risco (vale nos dois lados: é o próprio registro do módulo de riscos). */
  E.riscoEditarBasico = function (id, d) {
    var nome = S(d.nome, 500); if (nome === '') throw new Error('O nome do risco não pode ficar vazio.');
    var cod = S(d.codigo, 20); if (cod && !E.codigoRiscoLivre(cod, id)) throw new Error('O código ' + cod + ' já está em uso por outro risco.');
    DB.tx(function () { DB.run('UPDATE riscos SET nome = ?, categoria = ?, codigo = COALESCE(NULLIF(?, \'\'), codigo), atualizado_em = CURRENT_TIMESTAMP WHERE id = ?', [nome, S(d.categoria, 100), cod, id]); });
  };
  /** Liga um risco existente a um processo (e, opcionalmente, a uma atividade do diagrama); com processo nulo, desliga. */
  E.riscoVincular = function (riscoId, procId, elemento) {
    DB.tx(function () {
      if (!procId) { DB.run('UPDATE riscos SET flag_id = NULL, processo_id = NULL WHERE id = ?', [riscoId]); return; }
      var c = E.processoCarregar(procId); if (!c) throw new Error('Processo não encontrado.');
      var fid = null;
      if (elemento) { var el = E.processoElementos(c).filter(function (x) { return x.id === elemento; })[0]; fid = E.flagDoElemento(c.id, elemento, el ? el.nome : ''); }
      DB.run('UPDATE riscos SET flag_id = ?, processo_id = ?, ambiente = ? WHERE id = ?', [fid, c.id, c.nome, riscoId]);
    });
  };

  // ---------- exportar / importar processos (XML com o PDF dentro) ----------
  function b64de(u8) { var s = '', n = 0x8000; for (var i = 0; i < u8.length; i += n) s += String.fromCharCode.apply(null, u8.subarray(i, i + n)); return btoa(s); }
})(window);
