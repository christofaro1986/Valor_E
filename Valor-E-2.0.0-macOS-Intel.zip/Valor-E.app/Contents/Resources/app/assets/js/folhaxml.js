/* folhaxml.js — exportação/importação da Folha de Dados em XML (formato idêntico ao da versão PHP).
 * <folhaDeDados formato="folha-bpmn" versao="1"> com <nome>, <folha>, <atividades>, <opcoes>; atributo t: s n b z l o. */
(function (w) {
  'use strict';
  var INVALIDO = /[^\x09\x0A\x0D\x20-퟿-�\u{10000}-\u{10FFFF}]/gu;
  function escT(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\r/g, '&#13;'); }
  function escA(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/\r/g, '&#13;').replace(/\n/g, '&#10;').replace(/\t/g, '&#9;'); }
  function nomeValido(t) { return /^[A-Za-z_][A-Za-z0-9_]*$/.test(t) && t.toLowerCase().indexOf('xml') !== 0; }

  function no(tag, v, ind) {
    var ok = nomeValido(tag), nome = ok ? tag : 'c', at = ok ? '' : ' k="' + escA(tag) + '"', pad = new Array(ind + 1).join('  ');
    if (v !== null && typeof v === 'object') {
      var lista = Array.isArray(v), chaves = lista ? null : Object.keys(v);
      if (!lista && !chaves.length) lista = true;     // {} == [] no PHP
      var filhos = lista ? (Array.isArray(v) ? v : []).map(function (x) { return no('item', x, ind + 1); }) : chaves.map(function (k) { return no(k, v[k], ind + 1); });
      if (!filhos.length) return pad + '<' + nome + at + ' t="l"/>\n';
      return pad + '<' + nome + at + ' t="' + (lista ? 'l' : 'o') + '">\n' + filhos.join('') + pad + '</' + nome + '>\n';
    }
    if (typeof v === 'boolean') return pad + '<' + nome + at + ' t="b">' + (v ? 'true' : 'false') + '</' + nome + '>\n';
    if (typeof v === 'number') return pad + '<' + nome + at + ' t="n">' + String(v) + '</' + nome + '>\n';
    if (v === null || v === undefined) return pad + '<' + nome + at + ' t="z"/>\n';
    var s = String(v).replace(INVALIDO, '');
    return pad + '<' + nome + at + '>' + escT(s) + '</' + nome + '>\n';
  }
  function paraXml(p) {
    var o = '<?xml version="1.0" encoding="UTF-8"?>\n<folhaDeDados formato="folha-bpmn" versao="1">\n';
    o += no('nome', String(p.nome), 1);
    ['folha', 'atividades', 'opcoes'].forEach(function (k) { var v = p[k]; o += no(k, (v !== null && typeof v === 'object') ? v : [], 1); });
    return o + '</folhaDeDados>\n';
  }

  function valor(e) {
    var t = e.getAttribute('t');
    if (t === 'l' || t === 'o') {
      var r = t === 'l' ? [] : {};
      for (var c = e.firstChild; c; c = c.nextSibling) {
        if (c.nodeType !== 1) continue;
        if (t === 'l') r.push(valor(c)); else r[c.hasAttribute('k') ? c.getAttribute('k') : c.nodeName] = valor(c);
      }
      return r;
    }
    var txt = e.textContent;
    if (t === 'b') return txt === 'true';
    if (t === 'n') return Number(txt);
    if (t === 'z') return null;
    return txt;
  }
  function deXml(xml) {
    if (String(xml).replace(/^\s+|\s+$/g, '') === '') throw new Error('Arquivo XML vazio.');
    var d = new DOMParser().parseFromString(xml, 'application/xml');
    if (!d.documentElement || d.getElementsByTagName('parsererror').length) throw new Error('O arquivo não é um XML válido.');
    var r = d.documentElement;
    if (r.nodeName !== 'folhaDeDados' || r.getAttribute('formato') !== 'folha-bpmn') throw new Error('Arquivo não reconhecido: esperado XML de Folha de Dados (folhaDeDados).');
    var o = { nome: 'Processo importado', folha: {}, atividades: [], opcoes: {} };
    for (var c = r.firstChild; c; c = c.nextSibling) {
      if (c.nodeType !== 1) continue;
      if (c.nodeName === 'nome') o.nome = (String(valor(c)).replace(/^\s+|\s+$/g, '')) || o.nome;
      else if (c.nodeName === 'folha' || c.nodeName === 'atividades' || c.nodeName === 'opcoes') { var v = valor(c); o[c.nodeName] = (v !== null && typeof v === 'object') ? v : (c.nodeName === 'atividades' ? [] : {}); }
    }
    return o;
  }
  w.FolhaXml = { paraXml: paraXml, deXml: deXml };
})(typeof window !== 'undefined' ? window : global);
