/* mapris.js — utilitários comuns: datas dd/mm/aaaa, chamadas à API e registro de revisão */
(function (w) {
  'use strict';
  var E = w.Mapris = {};
  // Ponte local: as mesmas "ações" da versão PHP, agora executadas direto no banco da janela.
  function pronto(f) { return new Promise(function (res) { try { res(f()); } catch (e) { res({ ok: false, erro: e.message }); } }); }
  var ACOES = {
    salvar: function (b) { var id = w.E.riscoSalvar(b), r = w.E.riscoCarregar(id); return { ok: true, id: id, risco: r, alertas: w.E.alertasRisco(r) }; },
    revisar: function (b) { var res = w.E.revisaoRegistrar(parseInt(b.id, 10), String(b.parecer || ''), String(b.autor || '')), r = w.E.riscoCarregar(parseInt(b.id, 10)); return { ok: true, ultima_revisao: res.ultima_revisao, proxima_revisao: res.proxima_revisao, revisoes: r.revisoes, alertas: w.E.alertasRisco(r) }; },
    config_salvar: function (b) { w.E.configSalvar(b); return { ok: true }; },
    plano_prazo: function (b) { w.E.planoPrazo(parseInt(b.plano, 10), b.prazo); return { ok: true }; },
    plano_status: function (b) { w.E.planoStatus(parseInt(b.plano, 10), String(b.status)); return { ok: true }; },
    excluir: function (b) { w.E.riscoExcluir(parseInt(b.id, 10)); return { ok: true }; },
    duplicar: function (b) { return { ok: true, id: w.E.riscoDuplicar(parseInt(b.id, 10)) }; }
  };
  E.api = function (a, body) { return pronto(function () { if (!ACOES[a]) throw new Error('Ação desconhecida'); return ACOES[a](body || {}); }); };
  /** Entrega um arquivo ao usuário: no aplicativo abre "Salvar como…"; no navegador baixa. */
  E.baixar = function (nome, texto, tipo) {
    var b64 = btoa(unescape(encodeURIComponent(texto)));
    if (w.__maprisHost && w.__maprisHost.invocar) { w.__maprisHost.invocar('salvar', JSON.stringify({ nome: nome, b64: b64 })); return; }
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([texto], { type: tipo || 'application/octet-stream' })); a.download = nome;
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  };
  E.isoToBr = function (v) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : ''; };
  E.brToIso = function (v) {
    var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec((v || '').trim()); if (!m) return null;
    var d = +m[1], mo = +m[2], y = +m[3], t = new Date(y, mo - 1, d);
    if (t.getFullYear() !== y || t.getMonth() !== mo - 1 || t.getDate() !== d) return null;
    return m[3] + '-' + m[2] + '-' + m[1];
  };
  E.hojeIso = function () { var d = new Date(); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); };
  E.mascara = function (inp) {
    inp.addEventListener('input', function () {
      var v = inp.value.replace(/\D/g, '').slice(0, 8), o = v;
      if (v.length > 4) o = v.slice(0, 2) + '/' + v.slice(2, 4) + '/' + v.slice(4);
      else if (v.length > 2) o = v.slice(0, 2) + '/' + v.slice(2);
      inp.value = o;
    });
  };
  /** Campo de data em texto (dd/mm/aaaa) + botão de calendário. on(iso|'' ) é chamado a cada mudança válida. */
  E.campoData = function (iso, on, cls) {
    var wrap = document.createElement('div'); wrap.className = 'dt-wrap';
    var i = document.createElement('input'); i.type = 'text'; i.className = (cls || 'form-control form-control-sm') + ' dt';
    i.placeholder = 'dd/mm/aaaa'; i.maxLength = 10; i.setAttribute('inputmode', 'numeric'); i.value = E.isoToBr(iso);
    E.mascara(i);
    var p = document.createElement('input'); p.type = 'date'; p.className = 'dt-pick'; p.tabIndex = -1; p.value = iso || '';
    var b = document.createElement('button'); b.type = 'button'; b.className = 'dt-btn'; b.title = 'Calendário'; b.innerHTML = '<i class="bi bi-calendar3"></i>';
    b.addEventListener('click', function () { try { if (p.showPicker) p.showPicker(); else p.focus(); } catch (e) { p.focus(); } });
    p.addEventListener('change', function () { i.value = E.isoToBr(p.value); on(p.value || ''); i.classList.remove('is-invalid'); });
    i.addEventListener('input', function () {
      if (i.value === '') { on(''); i.classList.remove('is-invalid'); p.value = ''; return; }
      var v = E.brToIso(i.value);
      if (v) { on(v); p.value = v; i.classList.remove('is-invalid'); } else if (i.value.length === 10) i.classList.add('is-invalid');
    });
    wrap.appendChild(i); wrap.appendChild(p); wrap.appendChild(b);
    return wrap;
  };
  /** Janela de registro de revisão (análise crítica). cb(resposta) após sucesso. */
  E.revisar = function (id, nome, cb) {
    var el = document.getElementById('mRev');
    if (el) el.remove();
    el = document.createElement('div'); el.id = 'mRev'; el.className = 'modal fade'; el.tabIndex = -1;
    el.innerHTML = '<div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title"><i class="bi bi-clipboard-check"></i> Registrar revisão</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>' +
      '<div class="modal-body"><div class="fw-semibold mb-2"></div><label class="lbl">Parecer da análise crítica</label>' +
      '<textarea class="form-control" rows="4" id="mRevTxt" placeholder="O que mudou? Probabilidade, impacto e controles continuam adequados? Há novos fatos?"></textarea>' +
      '<div class="ajuda mt-2">A próxima revisão será agendada automaticamente conforme o nível do risco.</div></div>' +
      '<div class="modal-footer"><button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-success" id="mRevOk"><i class="bi bi-check2"></i> Registrar revisão</button></div></div></div>';
    el.querySelector('.fw-semibold').textContent = nome || '';
    document.body.appendChild(el);
    var m = new bootstrap.Modal(el); m.show();
    el.querySelector('#mRevOk').addEventListener('click', function () {
      var t = el.querySelector('#mRevTxt').value;
      E.api('revisar', { id: id, parecer: t }).then(function (r) { if (r.ok) { m.hide(); cb && cb(r); } else alert(r.erro || 'Erro'); });
    });
  };
})(window);
