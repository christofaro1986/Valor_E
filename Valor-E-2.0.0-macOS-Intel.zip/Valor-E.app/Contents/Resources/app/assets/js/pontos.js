/* pontos.js — pontos de restauração automáticos e lembrete de cópia externa.
 *
 * Os pontos ficam no armazenamento interno do aplicativo (IndexedDB), separados do arquivo do banco, e seguem o mesmo formato
 * que é gravado em disco (cifrados, se a proteção por senha estiver ativa). Eles protegem contra erro humano (importar, limpar,
 * excluir sem querer) e contra um arquivo de banco danificado. NÃO substituem a cópia externa (pendrive, outro computador):
 * se o armazenamento do aplicativo for apagado, os pontos vão junto. Por isso há também o lembrete de cópia externa.
 */
(function (w) {
  'use strict';
  var Pontos = w.Pontos = w.Pontos || {};
  var NOME = 'valore-pontos', LIM_TOTAL = 1, h = function (s) { return w.E && E.esc ? E.esc(s) : String(s); };

  function abrir() {
    return new Promise(function (res) {
      try {
        var rq = w.indexedDB.open(NOME, 1);
        rq.onupgradeneeded = function () { rq.result.createObjectStore('p', { keyPath: 'id' }); };
        rq.onsuccess = function () { res(rq.result); };
        rq.onerror = function () { Pontos.erro = 'não foi possível abrir o armazenamento interno (' + (rq.error && rq.error.name || 'erro') + ')'; res(null); };
        rq.onblocked = function () { Pontos.erro = 'armazenamento interno bloqueado por outra janela'; res(null); };
      } catch (e) { Pontos.erro = 'armazenamento interno indisponível (' + (e && e.name || e) + ')'; res(null); }
    });
  }
  function pedido(modo, fn) {   // executa fn(store) e resolve com o resultado do pedido
    return abrir().then(function (db) {
      if (!db) return null;
      return new Promise(function (res) {
        try {
          var t = db.transaction('p', modo), r = fn(t.objectStore('p'));
          t.oncomplete = function () { db.close(); res(r && r.result !== undefined ? r.result : true); };
          t.onerror = t.onabort = function () { Pontos.erro = 'falha ao gravar (' + (t.error && t.error.name || 'erro') + (t.error && t.error.message ? ': ' + t.error.message : '') + ')'; db.close(); res(null); };
        } catch (e) { Pontos.erro = 'falha ao gravar (' + (e && e.name || e) + ')'; try { db.close(); } catch (x) {} res(null); }
      });
    });
  }
  Pontos.disponivel = function () { return abrir().then(function (d) { if (d) d.close(); return !!d; }); };

  /** Lista (sem o conteúdo), do mais novo para o mais antigo. */
  Pontos.listar = function () {
    return pedido('readonly', function (st) { return st.getAll(); }).then(function (r) {
      return (r || []).map(function (p) { return { id: p.id, motivo: p.motivo, tipo: p.tipo, tam: p.tam, em: p.em }; }).sort(function (a, b) { return a.id < b.id ? 1 : -1; });
    });
  };
  function obter(id) { return pedido('readonly', function (st) { return st.get(id); }); }
  Pontos.excluir = function (id) { return pedido('readwrite', function (st) { return st.delete(id); }); };

  /** Guarda só o ponto mais recente: cada ponto novo substitui o anterior. */
  function limitar() {
    return Pontos.listar().then(function (ls) { return Promise.all(ls.slice(LIM_TOTAL).map(function (p) { return Pontos.excluir(p.id); })); });
  }
  Pontos.limparTodos = function () { return Pontos.listar().then(function (ls) { return Promise.all(ls.map(function (p) { return Pontos.excluir(p.id); })); }); };

  /** Cria um ponto com o estado ATUAL do banco (a captura é síncrona; a gravação, assíncrona). */
  Pontos.criar = function (motivo, tipo) {
    if (!w.DB || !DB.db) return Promise.resolve(null);
    var cap;
    Pontos.erro = '';
    try { cap = DB.instantaneo(); } catch (e) { Pontos.erro = (e && e.message === 'bloqueado') ? 'os dados estão bloqueados; desbloqueie o aplicativo e tente de novo' : 'não foi possível copiar o banco (' + (e && e.message || e) + ')'; return Promise.resolve(null); }
    var id = new Date().toISOString();
    return cap.then(function (payload) {
      return pedido('readwrite', function (st) { return st.put({ id: id, motivo: motivo || 'Ponto de restauração', tipo: tipo || 'manual', em: id, tam: payload.length, payload: payload }); });
    }).then(function (ok) { if (!ok) return null; return limitar().then(function () { return id; }); }, function (e) { Pontos.erro = (e && e.message === 'bloqueado') ? 'os dados estão bloqueados; desbloqueie o aplicativo e tente de novo' : 'não foi possível copiar o banco (' + (e && e.message || e) + ')'; return null; });
  };

  /** Restaura um ponto. Antes, guarda o estado atual (assim a restauração também pode ser desfeita). */
  Pontos.restaurar = function (id) {
    return obter(id).then(function (p) {
      if (!p || !p.payload) throw new Error('Ponto de restauração não encontrado.');
      return DB.abrirInstantaneo(p.payload).then(function (bytes) {
        var mag = String.fromCharCode.apply(null, bytes.subarray(0, 15));
        if (mag.indexOf('SQLite format 3') !== 0) throw new Error('O ponto de restauração está danificado.');
        return Pontos.criar('Antes de restaurar um ponto', 'antes').then(function () {
          DB.substituir(bytes);
          if (w.SEC) SEC.audit('restaurar', 'ponto ' + id);
          return DB.flush();
        });
      });
    });
  };

  function temDados() {
    try {
      return ['processos', 'riscos', 'projetos', 'indicadores', 'cva_ciclos', 'me_mapas'].some(function (t) { return (DB.one('SELECT COUNT(*) AS n FROM ' + t) || {}).n > 0; });
    } catch (e) { return false; }
  }
  /** Na abertura: guarda o estado do dia (uma vez por dia), antes de qualquer edição. */
  Pontos.aoIniciar = function () {
    if (!temDados()) return;
    Pontos.listar().then(function (ls) {
      var hoje = (w.E && E.hoje) ? E.hoje() : new Date().toISOString().slice(0, 10);
      var jaTem = ls.some(function (p) { return p.tipo === 'auto' && new Date(p.id).toLocaleDateString('sv-SE') === hoje; });
      // o ponto do dia não apaga, nos 2 primeiros dias, um ponto feito antes de uma ação arriscada (importar, restaurar, limpar) ou criado à mão: dá tempo de notar um erro
      var protegido = ls.some(function (p) { return p.tipo !== 'auto' && Date.now() - new Date(p.id).getTime() < 2 * 864e5; });
      if (!jaTem && !protegido) Pontos.criar('Abertura do dia', 'auto');
    });
  };

  // ---- cópia externa (pendrive, outro computador): o aplicativo só sabe quando o usuário ACIONOU a exportação ----
  function cfgGet(k) { try { var r = DB.one('SELECT valor FROM config WHERE chave = ?', [k]); return r ? r.valor : ''; } catch (e) { return ''; } }
  function cfgSet(k, v) { DB.run('INSERT INTO config (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor', [k, String(v)]); DB.sujo(); }
  Pontos.cfgGet = cfgGet; Pontos.cfgSet = cfgSet;
  var LS_COPIA = 'valore_copia_externa_em';
  // O registro fica no banco e TAMBÉM fora dele: restaurar um ponto, importar em modo substituir ou limpar os dados troca o banco
  // inteiro e apagaria o aviso, mesmo com a cópia já feita.
  Pontos.copiaExterna = function () {
    var agora = new Date().toISOString();
    try { cfgSet('copia_externa_em', agora); } catch (e) {}
    try { w.localStorage.setItem(LS_COPIA, agora); } catch (e) {}
  };
  /** {dias, quando} da última exportação acionada, ou null se nunca. */
  Pontos.ultimaCopiaExterna = function () {
    var v = cfgGet('copia_externa_em'), l = ''; try { l = w.localStorage.getItem(LS_COPIA) || ''; } catch (e) {}
    if (l && (!v || l > v)) v = l;
    if (!v) return null;
    var d = new Date(v); if (isNaN(d)) return null;
    return { quando: d, dias: Math.floor((Date.now() - d.getTime()) / 864e5) };
  };
  var LIM_DIAS = 30;
  /** Texto de aviso para o Painel (ou '' se tudo em dia ou se não há dados). */
  Pontos.avisoCopia = function () {
    if (!temDados()) return '';
    var u = Pontos.ultimaCopiaExterna();
    if (!u) return 'Nenhuma cópia externa dos dados foi feita ainda. Use Mais ▸ Exportar / importar ▸ Cópia do banco e guarde o arquivo fora deste computador.';
    if (u.dias > LIM_DIAS) return 'A última cópia externa dos dados foi há ' + u.dias + ' dias. Faça uma nova em Mais ▸ Exportar / importar.';
    return '';
  };

  // ---- interface (cartão na tela Exportar / importar) ----
  function fmt(iso) { var d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
  function kb(n) { return n > 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  Pontos.cartao = function () {
    setTimeout(Pontos.desenhar, 20);
    return '<div class="cartao mb-3"><h2><i class="bi bi-clock-history"></i> Pontos de restauração e cópia externa</h2><div class="corpo">' +
      '<p class="ajuda">O aplicativo guarda <b>um único ponto de restauração: o mais recente</b>. Ele é refeito sozinho uma vez por dia e também <b>antes de importar, restaurar ou limpar dados</b> (nesse caso o ponto fica protegido por 2 dias contra o refeito automático). Serve para desfazer um erro. ' +
      '<b>Ele fica dentro do aplicativo</b>: se o aplicativo for removido ou seus dados apagados, vai junto. Para proteção de verdade, faça também uma <b>cópia externa</b>.</p>' +
      '<div id="ptExt" class="mb-2"></div>' +
      '<div class="mb-2"><button class="btn btn-sm btn-outline-primary" onclick="Pontos.criarUI()"><i class="bi bi-plus-circle"></i> Atualizar o ponto agora</button> <button class="btn btn-sm btn-outline-secondary" onclick="Pontos.limparUI()"><i class="bi bi-trash"></i> Apagar o ponto</button></div>' +
      '<div id="ptLista" class="small text-muted">Carregando…</div></div></div>';
  };
  Pontos.desenhar = function () {
    var ext = document.getElementById('ptExt'), box = document.getElementById('ptLista'); if (!box && !ext) return;
    if (ext) {
      var u = Pontos.ultimaCopiaExterna(), av = Pontos.avisoCopia();
      ext.innerHTML = '<span class="badge ' + (av ? 'text-bg-warning' : 'text-bg-success') + '">Cópia externa</span> ' + (u ? 'última exportação acionada em ' + u.quando.toLocaleDateString('pt-BR') + ' (há ' + u.dias + ' dia(s))' : 'nenhuma exportação feita ainda neste banco');
    }
    if (!box) return;
    Pontos.disponivel().then(function (ok) {
      if (!ok) { box.innerHTML = '<div class="alert alert-warning mb-0">O armazenamento interno não está disponível neste ambiente; os pontos de restauração ficam desativados. Faça cópias externas com frequência.</div>'; return; }
      Pontos.listar().then(function (ls) {
        if (!ls.length) { box.textContent = 'Nenhum ponto ainda. O primeiro é criado na próxima abertura do aplicativo, se já houver dados.'; return; }
        box.innerHTML = '<table class="table table-sm align-middle mb-0"><thead><tr><th>Quando</th><th>Motivo</th><th>Tamanho</th><th></th></tr></thead><tbody>' + ls.map(function (p) {
          return '<tr><td>' + h(fmt(p.em)) + '</td><td>' + h(p.motivo) + '</td><td>' + kb(p.tam || 0) + '</td><td class="text-end">' +
            '<button class="btn btn-sm btn-outline-warning" data-pt="' + h(p.id) + '" onclick="Pontos.restaurarUI(this.dataset.pt)">Restaurar</button> ' +
            '<button class="btn btn-sm btn-outline-danger" data-pt="' + h(p.id) + '" onclick="Pontos.excluirUI(this.dataset.pt)"><i class="bi bi-trash"></i></button></td></tr>';
        }).join('') + '</tbody></table>';
      });
    });
  };
  Pontos.criarUI = function () { Pontos.criar('Criado manualmente', 'manual').then(function (id) { if (!id) alert('Não foi possível criar o ponto: ' + (Pontos.erro || 'armazenamento indisponível ou banco bloqueado') + '.'); Pontos.desenhar(); }); };
  Pontos.limparUI = function () { if (!confirm('Apagar TODOS os pontos de restauração? Os dados atuais não são afetados.')) return; Pontos.limparTodos().then(Pontos.desenhar); };
  Pontos.excluirUI = function (id) { if (!confirm('Excluir este ponto de restauração?')) return; Pontos.excluir(id).then(Pontos.desenhar); };
  Pontos.restaurarUI = function (id) {
    if (!confirm('Restaurar o banco para o estado de ' + fmt(id) + '?\n\nO que foi feito depois desse momento será desfeito. O estado atual é guardado antes, então esta restauração também pode ser desfeita.')) return;
    Pontos.restaurar(id).then(function () { alert('Banco restaurado.'); Nav.ir('#/'); location.reload(); }, function (e) { alert('Não foi possível restaurar: ' + (e && e.message || e)); });
  };
})(window);
