(function (DB) {
/* ui.js — OPTIMUS 2.0: Dashboard · Capacidade · Indicador · Objetivos/ICV · Monitoramento (modelo SISREL) */
(function (w) {
  'use strict';
  var UI = w.UI = {};

  function h(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function pct(v, c) { return v == null || isNaN(v) ? '—' : (v * 100).toFixed(c == null ? 1 : c).replace('.', ',') + '%'; }
  function num(v, c) { return v == null || isNaN(v) ? '—' : (+v).toFixed(c == null ? 2 : c).replace('.', ','); }
  function badge(s, cls) { return '<span class="badge badge-' + (cls || 'muted') + '">' + h(s || '—') + '</span>'; }
  function badgeAbc(c) { return c ? '<span class="badge badge-abc-' + String(c).toLowerCase() + '">' + h(c) + '</span>' : ''; }
  function kpi(t, v, sub, cls) {
    return '<div class="card-kpi ' + (cls || '') + '"><div class="kpi-label">' + h(t) + '</div><div class="kpi-valor">' + v + '</div>' + (sub ? '<div class="kpi-sub">' + sub + '</div>' : '') + '</div>';
  }
  function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
  function ajuda(t) { return '<p class="ajuda">' + t + '</p>'; }
  var CLS = { ok: 'ok', atencao: 'warn', critico: 'err', 'sem-dados': 'muted' };
  function chip(k, femin) {
    var r = femin ? MET.ROTULO_F : MET.ROTULO;
    return '<span class="status-chip st-' + k + '"><i class="dot"></i>' + h(r[k] || r['sem-dados']) + '</span>';
  }
  function chipRisco(k) { return '<span class="status-chip st-' + k + '">Risco ' + h(MET.RISCO[k] || '—').toLowerCase() + '</span>'; }
  function fmtVal(v, uni) { return v == null ? '—' : num(v, 2) + (uni ? ' ' + h(uni) : ''); }
  function lastId() { return (DB.one('SELECT last_insert_rowid() id') || {}).id; }
  function norm(s) { return String(s || '').trim().toLowerCase(); }

  /* ---------- navegação ---------- */
  var SUB_VAL = [['dashboard', '#/valor', 'bi-grid-1x2', 'Capacidades'], ['ciclos', '#/valor/ciclos', 'bi-calendar-range', 'Ciclos e metas'], ['objetivos', '#/valor/objetivos', 'bi-bullseye', 'Objetivos e ICV'], ['monitoramento', '#/valor/monitoramento', 'bi-activity', 'Monitoramento'], ['relatorio', '#/valor/relatorio', 'bi-file-earmark-text', 'Relatório'], ['validacao', '#/valor/validacao', 'bi-patch-check', 'Verificação']];
  var SUB_IND = [['lista', '#/indicadores', 'bi-list-ul', 'Indicadores'], ['relind', '#/relindicadores', 'bi-file-earmark-bar-graph', 'Relatório de indicadores']];
  function sub(lista, ativo) { return '<div class="subnav no-print"><div class="subnav-in">' + lista.map(function (x) { return '<a href="' + x[1] + '" class="' + (ativo === x[0] ? 'ativo' : '') + '"><i class="bi ' + x[2] + '"></i> ' + x[3] + '</a>'; }).join('') + '</div></div>'; }
  UI.sub = sub; UI.SUB_IND = SUB_IND;
  function topo() { return ''; }
  function pagina(ativo, html) {
    var s = ativo === 'indicadores' ? '' : (ativo === 'lista' || ativo === 'relind') ? sub(SUB_IND, ativo) : sub(SUB_VAL, ativo);
    var tit = (ativo === 'indicadores' || ativo === 'lista' || ativo === 'relind') ? '' : '<div class="veb-tit"><span>Valor Estratégico Baseado em Capacidades</span> – VEB-C</div>';
    return s + '<main class="pagina val-host">' + tit + html + '</main>';
  }
  function parseHash() {
    var raw = (location.hash || '#/valor').replace(/^#/, ''), parts = raw.split('?'), q = {};
    if (parts[1]) parts[1].split('&').forEach(function (p) { var kv = p.split('='); q[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || ''); });
    return { path: parts[0] || '/', q: q };
  }
  function ir(hash) { if (location.hash === hash) rota(); else location.hash = hash; }
  try { w.DB.migracao('valor-002-planos-5w2h', function () { w.DB.db.run("CREATE TABLE IF NOT EXISTS va_planos (id INTEGER PRIMARY KEY AUTOINCREMENT, objetivo_id INTEGER NOT NULL, ciclo_id INTEGER, titulo TEXT NOT NULL, o_que TEXT, por_que TEXT, onde TEXT, quando_inicio TEXT, quando_fim TEXT, quem TEXT, como TEXT, quanto TEXT, status TEXT DEFAULT 'Planejada', criado_em TEXT DEFAULT CURRENT_TIMESTAMP)"); }); } catch (e) {}
  function openModal(html, opts) {
    fechar();
    var w = document.createElement('div'); w.id = 'mdlw'; w.className = 'val-host'; w.style.cssText = 'display:contents;background:none;height:auto';
    var d = document.createElement('div'); d.id = 'mdl'; d.className = 'vmodal active';
    d.innerHTML = '<div class="vmodal-content' + (opts && opts.wide ? ' vvmodal-content-wide' : '') + (opts && opts.xwide ? ' vvmodal-content-xwide' : '') + '">' + html + '</div>';
    d.addEventListener('mousedown', function (e) { d._dn = (e.target === d); });
    d.addEventListener('click', function (e) { if (e.target === d && d._dn) fechar(); });
    w.appendChild(d); document.body.appendChild(w);
  }
  function fechar() { var m = document.getElementById('mdlw'); if (m) m.remove(); m = document.getElementById('mdl'); if (m) m.remove(); }
  function modal(titulo, corpo, okAttr, rotuloOk) {
    return '<div class="vmodal-hd"><h2>' + h(titulo) + '</h2><button type="button" class="btn-fechar" onclick="UI.fechar()" title="Fechar">×</button></div>' +
      '<div class="vmodal-bd">' + corpo + '</div><div class="vmodal-ft"><button type="button" class="btn btn-outline" onclick="UI.fechar()">Cancelar</button>' +
      (okAttr ? '<button type="button" class="btn" ' + okAttr + '>' + (rotuloOk || 'Salvar') + '</button>' : '') + '</div>';
  }
  UI.fechar = fechar;
  function persistirERota() { DB.persistir(); fechar(); rota(); }

  /* ---------- cálculo de situação dos cards (regra SISREL: pior indicador) ---------- */
  function statusCap(res) {
    var c = res.contadores;
    return c.critico ? 'critico' : c.atencao ? 'atencao' : c.ok ? 'ok' : 'sem-dados';
  }

  /* ====================== DASHBOARD ====================== */
  function cardCap(c) {
    var res = M_ihc(c.id), st = statusCap(res), obj = MET.objetivoDaCapacidade(c.id);
    var cont = res.contadores;
    return '<div class="classe-card st-' + st + '" onclick="location.hash=\'#/valor/capacidade?id=' + c.id + '\'" tabindex="0">' +
      '<div class="cc-top"><span class="cc-cod">' + h(c.codigo) + '</span>' + chip(st, true) + '</div>' +
      '<h3 class="cc-nome">' + h(c.nome) + '</h3>' +
      '<div class="cc-obj">' + (obj ? 'Objetivo: <b>' + h(obj.codigo) + '</b>' + (obj.nome && norm(obj.nome) !== norm(obj.codigo) ? ' — ' + h(obj.nome) : '') : '<span class="muted">Sem objetivo estratégico vinculado</span>') + '</div>' +
      (c.descricao ? '<div class="cc-desc">' + h(c.descricao) + '</div>' : '') +
      '<div class="cc-meta"><div><span>IHC</span><b>' + pct(res.ihc) + '</b></div><div><span>Grau de risco</span><b>' + (st === 'sem-dados' ? '—' : h(MET.RISCO[st])) + '</b></div>' +
      '<div><span>Dimensões</span><b>' + res.dims.length + '</b></div><div><span>Indicadores</span><b>' + res.totalInds + '</b></div></div>' +
      '<div class="cc-cont">' + (cont.ok ? '<span class="st-ok">' + cont.ok + ' em conformidade</span>' : '') + (cont.atencao ? '<span class="st-atencao">' + cont.atencao + ' em atenção</span>' : '') + (cont.critico ? '<span class="st-critico">' + cont.critico + ' crítico(s)</span>' : '') + '</div>' +
      '<div class="cc-acoes" onclick="event.stopPropagation()"><button type="button" class="btn btn-sm btn-outline" onclick="UI.formCapacidade(' + c.id + ')">Editar</button> ' +
      '<button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirCapacidade(' + c.id + ')">Excluir</button></div></div>';
  }
  function M_ihc(id) { return MET.ihcCapacidade(id); }

  var DASH = { f: 'todas', q: '', mapa: '' };
  function listaCapsDash() {
    var caps = DB.rows("SELECT * FROM capacidades WHERE status='ativo' ORDER BY codigo"), q = norm(DASH.q), out = '', n = 0;
    caps.forEach(function (c) {
      var st = statusCap(M_ihc(c.id));
      if (DASH.f !== 'todas' && st !== DASH.f) return;
      if (DASH.mapa && !DB.one('SELECT 1 AS x FROM objetivo_capacidades oc JOIN me_objetivos mo ON mo.oe_id = oc.objetivo_id JOIN me_perspectivas mp ON mp.id = mo.perspectiva_id WHERE oc.capacidade_id = ? AND mp.mapa_id = ?', [c.id, DASH.mapa])) return;
      if (q) { var o = MET.objetivoDaCapacidade(c.id); if ((norm(c.codigo) + ' ' + norm(c.nome) + ' ' + norm(o ? o.codigo + ' ' + o.nome : '')).indexOf(q) < 0) return; }
      out += cardCap(c); n++;
    });
    return n ? '<div class="cards-grid">' + out + '</div>' : '<div class="dash-vazio"><p>Nenhuma capacidade corresponde ao filtro.</p></div>';
  }
  UI.dashFiltro = function (k) { DASH.f = (DASH.f === k && k !== 'todas') ? 'todas' : k; rota(); };
  UI.dashMapa = function (v) { DASH.mapa = v; var el = document.getElementById('dash_lista'); if (el) el.innerHTML = listaCapsDash(); };
  UI.dashBusca = function (v) { DASH.q = v; var el = document.getElementById('dash_lista'); if (el) el.innerHTML = listaCapsDash(); };

  /** Quadro "como o valor estratégico se forma": indicador → capacidade → objetivo estratégico. */
  function cadeiaValor() {
    function no(ic, t, d) { return '<div class="cv-no"><b>' + t + '</b><span>' + d + '</span></div>'; }
    return '<div class="cv-quadro"><div class="cv-tit">Como se forma o valor estratégico</div><div class="cv-fluxo">' +
      no('', 'Indicador', 'Entrega dos <b>processos</b> e dos <b>projetos</b> que habilitam a capacidade') + '<div class="cv-seta">→</div>' +
      no('', 'Capacidade', 'Habilitada pelo desempenho dos seus indicadores (IHC)') + '<div class="cv-seta">→</div>' +
      no('', 'Objetivo estratégico', 'A capacidade habilitada gera resultados — <b>captura de valor</b> (ICV)') + '<div class="cv-seta">→</div>' +
      no('', 'Valor estratégico', 'Valor da organização: o objetivo estratégico é alcançado') + '</div></div>';
  }
  function dashboard() {
    var caps = DB.rows("SELECT * FROM capacidades WHERE status='ativo' ORDER BY codigo");
    var cont = { ok: 0, atencao: 0, critico: 0, 'sem-dados': 0 }, totInd = 0;
    caps.forEach(function (c) { var r = M_ihc(c.id); cont[statusCap(r)]++; totInd += r.totalInds || 0; });
    function kpi(k, cls, rot, n) { return '<button type="button" class="kpi k-' + cls + '" onclick="UI.dashFiltro(\'' + k + '\')"><b>' + n + '</b><span>' + rot + '</span></button>'; }
    var html = '<div class="dash-topo"><div><h1>Capacidades</h1><p>' + caps.length + ' capacidade' + (caps.length === 1 ? '' : 's') + ' · ' + totInd + ' indicador' + (totInd === 1 ? '' : 'es') + ' monitorado' + (totInd === 1 ? '' : 's') + '</p></div><div class="sp"></div>' +
      (caps.length ? '<input class="dash-busca" type="search" placeholder="Buscar capacidade ou objetivo…" value="' + h(DASH.q) + '" oninput="UI.dashBusca(this.value)">' : '') +
      (DB.rows('SELECT id, nome FROM me_mapas ORDER BY id').length > 1 ? '<select class="dash-busca" style="max-width:260px;margin-left:8px" title="Mapa estratégico" onchange="UI.dashMapa(this.value)"><option value="">Todos os mapas estratégicos</option>' + DB.rows('SELECT id, nome FROM me_mapas ORDER BY id').map(function (m) { return '<option value="' + m.id + '"' + (String(DASH.mapa) === String(m.id) ? ' selected' : '') + '>' + h(m.nome) + '</option>'; }).join('') + '</select>' : '') +
      '<button type="button" class="btn" onclick="UI.formCapacidade(0)">+ Nova capacidade</button></div>';
    html += cadeiaValor();
    if (!caps.length) return pagina('dashboard', html + '<div class="dash-vazio"><h2>Comece pela primeira capacidade</h2><p>Cadastre uma capacidade, vincule-a a um objetivo estratégico e acompanhe seus indicadores.</p><button type="button" class="btn" onclick="UI.formCapacidade(0)">+ Nova capacidade</button></div>');
    html += '<div class="kpis">' + kpi('todas', 'todas', 'Todas', caps.length) + kpi('critico', 'critico', 'Críticas', cont.critico) + kpi('atencao', 'atencao', 'Em atenção', cont.atencao) + kpi('ok', 'ok', 'Em conformidade', cont.ok) + '</div>' +
      '<div id="dash_lista">' + listaCapsDash() + '</div>';
    return pagina('dashboard', html);
  }

  /* ---------- CRUD capacidade ---------- */
  function objetivosDatalist() {
    return '<datalist id="dl_obj">' + DB.rows("SELECT codigo, nome FROM objetivos_estrategicos WHERE status='ativo' ORDER BY codigo").map(function (o) {
      var label = (norm(o.nome) === norm(o.codigo) || !o.nome) ? o.codigo : (o.codigo + ' — ' + o.nome);
      return '<option value="' + h(label) + '"></option>';
    }).join('') + '</datalist>';
  }
  function labelObjetivo(o) {
    if (!o) return '';
    if (!o.nome || norm(o.nome) === norm(o.codigo)) return o.codigo;
    return o.codigo + ' — ' + o.nome;
  }
  /** Lista de escolha: objetivos cadastrados no Mapa Estratégico (agrupados por perspectiva). */
  function seletorObjetivo(atual) {
    var lista = window.Mapa ? window.Mapa.objetivosParaEscolha() : [];
    if (!lista.length) return '<div class="muted" style="padding:8px 0">Nenhum objetivo estratégico cadastrado. Cadastre os objetivos no módulo <a href="#/estrategia" onclick="UI.fechar && UI.fechar()">Mapa Estratégico</a> e volte aqui.</div><input type="hidden" id="f_obj" value="">';
    var grupos = [], idx = {};
    lista.forEach(function (x) { if (!idx[x.grupo]) { idx[x.grupo] = []; grupos.push(x.grupo); } idx[x.grupo].push(x); });
    return '<select id="f_obj"><option value="">— escolha o objetivo estratégico —</option>' + grupos.map(function (g) {
      return '<optgroup label="' + h(g) + '">' + idx[g].map(function (x) { return '<option value="' + h(x.codigo) + '"' + (atual && atual.codigo === x.codigo ? ' selected' : '') + '>' + h(x.codigo + ' — ' + x.nome) + '</option>'; }).join('') + '</optgroup>';
    }).join('') + '</select><small class="muted">A lista vem do módulo <a href="#/estrategia">Mapa Estratégico</a>.</small>';
  }
  UI.formCapacidade = function (id) {
    var r = id ? DB.one('SELECT * FROM capacidades WHERE id=?', [id]) : { codigo: '', nome: '', descricao: '' };
    var o = id ? MET.objetivoDaCapacidade(id) : null;
    openModal(modal(id ? 'Editar capacidade' : 'Cadastrar nova capacidade',
      '<div class="form-grid">' +
      '<div class="campo"><label>Código da capacidade *</label><input id="f_cod" value="' + h(r.codigo) + '" placeholder="Ex.: CAP-01"></div>' +
      '<div class="campo"><label>Nome da capacidade *</label><input id="f_nome" value="' + h(r.nome) + '" placeholder="Ex.: Atendimento digital integrado"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Objetivo estratégico que impacta *</label>' + seletorObjetivo(o) + '</div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Descrição <span class="muted">(opcional)</span></label><textarea id="f_desc" rows="3">' + h(r.descricao || '') + '</textarea></div></div>',
      'onclick="UI.salvarCapacidade(' + (id || 0) + ')"'));
  };
  function resolverObjetivo(txt) {
    txt = String(txt || '').trim(); if (!txt) return null;
    var parts = txt.split(/\s+[—–-]\s+/);
    var cod = parts[0].trim();
    var nome = parts.slice(1).join(' — ').trim();
    if (!nome) nome = cod;
    var ex = DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(codigo)=?', [norm(cod)]) || DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(nome)=?', [norm(txt)]) || DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(nome)=?', [norm(nome)]);
    if (ex) return ex.id;
    DB.run("INSERT INTO objetivos_estrategicos (codigo, nome, status) VALUES (?,?,'ativo')", [cod, nome]);
    return lastId();
  }
  function igualarWc(objId) {
    var n = DB.one('SELECT COUNT(*) n FROM objetivo_capacidades WHERE objetivo_id=?', [objId]).n;
    if (n) DB.run('UPDATE objetivo_capacidades SET wc=? WHERE objetivo_id=?', [1 / n, objId]);
  }
  UI.salvarCapacidade = function (id) {
    var cod = val('f_cod').trim(), nome = val('f_nome').trim(), objTxt = val('f_obj').trim();
    if (!cod || !nome) { alert('Informe o código e o nome da capacidade.'); return; }
    if (!objTxt) { alert('Informe o objetivo estratégico que a capacidade impacta.'); return; }
    var dup = DB.one('SELECT id FROM capacidades WHERE lower(codigo)=? AND id<>?', [norm(cod), id || 0]);
    if (dup) { alert('Já existe uma capacidade com esse código.'); return; }
    if (id) DB.run('UPDATE capacidades SET codigo=?, nome=?, descricao=? WHERE id=?', [cod, nome, val('f_desc'), id]);
    else { DB.run("INSERT INTO capacidades (codigo, nome, descricao, status) VALUES (?,?,?,'ativo')", [cod, nome, val('f_desc')]); id = lastId(); }
    var oid = resolverObjetivo(objTxt), atual = MET.objetivoDaCapacidade(id);
    if (!atual || atual.id !== oid) {
      var antigo = atual ? atual.id : 0;
      DB.run('DELETE FROM objetivo_capacidades WHERE capacidade_id=?', [id]);
      DB.run('INSERT INTO objetivo_capacidades (objetivo_id, capacidade_id, wc) VALUES (?,?,0)', [oid, id]);
      igualarWc(oid); if (antigo) igualarWc(antigo);
    }
    persistirERota();
  };
  function apagarIndicador(indId) {
    ['lanc_ind', 'lanc_itm', 'ind_ciclos', 'indicador_itens', 'indicador_fatores'].forEach(function (t) { DB.run('DELETE FROM ' + t + ' WHERE indicador_id=?', [indId]); });
    DB.run("DELETE FROM planos_intervencao WHERE tipo_alvo='indicador' AND alvo_id=?", [indId]);
    DB.run('DELETE FROM indicadores WHERE id=?', [indId]);
  }
  function apagarDimensao(fid) {
    DB.run('DELETE FROM indicador_fatores WHERE fator_id=?', [fid]);   // os indicadores permanecem no módulo Indicadores
    DB.run('DELETE FROM fatores_determinantes WHERE id=?', [fid]);
  }
  UI.excluirCapacidade = function (id) {
    var c = DB.one('SELECT * FROM capacidades WHERE id=?', [id]); if (!c) return;
    var n = DB.one('SELECT COUNT(*) n FROM fatores_determinantes WHERE capacidade_id=?', [id]).n;
    if (!confirm('Excluir a capacidade ' + c.codigo + ' — ' + c.nome + '?' + (n ? '\nSerão excluídas também as ' + n + ' dimensão(ões); os indicadores vinculados NÃO são excluídos (permanecem no módulo Indicadores).' : '') + '\nEsta ação não pode ser desfeita.')) return;
    var o = MET.objetivoDaCapacidade(id);
    DB.rows('SELECT id FROM fatores_determinantes WHERE capacidade_id=?', [id]).forEach(function (f) { apagarDimensao(f.id); });
    DB.run('DELETE FROM objetivo_capacidades WHERE capacidade_id=?', [id]);
    DB.run('DELETE FROM capacidades WHERE id=?', [id]);
    if (o) igualarWc(o.id);
    DB.persistir(); location.hash = '#/valor'; rota();
  };

  /* ====================== PÁGINA DA CAPACIDADE ====================== */
  var ABA = { dim: {}, sub: {} }, CUR_F = 0;
  UI.selDim = function (capId, fid) { ABA.dim[capId] = fid; rota(); };
  UI.selSub = function (capId, s) { ABA.sub[capId] = s; rota(); };

  function celulaInd(e) {
    return '<tr class="' + (e.ativo ? '' : 'inativo') + '"><td><a href="#/indicador?id=' + e.id + '" class="lnk-ind">' + h(e.ind.nome) + '</a><div class="muted" style="font-size:11.5px">' + h(e.ind.codigo) + ' · ' + (e.tipo === 'multiplo' ? 'múltiplo' : 'simples') + '</div></td>' +
      '<td class="num">' + (e.tipo === 'multiplo' ? 'composto' : fmtVal(e.valor, e.ind.unidade)) + '</td>' +
      '<td class="num">' + (e.meta == null ? '—' : num(e.meta, 2)) + '</td>' +
      '<td class="num">' + pct(e.pct, 0) + '</td><td class="num">' + (e.desvio == null ? '—' : num(e.desvio, 2)) + '</td>' +
      '<td>' + chip(e.status) + '</td><td>' + chipRisco(e.status) + '</td>' +
      '<td class="num">' + (e.grh != null ? pct(e.grh, 0) : '—') + '</td>' +
      '<td class="acoes"><a class="btn btn-sm btn-outline" href="#/indicador?id=' + e.id + '" title="Abrir no módulo Indicadores (registros de valores)">Abrir</a> ' +
      '<button type="button" class="btn btn-sm btn-danger" title="Remove o vínculo com esta dimensão (o indicador continua no módulo Indicadores)" onclick="UI.desvincularInd(' + e.id + ',' + CUR_F + ')">Desvincular</button></td></tr>';
  }
  function tabelaInds(lista, vazio) {
    if (!lista.length) return '<p class="vazio">' + vazio + '</p>';
    return '<div class="tabela-wrap"><table class="tabela-compacta"><thead><tr><th>Indicador</th><th class="num">Último valor</th><th class="num">Meta</th><th class="num">% da meta</th><th class="num">Desvio da meta</th><th>Situação</th><th>Risco</th><th class="num">Peso (GRH)</th><th>Ações</th></tr></thead><tbody>' + lista.map(celulaInd).join('') + '</tbody></table></div>';
  }

  function paginaCapacidade(q) {
    var id = parseInt(q.id, 10), cap = DB.one('SELECT * FROM capacidades WHERE id=?', [id]);
    if (!cap) return pagina('dashboard', '<div class="card"><p class="vazio">Capacidade não encontrada.</p><a class="btn" href="#/valor">Voltar ao dashboard</a></div>');
    var res = MET.ihcCapacidade(id), obj = MET.objetivoDaCapacidade(id), st = statusCap(res);
    var dims = res.dims, fid = ABA.dim[id];
    if (!dims.some(function (d) { return d.f.id === fid; })) fid = dims.length ? dims[0].f.id : 0;
    var subAba = ABA.sub[id] || 'ativos'; CUR_F = fid;
    var html = '<div class="card"><div class="toolbar"><a class="btn btn-outline btn-sm" href="#/valor">← Dashboard</a><div class="sp"></div>' +
      '<button type="button" class="btn btn-sm btn-outline" onclick="UI.formCapacidade(' + id + ')">Editar capacidade</button></div>' +
      '<div class="cap-head"><div><div class="muted" style="font-size:12px">' + h(cap.codigo) + '</div><h2 style="margin:2px 0 4px">' + h(cap.nome) + '</h2>' +
      (obj ? '<div class="muted" style="font-size:13px">Objetivo: <b>' + h(labelObjetivo(obj)) + '</b></div>' : '<div class="muted" style="font-size:13px">Sem objetivo estratégico vinculado</div>') +
      (cap.descricao ? '<p style="margin:8px 0 0">' + h(cap.descricao) + '</p>' : '') + '</div>' +
      '<div class="classe-card st-' + res.status + ' ihc-card"><div class="cc-top"><span class="cc-cod">IHC</span>' + chip(res.status, true) + '</div><div class="ihc-valor">' + pct(res.ihc) + '</div>' +
      '<div class="cc-meta"><div><span>Grau de risco</span><b>' + h(MET.RISCO[res.status]) + '</b></div><div><span>Cobertura</span><b>' + pct(res.cobertura, 0) + '</b></div></div>' +
      (res.parcial ? '<div class="muted" style="font-size:11.5px">Resultado parcial: há dimensões sem dados.</div>' : '') + '</div></div>' +
      (res.essenciaisCrit.length ? '<div class="alert alert-warn">Atenção: dimensão essencial em situação crítica — ' + h(res.essenciaisCrit.join(', ')) + '.</div>' : '') + '</div>';

    html += '<div class="card"><div class="toolbar"><h2 style="margin:0">Dimensões (fatores determinantes)</h2><div class="sp"></div><button type="button" class="btn" onclick="UI.formFator(0,' + id + ')">+ Nova dimensão</button></div>';
    if (!dims.length) html += '<p class="vazio">Nenhuma dimensão cadastrada. Cadastre as dimensões que determinam esta capacidade; cada uma vira uma aba.</p></div>';
    else {
      html += '<div class="abas">' + dims.map(function (d) {
        return '<button type="button" class="aba st-' + d.status + (d.f.id === fid ? ' ativa' : '') + '" onclick="UI.selDim(' + id + ',' + d.f.id + ')"><i class="dot"></i>' + h(d.f.codigo + ' — ' + d.f.nome) + '</button>';
      }).join('') + '</div>';
      var d = dims.filter(function (x) { return x.f.id === fid; })[0];
      html += '<div class="aba-corpo st-' + d.status + '"><div class="toolbar"><div><b>' + h(d.f.codigo + ' — ' + d.f.nome) + '</b>' + (d.f.essencial ? ' <span class="badge badge-warn">essencial</span>' : '') +
        '<div class="muted" style="font-size:12px">' + h(d.f.descricao || '') + '</div></div><div class="sp"></div>' + chip(d.status, true) + chipRisco(d.status) +
        ' <span class="muted">Desempenho: <b>' + pct(d.desempenho, 1) + '</b></span></div>' +
        '<div class="toolbar"><button type="button" class="btn btn-sm" onclick="UI.vincularInd(' + d.f.id + ')">+ Vincular indicador</button>' +
        (d.ativos.length > 1 ? '<button type="button" class="btn btn-sm btn-outline" onclick="UI.abrirPesosInd(' + d.f.id + ')">⚖ Calcular pesos dos indicadores (AHP)</button>' : '') +
        '<div class="sp"></div><button type="button" class="btn btn-sm btn-outline" onclick="UI.formFator(' + d.f.id + ',' + id + ')">Editar dimensão</button>' +
        '<button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirDimensao(' + d.f.id + ')">Excluir dimensão</button></div>' +
        '<div class="subabas"><button type="button" class="subaba' + (subAba === 'ativos' ? ' ativa' : '') + '" onclick="UI.selSub(' + id + ',\'ativos\')">Ativos <span class="badge">' + d.ativos.length + '</span></button>' +
        '<button type="button" class="subaba' + (subAba === 'inativos' ? ' ativa' : '') + '" onclick="UI.selSub(' + id + ',\'inativos\')">Inativos <span class="badge">' + d.inativos.length + '</span></button></div>' +
        (subAba === 'ativos' ? tabelaInds(d.ativos, 'Nenhum indicador ativo nesta dimensão. Use <b>+ Vincular indicador</b> para escolher na lista do módulo Indicadores.') : tabelaInds(d.inativos, 'Nenhum indicador inativo.')) + '</div></div>';
    }
    return pagina('dashboard', html);
  }

  /* ---------- dimensão ---------- */
  UI.formFator = function (id, capId) {
    var r = id ? DB.one('SELECT * FROM fatores_determinantes WHERE id=?', [id]) : { capacidade_id: capId, codigo: '', nome: '', descricao: '' };
    openModal(modal(id ? 'Editar dimensão' : 'Nova dimensão (fator determinante)',
      '<div class="form-grid"><div class="campo"><label>Código *</label><input id="f_cod" value="' + h(r.codigo) + '" placeholder="Ex.: D1"></div>' +
      '<div class="campo"><label>Dimensão essencial?</label><select id="f_ess"><option value="0">Não</option><option value="1"' + (r.essencial ? ' selected' : '') + '>Sim — requisito legal, de segurança ou continuidade</option></select></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Nome *</label><input id="f_nome" value="' + h(r.nome) + '"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Descrição</label><textarea id="f_desc" rows="2">' + h(r.descricao || '') + '</textarea></div></div>' +
      '<input type="hidden" id="f_cap" value="' + (r.capacidade_id || capId) + '">', 'onclick="UI.salvarFator(' + (id || 0) + ')"'));
  };
  UI.salvarFator = function (id) {
    var cap = parseInt(val('f_cap'), 10), cod = val('f_cod').trim(), nome = val('f_nome').trim();
    if (!cod || !nome) { alert('Informe o código e o nome da dimensão.'); return; }
    var ess = parseInt(val('f_ess'), 10) || 0;
    if (id) DB.run('UPDATE fatores_determinantes SET codigo=?, nome=?, descricao=?, essencial=? WHERE id=?', [cod, nome, val('f_desc'), ess, id]);
    else { DB.run("INSERT INTO fatores_determinantes (capacidade_id, codigo, nome, descricao, status, essencial) VALUES (?,?,?,?, 'ativo', ?)", [cap, cod, nome, val('f_desc'), ess]); ABA.dim[cap] = lastId(); }
    persistirERota();
  };
  UI.excluirDimensao = function (fid) {
    var f = DB.one('SELECT * FROM fatores_determinantes WHERE id=?', [fid]); if (!f) return;
    var n = DB.one('SELECT COUNT(*) n FROM indicador_fatores WHERE fator_id=?', [fid]).n;
    if (!confirm('Excluir a dimensão ' + f.codigo + ' — ' + f.nome + '?' + (n ? '\nOs ' + n + ' indicador(es) serão apenas desvinculados (permanecem no módulo Indicadores).' : '') + '\nEsta ação não pode ser desfeita.')) return;
    apagarDimensao(fid); DB.persistir(); rota();
  };

  /* ====================== INDICADOR: ficha (idêntica ao SISREL) ====================== */
  function linhaCiclo(c) {
    c = c || {};
    return '<div class="ciclo-row"><label>Início<input type="date" class="cm-ini" value="' + h(String(c.data_inicio || '').slice(0, 10)) + '"></label>' +
      '<label>Término<input type="date" class="cm-fim" value="' + h(String(c.data_fim || '').slice(0, 10)) + '"></label>' +
      '<label>Meta<input type="number" step="any" class="cm-meta" value="' + (c.meta != null ? c.meta : '') + '" placeholder="Ex.: 95"></label>' +
      '<button type="button" class="btn btn-sm btn-danger" title="Remover ciclo" onclick="this.parentNode.remove()">×</button></div>';
  }
  function linhaItem(it) {
    it = it || {};
    return '<div class="it-row" data-id="' + (it.id || '') + '" data-peso="' + (it.peso != null ? it.peso : 1) + '"><input class="it-nome" placeholder="Nome do item" value="' + h(it.nome || '') + '">' +
      '<input class="it-uni" placeholder="Unidade" value="' + h(it.unidade || '') + '"><input class="it-obs" placeholder="Observação" value="' + h(it.observacao || '') + '">' +
      '<button type="button" class="btn btn-sm btn-danger" onclick="this.parentNode.remove()">×</button></div>';
  }
  UI.addCicloMeta = function () { document.getElementById('lista_ciclos').insertAdjacentHTML('beforeend', linhaCiclo()); };
  UI.addItemInd = function () { document.getElementById('lista_itens').insertAdjacentHTML('beforeend', linhaItem()); };
  UI.tipoInd = function () {
    var m = val('f_tipo') === 'multiplo';
    document.getElementById('bloco_simples').style.display = m ? 'none' : '';
    document.getElementById('bloco_multiplo').style.display = m ? '' : 'none';
  };
  UI.formIndicador = function (id, fatorId) {
    var r = id ? DB.one('SELECT * FROM indicadores WHERE id=?', [id]) : { processo_id: UI._procPre || null, nome: '', polaridade: 'maior_melhor', tipo: 'simples', unidade: '', item_nome: '', observacao: '', om_responsavel: '', usuario_cadastro: '' };
    var tipo = r.tipo === 'multiplo' ? 'multiplo' : 'simples';
    var ciclos = id ? MET.ciclosInd(id) : []; if (!ciclos.length) ciclos = [{}];
    var itens = id ? MET.itensIndicador(id) : []; if (!itens.length) itens = [{}, {}];
    openModal(modal(id ? 'Editar indicador' : 'Criar indicador',
      '<div class="form-grid">' +
      '<div class="campo" style="grid-column:1/-1"><label>Tipo *</label><select class="form-select" id="f_tipo" onchange="UI.tipoInd()">' +
      '<option value="simples"' + (tipo === 'simples' ? ' selected' : '') + '>Simples (um item mensurável)</option>' +
      '<option value="multiplo"' + (tipo === 'multiplo' ? ' selected' : '') + '>Múltiplo (vários itens independentes — ex.: gêneros)</option></select></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Nome do indicador *</label><input id="f_nome" value="' + h(r.nome) + '" placeholder="Ex.: Disponibilidade do serviço / Taxa de resolução"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Processo vinculado</label><select class="form-select" id="f_proc">' + UI.optsProc(r.processo_id) + '</select><small class="muted">O indicador mede o desempenho deste processo (módulo Processos). Pode ficar em branco.</small></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Polaridade (direção desejada) *</label><select class="form-select" id="f_pol">' +
      '<option value="maior_melhor"' + (r.polaridade !== 'menor_melhor' ? ' selected' : '') + '>📈 Quanto MAIOR, melhor (ex.: disponibilidade, cobertura)</option>' +
      '<option value="menor_melhor"' + (r.polaridade === 'menor_melhor' ? ' selected' : '') + '>📉 Quanto MENOR, melhor (ex.: perdas, avarias, consumo excedente)</option></select>' +
      '<small class="muted">Para "menor é melhor", a meta ideal costuma ser <b>0</b>.</small></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Ciclos de metas *</label><div id="lista_ciclos" class="caixa-lista">' + ciclos.map(linhaCiclo).join('') + '</div>' +
      '<button type="button" class="btn btn-sm btn-outline" style="margin-top:6px" onclick="UI.addCicloMeta()">+ Adicionar ciclo</button>' +
      '<small class="muted">A meta é definida <b>somente pelos ciclos</b> (um ou vários). Todos os itens obedecem à meta do ciclo vigente em cada mês.</small></div></div>' +
      '<div id="bloco_simples" class="form-grid" style="' + (tipo === 'multiplo' ? 'display:none' : '') + '">' +
      '<div class="campo"><label>Item *</label><input id="f_item" value="' + h(r.item_nome || '') + '" placeholder="Ex.: Solicitações respondidas"></div>' +
      '<div class="campo"><label>Unidade *</label><input id="f_uni" value="' + h(r.unidade || '') + '" placeholder="Ex.: unidades, horas, %"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Observação</label><input id="f_obs" value="' + h(r.observacao || '') + '" placeholder="Observações adicionais"></div></div>' +
      '<div id="bloco_multiplo" style="' + (tipo === 'multiplo' ? '' : 'display:none') + '"><div class="campo"><label>Itens do indicador *</label>' +
      '<div id="lista_itens" class="caixa-lista">' + itens.map(linhaItem).join('') + '</div><button type="button" class="btn btn-sm btn-outline" style="margin-top:6px" onclick="UI.addItemInd()">+ Adicionar item</button>' +
      '<small class="muted">Os itens <b>compartilham a meta do indicador</b>. Não há meta por item. Os pesos dos itens podem ser calculados por AHP na página do indicador.</small></div>' +
      '<div class="campo"><label>Observação geral do indicador</label><input id="f_obsm" value="' + h(r.observacao || '') + '"></div></div>' +
      '<div class="form-grid" style="margin-top:8px"><div class="campo"><label>Organização responsável *</label><input id="f_om" value="' + h(r.om_responsavel || '') + '" placeholder="Ex.: Nome da organização"></div>' +
      '<div class="campo"><label>Usuário responsável pelo cadastro *</label><input id="f_usr" value="' + h(r.usuario_cadastro || '') + '" placeholder="Ex.: Gestor da capacidade"></div></div>' +
      '<input type="hidden" id="f_fator" value="' + (fatorId || 0) + '">', 'onclick="UI.salvarIndicador(' + (id || 0) + ')"'), { wide: true });
  };
  UI.salvarIndicador = function (id) {
    var nome = val('f_nome').trim(), tipo = val('f_tipo') === 'multiplo' ? 'multiplo' : 'simples', pol = val('f_pol');
    if (!nome) { alert('Informe o nome do indicador.'); return; }
    var ciclos = [], okC = true;
    Array.prototype.forEach.call(document.querySelectorAll('#lista_ciclos .ciclo-row'), function (row) {
      var ini = row.querySelector('.cm-ini').value, fim = row.querySelector('.cm-fim').value, mt = parseFloat(row.querySelector('.cm-meta').value);
      if (!ini && !fim && isNaN(mt)) return;
      if (!ini || !fim || isNaN(mt) || fim < ini) { okC = false; return; }
      ciclos.push({ ini: ini, fim: fim, meta: mt });
    });
    if (!okC || !ciclos.length) { alert('Informe ao menos um ciclo de meta com início, término (posterior ao início) e meta.'); return; }
    var itens = [];
    if (tipo === 'multiplo') {
      Array.prototype.forEach.call(document.querySelectorAll('#lista_itens .it-row'), function (row, k) {
        var n = row.querySelector('.it-nome').value.trim(); if (!n) return;
        itens.push({ id: parseInt(row.getAttribute('data-id'), 10) || 0, nome: n, unidade: row.querySelector('.it-uni').value.trim(), obs: row.querySelector('.it-obs').value.trim(), peso: parseFloat(row.getAttribute('data-peso')) || 1, ordem: k });
      });
      if (itens.length < 2) { alert('Um indicador múltiplo precisa de pelo menos 2 itens.'); return; }
    } else {
      if (!val('f_item').trim() || !val('f_uni').trim()) { alert('Informe o item e a unidade.'); return; }
    }
    var om = val('f_om').trim(), usr = val('f_usr').trim();
    if (!om || !usr) { alert('Informe a organização responsável e o usuário responsável pelo cadastro.'); return; }
    if (id) {
      var ant = DB.one('SELECT tipo FROM indicadores WHERE id=?', [id]) || {};
      if ((ant.tipo || 'simples') !== tipo && !confirm('Mudar o tipo do indicador deixa de considerar os registros já lançados no tipo anterior. Continuar?')) return;
    }
    var obs = tipo === 'multiplo' ? val('f_obsm') : val('f_obs'), uni = tipo === 'multiplo' ? '' : val('f_uni').trim(), item = tipo === 'multiplo' ? '' : val('f_item').trim();
    if (id) DB.run('UPDATE indicadores SET nome=?, polaridade=?, tipo=?, unidade=?, item_nome=?, observacao=?, om_responsavel=?, usuario_cadastro=?, responsavel=? WHERE id=?', [nome, pol, tipo, uni, item, obs, om, usr, om, id]);
    else {
      DB.run("INSERT INTO indicadores (codigo, nome, polaridade, tipo, unidade, item_nome, observacao, om_responsavel, usuario_cadastro, responsavel, periodicidade, status) VALUES (?,?,?,?,?,?,?,?,?,?, 'mensal', 'ativo')", [MET.proximoCodigoInd(), nome, pol, tipo, uni, item, obs, om, usr, om]);
      id = lastId();
    }
    DB.run('UPDATE indicadores SET processo_id=? WHERE id=?', [parseInt(val('f_proc'), 10) || null, id]);
    DB.run('DELETE FROM ind_ciclos WHERE indicador_id=?', [id]);
    ciclos.forEach(function (c) { DB.run('INSERT INTO ind_ciclos (indicador_id, data_inicio, data_fim, meta) VALUES (?,?,?,?)', [id, c.ini, c.fim, c.meta]); });
    if (tipo === 'multiplo') {
      var mantidos = itens.filter(function (i) { return i.id; }).map(function (i) { return i.id; });
      DB.rows('SELECT id FROM indicador_itens WHERE indicador_id=?', [id]).forEach(function (e) {
        if (mantidos.indexOf(e.id) < 0) { DB.run('DELETE FROM lanc_itm WHERE item_id=?', [e.id]); DB.run('DELETE FROM indicador_itens WHERE id=?', [e.id]); }
      });
      var soma = 0; itens.forEach(function (i) { soma += i.peso; });
      itens.forEach(function (i) {
        if (i.id) DB.run('UPDATE indicador_itens SET nome=?, unidade=?, observacao=?, ordem=? WHERE id=?', [i.nome, i.unidade, i.obs, i.ordem, i.id]);
        else DB.run('INSERT INTO indicador_itens (indicador_id, nome, unidade, observacao, peso, ordem) VALUES (?,?,?,?,?,?)', [id, i.nome, i.unidade, i.obs, 1 / itens.length, i.ordem]);
      });
      if (itens.some(function (i) { return !i.id; })) DB.run('UPDATE indicador_itens SET peso=? WHERE indicador_id=?', [1 / itens.length, id]);
    }
    var fatorId = parseInt(val('f_fator'), 10);
    if (fatorId && !DB.one('SELECT id FROM indicador_fatores WHERE indicador_id=? AND fator_id=?', [id, fatorId])) {
      DB.run('INSERT INTO indicador_fatores (indicador_id, fator_id, grh) VALUES (?,?,0)', [id, fatorId]);
      var qtd = DB.one('SELECT COUNT(*) n FROM indicador_fatores WHERE fator_id=?', [fatorId]).n;
      DB.run('UPDATE indicador_fatores SET grh=? WHERE fator_id=?', [1 / qtd, fatorId]);
    }
    fechar(); DB.persistir(); UI._procPre = null; if (/novo=1/.test(location.hash)) location.hash = '#/indicador?id=' + id; else rota();
  };
  UI.alternarInd = function (id) {
    var r = DB.one('SELECT status FROM indicadores WHERE id=?', [id]); if (!r) return;
    var novo = r.status === 'inativo' ? 'ativo' : 'inativo';
    if (novo === 'inativo' && !confirm('Inativar o indicador? Ele deixa de compor a situação, o IHC e o ICV, mas seus registros são preservados.')) return;
    DB.run('UPDATE indicadores SET status=? WHERE id=?', [novo, id]); DB.persistir(); rota();
  };
  UI.excluirIndicador = function (id) {
    var r = DB.one('SELECT nome FROM indicadores WHERE id=?', [id]); if (!r) return;
    if (!confirm('Excluir o indicador "' + r.nome + '" e todos os seus registros de valores?\nEsta ação não pode ser desfeita.')) return;
    var fx = DB.one('SELECT f.capacidade_id c FROM indicador_fatores x JOIN fatores_determinantes f ON f.id=x.fator_id WHERE x.indicador_id=?', [id]);
    apagarIndicador(id); DB.persistir();
    if (location.hash.indexOf('#/indicador') === 0) location.hash = '#/indicadores'; else rota();
  };

  /* ---------- registros de valor ---------- */
  function mesAtual() { return new Date().toISOString().slice(0, 7); }
  function lerMes(txt) {
    txt = String(txt || '').trim();
    if (/^\d{4}-\d{2}/.test(txt)) return txt.slice(0, 7);
    var m = txt.match(/^(\d{1,2})\/(\d{4})$/); if (m) return m[2] + '-' + ('0' + m[1]).slice(-2);
    return '';
  }
  UI.formLanc = function (indId, mesEd) {
    var ind = DB.one('SELECT * FROM indicadores WHERE id=?', [indId]); if (!ind) return;
    var multi = ind.tipo === 'multiplo', mes = mesEd || mesAtual(), corpo;
    if (multi) {
      var itens = MET.itensIndicador(indId);
      corpo = '<div class="campo"><label>Mês de referência *</label><input type="month" id="l_mes" value="' + h(mes) + '" placeholder="AAAA-MM"></div><div class="campo"><label>Valores por item</label>' +
        itens.map(function (it) {
          var r = DB.one('SELECT valor FROM lanc_itm WHERE item_id=? AND mes_ano=?', [it.id, mes]);
          return '<div class="lanc-item"><span>' + h(it.nome) + (it.unidade ? ' <small class="muted">(' + h(it.unidade) + ')</small>' : '') + '</span><input type="number" step="any" class="l_item" data-id="' + it.id + '" value="' + (r && r.valor != null ? r.valor : '') + '"></div>';
        }).join('') + '<small class="muted">Itens em branco não são registrados no mês.</small></div>';
    } else {
      var rr = DB.one('SELECT valor, observacao FROM lanc_ind WHERE indicador_id=? AND mes_ano=?', [indId, mes]) || {};
      corpo = '<div class="form-grid"><div class="campo"><label>Mês de referência *</label><input type="month" id="l_mes" value="' + h(mes) + '" placeholder="AAAA-MM"></div>' +
        '<div class="campo"><label>Valor' + (ind.unidade ? ' (' + h(ind.unidade) + ')' : '') + ' *</label><input type="number" step="any" id="l_valor" value="' + (rr.valor != null ? rr.valor : '') + '"></div>' +
        '<div class="campo" style="grid-column:1/-1"><label>Observação</label><input id="l_obs" value="' + h(rr.observacao || '') + '"></div></div>';
    }
    openModal(modal((mesEd ? 'Editar' : 'Novo') + ' registro — ' + ind.nome, (mesEd ? '' : ajuda('Se já houver registro no mês informado, ele será substituído.')) + corpo, 'onclick="UI.salvarLanc(' + indId + ')"'));
  };
  UI.salvarLanc = function (indId) {
    var ind = DB.one('SELECT * FROM indicadores WHERE id=?', [indId]), mes = lerMes(val('l_mes'));
    if (!mes) { alert('Informe o mês de referência.'); return; }
    if (ind.tipo === 'multiplo') {
      var algum = false;
      Array.prototype.forEach.call(document.querySelectorAll('.l_item'), function (el) {
        var v = parseFloat(el.value), iid = parseInt(el.getAttribute('data-id'), 10);
        DB.run('DELETE FROM lanc_itm WHERE item_id=? AND mes_ano=?', [iid, mes]);
        if (!isNaN(v)) { algum = true; DB.run('INSERT INTO lanc_itm (item_id, indicador_id, mes_ano, valor) VALUES (?,?,?,?)', [iid, indId, mes, v]); }
      });
      if (!algum) { alert('Informe o valor de ao menos um item.'); return; }
    } else {
      var v = parseFloat(val('l_valor')); if (isNaN(v)) { alert('Informe o valor.'); return; }
      DB.run('DELETE FROM lanc_ind WHERE indicador_id=? AND mes_ano=?', [indId, mes]);
      DB.run('INSERT INTO lanc_ind (indicador_id, mes_ano, valor, observacao) VALUES (?,?,?,?)', [indId, mes, v, val('l_obs')]);
    }
    persistirERota();
  };
  UI.excluirLanc = function (indId, mes) {
    if (!confirm('Excluir o registro de ' + MET.fmtMes(mes) + '?')) return;
    DB.run('DELETE FROM lanc_ind WHERE indicador_id=? AND mes_ano=?', [indId, mes]);
    DB.run('DELETE FROM lanc_itm WHERE indicador_id=? AND mes_ano=?', [indId, mes]);
    DB.persistir(); rota();
  };

    /* ---------- AXIA: vínculo indicador ↔ dimensão (lista de escolha do módulo Indicadores) ---------- */
  UI.vincularInd = function (fid) {
    var f = DB.one('SELECT * FROM fatores_determinantes WHERE id=?', [fid]); if (!f) return;
    var lista = DB.rows("SELECT i.id, i.codigo, i.nome, i.tipo, i.status, i.unidade, (SELECT p.nome FROM processos p WHERE p.id=i.processo_id) AS proc FROM indicadores i WHERE i.id NOT IN (SELECT indicador_id FROM indicador_fatores WHERE fator_id=?) ORDER BY i.nome COLLATE NOCASE", [fid]);
    var corpo;
    if (!lista.length) {
      corpo = '<p class="vazio">Não há indicadores disponíveis. Cadastre-os no módulo <a href="#/indicadores">Indicadores</a> (idealmente vinculados a um processo) e volte aqui.</p>';
    } else {
      corpo = '<div class="campo" style="grid-column:1/-1"><label>Selecione os indicadores que compõem esta dimensão</label>' +
        '<div class="mb-2 d-flex flex-wrap gap-2 align-items-center"><input type="search" class="form-control form-control-sm" id="vi_busca" placeholder="Filtrar por código, nome ou processo…" oninput="UI.filtrarVinculoInd(this.value)" style="flex:1;min-width:180px">' +
        '<span class="small muted" id="vi_contagem">0 selecionado(s)</span></div>' +
        '<div class="caixa-lista" id="vi_lista" style="max-height:min(60vh,480px);overflow:auto;border:1px solid var(--borda,#dee2e6);border-radius:8px">' +
        '<table class="table table-sm table-hover align-middle mb-0"><thead class="table-light sticky-top"><tr>' +
        '<th style="width:42px" class="text-center"><input type="checkbox" class="form-check-input vi_ck_all" title="Marcar todos" onclick="UI.marcarTodosVinculo(this.checked)"></th>' +
        '<th style="width:100px">Código</th><th>Nome</th><th style="width:90px">Tipo</th><th>Processo</th><th style="width:70px">Status</th></tr></thead><tbody>' +
        lista.map(function (i) {
          return '<tr class="vi-row" data-txt="' + h((i.codigo + ' ' + i.nome + ' ' + (i.proc || '')).toLowerCase()) + '" onclick="UI.toggleVinculoRow(event, this)">' +
            '<td class="text-center" onclick="event.stopPropagation()"><input type="checkbox" class="form-check-input vi_ck" value="' + i.id + '" onchange="UI.atualizarVinculoSel()" style="width:1.15rem;height:1.15rem;cursor:pointer"></td>' +
            '<td><b>' + h(i.codigo || '—') + '</b></td>' +
            '<td>' + h(i.nome) + (i.unidade ? ' <small class="muted">(' + h(i.unidade) + ')</small>' : '') + '</td>' +
            '<td><span class="badge text-bg-light border">' + (i.tipo === 'multiplo' ? 'múltiplo' : 'simples') + '</span></td>' +
            '<td class="small">' + h(i.proc || '—') + '</td>' +
            '<td>' + (i.status === 'inativo' ? '<span class="badge badge-muted">inativo</span>' : '<span class="badge text-bg-success">ativo</span>') + '</td></tr>';
        }).join('') +
        '</tbody></table></div>' +
        '<small class="muted">Clique na linha ou no quadrado para selecionar. Os valores e metas vêm do módulo Indicadores; aqui apenas se escolhe o que compõe a dimensão.</small></div>';
    }
    openModal(modal('Vincular indicadores à dimensão ' + f.codigo + ' — ' + f.nome, corpo, lista.length ? 'onclick="UI.salvarVinculoInd(' + fid + ')"' : '', 'Vincular'), { wide: true, xwide: true });
    setTimeout(function () { UI.atualizarVinculoSel(); }, 0);
  };
  UI.filtrarVinculoInd = function (q) {
    q = String(q || '').trim().toLowerCase();
    Array.prototype.forEach.call(document.querySelectorAll('#vi_lista .vi-row'), function (tr) {
      tr.style.display = !q || (tr.getAttribute('data-txt') || '').indexOf(q) >= 0 ? '' : 'none';
    });
  };
  UI.toggleVinculoRow = function (ev, tr) {
    if (!tr) return;
    var ck = tr.querySelector('.vi_ck');
    if (!ck) return;
    ck.checked = !ck.checked;
    UI.atualizarVinculoSel();
  };
  UI.marcarTodosVinculo = function (on) {
    Array.prototype.forEach.call(document.querySelectorAll('#vi_lista .vi-row'), function (tr) {
      if (tr.style.display === 'none') return;
      var ck = tr.querySelector('.vi_ck');
      if (ck) ck.checked = !!on;
    });
    UI.atualizarVinculoSel();
  };
  UI.atualizarVinculoSel = function () {
    var n = 0;
    Array.prototype.forEach.call(document.querySelectorAll('#vi_lista .vi-row'), function (tr) {
      var ck = tr.querySelector('.vi_ck');
      var on = ck && ck.checked;
      if (on) n++;
      if (on) tr.classList.add('table-success'); else tr.classList.remove('table-success');
    });
    var el = document.getElementById('vi_contagem');
    if (el) el.textContent = n + ' selecionado(s)';
    var all = document.querySelector('.vi_ck_all');
    if (all) {
      var vis = Array.prototype.filter.call(document.querySelectorAll('#vi_lista .vi-row'), function (tr) { return tr.style.display !== 'none'; });
      var checked = vis.filter(function (tr) { var c = tr.querySelector('.vi_ck'); return c && c.checked; });
      all.checked = vis.length > 0 && checked.length === vis.length;
      all.indeterminate = checked.length > 0 && checked.length < vis.length;
    }
  };
  UI.salvarVinculoInd = function (fid) {
    var ids = Array.prototype.map.call(document.querySelectorAll('.vi_ck:checked'), function (e) { return parseInt(e.value, 10); });
    if (!ids.length) { alert('Marque ao menos um indicador.'); return; }
    ids.forEach(function (iid) { if (!DB.one('SELECT id FROM indicador_fatores WHERE indicador_id=? AND fator_id=?', [iid, fid])) DB.run('INSERT INTO indicador_fatores (indicador_id, fator_id, grh) VALUES (?,?,0)', [iid, fid]); });
    var qtd = DB.one('SELECT COUNT(*) n FROM indicador_fatores WHERE fator_id=?', [fid]).n;
    DB.run('UPDATE indicador_fatores SET grh=? WHERE fator_id=?', [1 / qtd, fid]);
    persistirERota();
  };
  UI.desvincularInd = function (iid, fid) {
    var i = DB.one('SELECT nome FROM indicadores WHERE id=?', [iid]); if (!i) return;
    if (!confirm('Desvincular "' + i.nome + '" desta dimensão? O indicador e seus registros permanecem no módulo Indicadores.')) return;
    DB.run('DELETE FROM indicador_fatores WHERE indicador_id=? AND fator_id=?', [iid, fid]);
    var qtd = DB.one('SELECT COUNT(*) n FROM indicador_fatores WHERE fator_id=?', [fid]).n;
    if (qtd) DB.run('UPDATE indicador_fatores SET grh=? WHERE fator_id=?', [1 / qtd, fid]);
    persistirERota();
  };
  UI.optsProc = function (sel) { return '<option value="">— sem processo —</option>' + DB.rows('SELECT id, nome FROM processos ORDER BY nome COLLATE NOCASE').map(function (p) { return '<option value="' + p.id + '"' + (+sel === p.id ? ' selected' : '') + '>' + h(p.nome) + '</option>'; }).join(''); };
  UI.procLink = function (pid) { var p = pid ? DB.one('SELECT id, nome FROM processos WHERE id=?', [pid]) : null; return p ? '<a href="#/folha?id=' + p.id + '">' + h(p.nome) + '</a>' : '—'; };
  UI.novoIndicador = function (pid) { UI._procPre = pid || null; UI.formIndicador(0, 0); };

  /* ====================== PÁGINA DO INDICADOR ====================== */
  var EDITORES = {};
  function paginaIndicador(q) {
    var id = parseInt(q.id, 10), ind = DB.one('SELECT * FROM indicadores WHERE id=?', [id]);
    if (!ind) return pagina('lista', '<div class="card"><p class="vazio">Indicador não encontrado.</p><a class="btn" href="#/indicadores">Voltar</a></div>');
    var e = MET.avaliarIndicador(ind), multi = e.tipo === 'multiplo';
    var loc = DB.one('SELECT f.id fid, f.codigo fcod, f.nome fnome, c.id cid, c.codigo ccod, c.nome cnome FROM indicador_fatores x JOIN fatores_determinantes f ON f.id=x.fator_id JOIN capacidades c ON c.id=f.capacidade_id WHERE x.indicador_id=?', [id]);
    if (loc) ABA.dim[loc.cid] = loc.fid;
    var disp = MET.dispersao(e);
    var html = '<div class="card"><div class="toolbar"><a class="btn btn-outline btn-sm" href="#/indicadores">← Indicadores</a>' + (loc ? '<a class="btn btn-outline btn-sm" style="margin-left:6px" href="#/valor/capacidade?id=' + loc.cid + '">' + h(loc.ccod) + ' · ' + h(loc.fcod) + ' (Valor Estratégico)</a>' : '') + '<div class="sp"></div>' +
      (/^PRJ-PROG-/.test(ind.codigo || '') ? '' : '<button type="button" class="btn btn-sm" onclick="UI.formLanc(' + id + ')">Registro</button>') +
      '<button type="button" class="btn btn-sm btn-outline" onclick="UI.formIndicador(' + id + ',0)">Editar</button>' +
      '<button type="button" class="btn btn-sm btn-outline" onclick="UI.alternarInd(' + id + ')">' + (e.ativo ? 'Inativar' : 'Ativar') + '</button>' +
      '<button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirIndicador(' + id + ')">Excluir</button></div>' +
      '<div class="muted" style="font-size:12px">' + h(ind.codigo) + (loc ? ' · ' + h(loc.cnome) + ' · ' + h(loc.fnome) : '') + '</div><h2 style="margin:2px 0 8px">' + h(ind.nome) + (e.ativo ? '' : ' <span class="badge badge-muted">inativo</span>') + '</h2>' +
      '<div class="kpi-grid">' + kpi('Último valor', multi ? 'composto' : fmtVal(e.valor, ind.unidade), e.mes ? MET.fmtMes(e.mes) : 'sem registros') +
      kpi('Meta vigente', e.meta == null ? '—' : num(e.meta, 2), ind.polaridade === 'menor_melhor' ? 'menor é melhor' : 'maior é melhor') +
      kpi('% da meta', pct(e.pct, 1), '') + kpi('Desvio da meta', e.desvio == null ? '—' : num(e.desvio, 2), 'distância à meta') +
      '<div class="classe-card st-' + e.status + ' kpi-status"><div class="cc-top"><span class="cc-cod">Situação</span></div>' + chip(e.status) + '<div style="margin-top:6px">' + chipRisco(e.status) + '</div></div></div>' +
      '<div class="rel-ficha"><div><span>Tipo:</span> ' + (multi ? 'múltiplo' : 'simples') + '</div>' + (multi ? '' : '<div><span>Item:</span> ' + h(ind.item_nome || '—') + '</div><div><span>Unidade:</span> ' + h(ind.unidade || '—') + '</div>') +
      '<div><span>Processo vinculado:</span> ' + UI.procLink(ind.processo_id) + '</div><div><span>Organização responsável:</span> ' + h(ind.om_responsavel || '—') + '</div><div><span>Cadastro:</span> ' + h(ind.usuario_cadastro || '—') + '</div>' + (ind.observacao ? '<div><span>Observação:</span> ' + h(ind.observacao) + '</div>' : '') + '</div>' +
      '<div class="muted" style="font-size:12.5px;margin-top:6px"><b>Ciclos de metas:</b> ' + (e.ciclos.map(function (c) { return MET.fmtMes(String(c.data_inicio).slice(0, 7)) + ' a ' + MET.fmtMes(String(c.data_fim).slice(0, 7)) + ' → meta ' + num(c.meta, 2); }).join(' · ') || '—') + '</div></div>';

    html += '<div class="card"><h2>Evolução do indicador</h2>' + (e.serie.length ? '<div class="chart-box" style="height:340px"><canvas id="g_ind"></canvas></div>' : '<p class="vazio">Sem registros — use o botão <b>Registro</b> para ver o gráfico.</p>') +
      (disp ? '<p class="muted" style="font-size:12.5px">Análise de dispersão (Six Sigma, exploratória — ' + disp.n + ' apurações): média ' + num(disp.media, 2) + ', desvio-padrão ' + num(disp.desvio, 2) + ', distância desfavorável à meta de ' + num(disp.z, 2) + ' desvios.</p>' : '') + '</div>';

    if (multi) {
      html += '<div class="card"><div class="toolbar"><h2 style="margin:0">Itens do indicador</h2><div class="sp"></div>' + (e.itens.length > 1 ? '<button type="button" class="btn btn-sm btn-outline" onclick="UI.abrirPesosItens(' + id + ')">⚖ Pesos dos itens (AHP)</button>' : '') + '</div>' +
        '<table class="tabela-compacta"><thead><tr><th>Item</th><th>Unidade</th><th class="num">Último valor</th><th class="num">% da meta</th><th>Situação</th><th class="num">Peso</th></tr></thead><tbody>' +
        e.itens.map(function (i) { var tot = e.itens.reduce(function (s, x) { return s + (+x.peso || 0); }, 0) || 1; return '<tr><td>' + h(i.nome) + '</td><td>' + h(i.unidade || '') + '</td><td class="num">' + num(i.valor, 2) + '</td><td class="num">' + pct(i.pct, 0) + '</td><td>' + chip(i.status) + '</td><td class="num">' + pct((+i.peso || 0) / tot, 0) + '</td></tr>'; }).join('') + '</tbody></table></div>';
    }

    html += '<div class="card"><h2>Registros de valores</h2>';
    if (!e.serie.length) html += '<p class="vazio">Nenhum registro lançado.</p>';
    else if (multi) {
      var meses = {}; e.itens.forEach(function (i) { i.registros.forEach(function (r) { (meses[r.mes_ano] = meses[r.mes_ano] || {})[i.id] = r.valor; }); });
      html += '<div class="tabela-wrap"><table class="tabela-compacta"><thead><tr><th>Mês</th>' + e.itens.map(function (i) { return '<th class="num">' + h(i.nome) + '</th>'; }).join('') + '<th class="num">Meta</th><th></th></tr></thead><tbody>' +
        Object.keys(meses).sort().reverse().map(function (m) {
          return '<tr><td>' + h(MET.fmtMes(m)) + '</td>' + e.itens.map(function (i) { return '<td class="num">' + (meses[m][i.id] != null ? num(meses[m][i.id], 2) : '—') + '</td>'; }).join('') + '<td class="num">' + num(MET.metaDoMes(e.ciclos, m), 2) + '</td><td class="acoes"><button type="button" class="btn btn-sm btn-outline" onclick="UI.formLanc(' + id + ',\'' + m + '\')">Editar</button> <button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirLanc(' + id + ',\'' + m + '\')">Excluir</button></td></tr>';
        }).join('') + '</tbody></table></div>';
    } else {
      html += '<div class="tabela-wrap"><table class="tabela-compacta"><thead><tr><th>Mês</th><th class="num">Valor</th><th class="num">Meta do mês</th><th class="num">% da meta</th><th>Situação</th><th>Observação</th><th></th></tr></thead><tbody>' +
        e.serie.slice().reverse().map(function (s) {
          return '<tr><td>' + h(MET.fmtMes(s.mes)) + '</td><td class="num">' + num(s.valor, 2) + '</td><td class="num">' + num(s.meta, 2) + '</td><td class="num">' + pct(s.pct, 0) + '</td><td>' + chip(MET.classe(s.pct)) + '</td><td class="muted">' + h(s.observacao || '') + '</td>' +
            '<td class="acoes">' + (/^PRJ-PROG-/.test(ind.codigo || '') ? '' : '<button type="button" class="btn btn-sm btn-outline" onclick="UI.formLanc(' + id + ',\'' + s.mes + '\')">Editar</button> <button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirLanc(' + id + ',\'' + s.mes + '\')">Excluir</button>') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    html += '</div>';

    html += '<div class="card"><h2>Análise crítica</h2><p class="muted" style="margin:0 0 8px">Interpretação dos resultados, causas e contexto.</p><div id="ed_analise"></div><div class="toolbar" style="margin-top:10px"><button type="button" class="btn" onclick="UI.salvarTexto(' + id + ',\'analise\')">Salvar análise</button><span id="ok_analise" class="muted"></span></div></div>' +
      '<div class="card"><h2>Plano de ação</h2><p class="muted" style="margin:0 0 8px">Ações, responsáveis, prazos, recursos e resultado esperado para este indicador.</p><div id="ed_plano"></div><div class="toolbar" style="margin-top:10px"><button type="button" class="btn" onclick="UI.salvarTexto(' + id + ',\'plano\')">Salvar plano de ação</button><span id="ok_plano" class="muted"></span></div></div>';

    setTimeout(function () {
      if (e.serie.length && document.getElementById('g_ind')) {
        w.OPTCharts.evolucao('g_ind', e.serie.map(function (s) { return MET.fmtMes(s.mes); }), e.serie.map(function (s) { return s.valor; }), e.serie.map(function (s) { return s.meta; }), { titulo: ind.nome + (ind.unidade ? ' (' + ind.unidade + ')' : ''), labelValor: multi ? 'Valor composto' : 'Valor apurado', labelMeta: 'Meta' });
      }
      [['analise', ind.analise_html], ['plano', ind.plano_html]].forEach(function (p) {
        var el = document.getElementById('ed_' + p[0]); if (!el || !w.SisrelEditor) return;
        w.SisrelEditor.criar(el, { placeholder: p[0] === 'plano' ? 'Descreva as ações do plano…' : 'Escreva a análise crítica…', dados: p[1] ? w.SisrelHtml.seguro(p[1]) : '', minAltura: p[0] === 'plano' ? 260 : 180 })
          .then(function (ed) { EDITORES[p[0]] = ed; if (p[1] && ed.setData) ed.setData(w.SisrelHtml.seguro(p[1])); }).catch(function (er) { el.innerHTML = '<p class="alert alert-warn">Editor indisponível: ' + h(er && er.message || er) + '</p>'; });
      });
    }, 60);
    return pagina('indicadores', html);
  }
  UI.salvarTexto = function (id, qual) {
    var ed = EDITORES[qual]; if (!ed) return;
    var html = w.SisrelHtml.seguro(ed.getData() || '');
    DB.run('UPDATE indicadores SET ' + (qual === 'plano' ? 'plano_html' : 'analise_html') + '=? WHERE id=?', [html, id]); DB.persistir();
    var ok = document.getElementById('ok_' + qual); if (ok) { ok.textContent = 'Salvo às ' + new Date().toLocaleTimeString('pt-BR'); }
  };

  /* ====================== OBJETIVOS / ICV ====================== */
  var OBJ = { sel: 0 };
  UI.selObj = function (id) { OBJ.sel = id; rota(); };
  UI.formObjetivo = function (id) {
    var r = id ? DB.one('SELECT * FROM objetivos_estrategicos WHERE id=?', [id]) : { codigo: '', nome: '', descricao: '' };
    openModal(modal(id ? 'Editar objetivo estratégico' : 'Novo objetivo estratégico',
      '<div class="form-grid"><div class="campo"><label>Código *</label><input id="f_cod" value="' + h(r.codigo) + '" placeholder="Ex.: OE-01"></div><div class="campo"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Nome *</label><input id="f_nome" value="' + h(r.nome) + '"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Descrição</label><textarea id="f_desc" rows="2">' + h(r.descricao || '') + '</textarea></div></div>', 'onclick="UI.salvarObjetivo(' + (id || 0) + ')"'));
  };
  UI.salvarObjetivo = function (id) {
    var cod = val('f_cod').trim(), nome = val('f_nome').trim();
    if (!cod || !nome) { alert('Informe o código e o nome.'); return; }
    if (DB.one('SELECT id FROM objetivos_estrategicos WHERE lower(codigo)=? AND id<>?', [norm(cod), id || 0])) { alert('Já existe um objetivo com esse código.'); return; }
    if (id) DB.run('UPDATE objetivos_estrategicos SET codigo=?, nome=?, descricao=? WHERE id=?', [cod, nome, val('f_desc'), id]);
    else { DB.run("INSERT INTO objetivos_estrategicos (codigo, nome, descricao, status) VALUES (?,?,?, 'ativo')", [cod, nome, val('f_desc')]); OBJ.sel = lastId(); }
    persistirERota();
  };
  UI.excluirObjetivo = function (id) {
    var o = DB.one('SELECT * FROM objetivos_estrategicos WHERE id=?', [id]); if (!o) return;
    var n = DB.one('SELECT COUNT(*) n FROM objetivo_capacidades WHERE objetivo_id=?', [id]).n;
    if (!confirm('Excluir o objetivo ' + o.codigo + ' — ' + o.nome + '?' + (n ? '\nAs ' + n + ' capacidade(s) vinculada(s) não serão excluídas, mas ficarão sem objetivo.' : ''))) return;
    DB.run('DELETE FROM objetivo_capacidades WHERE objetivo_id=?', [id]); DB.run('DELETE FROM metas_objetivo_ciclo WHERE objetivo_id=?', [id]); DB.run('DELETE FROM va_planos WHERE objetivo_id=?', [id]); DB.run('DELETE FROM objetivos_estrategicos WHERE id=?', [id]);
    OBJ.sel = 0; DB.persistir(); rota();
  };
  function paginaObjetivos(q) {
    var objs = DB.rows("SELECT * FROM objetivos_estrategicos WHERE status='ativo' ORDER BY codigo");
    if (q.ciclo) MET.cicloSel = parseInt(q.ciclo, 10) || null;
    var ciclos = MET.ciclos(), cic = MET.cicloAtivo();
    var html = '<div class="card"><div class="toolbar"><a class="btn btn-outline btn-sm" href="#/valor">← Dashboard</a><h2 style="margin:0 0 0 6px">ICV · Objetivos estratégicos</h2></div>' +
      cadeiaValor() + ajuda('O <b>ICV</b> (Índice de Captura de Valor) de cada objetivo é calculado no <b>ciclo estratégico</b> escolhido: <b>ICV = Σ Wc × C</b>, em que <b>Wc</b> é o peso AHP da capacidade e <b>C</b> a contribuição da capacidade em relação à <b>meta do objetivo no ciclo</b> (C = IHC ÷ meta, limitado a 100%). A situação segue a <b>Curva ABC</b> (acima de 95% em conformidade · 75% a 95% em atenção · abaixo de 75% estado crítico) e o desvio em relação à meta segue o parâmetro <b>Six Sigma</b> (abaixo de 5% risco baixo · 5% a 25% médio · acima de 25% alto).') +
      '<div class="toolbar"><label style="margin-right:8px"><b>Ciclo estratégico:</b></label>' +
      (ciclos.length ? '<select id="sel_ciclo" onchange="UI.selCiclo(this.value)">' + ciclos.map(function (c) { return '<option value="' + c.id + '"' + (cic && cic.id === c.id ? ' selected' : '') + '>' + h((c.codigo ? c.codigo + ' — ' : '') + c.nome + ' (' + MET.fmtData(c.data_inicio) + ' a ' + MET.fmtData(c.data_fim) + ')') + '</option>'; }).join('') + '</select>' : '<span class="muted">Nenhum ciclo cadastrado — as metas dos objetivos são consideradas 100%.</span>') +
      '<div class="sp"></div><a class="btn btn-sm btn-outline" href="#/valor/ciclos"><i class="bi bi-calendar-range"></i> Ciclos e metas</a></div></div>';
    if (!objs.length) return pagina('objetivos', html + '<div class="card"><p class="vazio">Nenhum objetivo estratégico cadastrado. Os objetivos são criados no Mapa Estratégico.</p></div>');
    var sel = parseInt(q.oe, 10) || OBJ.sel; if (!objs.some(function (o) { return o.id === sel; })) sel = objs[0].id; OBJ.sel = sel;
    var res = {}; objs.forEach(function (o) { res[o.id] = MET.icvObjetivo(o.id); });
    html += '<div class="card"><div class="abas">' + objs.map(function (o) { return '<button type="button" class="aba st-' + res[o.id].status + (o.id === sel ? ' ativa' : '') + '" onclick="UI.selObj(' + o.id + ')"><i class="dot"></i>' + h(o.codigo) + '</button>'; }).join('') + '</div>';
    var o = objs.filter(function (x) { return x.id === sel; })[0], r = res[sel];
    var sg = r.sigma ? 'sg-' + r.sigma : 'sg-nd';
    html += '<div class="aba-corpo st-' + r.status + '"><div class="cap-head"><div>' +
      (o.nome && norm(o.nome) !== norm(o.codigo)
        ? '<div class="muted" style="font-size:12px">' + h(o.codigo) + '</div><h2 style="margin:2px 0 4px">' + h(o.nome) + '</h2>'
        : '<h2 style="margin:2px 0 4px">' + h(o.codigo) + '</h2>') +
      (o.descricao ? '<p style="margin:6px 0 0">' + h(o.descricao) + '</p>' : '') + '</div>' +
      '<div class="classe-card st-' + r.status + ' ihc-card"><div class="cc-top"><span class="cc-cod">ICV' + (r.ciclo ? ' · ' + h(r.ciclo.codigo || r.ciclo.nome) : '') + '</span>' + chip(r.status, false) + '</div><div class="ihc-valor">' + pct(r.icv) + '</div><div class="cc-meta"><div><span>Meta do ciclo</span><b>' + pct(r.meta, 0) + (r.metaDefinida ? '' : ' *') + '</b></div><div><span>Desvio da meta</span><b>' + pct(r.desvio) + '</b></div><div><span>Six Sigma</span><b>' + (r.sigma ? h(MET.SIGMA_ROT[r.sigma]) : '—') + '</b></div><div><span>Cobertura</span><b>' + pct(r.cobertura, 0) + '</b></div></div>' +
      (r.parcial && r.caps.length ? '<div class="muted" style="font-size:11.5px">Resultado parcial: há capacidades sem IHC.</div>' : '') + '</div></div>' +
      (r.ciclo && !r.metaDefinida ? '<p class="muted" style="font-size:12.5px">* Este objetivo ainda não tem meta no ciclo <b>' + h(r.ciclo.nome) + '</b>; está sendo considerada a meta de 100%. <a href="#" onclick="UI.formMetasCiclo(' + r.ciclo.id + ');return false">Definir metas do ciclo</a></p>' : '') +
      '<div class="veb-diag"><div class="veb-diag-i st-' + r.status + '"><b>Curva ABC · ' + h(MET.ROTULO[r.status]) + '</b><span>' + h(MET.ABC_TXT[r.status] || 'Sem dados suficientes para classificar.') + '</span></div>' +
      '<div class="veb-diag-i ' + sg + '"><b>Desvio Six Sigma · ' + (r.sigma ? h(MET.SIGMA_ROT[r.sigma]) : 'Sem dados') + '</b><span>' + (r.sigma ? h(MET.SIGMA_TXT[r.sigma]) : 'Sem dados suficientes para avaliar o desvio.') + '</span></div></div>' +
      '<div class="toolbar" style="margin-top:12px"><button type="button" class="btn btn-sm"' + (r.caps.length > 1 ? '' : ' disabled') + ' onclick="UI.abrirPesosCap(' + sel + ')">⚖ Calcular pesos das capacidades (AHP)</button>' +
      (r.ciclo ? '<button type="button" class="btn btn-sm btn-outline" onclick="UI.formMeta(' + sel + ',' + r.ciclo.id + ')">Meta do objetivo no ciclo</button>' : '') +
      '<div class="sp"></div><button type="button" class="btn btn-sm btn-outline" onclick="UI.formObjetivo(' + sel + ')">Editar objetivo</button><button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirObjetivo(' + sel + ')">Excluir objetivo</button></div>';
    if (!r.caps.length) html += '<p class="vazio">Nenhuma capacidade vinculada a este objetivo.</p>';
    else html += '<div class="tabela-wrap"><table class="tabela-compacta"><thead><tr><th>Código</th><th>Nome da capacidade</th><th class="num">IHC</th><th class="num">Contribuição C</th><th class="num">Peso da capacidade (AHP)</th></tr></thead><tbody>' +
      r.caps.map(function (x) { return '<tr><td><a href="#/valor/capacidade?id=' + x.c.id + '">' + h(x.c.codigo) + '</a></td><td>' + h(x.c.nome) + '</td><td class="num">' + pct(x.ihc) + ' ' + (x.ihc == null ? '' : chip(x.res.status, true)) + '</td><td class="num">' + pct(x.contribC) + '</td><td class="num">' + (x.wc > 0 ? pct(x.wc, 1) : '<span class="muted">não calculado</span>') + '</td></tr>'; }).join('') + '</tbody></table></div>' +
      (r.caps.length > 1 && !r.pesoDefinido ? '<p class="muted" style="font-size:12.5px">Pesos ainda não calculados: enquanto isso, o ICV considera pesos iguais.</p>' : '') +
      '<p class="muted" style="font-size:12px">IHC informa a habilitação da capacidade; C expressa sua contribuição para a meta do objetivo no ciclo. Os resultados são evidências diagnósticas e não substituem o julgamento gerencial.</p>';
    html += planoHtml(sel, r.ciclo);
    return pagina('objetivos', html + '</div></div>');
  }
  UI.selCiclo = function (id) { MET.cicloSel = parseInt(id, 10) || null; rota(); };

  /* ====================== PLANO DE AÇÃO DO VALOR ESTRATÉGICO (5W2H) ====================== */
  var ST_PLANO = ['Planejada', 'Em execução', 'Concluída', 'Suspensa', 'Cancelada'];
  var COR_PLANO = { 'Planejada': 'muted', 'Em execução': 'warn', 'Concluída': 'ok', 'Suspensa': 'muted', 'Cancelada': 'err' };
  function seguro(t) { return t ? (w.SisrelHtml ? w.SisrelHtml.seguro(t) : h(t)) : '<span class="muted">—</span>'; }
  function planoHtml(oeId, cic) {
    var ps = []; try { ps = DB.rows('SELECT * FROM va_planos WHERE objetivo_id=? ORDER BY id', [oeId]); } catch (e) { ps = []; }
    var o = '<div class="card" style="margin-top:14px"><div class="toolbar"><h2 style="margin:0">Plano de ação do objetivo (5W2H)</h2><div class="sp"></div><button type="button" class="btn btn-sm" onclick="UI.formPlano(' + oeId + ',0)">+ Nova ação</button></div>' +
      ajuda('Define <b>o quê</b> (What), <b>por quê</b> (Why), <b>onde</b> (Where), <b>quando</b> (When), <b>quem</b> (Who), <b>como</b> (How) e <b>quanto custa</b> (How much) para corrigir os desvios do objetivo e reavaliar os índices no ciclo seguinte.');
    if (!ps.length) return o + '<p class="vazio">Nenhuma ação cadastrada para este objetivo.</p></div>';
    o += ps.map(function (p) {
      var ci = p.ciclo_id ? DB.one('SELECT codigo, nome FROM ciclos_estrategicos WHERE id=?', [p.ciclo_id]) : null;
      return '<div class="p5-card"><div class="p5-top"><b>' + h(p.titulo || 'Ação') + '</b>' + badge(p.status || 'Planejada', COR_PLANO[p.status] || 'muted') + (ci ? ' <span class="muted" style="font-size:12px">ciclo ' + h(ci.codigo || ci.nome) + '</span>' : '') + '<div class="sp"></div>' +
        '<button type="button" class="btn btn-sm btn-outline" onclick="UI.formPlano(' + oeId + ',' + p.id + ')">Editar</button> <button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirPlano(' + p.id + ')">Excluir</button></div>' +
        '<div class="p5-grid">' +
        '<div class="p5-c p5-w"><span>O quê (What)</span><div>' + seguro(p.o_que) + '</div></div><div class="p5-c p5-w"><span>Por quê (Why)</span><div>' + seguro(p.por_que) + '</div></div>' +
        '<div class="p5-c"><span>Onde (Where)</span><div>' + (p.onde ? h(p.onde) : '—') + '</div></div><div class="p5-c"><span>Quando (When)</span><div>' + (p.quando_inicio || p.quando_fim ? h(MET.fmtData(p.quando_inicio)) + ' → ' + h(MET.fmtData(p.quando_fim)) : '—') + '</div></div>' +
        '<div class="p5-c"><span>Quem (Who)</span><div>' + (p.quem ? h(p.quem) : '—') + '</div></div><div class="p5-c"><span>Quanto (How much)</span><div>' + (p.quanto ? h(p.quanto) : '—') + '</div></div>' +
        '<div class="p5-c p5-w p5-full"><span>Como (How)</span><div>' + seguro(p.como) + '</div></div></div></div>';
    }).join('');
    return o + '</div>';
  }
  UI.formPlano = function (oeId, id) {
    var p = id ? DB.one('SELECT * FROM va_planos WHERE id=?', [id]) : { titulo: '', status: 'Planejada', ciclo_id: (MET.cicloAtivo() || {}).id || '' };
    var cs = MET.ciclos();
    openModal(modal(id ? 'Editar ação do plano (5W2H)' : 'Nova ação do plano (5W2H)',
      '<div class="form-grid"><div class="campo" style="grid-column:1/-1"><label>Título da ação *</label><input id="pl_tit" value="' + h(p.titulo || '') + '"></div>' +
      '<div class="campo"><label>Ciclo estratégico</label><select id="pl_ciclo"><option value="">— nenhum —</option>' + cs.map(function (c) { return '<option value="' + c.id + '"' + (String(p.ciclo_id) === String(c.id) ? ' selected' : '') + '>' + h((c.codigo ? c.codigo + ' — ' : '') + c.nome) + '</option>'; }).join('') + '</select></div>' +
      '<div class="campo"><label>Situação da ação</label><select id="pl_st">' + ST_PLANO.map(function (s) { return '<option' + (p.status === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></div>' +
      '</div>' + '<div class="ed5"><label>O quê (What) — o que será feito</label><div id="pl_o_que"></div></div>' +
      '<div class="ed5"><label>Por quê (Why) — justificativa</label><div id="pl_por_que"></div></div>' +
      '<div class="form-grid"><div class="campo"><label>Onde (Where)</label><input id="pl_onde" value="' + h(p.onde || '') + '"></div><div class="campo"><label>Quem (Who) — responsável</label><input id="pl_quem" value="' + h(p.quem || '') + '"></div>' +
      '<div class="campo"><label>Quando (When) — início</label><input type="date" id="pl_ini" value="' + h(p.quando_inicio || '') + '"></div><div class="campo"><label>Quando (When) — fim</label><input type="date" id="pl_fim" value="' + h(p.quando_fim || '') + '"></div></div>' +
      '<div class="ed5"><label>Como (How) — método e etapas</label><div id="pl_como"></div></div>' +
      '<div class="form-grid"><div class="campo" style="grid-column:1/-1"><label>Quanto (How much) — custo / recursos</label><input id="pl_quanto" value="' + h(p.quanto || '') + '" placeholder="Ex.: R$ 50.000,00 ou 2 servidores por 30 dias"></div></div>',
      'onclick="UI.salvarPlano(' + oeId + ',' + (id || 0) + ')"'), { wide: true });
    ['o_que', 'por_que', 'como'].forEach(function (k) {
      var el = document.getElementById('pl_' + k); if (!el) return;
      if (!w.SisrelEditor) { el.innerHTML = '<textarea id="pl_ta_' + k + '" rows="3" style="width:100%">' + h(p[k] || '') + '</textarea>'; return; }
      w.SisrelEditor.criar(el, { placeholder: k === 'o_que' ? 'Descreva a ação…' : k === 'por_que' ? 'Justifique a ação…' : 'Descreva como será executada…', dados: p[k] ? seguroTxt(p[k]) : '', minAltura: 110 })
        .then(function (ed) { EDITORES['pl_' + k] = ed; if (p[k] && ed.setData) ed.setData(seguroTxt(p[k])); }).catch(function (er) { el.innerHTML = '<p class="alert alert-warn">Editor indisponível: ' + h(er && er.message || er) + '</p>'; });
    });
  };
  function seguroTxt(t) { return w.SisrelHtml ? w.SisrelHtml.seguro(t) : t; }
  function textoEd(k) { var ed = EDITORES['pl_' + k]; if (ed) return seguroTxt(ed.getData() || ''); var ta = document.getElementById('pl_ta_' + k); return ta ? ta.value : ''; }
  UI.salvarPlano = function (oeId, id) {
    var tit = val('pl_tit').trim(); if (!tit) return alert('Informe o título da ação.');
    var ini = val('pl_ini'), fim = val('pl_fim'); if (ini && fim && fim < ini) return alert('O fim deve ser posterior ao início.');
    var vs = [oeId, parseInt(val('pl_ciclo'), 10) || null, tit, textoEd('o_que'), textoEd('por_que'), val('pl_onde').trim(), ini || null, fim || null, val('pl_quem').trim(), textoEd('como'), val('pl_quanto').trim(), val('pl_st')];
    if (id) DB.run('UPDATE va_planos SET objetivo_id=?, ciclo_id=?, titulo=?, o_que=?, por_que=?, onde=?, quando_inicio=?, quando_fim=?, quem=?, como=?, quanto=?, status=? WHERE id=?', vs.concat([id]));
    else DB.run('INSERT INTO va_planos (objetivo_id,ciclo_id,titulo,o_que,por_que,onde,quando_inicio,quando_fim,quem,como,quanto,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', vs);
    DB.persistir(); fechar(); rota();
  };
  UI.excluirPlano = function (id) { if (!confirm('Excluir esta ação do plano?')) return; DB.run('DELETE FROM va_planos WHERE id=?', [id]); DB.persistir(); rota(); };

  /* ====================== CICLOS ESTRATÉGICOS E METAS DOS OBJETIVOS ====================== */
  function paginaCiclos() {
    var cs = MET.ciclos(), objs = DB.rows("SELECT id FROM objetivos_estrategicos WHERE status='ativo'"), vig = MET.cicloVigente();
    var html = '<div class="card"><div class="toolbar"><a class="btn btn-outline btn-sm" href="#/valor/objetivos">← Objetivos e ICV</a><h2 style="margin:0 0 0 6px">Ciclos estratégicos e metas dos objetivos</h2><div class="sp"></div><button type="button" class="btn" onclick="UI.formCiclo(0)">+ Novo ciclo</button></div>' +
      ajuda('O <b>ciclo estratégico</b> é o período do planejamento (ex.: 2026–2029). Em cada ciclo, cada objetivo estratégico recebe uma <b>meta</b> (valor estabelecido para o ciclo). O ICV é apurado contra a <b>meta vigente no ciclo</b>, que não se confunde com a capacidade plena de longo prazo. O histórico das metas de cada ciclo é mantido.');
    if (!cs.length) return pagina('ciclos', html + '<p class="vazio">Nenhum ciclo cadastrado. Crie o primeiro ciclo e defina as metas dos objetivos.</p></div>');
    html += '<div class="tabela-wrap"><table class="tabela-compacta"><thead><tr><th>Código</th><th>Ciclo</th><th>Início</th><th>Fim</th><th>Situação</th><th class="num">Metas definidas</th><th></th></tr></thead><tbody>' +
      cs.map(function (c) {
        var n = DB.one('SELECT COUNT(*) n FROM metas_objetivo_ciclo WHERE ciclo_id=?', [c.id]).n;
        return '<tr><td>' + h(c.codigo) + '</td><td>' + h(c.nome) + (vig && vig.id === c.id ? ' <span class="badge badge-ok">em curso</span>' : '') + '</td><td>' + h(MET.fmtData(c.data_inicio)) + '</td><td>' + h(MET.fmtData(c.data_fim)) + '</td><td>' + h(c.status || '') + '</td><td class="num">' + n + ' de ' + objs.length + '</td>' +
          '<td class="acoes"><button type="button" class="btn btn-sm" onclick="UI.formMetasCiclo(' + c.id + ')">Metas dos objetivos</button> <a class="btn btn-sm btn-outline" href="#/valor/objetivos?ciclo=' + c.id + '">Ver ICV</a> <button type="button" class="btn btn-sm btn-outline" onclick="UI.formCiclo(' + c.id + ')">Editar</button> <button type="button" class="btn btn-sm btn-danger" onclick="UI.excluirCiclo(' + c.id + ')">Excluir</button></td></tr>';
      }).join('') + '</tbody></table></div>';
    return pagina('ciclos', html + '</div>');
  }
  UI.formCiclo = function (id) {
    var c = id ? DB.one('SELECT * FROM ciclos_estrategicos WHERE id=?', [id]) : { codigo: 'CE-' + String(MET.ciclos().length + 1).padStart(2, '0'), nome: '', data_inicio: '', data_fim: '', status: 'vigente', observacoes: '' };
    openModal(modal(id ? 'Editar ciclo estratégico' : 'Novo ciclo estratégico',
      '<div class="form-grid"><div class="campo"><label>Código *</label><input id="ci_cod" value="' + h(c.codigo) + '"></div><div class="campo"><label>Situação</label><select id="ci_st">' + ['planejado', 'vigente', 'encerrado'].map(function (s) { return '<option' + (c.status === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Nome *</label><input id="ci_nome" value="' + h(c.nome) + '" placeholder="Ex.: Planejamento Estratégico 2026–2029"></div>' +
      '<div class="campo"><label>Início *</label><input type="date" id="ci_ini" value="' + h(c.data_inicio) + '"></div><div class="campo"><label>Fim *</label><input type="date" id="ci_fim" value="' + h(c.data_fim) + '"></div>' +
      '<div class="campo" style="grid-column:1/-1"><label>Observações</label><textarea id="ci_obs" rows="2">' + h(c.observacoes || '') + '</textarea></div></div>', 'onclick="UI.salvarCiclo(' + (id || 0) + ')"'));
  };
  UI.salvarCiclo = function (id) {
    var cod = val('ci_cod').trim(), nome = val('ci_nome').trim(), ini = val('ci_ini'), fim = val('ci_fim');
    if (!cod || !nome || !ini || !fim) return alert('Preencha código, nome, início e fim.'); if (fim < ini) return alert('O fim deve ser posterior ao início.');
    var vs = [cod, nome, ini, fim, val('ci_st'), val('ci_obs').trim()];
    if (id) DB.run('UPDATE ciclos_estrategicos SET codigo=?, nome=?, data_inicio=?, data_fim=?, status=?, observacoes=? WHERE id=?', vs.concat([id]));
    else DB.run('INSERT INTO ciclos_estrategicos (codigo,nome,data_inicio,data_fim,status,observacoes) VALUES (?,?,?,?,?,?)', vs);
    DB.persistir(); fechar(); rota();
  };
  UI.excluirCiclo = function (id) {
    var c = DB.one('SELECT * FROM ciclos_estrategicos WHERE id=?', [id]); if (!c) return;
    if (!confirm('Excluir o ciclo "' + c.nome + '" e as metas dos objetivos definidas nele?')) return;
    DB.run('DELETE FROM metas_objetivo_ciclo WHERE ciclo_id=?', [id]); DB.run('UPDATE va_planos SET ciclo_id=NULL WHERE ciclo_id=?', [id]); DB.run('DELETE FROM ciclos_estrategicos WHERE id=?', [id]);
    if (MET.cicloSel === id) MET.cicloSel = null; DB.persistir(); rota();
  };
  function numPct(s) { s = String(s == null ? '' : s).trim().replace('%', '').replace(',', '.'); if (s === '') return null; var n = parseFloat(s); return isNaN(n) ? NaN : n; }
  UI.formMetasCiclo = function (cid) {
    var c = DB.one('SELECT * FROM ciclos_estrategicos WHERE id=?', [cid]); if (!c) return;
    var objs = DB.rows("SELECT * FROM objetivos_estrategicos WHERE status='ativo' ORDER BY codigo");
    if (!objs.length) return alert('Cadastre objetivos estratégicos antes de definir metas.');
    openModal(modal('Metas dos objetivos — ' + c.nome,
      '<p class="ajuda">Informe a <b>meta</b> de cada objetivo neste ciclo, em % (ex.: 85). Em branco, vale 100%.</p><div class="tabela-wrap"><table class="tabela-compacta"><thead><tr><th>Objetivo</th><th class="num">Meta do ciclo (%)</th></tr></thead><tbody>' +
      objs.map(function (o) { var m = MET.metaObjetivo(o.id, cid) || {}; return '<tr><td><b>' + h(o.codigo) + '</b> ' + h(o.nome) + '</td><td class="num"><input id="mt_' + o.id + '" style="width:80px" value="' + (m.meta_poe == null ? '' : m.meta_poe) + '"></td></tr>'; }).join('') + '</tbody></table></div>', 'onclick="UI.salvarMetasCiclo(' + cid + ')"'), { wide: true });
  };
  function gravaMeta(oid, cid, mt) {
    if (isNaN(mt)) return false;
    if (mt == null) { DB.run('DELETE FROM metas_objetivo_ciclo WHERE objetivo_id=? AND ciclo_id=?', [oid, cid]); return true; }
    if (mt <= 0 || mt > 100) return false;
    var ex = DB.one('SELECT id FROM metas_objetivo_ciclo WHERE objetivo_id=? AND ciclo_id=?', [oid, cid]);
    if (ex) DB.run('UPDATE metas_objetivo_ciclo SET meta_poe=? WHERE id=?', [mt, ex.id]); else DB.run('INSERT INTO metas_objetivo_ciclo (objetivo_id,ciclo_id,meta_poe) VALUES (?,?,?)', [oid, cid, mt]);
    return true;
  }
  UI.salvarMetasCiclo = function (cid) {
    var objs = DB.rows("SELECT id, codigo FROM objetivos_estrategicos WHERE status='ativo'"), erro = '';
    objs.forEach(function (o) { if (!gravaMeta(o.id, cid, numPct(val('mt_' + o.id)))) erro = erro || ('Valor inválido no objetivo ' + o.codigo + ' (use de 0 a 100).'); });
    if (erro) { alert(erro); }
    DB.persistir(); fechar(); rota();
  };
  UI.formMeta = function (oid, cid) {
    var o = DB.one('SELECT * FROM objetivos_estrategicos WHERE id=?', [oid]), c = DB.one('SELECT * FROM ciclos_estrategicos WHERE id=?', [cid]), m = MET.metaObjetivo(oid, cid) || {};
    openModal(modal('Meta do objetivo no ciclo',
      '<p class="ajuda"><b>' + h(o.codigo) + '</b> — ' + h(o.nome) + '<br>Ciclo: <b>' + h(c.nome) + '</b> (' + h(MET.fmtData(c.data_inicio)) + ' a ' + h(MET.fmtData(c.data_fim)) + ')</p><div class="form-grid"><div class="campo"><label>Meta do ciclo (%)</label><input id="mt_' + oid + '" value="' + (m.meta_poe == null ? '' : m.meta_poe) + '" placeholder="100"></div></div>', 'onclick="UI.salvarMeta(' + oid + ',' + cid + ')"'));
  };
  UI.salvarMeta = function (oid, cid) {
    if (!gravaMeta(oid, cid, numPct(val('mt_' + oid)))) return alert('Valor inválido (use de 0 a 100; a meta deve ser maior que zero).');
    DB.persistir(); fechar(); rota();
  };

  /* ====================== AHP ====================== */
  var ahp = { modo: '', ref: 0, ids: [], labels: [], rc: null, cons: null };
  function abrirAhp(modo, ref, ids, labels, titulo, intro) { ahp = { modo: modo, ref: ref, ids: ids, labels: labels, rc: null, cons: null }; telaAhp(titulo, intro); }
  UI.abrirPesosCap = function (oeId) {
    var l = MET.capacidadesDoObjetivo(oeId); if (l.length < 2) { alert('Vincule ao menos duas capacidades ao objetivo.'); return; }
    abrirAhp('wc', oeId, l.map(function (x) { return x.id; }), l.map(function (x) { return x.codigo + ' — ' + x.nome; }), 'Pesos das capacidades (AHP)', 'Quanto cada <b>capacidade</b> contribui para o objetivo? Compare-as duas a duas.');
  };
  UI.abrirPesosInd = function (fid) {
    var l = DB.rows("SELECT i.* FROM indicadores i JOIN indicador_fatores x ON x.indicador_id=i.id WHERE x.fator_id=? AND i.status='ativo' ORDER BY i.codigo", [fid]); if (l.length < 2) { alert('A dimensão precisa de ao menos dois indicadores ativos.'); return; }
    abrirAhp('grh', fid, l.map(function (x) { return x.id; }), l.map(function (x) { return x.nome; }), 'Pesos dos indicadores (AHP)', 'Quanto cada <b>indicador</b> importa para medir esta dimensão? Compare-os dois a dois.');
  };
  UI.abrirPesosItens = function (indId) {
    var l = MET.itensIndicador(indId); if (l.length < 2) return;
    abrirAhp('itm', indId, l.map(function (x) { return x.id; }), l.map(function (x) { return x.nome; }), 'Pesos dos itens (AHP)', 'Quanto cada <b>item</b> pesa na composição do indicador? Compare-os dois a dois.');
  };
  function telaAhp(titulo, intro) {
    var n = ahp.ids.length, c = '<div class="peso-intro">' + intro + '</div><div class="ahp-pares">';
    for (var i = 0; i < n; i++) for (var j = i + 1; j < n; j++) {
      var id = i + '_' + j;
      c += '<div class="ahp-par-card"><div class="ahp-par-pergunta">Qual é mais importante?</div><div class="ahp-par-ops">' +
        '<button type="button" class="ahp-chip" id="chip_a_' + id + '" onclick="UI._escolhePar(\'' + id + '\',\'a\')">' + h(ahp.labels[i]) + '</button>' +
        '<button type="button" class="ahp-chip ahp-chip-eq ativo" id="chip_eq_' + id + '" onclick="UI._escolhePar(\'' + id + '\',\'eq\')">Iguais</button>' +
        '<button type="button" class="ahp-chip" id="chip_b_' + id + '" onclick="UI._escolhePar(\'' + id + '\',\'b\')">' + h(ahp.labels[j]) + '</button></div>' +
        '<div class="ahp-intensidade" id="int_' + id + '" style="display:none"><span class="muted">Quanto mais importante?</span> <select id="ahp_int_' + id + '"><option value="1">Quase iguais</option><option value="3" selected>Um pouco mais</option><option value="5">Bastante mais</option><option value="7">Muito mais</option><option value="9">Extremamente mais</option></select></div>' +
        '<input type="hidden" id="ahp_lado_' + id + '" value="eq"></div>';
    }
    c += '</div><div class="toolbar" style="margin-top:12px"><button type="button" class="btn" onclick="UI._calcularAhp()">Calcular pesos</button><span id="ahp_cr"></span></div><div id="ahp_resultado"></div>';
    for (var k = 0; k < n; k++) c += '<input type="hidden" id="peso_m_' + k + '" value="">';
    openModal('<div class="vmodal-hd"><h2>' + h(titulo) + '</h2><button type="button" class="btn-fechar" onclick="UI.fechar()">×</button></div><div class="vmodal-bd vvmodal-bd-peso">' + c + '</div>' +
      '<div class="vmodal-ft"><button type="button" class="btn btn-outline" onclick="UI.fechar()">Cancelar</button><button type="button" class="btn" id="btn_salvar_pesos" onclick="UI.salvarPesos()" disabled>Salvar pesos</button></div>', { wide: true });
  }
  UI._escolhePar = function (id, lado) {
    document.getElementById('ahp_lado_' + id).value = lado;
    ['a', 'eq', 'b'].forEach(function (L) { var el = document.getElementById('chip_' + L + '_' + id); if (el) el.classList.toggle('ativo', L === lado); });
    document.getElementById('int_' + id).style.display = lado === 'eq' ? 'none' : 'block';
  };
  UI._calcularAhp = function () {
    var n = ahp.ids.length, Mx = [], i, j;
    for (i = 0; i < n; i++) { Mx[i] = []; for (j = 0; j < n; j++) Mx[i][j] = 1; }
    for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) {
      var id = i + '_' + j, lado = val('ahp_lado_' + id) || 'eq', k = parseInt(val('ahp_int_' + id), 10) || 1, v = MET.ahpValor(lado, k);
      Mx[i][j] = v; Mx[j][i] = 1 / v;
    }
    var res = MET.ahpPesos(Mx);
    if (!res || !res.pesos) { alert('Não foi possível calcular.'); return; }
    ahp.rc = res.rc; ahp.cons = res.consistente ? 1 : 0;
    var li = '';
    for (i = 0; i < n; i++) { document.getElementById('peso_m_' + i).value = (res.pesos[i] * 100).toFixed(4); li += '<li><span class="peso-res-nome">' + h(ahp.labels[i]) + '</span><span class="peso-res-val">' + pct(res.pesos[i], 1) + '</span></li>'; }
    document.getElementById('ahp_resultado').innerHTML = '<div class="peso-resultado"><div class="peso-resultado-titulo">Resultado da avaliação</div><ul class="peso-resultado-lista">' + li + '</ul></div>';
    document.getElementById('ahp_cr').innerHTML = (res.consistente || res.rc <= 0.1) ? '<span class="badge badge-ok">Avaliação consistente (RC ' + num(res.rc, 3) + ')</span>' : '<span class="badge badge-warn">Respostas pouco consistentes (RC ' + num(res.rc, 3) + ') — revise os pares</span>';
    document.getElementById('btn_salvar_pesos').disabled = false;
  };
  UI.salvarPesos = function () {
    var n = ahp.ids.length, p = [], s = 0, i;
    for (i = 0; i < n; i++) { var v = parseFloat(val('peso_m_' + i)); if (isNaN(v) || v < 0) v = 0; p.push(v); s += v; }
    if (s <= 0) { alert('Calcule os pesos antes de salvar.'); return; }
    p = p.map(function (x) { return x / s; });
    for (i = 0; i < n; i++) {
      if (ahp.modo === 'wc') DB.run('UPDATE objetivo_capacidades SET wc=? WHERE objetivo_id=? AND capacidade_id=?', [p[i], ahp.ref, ahp.ids[i]]);
      else if (ahp.modo === 'grh') DB.run('UPDATE indicador_fatores SET grh=? WHERE fator_id=? AND indicador_id=?', [p[i], ahp.ref, ahp.ids[i]]);
      else DB.run('UPDATE indicador_itens SET peso=? WHERE id=?', [p[i], ahp.ids[i]]);
    }
    var esc = ahp.modo === 'wc' ? 'Wc (capacidades no objetivo)' : ahp.modo === 'grh' ? 'GRH (indicadores na dimensão)' : 'Pesos dos itens do indicador';
    DB.run('INSERT INTO ahp_registros (escopo, ref_id, ciclo_id, rotulos_json, pesos_json, rc, consistente, versao) VALUES (?,?,NULL,?,?,?,?,?)', [esc, ahp.ref, JSON.stringify(ahp.labels), JSON.stringify(p), ahp.rc, ahp.cons, 'Metodologia 2.0']);
    MET.registrarHistorico('pesos', null, esc + ' atualizados: ' + ahp.labels.map(function (l, k) { return l.split(' — ')[0] + '=' + (p[k] * 100).toFixed(1) + '%'; }).join('; '));
    persistirERota();
  };

  /* ====================== MONITORAMENTO ====================== */
  var MON = { oe: 0, cap: 0, ind: 0, mes: '' };
  function monRota() { var y = window.scrollY; rota(); window.scrollTo(0, y); }
  UI.monOe = function (v) { MON.oe = parseInt(v, 10) || 0; MON.cap = 0; MON.ind = 0; monRota(); };
  UI.monCap = function (v) { MON.cap = parseInt(v, 10) || 0; MON.ind = 0; monRota(); };
  UI.monInd = function (v) { MON.ind = parseInt(v, 10) || 0; monRota(); };
  UI.monMes = function (v) { MON.mes = v || ''; monRota(); };
  UI.monIrInd = function (id, capId, oeId) { MON.ind = id; MON.cap = capId; MON.oe = oeId; monRota(); setTimeout(function () { var el = document.getElementById('mon_drill'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 80); };
  function pctTxt(v) { return v == null ? '—' : num(v * 100, 1) + '%'; }
  function deltaTxt(d, inverso, suf) {
    if (d == null || isNaN(d)) return '';
    var bom = inverso ? d < 0 : d > 0, z = Math.abs(d) < 1e-9;
    return '<em class="dl ' + (z ? 'dl-0' : (bom ? 'dl-bom' : 'dl-ruim')) + '">' + (z ? '= ' : (d > 0 ? '▲ ' : '▼ ')) + (z ? 'sem variação' : num(Math.abs(d), (Math.abs(d) < 10 && d % 1 !== 0) ? 1 : 0)) + (z ? '' : (suf || '')) + '</em>';
  }
  function spark(vals, cor) {
    vals = vals.filter(function (v) { return v != null; }); if (vals.length < 2) return '<span class="muted">—</span>';
    var W = 90, H = 26, mx = Math.max.apply(null, vals.concat([1])), mn = Math.min.apply(null, vals.concat([0])), rg = (mx - mn) || 1;
    var pts = vals.map(function (v, i) { return (i * (W - 6) / (vals.length - 1) + 3).toFixed(1) + ',' + (H - 3 - (v - mn) / rg * (H - 6)).toFixed(1); });
    var l = pts[pts.length - 1].split(',');
    return '<svg class="spark" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '"><polyline fill="none" stroke="' + cor + '" stroke-width="2" points="' + pts.join(' ') + '"/><circle cx="' + l[0] + '" cy="' + l[1] + '" r="3" fill="' + cor + '"/></svg>';
  }
  var COR_ST = { ok: '#2e7d46', atencao: '#c47a00', critico: '#c62828', 'sem-dados': '#9e9e9e' };
  /* agregados do sistema na posição (corte) atual */
  function agregado(objs) {
    var cont = { ok: 0, atencao: 0, critico: 0, 'sem-dados': 0 }, tot = 0, n = 0, caps = [];
    var oR = objs.map(function (o) { var r = MET.icvObjetivo(o.id); if (r.icv != null) { tot += r.icv; n++; } return { o: o, r: r, icv: r.icv }; });
    DB.rows("SELECT * FROM capacidades WHERE status='ativo' ORDER BY codigo").forEach(function (c) { var r = MET.ihcCapacidade(c.id); Object.keys(cont).forEach(function (k) { cont[k] += r.contadores[k] || 0; }); caps.push({ c: c, res: r }); });
    return { cont: cont, oR: oR, icvMedio: n ? tot / n : null, caps: caps, totInd: cont.ok + cont.atencao + cont.critico + cont['sem-dados'] };
  }

  function paginaMonitoramento() {
    var objs = DB.rows("SELECT * FROM objetivos_estrategicos WHERE status='ativo' ORDER BY codigo");
    var topoBase = function (extra) { return '<div class="dash-topo"><div><h1>Monitoramento</h1><p>Do objetivo estratégico ao indicador: clique nos gráficos para aprofundar a análise.</p></div><div class="sp"></div>' + (extra || '') + '</div>'; };
    if (!objs.length) return pagina('monitoramento', topoBase() + '<div class="dash-vazio"><h2>Sem objetivos cadastrados</h2><p>Cadastre uma capacidade e vincule-a a um objetivo estratégico para acompanhar o desempenho aqui.</p><a class="btn" href="#/valor">Ir ao dashboard</a></div>');
    var meses = MET.meses();
    if (MON.mes && meses.indexOf(MON.mes) < 0) MON.mes = '';
    var corte = MON.mes || null;
    return MET.comCorte(corte, function () { return monitoramentoCorpo(objs, meses, topoBase); });
  }

  function monitoramentoCorpo(objs, meses, topoBase) {
    var G = agregado(objs), cont = G.cont, objRes = G.oR, totInd = G.totInd, icvMedio = G.icvMedio;
    var mesAtual = MON.mes || (meses.length ? meses[meses.length - 1] : ''), ix = meses.indexOf(mesAtual), mesAnt = ix > 0 ? meses[ix - 1] : '';
    var ant = mesAnt ? MET.comCorte(mesAnt, function () { return agregado(objs); }) : null;
    var selMes = meses.length ? '<label class="mon-mes"><span>Posição em</span><select onchange="UI.monMes(this.value)"><option value="">Último lançamento' + (meses.length ? ' (' + MET.fmtMes(meses[meses.length - 1]) + ')' : '') + '</option>' +
      meses.slice().reverse().map(function (m) { return '<option value="' + m + '"' + (m === MON.mes ? ' selected' : '') + '>' + MET.fmtMes(m) + '</option>'; }).join('') + '</select></label>' : '';
    var ordObj = objRes.slice().sort(function (a, b) { return (a.icv == null ? 2 : a.icv) - (b.icv == null ? 2 : b.icv); });
    if (!objs.some(function (o) { return o.id === MON.oe; })) MON.oe = ordObj[0].o.id;
    var oSel = objRes.filter(function (x) { return x.o.id === MON.oe; })[0], capsRes = oSel.r.caps.slice().sort(function (a, b) { return (a.ihc == null ? 2 : a.ihc) - (b.ihc == null ? 2 : b.ihc); });
    if (!capsRes.some(function (x) { return x.c.id === MON.cap; })) MON.cap = capsRes.length ? capsRes[0].c.id : 0;
    var cSel = capsRes.filter(function (x) { return x.c.id === MON.cap; })[0], res = cSel ? cSel.res : null, inds = [];
    if (res) res.dims.forEach(function (d) { d.ativos.forEach(function (x) { inds.push(x); }); });
    inds.sort(function (a, b) { return (a.a == null ? 2 : a.a) - (b.a == null ? 2 : b.a); });
    if (inds.length && !inds.some(function (x) { return x.id === MON.ind; })) MON.ind = inds[0].id;
    var iSel = inds.filter(function (x) { return x.id === MON.ind; })[0];

    function kpi(cls, n, rot, sub, dl) { return '<div class="kpi kpi-st k-' + cls + '"><b>' + n + (dl || '') + '</b><span>' + rot + '</span>' + (sub ? '<small>' + sub + '</small>' : '') + '</div>'; }
    var stIcv = MET.classe(icvMedio), kIcv = stIcv === 'sem-dados' ? 'todas' : stIcv;
    var dIcv = ant && ant.icvMedio != null && icvMedio != null ? (icvMedio - ant.icvMedio) * 100 : null;
    var html = topoBase(selMes);
    html += '<div class="kpis">' + kpi(kIcv, pctTxt(icvMedio), 'ICV médio', objs.length + ' objetivo' + (objs.length === 1 ? '' : 's') + (mesAnt ? ' · vs. ' + MET.fmtMes(mesAnt) : ''), deltaTxt(dIcv, false, ' p.p.')) +
      kpi('critico', cont.critico, 'Indicadores críticos', 'abaixo de ' + Math.round(MET.LIM.aten * 100) + '% da meta', ant ? deltaTxt(cont.critico - ant.cont.critico, true) : '') +
      kpi('atencao', cont.atencao, 'Em atenção', 'entre ' + Math.round(MET.LIM.aten * 100) + '% e ' + Math.round(MET.LIM.conf * 100) + '%', ant ? deltaTxt(cont.atencao - ant.cont.atencao, true) : '') +
      kpi('ok', cont.ok, 'Em conformidade', Math.round(MET.LIM.conf * 100) + '% da meta ou mais', ant ? deltaTxt(cont.ok - ant.cont.ok, false) : '') + '</div>';

    /* atenção imediata: piores indicadores do sistema */
    var todos = []; G.caps.forEach(function (x) { var o = MET.objetivoDaCapacidade(x.c.id); x.res.dims.forEach(function (d) { d.ativos.forEach(function (e) { if (e.pct != null) todos.push({ e: e, cap: x.c, obj: o }); }); }); });
    todos.sort(function (a, b) { return a.e.pct - b.e.pct; });
    var urg = todos.filter(function (t) { return t.e.status !== 'ok'; }).slice(0, 7);
    function tend(e) { var s = e.serie; if (s.length < 2) return ''; var d = s[s.length - 1].pct - s[s.length - 2].pct; return d == null || isNaN(d) ? '' : deltaTxt(d * 100, false, ' p.p.'); }
    var urgHtml = urg.length ? '<div class="urg-lista">' + urg.map(function (t) {
      return '<div class="urg-item" onclick="UI.monIrInd(' + t.e.id + ',' + t.cap.id + ',' + (t.obj ? t.obj.id : 0) + ')"><span class="urg-dot" style="background:' + COR_ST[t.e.status] + '"></span>' +
        '<div class="urg-t"><b>' + h(t.e.ind.nome) + '</b><small>' + h(t.cap.codigo) + (t.obj ? ' · ' + h(t.obj.codigo) : '') + '</small></div>' +
        spark(t.e.serie.map(function (s) { return s.pct; }), COR_ST[t.e.status]) + '<div class="urg-v"><b>' + pctTxt(t.e.pct) + '</b>' + tend(t.e) + '</div></div>';
    }).join('') + '</div>' : '<p class="vazio">Nenhum indicador abaixo da conformidade. 👏</p>';

    html += '<div class="mon-grid g3"><div class="card"><h3 style="margin-top:0">Atingimento dos objetivos (ICV)</h3><div class="chart-box" style="height:' + Math.max(230, objs.length * 62 + 60) + 'px"><canvas id="m_obj"></canvas></div><p class="muted mon-dica">Do pior para o melhor. Clique para selecionar o objetivo.</p></div>' +
      '<div class="card"><h3 style="margin-top:0">Situação dos indicadores</h3>' + (totInd ? '<div class="chart-box" style="height:' + Math.max(230, objs.length * 62 + 60) + 'px"><canvas id="m_ros"></canvas></div>' : '<p class="vazio">Sem indicadores.</p>') + '</div>' +
      '<div class="card"><h3 style="margin-top:0">Atenção imediata</h3>' + urgHtml + '<p class="muted mon-dica">Piores indicadores do sistema, com tendência recente. Clique para abrir a análise.</p></div></div>';

    /* evolução histórica */
    var mh = meses.slice(-18), hist = null;
    if (mh.length >= 2) {
      var sIcv = objs.map(function (o) { return { nome: o.codigo, vals: [] }; });
      mh.forEach(function (m) { MET.comCorte(m, function () { objs.forEach(function (o, i) { sIcv[i].vals.push(MET.icvObjetivo(o.id).icv); }); }); });
      hist = { labels: mh.map(MET.fmtMes), s: sIcv };
      html += '<div class="card"><h3 style="margin-top:0">Evolução do ICV por objetivo</h3><div class="chart-box" style="height:300px"><canvas id="m_hist"></canvas></div><p class="muted mon-dica">Posição acumulada em cada mês, com as faixas de situação ao fundo (' + Math.round(MET.LIM.aten * 100) + '% e ' + Math.round(MET.LIM.conf * 100) + '%).</p></div>';
    }

    /* mapa de calor: todos os indicadores por capacidade */
    html += '<div class="card"><div class="toolbar"><h3 style="margin:0">Mapa de calor dos indicadores</h3><div class="sp"></div><span class="mapa-leg"><i style="background:#2e7d46"></i>conformidade <i style="background:#c47a00"></i>atenção <i style="background:#c62828"></i>crítico <i style="background:#bdbdbd"></i>sem dados</span></div><div class="mapa">' +
      G.caps.map(function (x) {
        var o = MET.objetivoDaCapacidade(x.c.id), tiles = '';
        x.res.dims.forEach(function (d) { d.ativos.forEach(function (e) {
          tiles += '<div class="tile" style="background:' + COR_ST[e.status] + '" title="' + h(e.ind.nome + ' — ' + (e.pct == null ? 'sem dados' : num(e.pct * 100, 1) + '% da meta')) + '" onclick="UI.monIrInd(' + e.id + ',' + x.c.id + ',' + (o ? o.id : 0) + ')"><b>' + (e.pct == null ? '—' : Math.round(e.pct * 100) + '%') + '</b><span>' + h(e.ind.codigo) + '</span></div>';
        }); });
        return '<div class="mapa-linha"><div class="mapa-rot"><b>' + h(x.c.codigo) + '</b><small>' + h(x.c.nome) + '</small></div><div class="mapa-tiles">' + (tiles || '<span class="muted">sem indicadores</span>') + '</div><div class="mapa-ihc"><span>IHC</span><b>' + pctTxt(x.res.ihc) + '</b></div></div>';
      }).join('') + '</div></div>';

    /* aprofundamento */
    html += '<div id="mon_drill"></div><div class="card mon-sel"><div class="toolbar"><h3 style="margin:0">Aprofundar no objetivo</h3><div class="sp"></div><select onchange="UI.monOe(this.value)">' + objs.map(function (o) { return '<option value="' + o.id + '"' + (o.id === MON.oe ? ' selected' : '') + '>' + h(labelObjetivo(o)) + '</option>'; }).join('') + '</select></div>' +
      '<div class="mon-resumo"><span class="status-chip st-' + oSel.r.status + '"><i class="dot"></i>' + h(MET.ROTULO[oSel.r.status] || '—') + '</span><span>ICV <b>' + pctTxt(oSel.icv) + '</b></span><span>Risco <b>' + h(oSel.r.risco || '—') + '</b></span><span><b>' + capsRes.length + '</b> capacidade' + (capsRes.length === 1 ? '' : 's') + '</span></div></div>';
    if (!capsRes.length) return pagina('monitoramento', html + '<div class="card"><p class="vazio">Sem capacidades neste objetivo.</p></div>');
    var sCap = null;
    if (mh.length >= 2) { sCap = capsRes.map(function (x) { return { nome: x.c.codigo, id: x.c.id, vals: [] }; }); mh.forEach(function (m) { MET.comCorte(m, function () { sCap.forEach(function (s) { s.vals.push(MET.ihcCapacidade(s.id).ihc); }); }); }); }
    html += '<div class="mon-grid g2"><div class="card"><h3 style="margin-top:0">Capacidades do objetivo (IHC)</h3><div class="chart-box" style="height:' + Math.max(200, capsRes.length * 62 + 60) + 'px"><canvas id="m_cap"></canvas></div><p class="muted mon-dica">Clique em uma capacidade para ver suas dimensões e indicadores.</p></div>' +
      (sCap ? '<div class="card"><h3 style="margin-top:0">Evolução do IHC das capacidades</h3><div class="chart-box" style="height:' + Math.max(260, capsRes.length * 62 + 60) + 'px"><canvas id="m_hcap"></canvas></div></div>' : '<div class="card"><h3 style="margin-top:0">Dimensões de ' + h(cSel.c.codigo) + '</h3><div class="chart-box" style="height:' + Math.max(160, res.dims.length * 50 + 60) + 'px"><canvas id="m_rad"></canvas></div></div>') + '</div>';
    if (sCap && res.dims.length) html += '<div class="card"><h3 style="margin-top:0">Dimensões de ' + h(cSel.c.codigo) + ' — ' + h(cSel.c.nome) + '</h3><div class="chart-box" style="height:' + (res.dims.length >= 3 ? 340 : Math.max(160, res.dims.length * 50 + 60)) + 'px"><canvas id="m_rad"></canvas></div></div>';
    if (!inds.length) return pagina('monitoramento', html + '<div class="card"><p class="vazio">Sem indicadores ativos nesta capacidade.</p></div>');
    var det = iSel.tipo === 'multiplo' && iSel.itens.length ? '<div class="tabela-wrap" style="margin-top:8px"><table class="tabela-compacta"><thead><tr><th>Item</th><th class="num">Último valor</th><th class="num">% da meta</th><th>Situação</th></tr></thead><tbody>' + iSel.itens.slice().sort(function (a, b) { return (a.pct == null ? 9 : a.pct) - (b.pct == null ? 9 : b.pct); }).map(function (it) { return '<tr><td>' + h(it.nome) + '</td><td class="num">' + fmtVal(it.valor, it.unidade) + '</td><td class="num">' + pctTxt(it.pct) + '</td><td>' + chip(it.status) + '</td></tr>'; }).join('') + '</tbody></table></div>' : '';
    html += '<div class="card"><div class="toolbar"><h3 style="margin:0">Indicadores de ' + h(cSel.c.codigo) + ' — ' + h(cSel.c.nome) + '</h3></div><div class="mon-grid g2" style="margin-top:6px"><div><div class="chart-box" style="height:' + Math.max(200, inds.length * 62 + 60) + 'px"><canvas id="m_ind"></canvas></div><p class="muted mon-dica">Percentual da meta no último lançamento. Clique para ver a evolução.</p></div>' +
      '<div><div class="toolbar" style="margin-bottom:4px"><b>' + h(iSel.ind.nome) + '</b><span class="muted">' + h(iSel.ind.codigo) + '</span><div class="sp"></div><a class="btn btn-sm btn-outline" href="#/indicador?id=' + iSel.id + '">Abrir indicador</a></div>' +
      '<div class="mon-resumo"><span class="status-chip st-' + iSel.status + '"><i class="dot"></i>' + h(MET.ROTULO[iSel.status] || '—') + '</span><span>% da meta <b>' + pctTxt(iSel.pct) + '</b></span><span>Último valor <b>' + fmtVal(iSel.valor, iSel.ind.unidade) + '</b></span><span>Meta <b>' + (iSel.meta == null ? '—' : num(iSel.meta, 2)) + '</b></span></div>' +
      (iSel.serie.length ? '<div class="chart-box" style="height:300px"><canvas id="m_evo"></canvas></div>' : '<p class="vazio">Sem lançamentos para este indicador.</p>') + det + '</div></div></div>';
    if (res.itens.length) html += '<div class="card"><h3 style="margin-top:0">Onde está o déficit? Pareto dos indicadores de ' + h(cSel.c.codigo) + '</h3><div class="chart-box" style="height:300px"><canvas id="m_par"></canvas></div><p class="muted mon-dica">Barras: participação de cada indicador no déficit da capacidade (vermelho = classe A, os poucos que concentram ~80% do problema). Linha: acumulado.</p></div>';
    setTimeout(function () {
      var C = w.OPTCharts;
      C.barrasH('m_obj', ordObj.map(function (x) { return labelObjetivo(x.o); }), ordObj.map(function (x) { return x.icv; }), { label: 'ICV', sel: ordObj.findIndex(function (x) { return x.o.id === MON.oe; }), onClick: function (i) { UI.monOe(ordObj[i].o.id); } });
      if (document.getElementById('m_ros')) C.rosca('m_ros', ['Em conformidade', 'Em atenção', 'Críticos', 'Sem dados'], [cont.ok, cont.atencao, cont.critico, cont['sem-dados']], ['#2e7d46', '#c47a00', '#c62828', '#bdbdbd'], { valor: String(totInd), rotulo: 'indicadores' });
      if (hist && document.getElementById('m_hist')) C.lineHist('m_hist', hist.labels, hist.s);
      C.barrasH('m_cap', capsRes.map(function (x) { return x.c.codigo + ' · ' + x.c.nome; }), capsRes.map(function (x) { return x.ihc; }), { label: 'IHC', sel: capsRes.findIndex(function (x) { return x.c.id === MON.cap; }), onClick: function (i) { UI.monCap(capsRes[i].c.id); } });
      if (sCap && document.getElementById('m_hcap')) C.lineHist('m_hcap', mh.map(MET.fmtMes), sCap);
      if (document.getElementById('m_rad')) (res.dims.length >= 3 ? C.radar : function (id, l, v) { C.barrasH(id, l, v, { label: 'Desempenho' }); })('m_rad', res.dims.map(function (d) { return d.f.codigo + ' ' + d.f.nome; }), res.dims.map(function (d) { return d.desempenho; }));
      C.barrasH('m_ind', inds.map(function (x) { return x.ind.codigo + ' · ' + x.ind.nome; }), inds.map(function (x) { return x.a; }), { label: '% da meta', sel: inds.findIndex(function (x) { return x.id === MON.ind; }), onClick: function (i) { UI.monInd(inds[i].id); } });
      if (document.getElementById('m_evo')) C.evolucao('m_evo', iSel.serie.map(function (s) { return MET.fmtMes(s.mes); }), iSel.serie.map(function (s) { return s.valor; }), iSel.serie.map(function (s) { return s.meta; }), { titulo: '', labelValor: iSel.tipo === 'multiplo' ? 'Valor composto' : 'Valor apurado', labelMeta: 'Meta' });
      if (document.getElementById('m_par')) C.pareto('m_par', res.itens.map(function (i) { return { nome: i.codigo || i.nome, part: i.participacao, classe: i.classe_abc }; }));
    }, 60);
    return pagina('monitoramento', html);
  }

  /* ====================== VERIFICAÇÃO ====================== */
  function paginaValidacao() {
    var v = MET.validar(), pend = v.filter(function (x) { return !x.ok; }).length;
    var html = '<div class="card"><div class="toolbar"><a class="btn btn-outline btn-sm" href="#/valor">← Dashboard</a><h2 style="margin:0 0 0 6px">Verificação antes da apuração</h2></div>' +
      ajuda('Consolida as informações cadastradas e aponta o que falta antes de apurar e emitir o relatório (critérios de cálculo da metodologia).') +
      '<p>' + (pend ? '<span class="badge badge-warn">' + pend + ' critério(s) com pendência</span>' : '<span class="badge badge-ok">Estrutura pronta para a apuração</span>') + '</p>' +
      '<table class="tabela-compacta"><thead><tr><th>Critério</th><th>Resultado</th><th>Detalhe</th></tr></thead><tbody>' +
      v.map(function (x) { return '<tr><td>' + h(x.titulo) + '</td><td>' + (x.ok ? badge('atendido', 'ok') : badge('pendente', 'warn')) + '</td><td>' + (x.ok ? h(x.detalhe) : '<ul class="pend">' + x.problemas.slice(0, 12).map(function (p) { return '<li>' + h(p) + '</li>'; }).join('') + (x.problemas.length > 12 ? '<li>… e mais ' + (x.problemas.length - 12) + '</li>' : '') + '</ul>') + '</td></tr>'; }).join('') + '</tbody></table></div>';
    return pagina('validacao', html);
  }

  /* ====================== XML ====================== */
  var TABELAS_XML = ['organizacoes', 'objetivos_estrategicos', 'capacidades', 'objetivo_capacidades', 'fatores_determinantes', 'indicadores', 'indicador_fatores', 'ind_ciclos', 'indicador_itens', 'lanc_ind', 'lanc_itm', 'ahp_registros', 'historico'];
  function escXml(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;'); }
  UI.exportarXml = function () {
    var xml = '<?xml version="1.0" encoding="UTF-8"?>\n<valore versao="1.0" gerado_em="' + escXml(new Date().toISOString()) + '">\n';
    TABELAS_XML.forEach(function (tb) {
      try {
        xml += '  <' + tb + '>\n';
        DB.rows('SELECT * FROM ' + tb).forEach(function (r) { xml += '    <registro>\n' + Object.keys(r).map(function (k) { return '      <' + k + '>' + escXml(r[k]) + '</' + k + '>\n'; }).join('') + '    </registro>\n'; });
        xml += '  </' + tb + '>\n';
      } catch (e) { xml += '  <!-- ' + tb + ': ' + escXml(e.message) + ' -->\n'; }
    });
    xml += '</valore>\n';
    var nome = 'optimus-export-' + new Date().toISOString().slice(0, 10) + '.xml', hb = w.__maprisHost;
    if (hb && hb.invocar) { try { var b = btoa(unescape(encodeURIComponent(xml))); hb.invocar('salvar', JSON.stringify({ nome: nome, b64: b })); return; } catch (e) {} }
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([xml], { type: 'application/xml;charset=utf-8' })); a.download = nome; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  };
  UI.importarXml = function (file) {
    if (!file) return;
    var rd = new FileReader();
    rd.onload = function () {
      try {
        var doc = new DOMParser().parseFromString(String(rd.result || ''), 'application/xml');
        if (doc.querySelector('parsererror')) { alert('XML inválido'); return; }
        var root = ((doc.querySelector('valore') || doc.querySelector('vmap3') || doc.querySelector('vio'))); if (!root) { alert('Arquivo não é uma exportação do Valor-E'); return; }
        if (!confirm('Importar XML? Registros com o mesmo identificador serão substituídos.')) return;
        TABELAS_XML.forEach(function (tb) {
          var node = root.querySelector(tb); if (!node) return;
          node.querySelectorAll('registro').forEach(function (reg) {
            var data = {}; Array.prototype.forEach.call(reg.children, function (ch) { data[ch.tagName] = ch.textContent; });
            var cols = Object.keys(data); if (!cols.length) return;
            try { DB.run('INSERT OR REPLACE INTO ' + tb + ' (' + cols.join(',') + ') VALUES (' + cols.map(function () { return '?'; }).join(',') + ')', cols.map(function (c) { return data[c]; })); } catch (e) {}
          });
        });
        DB.persistir(); alert('Importação concluída'); rota();
      } catch (e) { alert('Falha na importação: ' + (e.message || e)); }
    };
    rd.readAsText(file, 'UTF-8');
  };
  function exportarView() {
    return pagina('exportar', '<div class="card"><h2>Exportar / Importar XML</h2>' + ajuda('Cópia completa dos cadastros e registros. A importação insere ou atualiza registros.') +
      '<div class="toolbar"><button class="btn" onclick="UI.exportarXml()">Baixar XML completo</button></div><h3>Importar XML</h3><input type="file" accept=".xml,application/xml,text/xml" onchange="UI.importarXml(this.files[0])"></div>');
  }

  /* ====================== METODOLOGIA ====================== */
  function metodologia() {
    function fm(t) { return '<div class="met-formula">' + t + '</div>'; }
    var cadeia = ['Objetivos estratégicos', 'Capacidades', 'Dimensões', 'Indicadores', 'Situação e risco', 'IHC', 'ICV', 'Curva ABC', 'Plano de ação'];
    var cf = Math.round(MET.LIM.conf * 100), at = Math.round(MET.LIM.aten * 100);
    var html = '<div class="met-wrap"><div class="met-hero"><div class="met-hero-kicker">Valor-E · Metodologia</div><h1>Valor Estratégico Baseado em Capacidades (VEB-C)</h1>' +
      '<p>Planejar, medir, diagnosticar e agir para capturar valor. <b>Sistema e método são um só:</b> cada tela do Valor-E executa uma etapa deste referencial.</p></div>' +
      '<div class="met-cadeia">' + cadeia.map(function (c, i) { return '<span class="met-elo m' + (i % 5) + '">' + c + '</span>'; }).join('<span class="met-seta">→</span>') + '</div>' +

      '<div class="card met-doc"><h2>1. Estrutura</h2><div class="met-grid">' +
      '<div class="met-card"><div class="met-card-num">1</div><h3>Objetivo estratégico</h3><p>Resultado ou condição futura pretendida. Depende de capacidades desenvolvidas. <i>ICV · Objetivos.</i></p></div>' +
      '<div class="met-card"><div class="met-card-num">2</div><h3>Capacidade</h3><p>Aptidão integrada de pessoas, processos, estruturas, tecnologia e informações para produzir os efeitos exigidos. <i>Dashboard (cards).</i></p></div>' +
      '<div class="met-card"><div class="met-card-num">3</div><h3>Dimensão (fator determinante)</h3><p>Elemento que sustenta a capacidade; cada dimensão é uma aba na página da capacidade e pode ser marcada como <b>essencial</b>.</p></div>' +
      '<div class="met-card"><div class="met-card-num">4</div><h3>Indicador</h3><p>Mede o desempenho da dimensão. <b>Simples</b> (um item) ou <b>múltiplo</b> (vários itens que compartilham a meta). A meta é definida <b>por ciclos de metas no próprio indicador</b>; não há cadastro de ciclo estratégico separado. Indicadores inativos não entram nos cálculos.</p></div></div></div>' +

      '<div class="card met-doc"><h2>2. Situação e grau de risco — escala de atingimento da meta</h2>' +
      '<p>Para cada registro mensal, compara-se o valor apurado com a <b>meta do ciclo vigente naquele mês</b>. O <b>percentual da meta</b> (p) é:</p>' +
      fm('maior é melhor: p = valor ÷ meta') + fm('menor é melhor: p = meta ÷ valor   (valor = 0 ⇒ p = 100%; meta = 0 ⇒ p = 1 − valor ÷ pior valor registrado)') +
      '<table class="tabela-compacta met-escala"><thead><tr><th>Percentual da meta (p)</th><th>Situação</th><th>Grau de risco</th></tr></thead><tbody>' +
      '<tr><td>p ≥ ' + cf + '%</td><td><span class="status-chip st-ok"><i class="dot"></i>Em conformidade</span></td><td>Baixo</td></tr>' +
      '<tr><td>' + at + '% ≤ p &lt; ' + cf + '%</td><td><span class="status-chip st-atencao"><i class="dot"></i>Em atenção</span></td><td>Médio</td></tr>' +
      '<tr><td>p &lt; ' + at + '%</td><td><span class="status-chip st-critico"><i class="dot"></i>Crítico</span></td><td>Alto</td></tr></tbody></table>' +
      '<p><b>Desvio da meta (distância da meta)</b> = meta − valor (maior é melhor) ou valor − meta (menor é melhor); valores positivos indicam que a meta ainda não foi alcançada. A faixa de ' + (100 - cf) + '% de desvio relativo é a <b>tolerância</b> de conformidade; de ' + (100 - cf) + '% a ' + (100 - at) + '% configura atenção; acima de ' + (100 - at) + '% é crítico.</p>' +
      '<p>A situação do <b>card da capacidade</b> no dashboard e a da <b>dimensão</b> adotam o <b>pior estado</b> entre seus indicadores ativos (princípio da precaução: um indicador crítico não é "diluído" por indicadores bons). Um indicador múltiplo assume o pior estado entre seus itens.</p>' +
      '<p>Os limites de <b>' + cf + '%</b> (conformidade) e <b>' + at + '%</b> (atenção) são parâmetros únicos do sistema (<i>MET.LIM</i>) e aplicam-se de forma idêntica a indicadores, dimensões, capacidades e objetivos, o que torna as leituras comparáveis em todo o OPTIMUS.</p></div>' +

      '<div class="card met-doc"><h2>3. IHC e ICV</h2>' +
      '<div class="met-defs"><div class="met-def"><span class="met-def-tag">IHC</span> <b>Índice de Habilitação da Capacidade</b> — desempenho ponderado dos indicadores das dimensões da capacidade.</div>' +
      '<div class="met-def"><span class="met-def-tag">ICV</span> <b>Índice de Captura de Valor</b> — contribuição ponderada das capacidades ao objetivo estratégico. Não comprova, sozinho, o alcance do objetivo.</div></div>' +
      '<h3>Cálculo</h3>' + fm('a = limitar(p ; 0 ; 1)      (desempenho normalizado do indicador)') + fm('Desempenho da dimensão = Σ ( GRH × a )     GRH = peso do indicador na dimensão (AHP, soma 1)') +
      fm('IHC = média dos desempenhos das dimensões avaliadas') + fm('ICV = Σ ( Wc × IHC )     Wc = peso da capacidade no objetivo (AHP, soma 1)') +
      '<p>O IHC e o ICV são classificados pela <b>mesma escala</b> da seção 2 (≥ ' + cf + '% em conformidade/risco baixo; ' + at + '% a ' + cf + '% em atenção/risco médio; &lt; ' + at + '% crítico/risco alto).</p>' +
      '<p><b>Pesos (AHP).</b> Quando uma dimensão tem mais de um indicador, os pesos GRH são calculados pelo método AHP (comparação par a par, escala de Saaty, consistência RC ≤ 0,10). O mesmo vale para as capacidades de um objetivo (Wc) e para os itens de um indicador múltiplo. Matrizes e resultados ficam registrados.</p>' +
      '<p><b>Dados ausentes</b> nunca valem zero: o sistema informa a <b>cobertura</b>, renormaliza os pesos dos itens válidos e marca o resultado como <b>parcial</b>.</p></div>' +

      '<div class="card met-doc"><h2>4. Curva ABC — priorização do déficit</h2>' +
      '<p>A <b>curva ABC</b> (diagrama de Pareto) ordena os elementos pela sua participação no <b>déficit ponderado</b> e define onde agir primeiro. É aplicada em três níveis: <b>indicadores</b> dentro da capacidade, <b>capacidades</b> dentro do objetivo e <b>objetivos</b> no conjunto.</p>' +
      fm('Déficit do indicador: D = peso × máx(0 ; 1 − a)      participação = D ÷ ΣD') +
      '<div class="met-abc"><div class="met-abc-item a"><b>A</b><span>até 80% do déficit acumulado</span><small>prioridade principal — poucos itens, maior efeito</small></div>' +
      '<div class="met-abc-item b"><b>B</b><span>80% a 95%</span><small>programar intervenção</small></div><div class="met-abc-item c"><b>C</b><span>95% a 100%</span><small>monitorar</small></div></div>' +
      '<p>A <b>situação</b> (seção 2) diz <i>quão grave</i> é o desvio de cada elemento; a <b>classe ABC</b> diz <i>quanto ele pesa</i> no resultado da capacidade ou do objetivo. A leitura conjunta define a ordem de ação: <b>crítico + classe A</b> = prioridade máxima; crítico + C = tratar sem urgência sistêmica; conforme + A = acompanhar. Dimensões essenciais comprometidas são sempre destacadas, mesmo com pequena participação.</p></div>' +

      '<div class="card met-doc"><h2>5. Desvio e Six Sigma</h2>' +
      '<p>O <b>desvio da meta</b> é a distância entre o resultado e a meta (seção 2). Inspirada no <b>Six Sigma</b>, a análise de dispersão expressa essa distância em <b>desvios-padrão</b> da própria série do indicador, separando variação natural do processo de desvio sistemático:</p>' +
      fm('Z = máx( 0 ; (meta − μ) ÷ σ )      (maior é melhor; invertido para menor é melhor)') +
      '<table class="tabela-compacta"><thead><tr><th>Z (distância à meta)</th><th>Leitura</th></tr></thead><tbody><tr><td>Z &lt; 1</td><td>meta dentro da variação natural do processo; ajustes finos</td></tr><tr><td>1 ≤ Z &lt; 2</td><td>desvio provável do processo; investigar causas</td></tr><tr><td>Z ≥ 2</td><td>desvio sistemático (meta fora de ~95% da variação observada); exige ação estrutural</td></tr></tbody></table>' +
      '<p class="muted">Exploratória: calculada com 6 ou mais registros, a partir de μ e σ amostrais; <b>não</b> corresponde ao nível formal de capacidade Sigma (que exige dados de defeitos por milhão e processo estável).</p></div>' +

      '<div class="card met-doc"><h2>6. Plano de ação, relatório e passo a passo</h2>' +
      '<p>O <b>plano de ação</b> e a <b>análise crítica</b> são registrados na página de cada indicador, em editor de texto formatado. O <b>relatório</b> é organizado por <b>objetivo estratégico → capacidades → dimensões → indicadores</b> e exportado em PDF (ABNT).</p><ol class="met-steps">' +
      '<li><b>Dashboard</b> — cadastre as capacidades e o objetivo que cada uma impacta.</li><li><b>Página da capacidade</b> — cadastre as dimensões (abas) e os indicadores, com seus ciclos de metas.</li>' +
      '<li><b>Registros</b> — lance os valores mensais (coluna de ações da tabela).</li><li><b>Pesos</b> — use o AHP nas dimensões e no objetivo.</li>' +
      '<li><b>Verificação antes da apuração</b> — consolida o que falta.</li><li><b>ICV, Monitoramento e Relatório</b> — acompanhe, priorize e documente.</li></ol></div></div>';
    return pagina('metodologia', html);
  }

  function rota() { if (w.Rota) w.Rota(); }
  UI.render = function (r, q) {
    if (w.OPTCharts && w.OPTCharts.destroyAll) w.OPTCharts.destroyAll();
    EDITORES = {};
    if (r === 'capacidade') return paginaCapacidade(q);
    if (r === 'indicador') return paginaIndicador(q);
    if (r === 'objetivos') return paginaObjetivos(q);
    if (r === 'ciclos') return paginaCiclos();
    if (r === 'monitoramento') return paginaMonitoramento();
    if (r === 'validacao') return paginaValidacao();
    if (r === 'relatorio') return pagina('relatorio', w.RPT.tela(q));
    return dashboard();
  };
  UI.rota = rota;
  UI._u = { h: h, num: num, pct: pct, kpi: kpi, badge: badge, badgeAbc: badgeAbc, openModal: openModal, modal: modal, val: val, ajuda: ajuda, cadeiaValor: cadeiaValor, chip: chip, chipRisco: chipRisco, rota: rota };
})(window);

})(window.DB);
