/* org.js — organizações. A organização é a dona da Cadeia de Valor, do Mapa Estratégico e de tudo o que deles decorre
 * (processos, projetos, indicadores, riscos, valor estratégico). O banco guarda várias organizações; só a ATIVA fica "viva" nas telas.
 * As demais ficam guardadas, de forma compacta, em `org_arquivo`. Trocar de organização no Painel guarda a atual e carrega a escolhida,
 * de modo que o efeito é em cascata em todos os módulos, sem que nenhuma tela precise filtrar por organização.
 * Configurações do aplicativo (`config`) e usuários valem para todas as organizações. */
(function (w) {
  'use strict';
  var Org = w.Org = w.Org || {};
  var GLOBAIS = ['config', 'usuarios'];            // não acompanham a organização
  var h = function (s) { return w.E && E.esc ? E.esc(s) : String(s); };
  var recarregar = false;

  DB.migracao('org-001-ativa', function () {
    try { DB.db.run('ALTER TABLE organizacoes ADD COLUMN ativa INTEGER DEFAULT 0'); } catch (e) { /* já existe */ }
    DB.db.run('CREATE TABLE IF NOT EXISTS org_arquivo (organizacao_id INTEGER PRIMARY KEY, payload TEXT, tam INTEGER DEFAULT 0, atualizado_em TEXT)');
    // a "unidade" informada na versão anterior passa a ser a identificação da organização
    var sg = '', nm = '';
    try { sg = (DB.one("SELECT valor FROM config WHERE chave = 'unidade_sigla'") || {}).valor || ''; nm = (DB.one("SELECT valor FROM config WHERE chave = 'unidade_nome'") || {}).valor || ''; } catch (e) {}
    var p = DB.one('SELECT id FROM organizacoes ORDER BY id LIMIT 1');
    if (!p) { DB.db.run("INSERT INTO organizacoes (id, nome, codigo) VALUES (1, 'Organização', 'ORG')"); p = { id: 1 }; }
    if (sg) { try { DB.db.run('UPDATE organizacoes SET codigo = ?, nome = ? WHERE id = ?', [sg, nm || sg, p.id]); } catch (e) { /* sigla repetida: mantém */ } }
    if (!DB.one('SELECT 1 AS x FROM organizacoes WHERE ativa = 1')) DB.db.run('UPDATE organizacoes SET ativa = 1 WHERE id = ?', [p.id]);
  });

  Org.lista = function () { return DB.all('SELECT o.id, o.nome, o.codigo, o.ativa, (SELECT tam FROM org_arquivo a WHERE a.organizacao_id = o.id) AS tam FROM organizacoes o ORDER BY o.codigo COLLATE NOCASE'); };
  Org.ativa = function () { try { return DB.one('SELECT id, nome, codigo FROM organizacoes WHERE ativa = 1 ORDER BY id LIMIT 1') || DB.one('SELECT id, nome, codigo FROM organizacoes ORDER BY id LIMIT 1') || null; } catch (e) { return null; } };
  Org.achar = function (codigo) { return DB.one('SELECT id, nome, codigo FROM organizacoes WHERE codigo = ? COLLATE NOCASE', [String(codigo || '').trim()]); };
  Org.rotulo = function (o) { o = o || Org.ativa(); return o ? (o.codigo && o.nome && o.nome !== o.codigo ? o.codigo + ' — ' + o.nome : (o.codigo || o.nome)) : ''; };

  Org.criar = function (codigo, nome) {
    codigo = String(codigo || '').trim(); nome = String(nome || '').trim() || codigo;
    if (!codigo) throw new Error('Informe a sigla da organização.');
    if (Org.achar(codigo)) throw new Error('Já existe uma organização com a sigla ' + codigo + '.');
    DB.run('INSERT INTO organizacoes (nome, codigo, ativa) VALUES (?, ?, 0)', [nome, codigo]); DB.sujo();
    return Org.achar(codigo).id;
  };
  Org.salvar = function (id, codigo, nome) {
    codigo = String(codigo || '').trim(); nome = String(nome || '').trim() || codigo;
    if (!codigo) throw new Error('Informe a sigla da organização.');
    var outra = Org.achar(codigo); if (outra && outra.id !== id) throw new Error('Já existe uma organização com a sigla ' + codigo + '.');
    DB.run('UPDATE organizacoes SET codigo = ?, nome = ? WHERE id = ?', [codigo, nome, id]); DB.sujo();
  };

  /** Torna a organização ativa: guarda os dados da atual e carrega os da escolhida (vazio, se for nova). Síncrono. */
  Org.ativar = function (id) {
    var atual = Org.ativa(), alvo = DB.one('SELECT id FROM organizacoes WHERE id = ?', [id]); if (!alvo) throw new Error('Organização não encontrada.');
    if (atual && atual.id === alvo.id) return false;
    var P = w.Pacote, guardou = false;
    if (atual) {
      var txt = P.jsonStr(P.coletar(GLOBAIS));
      DB.run('INSERT OR REPLACE INTO org_arquivo (organizacao_id, payload, tam, atualizado_em) VALUES (?, ?, ?, ?)', [atual.id, txt, txt.length, new Date().toISOString()]); guardou = true;
    }
    try {
      var row = DB.one('SELECT payload FROM org_arquivo WHERE organizacao_id = ?', [alvo.id]);
      var o = row && row.payload ? JSON.parse(row.payload) : { formato: 'axia-pacote', versao: '4.0', tabelas: {} };
      P.aplicar(o, 'substituir', { ignorar: GLOBAIS });
    } catch (e) {
      if (guardou) DB.run('DELETE FROM org_arquivo WHERE organizacao_id = ?', [atual.id]);
      throw e;
    }
    DB.run('DELETE FROM org_arquivo WHERE organizacao_id = ?', [alvo.id]);
    DB.run('UPDATE organizacoes SET ativa = CASE WHEN id = ? THEN 1 ELSE 0 END', [alvo.id]); DB.sujo();
    if (w.SEC) SEC.audit('organizacao', 'ativar ' + alvo.id);
    return true;
  };

  Org.excluir = function (id) {
    var a = Org.ativa(); if (a && a.id === id) throw new Error('Não é possível excluir a organização ativa. Abra outra antes.');
    if (DB.one('SELECT COUNT(*) AS n FROM organizacoes').n < 2) throw new Error('É preciso manter ao menos uma organização.');
    DB.run('DELETE FROM org_arquivo WHERE organizacao_id = ?', [id]); DB.run('DELETE FROM organizacoes WHERE id = ?', [id]); DB.sujo();
    if (w.SEC) SEC.audit('organizacao', 'excluir ' + id);
  };

  /** Pacote com os dados de uma organização (a ativa vem do banco vivo; as demais, do arquivo interno). */
  Org.pacoteDe = function (id) {
    var a = Org.ativa(); if (a && a.id === id) return Pacote.coletar();
    var org = DB.one('SELECT nome, codigo FROM organizacoes WHERE id = ?', [id]), row = DB.one('SELECT payload FROM org_arquivo WHERE organizacao_id = ?', [id]);
    var o = row && row.payload ? JSON.parse(row.payload) : { formato: 'axia-pacote', versao: '4.0', tabelas: {} };
    o.unidade = org.codigo; o.unidade_nome = org.nome; o.gerado_em = new Date().toISOString(); o.aplicativo = 'Valor-E ' + (w.APP_VERSAO || '');
    return o;
  };
  Org.exportar = function (id, fmt) {
    var o = Org.pacoteDe(id), org = DB.one('SELECT codigo FROM organizacoes WHERE id = ?', [id]);
    var nome = 'valore-' + String(org.codigo).replace(/[^A-Za-z0-9_-]+/g, '') + '-' + E.hoje() + (fmt === 'json' ? '.json' : '.xml');
    if (w.Pontos) Pontos.copiaExterna();
    Mapris.baixar(nome, fmt === 'json' ? Pacote.jsonStr(o) : Pacote.serializarXml(o), fmt === 'json' ? 'application/json' : 'application/xml');
    if (w.SEC) SEC.audit('exportar', 'organização ' + org.codigo + ' ' + fmt);
  };

  /** Chamado antes de importar um pacote: se o arquivo é de outra organização, passa para ela (criando-a, se nova). Devolve false se o usuário desistir. */
  Org.rotear = function (o) {
    var cod = String((o && o.unidade) || '').trim(); if (!cod) return true;
    var a = Org.ativa(); if (a && String(a.codigo).toLowerCase() === cod.toLowerCase()) return true;
    var alvo = Org.achar(cod), nome = (o.unidade_nome || cod);
    var msg = alvo
      ? 'Este arquivo é da organização ' + Org.rotulo(alvo) + ', e a organização ativa agora é ' + Org.rotulo(a) + '.\n\nPara importar, o Valor-E vai abrir ' + alvo.codigo + ' (os dados de ' + (a ? a.codigo : 'a atual') + ' ficam guardados). Continuar?'
      : 'Este arquivo é de uma organização nova: ' + cod + ' — ' + nome + '.\n\nO Valor-E vai cadastrá-la e abri-la para importar (os dados de ' + (a ? a.codigo : 'a atual') + ' ficam guardados). Continuar?';
    if (!confirm(msg)) return false;
    if (w.Pontos) Pontos.criar('Antes de abrir a organização ' + cod + ' para importar', 'antes');
    var id = alvo ? alvo.id : Org.criar(cod, nome);
    Org.ativar(id); recarregar = true; Org.atualizarSelos();
    return true;
  };
  w.addEventListener('hashchange', function () { if (recarregar) { recarregar = false; Org.recarregarTela(); } });
  Org.recarregarTela = function () { DB.flush().then(function () { location.reload(); }); };

  // ---- interface ----
  Org.atualizarSelos = function () { Array.prototype.forEach.call(document.querySelectorAll('.org-selo'), function (e) { e.textContent = Org.rotulo(); }); };
  /** Seletor para o cabeçalho do Painel. */
  Org.seletor = function () {
    var ls = Org.lista(); if (!ls.length) return '';
    return '<div class="d-flex align-items-center gap-2 me-3"><label class="small text-muted mb-0" for="orgSel"><i class="bi bi-building"></i> Organização</label>' +
      '<select id="orgSel" class="form-select form-select-sm" style="width:auto;max-width:280px" onchange="Org.trocarUI(this.value)">' +
      ls.map(function (o) { return '<option value="' + o.id + '"' + (o.ativa ? ' selected' : '') + '>' + h(Org.rotulo(o)) + '</option>'; }).join('') +
      '<option value="gerir">Gerenciar organizações…</option></select></div>';
  };
  Org.trocarUI = function (v) {
    if (v === 'gerir') { Nav.ir('#/dados'); return; }
    try { Org.ativar(parseInt(v, 10)); } catch (e) { alert('Não foi possível trocar de organização: ' + e.message); return; }
    DB.flush().then(function () { Nav.ir('#/painel'); location.reload(); });
  };
  function kb(n) { return n > 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  Org.cartao = function () {
    var ls = Org.lista();
    return '<div class="cartao mb-3" id="orgCartao"><h2><i class="bi bi-building"></i> Organizações</h2><div class="corpo">' +
      '<p class="ajuda">A <b>organização</b> é a dona da Cadeia de Valor, do Mapa Estratégico e de tudo o que decorre deles: processos, projetos, indicadores, riscos e valor estratégico. ' +
      'Escolha a organização ativa no <a href="#/painel">Painel</a>; todas as telas passam a mostrar só os dados dela. Ao importar um arquivo, o Valor-E identifica a organização pela sigla e a cadastra se for nova.</p>' +
      '<table class="table table-sm align-middle"><thead><tr><th>Sigla</th><th>Nome</th><th>Situação</th><th></th></tr></thead><tbody>' +
      ls.map(function (o) {
        return '<tr><td><b>' + h(o.codigo) + '</b></td><td>' + h(o.nome) + '</td><td>' + (o.ativa ? '<span class="badge text-bg-success">Ativa</span>' : '<span class="text-muted small">guardada' + (o.tam ? ' (' + kb(o.tam) + ')' : '') + '</span>') + '</td><td class="text-end text-nowrap">' +
          (o.ativa ? '' : '<button class="btn btn-sm btn-outline-primary" onclick="Org.abrirUI(' + o.id + ')">Abrir</button> ') +
          '<button class="btn btn-sm btn-outline-secondary" onclick="Org.editarUI(' + o.id + ')">Editar</button> ' +
          '<button class="btn btn-sm btn-outline-success" onclick="Org.exportar(' + o.id + ',\'xml\')" title="Exportar os dados desta organização (.xml)"><i class="bi bi-filetype-xml"></i></button> ' +
          '<button class="btn btn-sm btn-outline-success" onclick="Org.exportar(' + o.id + ',\'json\')" title="Exportar os dados desta organização (.json)"><i class="bi bi-filetype-json"></i></button>' +
          (o.ativa ? '' : ' <button class="btn btn-sm btn-outline-danger" onclick="Org.excluirUI(' + o.id + ')"><i class="bi bi-trash"></i></button>') + '</td></tr>';
      }).join('') + '</tbody></table>' +
      '<div class="row g-2 align-items-end"><div class="col-auto"><label class="form-label small mb-0">Nova organização — sigla</label><input id="orgSigla" class="form-control form-control-sm" style="width:150px" maxlength="20"></div>' +
      '<div class="col"><label class="form-label small mb-0">Nome</label><input id="orgNome" class="form-control form-control-sm" maxlength="100"></div>' +
      '<div class="col-auto"><button class="btn btn-sm btn-primary" onclick="Org.novaUI()"><i class="bi bi-plus-circle"></i> Criar e abrir</button></div></div></div></div>';
  };
  Org.abrirUI = function (id) { Org.trocarUI(String(id)); };
  Org.novaUI = function () {
    try {
      var id = Org.criar(document.getElementById('orgSigla').value, document.getElementById('orgNome').value);
      Org.ativar(id); DB.flush().then(function () { Nav.ir('#/painel'); location.reload(); });
    } catch (e) { alert(e.message); }
  };
  Org.editarUI = function (id) {
    var o = DB.one('SELECT codigo, nome FROM organizacoes WHERE id = ?', [id]); if (!o) return;
    var cod = prompt('Sigla da organização:', o.codigo); if (cod === null) return;
    var nm = prompt('Nome da organização:', o.nome); if (nm === null) return;
    try { Org.salvar(id, cod, nm); Nav.ir('#/dados'); location.reload(); } catch (e) { alert(e.message); }
  };
  Org.excluirUI = function (id) {
    var o = DB.one('SELECT codigo FROM organizacoes WHERE id = ?', [id]); if (!o) return;
    if (!confirm('Excluir a organização ' + o.codigo + ' e TODOS os dados guardados dela (cadeia de valor, mapa, processos, projetos, indicadores, riscos)? Faça antes uma exportação, se precisar.')) return;
    try { Org.excluir(id); Nav.ir('#/dados'); location.reload(); } catch (e) { alert(e.message); }
  };
})(window);
