/* cva.js — Cadeia de Valor Agregado (Porter): ciclos de validação, macroprocessos (Finalísticos, Gerenciais, Apoio), missão, resultado e imagem. */
(function (w) {
  'use strict';
  var h = E.esc, TIPOS = ['Finalístico', 'Gerencial', 'Apoio'], PLURAL = { 'Finalístico': 'Finalísticos', 'Gerencial': 'Gerenciais', 'Apoio': 'De apoio' };
  var COR = { 'Finalístico': ['#0b3a73', '#ffffff'], 'Gerencial': ['#0a6fc2', '#ffffff'], 'Apoio': ['#01b2a1', '#ffffff'] };

  DB.migracao('cva-001-tabelas', function () {
    try { if (!DB.all('PRAGMA table_info(cva_ciclos)').some(function (c) { return c.name === 'cadeia'; })) DB.db.run("ALTER TABLE cva_ciclos ADD COLUMN cadeia TEXT DEFAULT 'Principal'"); DB.db.run("UPDATE cva_ciclos SET cadeia = 'Principal' WHERE cadeia IS NULL OR cadeia = ''"); } catch (e) {}
    DB.db.run("CREATE TABLE IF NOT EXISTS cva_validacoes (id INTEGER PRIMARY KEY AUTOINCREMENT, ciclo_id INTEGER NOT NULL, alvo TEXT NOT NULL, ref_id INTEGER NOT NULL, nome TEXT DEFAULT '', decisao TEXT NOT NULL, obs TEXT DEFAULT '', em TEXT DEFAULT CURRENT_TIMESTAMP)");
    DB.db.run("CREATE TABLE IF NOT EXISTS cva_documentos (id INTEGER PRIMARY KEY AUTOINCREMENT, ciclo_id INTEGER NOT NULL, titulo TEXT NOT NULL, gerado_em TEXT DEFAULT CURRENT_TIMESTAMP, html TEXT NOT NULL, obs TEXT DEFAULT '')");
    try {
      var colsDoc = DB.all('PRAGMA table_info(cva_documentos)').map(function (c) { return c.name; });
      if (colsDoc.indexOf('dados_json') < 0) DB.db.run("ALTER TABLE cva_documentos ADD COLUMN dados_json TEXT DEFAULT ''");
    } catch (e) {}
  });

  // ---------- dados ----------
  function hojeIso() { return E.hoje(); }
  function ciclos(cad) { return DB.all('SELECT * FROM cva_ciclos' + (cad ? ' WHERE cadeia = ?' : '') + ' ORDER BY (status = \'Vigente\') DESC, fim DESC, id DESC', cad ? [cad] : []); }
  function vigente(cad) { return DB.one("SELECT * FROM cva_ciclos WHERE status = 'Vigente'" + (cad ? ' AND cadeia = ?' : '') + ' ORDER BY id DESC', cad ? [cad] : []); }
  function cadeias() { return DB.all("SELECT cadeia, COUNT(*) AS n FROM cva_ciclos GROUP BY cadeia ORDER BY MIN(id)").map(function (x) { return x.cadeia || 'Principal'; }); }
  function macros(cid) { return DB.all('SELECT * FROM macroprocessos WHERE ciclo_id = ? ORDER BY ordem, id', [cid]); }
  function nProc(mid) { return DB.one('SELECT COUNT(*) AS n FROM processos WHERE macro_id = ?', [mid]).n; }
  function dias(fim) { if (!fim) return null; var a = new Date(hojeIso() + 'T00:00:00'), b = new Date(fim + 'T00:00:00'); return Math.round((b - a) / 86400000); }
  function validade(c) {
    if (!c) return { cls: 'secondary', txt: 'Sem ciclo', n: null };
    if (c.status !== 'Vigente') return { cls: 'secondary', txt: 'Encerrado em ' + (c.fim ? E.dataBr(c.fim) : '—'), n: null };
    var n = dias(c.fim);
    if (n === null) return { cls: 'success', txt: 'Vigente (sem data final)', n: null };
    if (n < 0) return { cls: 'danger', txt: 'Ciclo vencido há ' + (-n) + ' dia(s) — revisão necessária', n: n };
    if (n <= 60) return { cls: 'warning', txt: 'Vigente até ' + E.dataBr(c.fim) + ' — faltam ' + n + ' dia(s)', n: n };
    return { cls: 'success', txt: 'Vigente até ' + E.dataBr(c.fim) + ' — faltam ' + n + ' dias', n: n };
  }
  function cicloAtual(q) { var id = parseInt(q.ciclo, 10), cad = q.cadeia || ''; return (id && DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [id])) || (cad && (vigente(cad) || DB.one('SELECT * FROM cva_ciclos WHERE cadeia = ? ORDER BY id DESC', [cad]))) || vigente() || DB.one('SELECT * FROM cva_ciclos ORDER BY id DESC'); }

  // ---------- imagem de Porter ----------
  function quebra(t, max) {
    var p = String(t).split(/\s+/), l = [], c = '';
    p.forEach(function (x) { if ((c + ' ' + x).trim().length > max && c) { l.push(c); c = x; } else c = (c + ' ' + x).trim(); });
    if (c) l.push(c); return l.slice(0, 4);
  }
  /** Ícone clicável (somente no modo de edição; fica fora da imagem exportada). */
  function ic(x, y, acao, dica, tipo) {
    return '<g class="ic" onclick="' + acao + '" transform="translate(' + x + ',' + y + ')"><title>' + h(dica) + '</title><circle r="9" fill="#fff" stroke="#0a6fc2" stroke-width="1.4"/>' +
      (tipo === '+' ? '<path d="M-4 0H4M0-4V4" stroke="#0a6fc2" stroke-width="2" stroke-linecap="round"/>' : '<path d="M-4.5 4.5L-4 1.5L2.5-5L5-2.5L-1.5 4Z" fill="none" stroke="#0a6fc2" stroke-width="1.4" stroke-linejoin="round"/>') + '</g>';
  }
  function txt(x, y, linhas, cor, size, anc) {
    var o = '<text x="' + x + '" y="' + (y - (linhas.length - 1) * size * 0.6) + '" text-anchor="' + (anc || 'middle') + '" font-family="Arial,Helvetica,sans-serif" font-size="' + size + '" fill="' + cor + '" font-weight="600">';
    linhas.forEach(function (l, i) { o += '<tspan x="' + x + '" dy="' + (i ? size * 1.2 : 0) + '">' + h(l) + '</tspan>'; });
    return o + '</text>';
  }
  var PER = 6; // máximo de macroprocessos por linha; acima disso a faixa ganha novas linhas
  var FS = 12, BOXH = 58, PITCH = 64;   // fonte base e altura dos blocos (figura compacta)
  function linhasDe(n) { return Math.max(1, Math.ceil(n / PER)); }
  function repartir(lista) { var nl = linhasDe(lista.length), por = Math.ceil(lista.length / nl) || 1, r = []; for (var i = 0; i < lista.length; i += por) r.push(lista.slice(i, i + por)); return r; }
  function altFaixa(n) { return 28 + linhasDe(n) * PITCH + 2; }
  function faixa(lista, x0, y0, W, tipo, rotulo, ed, cid) {
    var H = altFaixa(lista.length);
    var o = '<rect x="' + x0 + '" y="' + y0 + '" width="' + W + '" height="' + H + '" rx="6" fill="' + COR[tipo][0] + '" opacity=".12"/>' + txt(x0 + 10, y0 + 16, [rotulo.toUpperCase()], COR[tipo][0], 10, 'start');
    if (ed) o += ic(x0 + W - 14, y0 + 13, 'Cva.macro(' + cid + ',\'' + tipo + '\')', 'Adicionar macroprocesso (' + tipo.toLowerCase() + ')', '+');
    if (!lista.length) return { s: o + txt(x0 + W / 2, y0 + H / 2 + 6, [ed ? '(clique em + para adicionar)' : '(sem macroprocessos)'], '#888', 11), h: H };
    var gap = 8;
    repartir(lista).forEach(function (linha, r) {
      var bw = Math.min((W - 20 - gap * (linha.length - 1)) / linha.length, 168);
      var tot = linha.length * bw + (linha.length - 1) * gap, xs = x0 + (W - tot) / 2;
      linha.forEach(function (m, i) {
        var x = xs + i * (bw + gap), y = y0 + 26 + r * PITCH, mw = Math.max(8, Math.floor((bw - 20) / (FS * 0.56)));
        o += '<rect x="' + x + '" y="' + y + '" width="' + bw + '" height="' + BOXH + '" rx="5" fill="' + COR[tipo][0] + '"/>' + txt(x + bw / 2, y + BOXH / 2 + 4, quebra(m.nome, mw).slice(0, 4), COR[tipo][1], FS);
        if (ed) o += ic(x + bw - 11, y + 11, 'Cva.macro(' + cid + ',\'' + tipo + '\',' + m.id + ')', 'Editar ou excluir: ' + m.nome);
      });
    });
    return { s: o, h: H };
  }
  function svgPorter(c, ed) {
    var ms = macros(c.id), g = {}; TIPOS.forEach(function (t) { g[t] = ms.filter(function (m) { return m.tipo === t; }); });
    var W = 1000, L = 20, AW = 790, nF = g['Finalístico'].length, rowsF = linhasDe(nF), hgt = rowsF === 1 ? 108 : 84;
    var yG = 102, fG = faixa(g['Gerencial'], L, yG, AW, 'Gerencial', PLURAL['Gerencial'] + ' — processos gerenciais', ed, c.id);
    var yA = yG + fG.h + 8, fA = faixa(g['Apoio'], L, yA, AW, 'Apoio', 'Processos de apoio', ed, c.id);
    var y0 = yA + fA.h + 8, hh = 28 + rowsF * (hgt + 6) + 2, H = y0 + hh + 26;
    var o = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '"><rect width="' + W + '" height="' + H + '" fill="#ffffff"/>';
    o += '<text x="' + (W / 2) + '" y="24" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="18" font-weight="700" fill="#06183e">Cadeia de Valor Agregado</text>';
    o += '<rect x="' + L + '" y="36" width="' + (W - 2 * L) + '" height="54" rx="7" fill="#06183e"/>' + txt(L + 12, 52, ['MISSÃO'], '#12d3a8', 10, 'start') + txt(W / 2, 71, quebra(c.missao || '(missão não informada)', 135).slice(0, 2), '#ffffff', 12.5);
    if (ed) o += ic(W - L - 16, 52, 'Cva.texto(' + c.id + ',\'missao\')', 'Editar a missão');
    o += fG.s + fA.s;
    // finalísticos: chevrons
    o += '<rect x="' + L + '" y="' + y0 + '" width="' + AW + '" height="' + hh + '" rx="6" fill="' + COR['Finalístico'][0] + '" opacity=".12"/>' + txt(L + 10, y0 + 16, ['PROCESSOS FINALÍSTICOS'], COR['Finalístico'][0], 10, 'start');
    if (ed) o += ic(L + AW - 14, y0 + 13, 'Cva.macro(' + c.id + ',\'Finalístico\')', 'Adicionar macroprocesso finalístico', '+');
    if (!nF) o += txt(L + AW / 2, y0 + hh / 2 + 6, [ed ? '(clique em + para adicionar)' : '(sem macroprocessos)'], '#888', 11);
    else {
      var pt = 26;
      repartir(g['Finalístico']).forEach(function (linha, r) {
        var cw = Math.min((AW - 20) / linha.length, 190), xs = L + 10 + ((AW - 20) - cw * linha.length) / 2, yy = y0 + 26 + r * (hgt + 6);
        linha.forEach(function (m, i) {
          var x = xs + i * cw;
          var pts = [x, yy, x + cw - pt, yy, x + cw, yy + hgt / 2, x + cw - pt, yy + hgt, x, yy + hgt, x + pt, yy + hgt / 2].join(' ');
          o += '<polygon points="' + pts + '" fill="' + COR['Finalístico'][0] + '" stroke="#fff" stroke-width="2.5"/>' + txt(x + cw / 2 + 4, yy + hgt / 2 + 4, quebra(m.nome, Math.max(8, Math.floor((cw - pt * 1.5) / (FS * 0.56)))).slice(0, 5), '#fff', FS);
          if (ed) o += ic(x + cw - pt - 12, yy + 13, 'Cva.macro(' + c.id + ',\'Finalístico\',' + m.id + ')', 'Editar ou excluir: ' + m.nome);
        });
      });
    }
    // seta de resultado (acompanha a altura total)
    var rx = L + AW + 12, rw = W - rx - L, yb = y0 + hh, midY = (yG + yb) / 2;
    o += '<polygon points="' + rx + ',' + yG + ' ' + (rx + rw - 30) + ',' + yG + ' ' + (rx + rw) + ',' + midY + ' ' + (rx + rw - 30) + ',' + yb + ' ' + rx + ',' + yb + '" fill="#0fbeca"/>';
    if (ed) o += ic(rx + 20, yG + 20, 'Cva.texto(' + c.id + ',\'resultado\')', 'Editar o resultado');
    o += txt(rx + (rw - 16) / 2, midY, ['RESULTADO'].concat(quebra(c.resultado || '(resultado não informado)', 16)), '#06183e', FS);
    o += '<text x="' + (W - L) + '" y="' + (H - 10) + '" text-anchor="end" font-family="Arial,Helvetica,sans-serif" font-size="9" fill="#777">' + h((c.nome || '') + (c.inicio ? ' · ' + E.dataBr(c.inicio) + ' a ' + (c.fim ? E.dataBr(c.fim) : '…') : '')) + '</text>';
    return o + '</svg>';
  }
  function baixarPng(svg, nome) {
    var img = new Image(), u = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    var vb = (svg.match(/viewBox="0 0 (\d+(?:\.\d+)?) (\d+(?:\.\d+)?)"/) || [0, 1100, 640]);
    img.onload = function () { var c = document.createElement('canvas'); c.width = Math.round(vb[1] * 2); c.height = Math.round(vb[2] * 2); var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); c.toBlob(function (b) { Common.baixarBlob ? Common.baixarBlob(nome, b) : Mapris.baixar(nome, b, 'image/png'); }); };
    img.src = u;
  }

  w.SvgUtil = { quebra: quebra, png: baixarPng };

  // ---------- modal simples ----------
  function mdl(titulo, corpo, ok, rotulo) {
    var d = document.createElement('div'); d.className = 'modal fade'; d.tabIndex = -1;
    d.innerHTML = '<div class="modal-dialog modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h6 class="modal-title">' + titulo + '</h6><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">' + corpo + '<div class="text-danger small mt-2" data-erro></div></div><div class="modal-footer"><button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-success btn-sm" data-ok>' + (rotulo || 'Salvar') + '</button></div></div></div>';
    document.body.appendChild(d); var M = new bootstrap.Modal(d);
    d.querySelector('[data-ok]').onclick = function () { try { if (ok(d) !== false) { M.hide(); } } catch (e) { d.querySelector('[data-erro]').textContent = e.message; } };
    d.addEventListener('hidden.bs.modal', function () { M.dispose(); d.remove(); }); M.show(); return d;
  }
  w.Mdl = mdl;

  function rotuloTipoCva(tipo) {
    return ({ 'Finalístico': 'Macroprocessos finalísticos', 'Gerencial': 'Macroprocessos gerenciais', 'Apoio': 'Macroprocessos de apoio' })[tipo] || (tipo || 'Macroprocessos');
  }
  /** Texto seguro para fontes padrão do jsPDF (WinAnsi / Helvetica). */
  function pdfTxt(s) {
    s = String(s == null ? '' : s);
    var map = {
      '\u00A0': ' ', '\u2013': '-', '\u2014': '-', '\u2018': "'", '\u2019': "'",
      '\u201C': '"', '\u201D': '"', '\u2022': '-', '\u25C6': '*', '\u25CB': '-',
      '\u25CF': '*', '\u25A0': '*', '\u2192': '->', '\u00B7': '-'
    };
    s = s.replace(/[\u00A0\u2013\u2014\u2018\u2019\u201C\u201D\u2022\u25C6\u25CB\u25CF\u25A0\u2192\u00B7]/g, function (ch) { return map[ch] || ' '; });
    // remove demais caracteres fora de Latin-1
    s = s.replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, '');
    return s;
  }
  /* ---------- Árvore de gestão da validação ---------- */
  var COR_DEC = { 'Manter': ['#2e7d32', '#ffffff'], 'Revisar': ['#f9a825', '#3b2f00'], 'Alterar': ['#c62828', '#ffffff'] };
  function seloDecisao(dec) { var c = COR_DEC[dec] || ['#64748b', '#ffffff']; return { t: dec || '—', cor: c[0], fg: c[1] }; }
  /** Monta a árvore (cadeia → nível → macroprocesso → processos) a partir das linhas de decisão da validação. */
  function arvoreValidacao(ciclo, linhas) {
    var vistos = {}, macrosL = [], procsL = [];
    (linhas || []).forEach(function (x) {
      var k = (x.alvo || '') + '#' + (x.ref_id != null ? x.ref_id : (x.nome || '')); if (vistos[k]) return; vistos[k] = true;
      if (x.alvo === 'macroprocesso') {
        var m = x.ref_id ? DB.one('SELECT tipo FROM macroprocessos WHERE id = ?', [x.ref_id]) : null;
        macrosL.push({ id: x.ref_id, nome: x.nome, decisao: x.decisao, tipo: (m && m.tipo) || x.tipo_macro || '' });
      } else {
        var p = x.ref_id ? DB.one('SELECT macro_id FROM processos WHERE id = ?', [x.ref_id]) : null;
        procsL.push({ id: x.ref_id, nome: x.nome, decisao: x.decisao, macro: x.macro_id !== undefined && x.macro_id !== null ? x.macro_id : (p ? p.macro_id : null) });
      }
    });
    var porNome = function (a, b) { return String(a.nome || '').localeCompare(String(b.nome || ''), 'pt'); };
    var usados = {}, grupos = [];
    TIPOS.concat(['']).forEach(function (tp) {
      var ms = macrosL.filter(function (m) { return (TIPOS.indexOf(m.tipo) < 0 ? '' : m.tipo) === tp; });
      if (!ms.length) return;
      grupos.push({
        tipo: 'grupo', rotulo: tp ? rotuloTipoCva(tp) : 'Outros macroprocessos', cor: tp ? COR[tp][0] : '#64748b',
        filhos: ms.map(function (m) {
          var fil = procsL.filter(function (p) { return p.macro === m.id; }).sort(porNome);
          fil.forEach(function (p) { usados[p.id] = 1; });
          return { tipo: 'macro', rotulo: m.nome, cor: tp ? COR[tp][0] : '#475569', badges: [seloDecisao(m.decisao)],
            filhos: fil.map(function (p) { return { tipo: 'proc', rotulo: p.nome, badges: [seloDecisao(p.decisao)] }; }) };
        })
      });
    });
    var sem = procsL.filter(function (p) { return !usados[p.id]; }).sort(porNome);
    if (sem.length) grupos.push({ tipo: 'grupo', rotulo: 'Processos sem macroprocesso neste ciclo', cor: '#64748b', filhos: sem.map(function (p) { return { tipo: 'proc', rotulo: p.nome, badges: [seloDecisao(p.decisao)] }; }) });
    var cont = { Manter: 0, Revisar: 0, Alterar: 0 };
    macrosL.concat(procsL).forEach(function (x) { if (cont[x.decisao] !== undefined) cont[x.decisao]++; });
    return {
      raiz: [{ tipo: 'raiz', rotulo: 'Cadeia de Valor Agregado — ' + (ciclo.cadeia || 'Principal'), meta: ciclo.nome || '', filhos: grupos }],
      nMacro: macrosL.length, nProc: procsL.length, cont: cont
    };
  }
  function gerarPdfValidacaoCva(ciclo, linhas, obs, dataBr, nomeArquivo) {
    var t = arvoreValidacao(ciclo, linhas), vig = '';
    if (ciclo.inicio) vig = ' · Vigência: ' + E.dataBr(ciclo.inicio) + (ciclo.fim ? ' a ' + E.dataBr(ciclo.fim) : '');
    Arvore.pdf({
      titulo: 'Validação da Cadeia de Valor Agregado — Árvore de gestão',
      subtitulo: 'Ciclo: ' + (ciclo.nome || '—') + ' · Cadeia: ' + (ciclo.cadeia || 'Principal') + vig + ' · Validação em ' + (dataBr || '—'),
      resumo: [t.nMacro + ' macroprocesso(s) · ' + t.nProc + ' processo(s) vinculado(s)  |  Manter: ' + t.cont.Manter + ' · Revisar: ' + t.cont.Revisar + ' · Alterar: ' + t.cont.Alterar],
      raiz: t.raiz,
      legendaTitulo: 'Decisão:', legenda: [seloDecisao('Manter'), seloDecisao('Revisar'), seloDecisao('Alterar')],
      observacao: obs, notaFinal: 'Documento gerado automaticamente pelo Valor-E na validação da CVA.',
      arquivo: nomeArquivo || 'validacao-cva'
    });
  }
  /** Mesma árvore em HTML (guardada junto ao documento de validação). */
  function htmlArvoreValidacao(t) {
    function no(n) {
      var b = (n.badges || []).map(function (x) { return '<span class="d" style="background:' + h(x.cor) + ';color:' + h(x.fg || '#fff') + '">' + h(x.t) + '</span>'; }).join('');
      return '<li class="' + n.tipo + '"><span class="r">' + h(n.rotulo) + '</span>' + (n.meta ? ' <small>' + h(n.meta) + '</small>' : '') + ' ' + b + ((n.filhos || []).length ? '<ul>' + n.filhos.map(no).join('') + '</ul>' : '') + '</li>';
    }
    return '<ul class="t">' + t.raiz.map(no).join('') + '</ul>';
  }

  function v(d, s) { return d.querySelector(s).value; }

  // ---------- tela ----------
  var Cva = w.Cva = {
    macrosDoCicloVigente: function () { var c = vigente(); return c ? macros(c.id) : []; },
    cadeias: cadeias,
    macroPorId: function (id) { return DB.one('SELECT * FROM macroprocessos WHERE id = ?', [id]); },
    contarProcessos: nProc,
    resumo: function () { var c = vigente(); return c ? { ciclo: c.nome, validade: validade(c).txt, macros: macros(c.id).length } : null; },
    cicloNovo: function (cad) {
      cad = cad || 'Principal'; var c = vigente(cad);
      mdl('Novo ciclo de validação', '<div class="mb-2"><label class="form-label">Nome</label><input class="form-control" id="cn" value="' + h('Ciclo ' + new Date().getFullYear()) + '"></div><div class="row g-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ci" value="' + hojeIso() + '"></div><div class="col"><label class="form-label">Término</label><input type="date" class="form-control" id="cf"></div></div>' +
        (c ? '<div class="form-check mt-3"><input class="form-check-input" type="checkbox" id="cc" checked><label class="form-check-label" for="cc">Copiar missão, resultado e macroprocessos do ciclo atual ("' + h(c.nome) + '"), que será encerrado e arquivado</label></div>' : ''),
        function (d) {
          if (!v(d, '#cn').trim()) throw new Error('Informe o nome do ciclo.');
          if (v(d, '#cf') && v(d, '#cf') < v(d, '#ci')) throw new Error('O término deve ser posterior ao início.');
          var id = DB.tx(function () {
            var cp = c && d.querySelector('#cc') && d.querySelector('#cc').checked;
            if (c) DB.run("UPDATE cva_ciclos SET status='Encerrado' WHERE status='Vigente' AND cadeia = ?", [cad]);
            DB.run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES (?,?,?,?,?, 'Vigente', ?)", [v(d, '#cn').trim(), cp ? c.missao : '', cp ? c.resultado : '', v(d, '#ci') || null, v(d, '#cf') || null, cad]);
            var nid = DB.lastId();
            if (cp) macros(c.id).forEach(function (m) {
              DB.run('INSERT INTO macroprocessos (ciclo_id,tipo,nome,descricao,responsavel,ordem) VALUES (?,?,?,?,?,?)', [nid, m.tipo, m.nome, m.descricao, m.responsavel, m.ordem]);
              DB.run('UPDATE processos SET macro_id = ? WHERE macro_id = ?', [DB.lastId(), m.id]);   // os processos acompanham o macroprocesso copiado
            });
            return nid;
          });
          Nav.ir('#/cva?ciclo=' + id);
        }, 'Criar ciclo');
    },
    cadeiaNova: function () {
      mdl('Nova cadeia de valor', '<p class="small text-muted">Use para registrar outra cadeia de valor. Cada cadeia tem seus próprios ciclos, missão, resultado e macroprocessos, e os processos, indicadores, riscos e capacidades vinculados a ela ficam identificados.</p><div class="mb-2"><label class="form-label">Nome da cadeia</label><input class="form-control" id="cdn" placeholder="Nome da cadeia"></div><div class="mb-2"><label class="form-label">Nome do primeiro ciclo</label><input class="form-control" id="cn" value="' + h('Ciclo ' + new Date().getFullYear()) + '"></div><div class="row g-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ci" value="' + hojeIso() + '"></div><div class="col"><label class="form-label">Término</label><input type="date" class="form-control" id="cf"></div></div>',
        function (d) {
          var cd = v(d, '#cdn').trim(); if (!cd) throw new Error('Informe o nome da cadeia.');
          if (cadeias().some(function (x) { return x.toLowerCase() === cd.toLowerCase(); })) throw new Error('Já existe uma cadeia com este nome.');
          if (!v(d, '#cn').trim()) throw new Error('Informe o nome do ciclo.');
          if (v(d, '#cf') && v(d, '#cf') < v(d, '#ci')) throw new Error('O término deve ser posterior ao início.');
          var id = DB.tx(function () { DB.run("INSERT INTO cva_ciclos (nome,missao,resultado,inicio,fim,status,cadeia) VALUES (?,'','',?,?, 'Vigente', ?)", [v(d, '#cn').trim(), v(d, '#ci') || null, v(d, '#cf') || null, cd]); return DB.lastId(); });
          Nav.ir('#/cva?ciclo=' + id);
        }, 'Criar cadeia');
    },
    cadeiaRenomear: function (cad) {
      mdl('Renomear cadeia de valor', '<div class="mb-2"><label class="form-label">Nome da cadeia</label><input class="form-control" id="cdn" value="' + h(cad) + '"></div>',
        function (d) {
          var nv = v(d, '#cdn').trim(); if (!nv) throw new Error('Informe o nome.');
          if (nv.toLowerCase() !== cad.toLowerCase() && cadeias().some(function (x) { return x.toLowerCase() === nv.toLowerCase(); })) throw new Error('Já existe uma cadeia com este nome.');
          DB.tx(function () { DB.run('UPDATE cva_ciclos SET cadeia = ? WHERE cadeia = ?', [nv, cad]); });
          Nav.ir('#/cva?cadeia=' + encodeURIComponent(nv));
        });
    },
    cicloEditar: function (id) {
      var c = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [id]);
      mdl('Dados do ciclo', '<div class="mb-2"><label class="form-label">Nome</label><input class="form-control" id="cn" value="' + h(c.nome) + '"></div><div class="row g-2"><div class="col"><label class="form-label">Início</label><input type="date" class="form-control" id="ci" value="' + h(c.inicio || '') + '"></div><div class="col"><label class="form-label">Término</label><input type="date" class="form-control" id="cf" value="' + h(c.fim || '') + '"></div></div><div class="mt-2"><label class="form-label">Observações</label><textarea class="form-control" id="co" rows="2">' + h(c.obs || '') + '</textarea></div>',
        function (d) { if (!v(d, '#cn').trim()) throw new Error('Informe o nome.'); DB.tx(function () { DB.run('UPDATE cva_ciclos SET nome=?,inicio=?,fim=?,obs=? WHERE id=?', [v(d, '#cn').trim(), v(d, '#ci') || null, v(d, '#cf') || null, v(d, '#co'), id]); }); Nav.ir('#/cva?ciclo=' + id); });
    },
    cicloExcluir: function (id) {
      var n = DB.one('SELECT COUNT(*) AS n FROM macroprocessos WHERE ciclo_id = ?', [id]).n;
      if (!confirm('Excluir este ciclo e seus ' + n + ' macroprocesso(s)? Os processos vinculados ficarão sem macroprocesso.')) return;
      DB.tx(function () { DB.run('UPDATE processos SET macro_id = NULL WHERE macro_id IN (SELECT id FROM macroprocessos WHERE ciclo_id = ?)', [id]); DB.run('DELETE FROM macroprocessos WHERE ciclo_id = ?', [id]); DB.run('DELETE FROM cva_validacoes WHERE ciclo_id = ?', [id]); DB.run('DELETE FROM cva_ciclos WHERE id = ?', [id]); });
      Nav.ir('#/cva');
    },
    texto: function (cid, campo) {
      var c = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [cid]), rot = campo === 'missao' ? 'Missão' : 'Resultado (valor entregue / margem)';
      mdl('Editar — ' + rot, '<label class="form-label">' + rot + '</label><textarea class="form-control" id="tx" rows="5">' + h(c[campo] || '') + '</textarea>',
        function (d) { DB.tx(function () { DB.run('UPDATE cva_ciclos SET ' + (campo === 'missao' ? 'missao' : 'resultado') + '=? WHERE id=?', [v(d, '#tx'), cid]); }); Nav.ir('#/cva?ciclo=' + cid); });
    },
    textos: function (id) { DB.tx(function () { DB.run('UPDATE cva_ciclos SET missao=?, resultado=? WHERE id=?', [document.getElementById('cvMis').value, document.getElementById('cvRes').value, id]); }); Nav.ir('#/cva?ciclo=' + id); },
    macro: function (cid, tipo, id) {
      var m = id ? DB.one('SELECT * FROM macroprocessos WHERE id = ?', [id]) : { tipo: tipo, nome: '', descricao: '', responsavel: '' };
      var dlg = mdl((id ? 'Editar' : 'Novo') + ' macroprocesso', '<div class="mb-2"><label class="form-label">Tipo</label><select class="form-select" id="mt">' + TIPOS.map(function (t) { return '<option value="' + t + '"' + (t === m.tipo ? ' selected' : '') + '>' + PLURAL[t] + '</option>'; }).join('') + '</select></div><div class="mb-2"><label class="form-label">Nome *</label><input class="form-control" id="mn" value="' + h(m.nome) + '"></div><div class="mb-2"><label class="form-label">Responsável</label><input class="form-control" id="mr" value="' + h(m.responsavel || '') + '"></div><div><label class="form-label">Descrição</label><textarea class="form-control" id="md" rows="3">' + h(m.descricao || '') + '</textarea></div>',
        function (d) {
          var nome = v(d, '#mn').trim(); if (!nome) throw new Error('Informe o nome do macroprocesso.');
          DB.tx(function () {
            if (id) DB.run('UPDATE macroprocessos SET tipo=?,nome=?,responsavel=?,descricao=? WHERE id=?', [v(d, '#mt'), nome, v(d, '#mr'), v(d, '#md'), id]);
            else DB.run('INSERT INTO macroprocessos (ciclo_id,tipo,nome,responsavel,descricao,ordem) VALUES (?,?,?,?,?,(SELECT COALESCE(MAX(ordem),0)+1 FROM macroprocessos WHERE ciclo_id=?))', [cid, v(d, '#mt'), nome, v(d, '#mr'), v(d, '#md'), cid]);
          }); Nav.ir('#/cva?ciclo=' + cid);
        }, id ? 'Salvar' : 'Adicionar');
      if (id) {
        var bd = dlg.querySelector('.modal-body'), n = nProc(id);
        var ex = document.createElement('div'); ex.className = 'd-flex flex-wrap gap-2 mt-3 pt-2 border-top';
        ex.innerHTML = '<a class="btn btn-sm btn-outline-secondary" href="#/processos?macro=' + id + '" data-bs-dismiss="modal"><i class="bi bi-diagram-3"></i> ' + n + ' processo(s)</a><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="-1"><i class="bi bi-arrow-left"></i> Mover</button><button type="button" class="btn btn-sm btn-outline-secondary" data-mv="1">Mover <i class="bi bi-arrow-right"></i></button><button type="button" class="btn btn-sm btn-outline-danger ms-auto" data-xx><i class="bi bi-trash"></i> Excluir</button>';
        if (bd) { bd.appendChild(ex);
          Array.prototype.forEach.call(ex.querySelectorAll('[data-mv]'), function (b) { b.onclick = function () { var mo = bootstrap.Modal.getInstance(bd.closest('.modal')); if (mo) mo.hide(); Cva.mover(cid, id, +b.getAttribute('data-mv')); }; });
          ex.querySelector('[data-xx]').onclick = function () { var mo = bootstrap.Modal.getInstance(bd.closest('.modal')); if (mo) mo.hide(); Cva.macroExcluir(cid, id); };
        }
      }
    },
    macroExcluir: function (cid, id) {
      var n = nProc(id); if (!confirm('Excluir o macroprocesso?' + (n ? '\n' + n + ' processo(s) vinculado(s) ficarão sem macroprocesso (não serão excluídos).' : ''))) return;
      DB.tx(function () { DB.run('UPDATE processos SET macro_id = NULL WHERE macro_id = ?', [id]); DB.run('DELETE FROM macroprocessos WHERE id = ?', [id]); }); Nav.ir('#/cva?ciclo=' + cid);
    },
    mover: function (cid, id, dir) {
      var m = DB.one('SELECT * FROM macroprocessos WHERE id = ?', [id]), l = macros(cid).filter(function (x) { return x.tipo === m.tipo; }), i = l.findIndex(function (x) { return x.id === id; }), j = i + dir;
      if (j < 0 || j >= l.length) return;
      DB.tx(function () { l.splice(j, 0, l.splice(i, 1)[0]); l.forEach(function (x, k) { DB.run('UPDATE macroprocessos SET ordem = ? WHERE id = ?', [k + 1, x.id]); }); }); Nav.ir('#/cva?ciclo=' + cid);
    },
    svg: function (id, fmt) { var c = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [id]), s = svgPorter(c), n = 'cadeia-de-valor-' + String(c.nome).replace(/[^A-Za-z0-9_-]+/g, '_'); if (fmt === 'png') baixarPng(s, n + '.png'); else Mapris.baixar(n + '.svg', s, 'image/svg+xml'); },
    imprimir: function () { document.body.classList.add('imp-cva'); window.print(); setTimeout(function () { document.body.classList.remove('imp-cva'); }, 500); },
    revisao: function (cid) {
      var ms = macros(cid), linhas = '';
      function sel(n) { return '<select class="form-select form-select-sm" data-rv="' + n + '"><option>Manter</option><option>Revisar</option><option>Alterar</option></select>'; }
      function rotuloNivel(tipo) {
        return ({ 'Finalístico': 'Macroprocessos finalísticos', 'Gerencial': 'Macroprocessos gerenciais', 'Apoio': 'Macroprocessos de apoio' })[tipo] || (tipo || 'Macroprocessos');
      }
      var tipoAtual = null;
      // ordenar: Finalístico, Gerencial, Apoio
      var ordem = { 'Finalístico': 1, 'Gerencial': 2, 'Apoio': 3 };
      ms = ms.slice().sort(function (a, b) {
        var oa = ordem[a.tipo] || 9, ob = ordem[b.tipo] || 9;
        if (oa !== ob) return oa - ob;
        return (a.ordem || 0) - (b.ordem || 0) || String(a.nome || '').localeCompare(String(b.nome || ''), 'pt');
      });
      ms.forEach(function (m) {
        if (m.tipo !== tipoAtual) {
          tipoAtual = m.tipo;
          linhas += '<tr class="cva-nivel-row"><td colspan="4" style="background:linear-gradient(90deg,#e8eef6,#f8fafc);border-left:4px solid #0a6fc2;font-weight:700;color:#0a6fc2;padding:.55rem .75rem">' + h(rotuloNivel(tipoAtual)) + '</td></tr>';
        }
        linhas += '<tr class="table-light"><td colspan="3"><b>◆ ' + h(m.nome) + '</b> <small class="text-muted">(macroprocesso)</small></td><td>' + sel('m' + m.id) + '</td></tr>';
        DB.all('SELECT id,nome FROM processos WHERE macro_id = ? ORDER BY nome', [m.id]).forEach(function (p) { linhas += '<tr><td></td><td colspan="2">○ ' + h(p.nome) + '</td><td>' + sel('p' + p.id) + '</td></tr>'; });
      });
      var sem = DB.all('SELECT id,nome FROM processos WHERE macro_id IS NULL OR macro_id NOT IN (SELECT id FROM macroprocessos WHERE ciclo_id = ?) ORDER BY nome', [cid]);
      if (sem.length) {
        linhas += '<tr class="cva-nivel-row"><td colspan="4" style="background:linear-gradient(90deg,#f5f5f5,#fafafa);border-left:4px solid #888;font-weight:700;color:#555;padding:.55rem .75rem">Processos sem macroprocesso</td></tr>';
      }
      sem.forEach(function (p) { linhas += '<tr><td colspan="3">' + h(p.nome) + ' <small class="text-muted">(sem macroprocesso neste ciclo)</small></td><td>' + sel('p' + p.id) + '</td></tr>'; });
      var d = mdl('Revisão do ciclo — manter, revisar ou alterar', '<p class="small text-muted">Para cada macroprocesso e processo, registre a decisão da validação. <b>Manter</b>: continua como está. <b>Revisar</b>: será reanalisado (a Folha de dados fica marcada). <b>Alterar</b>: haverá mudança no processo.</p><table class="table table-sm"><thead><tr><th style="width:20px"></th><th colspan="2">Item</th><th style="width:130px">Decisão</th></tr></thead><tbody>' + linhas + '</tbody></table><div><label class="form-label">Observações da validação</label><textarea class="form-control" id="ro" rows="2"></textarea></div>',
        function (d) {
          var obs = (d.querySelector('#ro') || {}).value || '';
          var linhas = [];
          Array.prototype.forEach.call(d.querySelectorAll('[data-rv]'), function (s) {
            var k = s.getAttribute('data-rv'), id = parseInt(k.slice(1), 10), alvo = k.charAt(0) === 'm' ? 'macroprocesso' : 'processo';
            var nome = (DB.one('SELECT nome FROM ' + (alvo === 'processo' ? 'processos' : 'macroprocessos') + ' WHERE id = ?', [id]) || {}).nome || '';
            var extra = {};
            if (alvo === 'processo') { var pr = DB.one('SELECT macro_id FROM processos WHERE id = ?', [id]); extra.macro_id = pr ? pr.macro_id : null; }
            else { var mm = DB.one('SELECT tipo FROM macroprocessos WHERE id = ?', [id]); extra.tipo_macro = mm ? mm.tipo : ''; }
            linhas.push({ alvo: alvo, ref_id: id, nome: nome, decisao: s.value, macro_id: extra.macro_id, tipo_macro: extra.tipo_macro });
          });
          var ciclo = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [cid]) || {};
          var agora = new Date();
          var emIso = agora.toISOString();
          var dataBr = E.dataBr(emIso.slice(0, 10));
          var titulo = 'Validação CVA — ' + (ciclo.nome || ('Ciclo ' + cid)) + ' — ' + dataBr;
          var htmlDoc = '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>' + h(titulo) + '</title>' +
            '<style>body{font-family:Arial,Helvetica,sans-serif;margin:28px;color:#1a1a1a}h1{font-size:18px;margin:0 0 6px}h2{font-size:14px;margin:18px 0 8px;border-bottom:1px solid #ccc;padding-bottom:4px}.meta{color:#555;font-size:12px;margin-bottom:16px}ul.t,ul.t ul{list-style:none;margin:0;padding-left:20px;border-left:1px solid #b7c6da}ul.t{border-left:0;padding-left:0}ul.t li{margin:5px 0;font-size:13px}li.raiz>.r{background:#0b2447;color:#fff;padding:3px 10px;border-radius:5px;font-weight:700}li.grupo>.r{font-weight:700;color:#0a6fc2}li.macro>.r{font-weight:700;background:#e8eef6;padding:2px 8px;border-radius:4px}.d{display:inline-block;font-size:11px;font-weight:700;border-radius:10px;padding:0 8px;margin-left:6px}.obs{margin-top:14px;padding:10px;background:#fafafa;border:1px solid #ddd;white-space:pre-wrap}</style></head><body>' +
            '<h1>Validação da Cadeia de Valor Agregado — Árvore de gestão</h1>' +
            '<div class="meta">Ciclo: <b>' + h(ciclo.nome || '') + '</b> · Cadeia: <b>' + h(ciclo.cadeia || 'Principal') + '</b><br>Emitido em: ' + h(dataBr) + (ciclo.inicio ? ' · Vigência: ' + h(E.dataBr(ciclo.inicio)) + (ciclo.fim ? ' a ' + h(E.dataBr(ciclo.fim)) : '') : '') + '</div>' +
            '<h2>Macroprocessos e processos vinculados — decisão por item</h2>' + htmlArvoreValidacao(arvoreValidacao(ciclo, linhas)) +
            (obs ? '<h2>Observações</h2><div class="obs">' + h(obs) + '</div>' : '') +
            '<p style="margin-top:24px;font-size:11px;color:#777">Documento gerado automaticamente pelo Valor-E na validação da CVA.</p></body></html>';
          var docId = null;
          var payloadJson = JSON.stringify(linhas);
          // embute os dados no HTML para recuperação garantida no download
          htmlDoc += '\n<!--VALORE_JSON:' + encodeURIComponent(payloadJson) + '-->';
          DB.tx(function () {
            linhas.forEach(function (x) {
              DB.run('INSERT INTO cva_validacoes (ciclo_id,alvo,ref_id,nome,decisao,obs) VALUES (?,?,?,?,?,?)', [cid, x.alvo, x.ref_id, x.nome, x.decisao, obs]);
              if (x.alvo === 'processo') DB.run('UPDATE processos SET validacao = ?, validado_ciclo_id = ? WHERE id = ?', [x.decisao, cid, x.ref_id]);
            });
            try {
              DB.run('INSERT INTO cva_documentos (ciclo_id,titulo,gerado_em,html,obs,dados_json) VALUES (?,?,?,?,?,?)', [cid, titulo, emIso, htmlDoc, obs, payloadJson]);
            } catch (eIns) {
              DB.run('INSERT INTO cva_documentos (ciclo_id,titulo,gerado_em,html,obs) VALUES (?,?,?,?,?)', [cid, titulo, emIso, htmlDoc, obs]);
            }
            docId = DB.lastId();
          });
          // baixa o documento anexo em PDF imediatamente
          try {
            var nomeArq = ('validacao-cva-' + (ciclo.nome || cid) + '-' + dataBr).replace(/[^A-Za-z0-9À-ÿ_-]+/g, '_');
            gerarPdfValidacaoCva(ciclo, linhas, obs, dataBr, nomeArq);
          } catch (e) { console.error(e); alert('Validação registrada, mas houve erro ao gerar o PDF: ' + (e.message || e)); }
          Nav.ir('#/cva?ciclo=' + cid);
        }, 'Registrar validação');
      try { d.querySelector('.modal-dialog').classList.add('modal-xl'); d.querySelector('.modal-dialog').style.maxWidth = '960px'; } catch (e) {}
    },
    baixarDocumento: function (id) {
      var doc = DB.one('SELECT * FROM cva_documentos WHERE id = ?', [id]);
      if (!doc) return alert('Documento não encontrado.');
      try {
        var ciclo = DB.one('SELECT * FROM cva_ciclos WHERE id = ?', [doc.ciclo_id]) || {};
        var dataBr = E.dataBr(String(doc.gerado_em || '').slice(0, 10));
        var linhas = [];
        // 1) coluna dados_json
        try {
          if (doc.dados_json && String(doc.dados_json).trim() && String(doc.dados_json).trim() !== '[]') {
            linhas = JSON.parse(doc.dados_json) || [];
          }
        } catch (e) { linhas = []; }
        // 2) marcador embutido no HTML: <!--VALORE_JSON:...-->
        if (!linhas.length && doc.html) {
          try {
            var m = String(doc.html).match(/<!--VALORE_JSON:([\s\S]*?)-->/);
            if (m && m[1]) linhas = JSON.parse(decodeURIComponent(m[1])) || [];
          } catch (e2) { linhas = []; }
        }
        // 3) fallback: validações do mesmo dia do documento (último lote do ciclo naquele dia)
        if (!linhas.length) {
          try {
            var dia = String(doc.gerado_em || '').slice(0, 10);
            var vals = DB.all(
              "SELECT alvo, ref_id, nome, decisao FROM cva_validacoes WHERE ciclo_id = ? AND (substr(em,1,10) = ? OR substr(em,1,10) = ?) ORDER BY id DESC",
              [doc.ciclo_id, dia, dia.replace('T', ' ').slice(0, 10)]
            );
            // pega o lote mais recente: itens consecutivos até repetir macro+processo set size roughly by unique names in one pass
            if (vals.length) {
              var lote = [], visto = {};
              for (var i = 0; i < vals.length; i++) {
                var k = vals[i].alvo + '#' + vals[i].ref_id;
                if (visto[k]) break;
                visto[k] = true;
                lote.push(vals[i]);
              }
              linhas = lote.reverse();
            }
          } catch (e3) {}
        }
        if (!linhas.length) {
          alert('Este documento não possui dados detalhados para regenerar o PDF. Faça uma nova validação.');
          return;
        }
        var nomeArq = (doc.titulo || ('validacao-cva-' + id)).replace(/[^A-Za-z0-9À-ÿ_-]+/g, '_');
        gerarPdfValidacaoCva(ciclo, linhas, doc.obs || '', dataBr, nomeArq);
      } catch (e) { console.error(e); alert('Não foi possível gerar o PDF do documento: ' + (e.message || e)); }
    }
  };

  function html(q) {
    var c = cicloAtual(q), cad = c ? (c.cadeia || 'Principal') : 'Principal', todos = ciclos(cad), cads = cadeias();
    if (!c) {
      return '<div class="pagina"><h1 class="h4"><i class="bi bi-bezier2"></i> CVA — Cadeia de Valor Agregado</h1><div class="cartao"><div class="vazio">Nenhum ciclo cadastrado. Crie o primeiro ciclo de validação para cadastrar a missão, o resultado e os macroprocessos da organização.<br><br><button class="btn btn-success" onclick="Cva.cicloNovo()"><i class="bi bi-plus-lg"></i> Criar ciclo da cadeia de valor</button></div></div></div>';
    }
    var vl = validade(c), ms = macros(c.id), o = '<div class="pagina cva-host">';
    o += '<div class="d-flex flex-wrap align-items-center mb-2"><h1 class="h4 mb-0 me-auto"><i class="bi bi-bezier2"></i> CVA — Cadeia de Valor Agregado</h1>' +
      '<select class="form-select form-select-sm" style="width:170px;margin-right:6px" title="Cadeia de valor" onchange="Nav.ir(\'#/cva?cadeia=\'+encodeURIComponent(this.value))">' + cads.map(function (x) { return '<option value="' + h(x) + '"' + (x === cad ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select><button class="btn btn-outline-secondary btn-sm" style="margin-right:8px" title="Renomear a cadeia" onclick="Cva.cadeiaRenomear(\'' + h(cad).replace(/'/g, '\\\'') + '\')"><i class="bi bi-tag"></i></button>' +
      '<select class="form-select form-select-sm" style="width:190px;margin-right:6px" title="Ciclo" onchange="Nav.ir(\'#/cva?ciclo=\'+this.value)">' + todos.map(function (x) { return '<option value="' + x.id + '"' + (x.id === c.id ? ' selected' : '') + '>' + h(x.nome) + (x.status === 'Vigente' ? ' (vigente)' : ' (encerrado)') + '</option>'; }).join('') + '</select>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="Cva.cicloEditar(' + c.id + ')"><i class="bi bi-pencil"></i> Ciclo</button><button class="btn btn-outline-danger btn-sm" style="margin-right:6px" onclick="Cva.cicloExcluir(' + c.id + ')"><i class="bi bi-trash"></i></button><button class="btn btn-success btn-sm" style="margin-right:6px" onclick="Cva.cicloNovo(\'' + h(cad).replace(/'/g, '\\\'') + '\')"><i class="bi bi-plus-lg"></i> Novo ciclo</button><button class="btn btn-outline-success btn-sm" onclick="Cva.cadeiaNova()" title="Cadastrar outra cadeia de valor"><i class="bi bi-diagram-2"></i> Nova cadeia</button></div>';
    o += '<div class="alert alert-' + vl.cls + ' d-flex flex-wrap align-items-center py-2"><i class="bi bi-calendar-check" style="margin-right:8px"></i><span class="me-auto"><b>Ciclo de validação:</b> ' + h(c.nome) + (c.inicio ? ' · ' + E.dataBr(c.inicio) + ' a ' + (c.fim ? E.dataBr(c.fim) : '…') : '') + ' — ' + h(vl.txt) + '</span>' +
      (c.status === 'Vigente' ? '<button class="btn btn-sm btn-' + (vl.n !== null && vl.n <= 60 ? 'dark' : 'outline-dark') + '" onclick="Cva.revisao(' + c.id + ')"><i class="bi bi-clipboard-check"></i> Revisar e validar a cadeia</button>' : '') + '</div>';
    o += '<div class="cartao"><h2><span class="me-auto"><i class="bi bi-bezier2"></i> Cadeia de valor — edite direto na imagem</span><span class="no-print"><button class="btn btn-sm btn-outline-secondary" onclick="Cva.svg(' + c.id + ',\'png\')"><i class="bi bi-filetype-png"></i> PNG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Cva.svg(' + c.id + ',\'svg\')"><i class="bi bi-filetype-svg"></i> SVG</button> <button class="btn btn-sm btn-outline-secondary" onclick="Cva.imprimir()"><i class="bi bi-printer"></i> Imprimir</button></span></h2><div class="corpo cva-img"><div class="ajuda no-print" style="margin-bottom:6px">Clique em <b>+</b> para adicionar um macroprocesso e no ícone de <b>lápis</b> para editar, mover ou excluir. A missão e o resultado também são editados pelo lápis. Os ícones não aparecem na imagem exportada.</div>' + svgPorter(c, true) + '</div></div>';
    var docs = [];
    try { docs = DB.all('SELECT id, titulo, gerado_em FROM cva_documentos WHERE ciclo_id = ? ORDER BY id DESC', [c.id]); } catch (e) { docs = []; }
    if (docs.length) {
      o += '<div class="cartao"><h2><i class="bi bi-paperclip"></i> Documentos de validação</h2><div class="corpo"><p class="small text-muted mb-2">Cada revisão gera um documento PDF anexo para download (não é listada item a item abaixo da CVA).</p><ul class="list-unstyled mb-0">';
      docs.forEach(function (d) {
        o += '<li class="d-flex align-items-center gap-2 py-1 border-bottom"><i class="bi bi-file-earmark-text"></i> <span class="me-auto">' + h(d.titulo) + ' <small class="text-muted">(' + E.dataBr(String(d.gerado_em).slice(0, 10)) + ')</small></span>' +
          '<button type="button" class="btn btn-sm btn-outline-primary" onclick="Cva.baixarDocumento(' + d.id + ')"><i class="bi bi-download"></i> Baixar</button></li>';
      });
      o += '</ul></div></div>';
    }
    return o + '</div>';
  }
  Modulos.registrar('/cva', { ativo: 'cva', titulo: 'CVA — Cadeia de Valor', html: html });
})(window);
