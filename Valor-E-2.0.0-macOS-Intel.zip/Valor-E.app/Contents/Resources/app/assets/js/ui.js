/* ui.js — telas do AXIA (porte de layout.php, index.php, riscos.php, alertas.php, planos.php, relatorio.php, config.php, metodo.php, risco.php)
 * Rotas por hash: #/ (painel), #/alertas, #/riscos, #/risco?id=N, #/planos, #/relatorio, #/config, #/metodo */
(function (w) {
  'use strict';
  var h = E.esc, NIVEIS = E.NIVEIS, APP_NOME = 'Valor-E', APP_VERSAO = "2.0", APP_SLOGAN = 'Gestão e Realização Estratégica';
  w.APP_VERSAO = APP_VERSAO; w.APP_SLOGAN = APP_SLOGAN;

  function logoSvg() { return '<img src="assets/icon.png" width="36" height="36" alt="Valor-E" style="display:block;border-radius:8px">'; }
  function nvBadge(n) { return n ? '<span class="nv ' + h(String(n).replace(/ /g, '-')) + '">' + h(n) + '</span>' : '<span class="nv nd">—</span>'; }
  function trunc(t, n) { t = String(t == null ? '' : t); var a = Array.from(t); return a.length > n ? a.slice(0, n - 1).join('') + '…' : t; }
  function enc(s) { return encodeURIComponent(s); }
  function nl2br(s) { return h(s).replace(/\n/g, '<br>'); }
  function dBr(x) { return x ? E.dataBr(x) : '—'; }
  function opts(lista, sel, vazio) { return (vazio ? '<option value="">' + vazio + '</option>' : '') + lista.map(function (v) { return '<option' + (v === sel ? ' selected' : '') + '>' + h(v) + '</option>'; }).join(''); }
  function ambOpts(sel, vazio) { return '<option value="">' + vazio + '</option>' + E.ambientesLista().map(function (a) { return '<option value="' + h(a.ambiente) + '"' + (a.ambiente === sel ? ' selected' : '') + '>' + h(a.ambiente) + ' (' + a.n + ')</option>'; }).join(''); }

  function heat(m) {
    var o = '<div class="heatw"><div class="ylab"><span>Probabilidade</span></div><div class="yt">';
    for (var p = 5; p >= 1; p--) o += '<i>' + p + '</i>';
    o += '</div><div class="heat">';
    for (p = 5; p >= 1; p--) for (var i = 1; i <= 5; i++) {
      var n = E.matrizIndice(p, i).nivel, q = (m[p] && m[p][i]) || 0;
      o += '<div class="c ' + h(n.replace(/ /g, '-')) + (q ? '' : ' vz') + '" title="Probabilidade ' + p + ' × Impacto ' + i + ' = ' + (p * i) + ' (' + h(n) + ') — ' + q + ' risco(s)"><small>' + (p * i) + '</small>' + (q ? '<b class="n">' + q + '</b>' : '') + '</div>';
    }
    o += '</div><div></div><div></div><div class="xt">';
    for (i = 1; i <= 5; i++) o += '<i>' + i + '</i>';
    o += '</div><div></div><div></div><div class="xlab">Impacto</div></div><div class="heat-leg">';
    NIVEIS.forEach(function (n) { o += '<span><i style="background:' + E.COR_NIVEL[n] + '"></i>' + n + '</span>'; });
    return o + '</div>';
  }

  // ---------- navegação ----------
  var Nav = w.Nav = { q: function () { return parse().q; }, atual: '', ir: function (hash) { if (location.hash === hash) rota(); else location.hash = hash; } };
  function parse() {
    var s = location.hash.replace(/^#/, '') || '/', i = s.indexOf('?'), p = i < 0 ? s : s.slice(0, i), q = {};
    if (i >= 0) s.slice(i + 1).split('&').forEach(function (kv) { if (!kv) return; var j = kv.indexOf('='); var k = decodeURIComponent(j < 0 ? kv : kv.slice(0, j)); q[k] = j < 0 ? '' : decodeURIComponent(kv.slice(j + 1).replace(/\+/g, ' ')); });
    return { rota: p, q: q };
  }
  function qs(o) { var a = []; Object.keys(o).forEach(function (k) { if (o[k] !== '' && o[k] != null) a.push(enc(k) + '=' + enc(o[k])); }); return a.length ? '?' + a.join('&') : ''; }
  // filtros (substitui <form method=get>)
  Nav.f = function (form) {
    var o = {}; new FormData(form).forEach(function (v, k) { o[k] = v; });
    var r = parse(); Nav.ir('#' + r.rota + qs(o));
  };
  w.addEventListener('submit', function (e) { if (e.target.classList && e.target.classList.contains('filtros')) { e.preventDefault(); Nav.f(e.target); } });

  // ---------- estrutura ----------
  function topo(ativo) {
    var s = E.alertasSelo(), n = s.critico + s.atencao;
    function a(k, href, ic, txt, extra) { return '<a href="' + href + '" class="' + (ativo === k ? 'ativo' : '') + '"><i class="bi ' + ic + '"></i> ' + txt + (extra || '') + '</a>'; }
    window.MAPRIS_SELO = s;
    return '<div class="topbar no-print"><a class="marca" href="#/">' + logoSvg() + ' <span class="marca-txt"><span class="nm">Valor<b class="e">-E</b></span><small title="' + APP_SLOGAN + '">' + APP_SLOGAN + '</small></span></a><nav class="nav-app">' +
      a('painel', '#/', 'bi-house-door', 'Painel') +
      a('cva', '#/cva', 'bi-bezier2', 'CVA') + a('mapa', '#/estrategia', 'bi-diagram-2', 'Mapa Estratégico') + a('processos', '#/processos', 'bi-diagram-3', 'Processos') + a('projetos', '#/projetos', 'bi-kanban', 'Projetos') + a('indicadores', '#/indicadores', 'bi-graph-up-arrow', 'Indicadores') +
      a('riscos', '#/riscos', 'bi-exclamation-triangle' + (n ? '-fill' : ''), 'Riscos', (s.critico ? '<span class="selo crit">' + s.critico + '</span>' : '') + (s.atencao ? '<span class="selo atn">' + s.atencao + '</span>' : '')) +
      a('valor', '#/valor', 'bi-bullseye', 'Valor Estratégico') + a('guia', '#/guia', 'bi-book', 'Guia do Usuário') +
      '</nav><div class="d-flex align-items-center gap-2 ms-auto me-2">' + '' + '</div><div class="dropdown"><button class="btn btn-outline-light btn-sm dropdown-toggle" data-bs-toggle="dropdown" data-bs-boundary="viewport"><i class="bi bi-gear"></i> Mais</button><ul class="dropdown-menu dropdown-menu-end">' +
            '<li><a class="dropdown-item" href="#/dados"><i class="bi bi-arrow-left-right"></i> Exportar / importar tudo</a></li>' +
      '<li><button class="dropdown-item" onclick="Pacote.exportarJson()"><i class="bi bi-filetype-json"></i> Exportar tudo (.json)</button></li>' +
      '<li><button class="dropdown-item" onclick="Pacote.exportarXml()"><i class="bi bi-filetype-xml"></i> Exportar tudo (.xml)</button></li>' +
      '<li><button class="dropdown-item" onclick="Acoes.expBanco()"><i class="bi bi-database"></i> Cópia do banco (.sqlite)</button></li><li><hr class="dropdown-divider"></li>' +
      '<li><a class="dropdown-item" href="#/config"><i class="bi bi-sliders"></i> Parâmetros de risco (apetite e prazos)</a></li>' +
      '</ul></div><input type="file" id="imp" accept=".xml,.json" hidden></div>';
  }
  var RODAPE = '<footer class="rodape-app no-print"><span class="me-2">Valor-E ' + APP_VERSAO + '</span> · © ' + new Date().getFullYear() + ' Angelo Christofaro · Todos os direitos reservados · <a href="mailto:angelo.christofaro@gmail.com">angelo.christofaro@gmail.com</a> · <a href="#" onclick="limparBase();return false">Limpar todos os dados</a></footer>';
  var MODAL_INICIO = '<div class="modal fade" id="mInicio" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header" style="background:#fdecea"><h5 class="modal-title text-danger"><i class="bi bi-bell-fill"></i> Antes de começar</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="mInicioCorpo"></div><div class="modal-footer"><button class="btn btn-outline-secondary" data-bs-dismiss="modal">Depois</button><a class="btn btn-danger" href="#/alertas">Ver alertas e agir</a></div></div></div></div>';
  var tituloBase = { '/folha': 'Folha de dados', '/diagrama': 'Fluxo do processo', '/impfolha': 'Folha de dados — impressão', '/processos': 'Processos', '/projetos': 'Projetos', '/projeto': 'Projeto', '/processo': 'Processo', '/mapa': 'Mapa do processo', '/relmapa': 'Relatório do mapa', '/': 'Painel', '/alertas': 'Alertas', '/riscos': 'Riscos', '/planos': 'Planos de ação', '/relatorio': 'Relatório', '/config': 'Apetite e prazos de revisão', '/dados': 'Exportar e importar', '/metodo': 'Metodologia', '/risco': 'Risco' };
  var inicioMostrado = false;

  /** Submenu do módulo de Riscos: Riscos · Alertas · Planos de ação · Relatório. */
  var SUB_RISCOS = { painelrisco: ['#/painelrisco', 'bi-speedometer2', 'Painel de riscos'], riscos: ['#/riscos', 'bi-exclamation-triangle', 'Riscos'], alertas: ['#/alertas', 'bi-bell', 'Alertas'], planos: ['#/planos', 'bi-list-check', 'Planos de ação'], relatorio: ['#/relatorio', 'bi-file-earmark-text', 'Relatório'] };
  function subRiscos(k) {
    return '<div class="subnav no-print"><div class="subnav-in">' + Object.keys(SUB_RISCOS).map(function (x) { var v = SUB_RISCOS[x]; return '<a href="' + v[0] + '" class="' + (k === x ? 'ativo' : '') + '"><i class="bi ' + v[1] + '"></i> ' + v[2] + '</a>'; }).join('') + '</div></div>';
  }
  function moldura(ativo, titulo, corpo) {
    var topAtivo = ativo, subk = SUB_RISCOS[ativo] ? ativo : '';
    if (subk) { topAtivo = 'riscos'; corpo = subRiscos(subk) + corpo; }
    ativo = topAtivo;
    // limpa restos de janelas modais (fundo escurecido) de uma tela anterior
    Array.prototype.forEach.call(document.querySelectorAll('.modal-backdrop'), function (x) { x.remove(); });
    document.body.classList.remove('modal-open'); document.body.style.removeProperty('overflow'); document.body.style.removeProperty('padding-right');
    var mr = document.getElementById('mRev'); if (mr) mr.remove();
    Array.prototype.forEach.call(document.querySelectorAll('#mdlw, #mdl, body > .modal'), function (x) { x.remove(); });
    document.getElementById('raiz').innerHTML = topo(ativo) + corpo + MODAL_INICIO + RODAPE;
    var s = window.MAPRIS_SELO, n = s.critico + s.atencao;
    document.title = (n > 0 ? '(' + n + ') ' : '') + titulo + ' — ' + APP_NOME;
    var imp = document.getElementById('imp');
    imp.addEventListener('change', function (e) { var f = e.target.files[0]; if (f) Acoes.importar(f); imp.value = ''; });
    var r = parse().rota;
    if (!inicioMostrado && s.critico > 0 && r !== '/alertas' && r !== '/risco') {
      inicioMostrado = true;
      document.getElementById('mInicioCorpo').innerHTML = '<p class="mb-2"><b>' + s.critico + ' alerta(s) crítico(s)</b>' + (s.atencao ? ' e ' + s.atencao + ' de atenção' : '') + ' exigem ação em ' + s.riscos_com_alerta + ' risco(s).</p><p class="mb-0 ajuda">Risco gerenciado é risco acompanhado: planos atrasados, revisões vencidas e riscos acima do apetite não resolvem sozinhos.</p>';
      new bootstrap.Modal(document.getElementById('mInicio')).show();
    }
    window.scrollTo(0, 0);
  }

  // ---------- ações globais ----------
  function nomeArq(s) { return String(s).replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '') || 'riscos'; }
  var Acoes = w.Acoes = {
    expXml: function (amb, id) { Mapris.baixar('valore-' + nomeArq(amb || 'riscos') + '.xml', E.riscosParaXml(E.riscosCompletos(amb, id)), 'application/xml'); },
    expJson: function () { Mapris.baixar('valore-backup-' + E.hoje() + '.json', E.backupJson(), 'application/json'); },
    expBanco: function () {
      DB.flush().then(function () {
        var u = DB.exportarBytes(), s = '', n = 0x8000; for (var i = 0; i < u.length; i += n) s += String.fromCharCode.apply(null, u.subarray(i, i + n));
        var b64 = btoa(s);
        if (w.__maprisHost && w.__maprisHost.invocar) w.__maprisHost.invocar('salvar', JSON.stringify({ nome: 'valore-' + E.hoje() + '.sqlite', b64: b64 }));
        else { var a = document.createElement('a'); a.href = 'data:application/x-sqlite3;base64,' + b64; a.download = 'valore-' + E.hoje() + '.sqlite'; document.body.appendChild(a); a.click(); a.remove(); }
      });
    },
    importar: function (f) {
      new Promise(function (res, rej) { var fr = new FileReader(); fr.onload = function () { res(String(fr.result)); }; fr.onerror = function () { rej(new Error('Arquivo inválido')); }; fr.readAsText(f); }).then(function (txt) {
        var pk = Pacote.importarTexto(txt, 'mesclar');
        if (pk) { alert('Importação concluída (mesclar).\n' + Pacote.resumo(pk)); Nav.ir('#/'); rota(); return; }
        var xml = /\.xml$/i.test(f.name) || txt.trimStart().charAt(0) === '<', lista = null, cens = null;
        if (xml) { lista = E.riscosDeXml(txt); }
        else {
          var j = JSON.parse(txt);
          if (j.formato === 'mapris-backup') { lista = Array.isArray(j.riscos) ? j.riscos : []; }
          else if (j.formato === 'mapris-riscos') lista = Array.isArray(j.riscos) ? j.riscos : [];
          else throw new Error('Arquivo não reconhecido (esperado backup ou exportação do Valor-E).');
        }
        var msg = [], av = [];
        if (lista && lista.length) { var r = E.importarLista(lista); msg.push(r.importados + ' risco(s) novo(s) e ' + (r.atualizados || 0) + ' atualizado(s).'); av = av.concat(r.erros); }
        alert(msg.join('\n') + (av.length ? '\n\nAvisos:\n' + av.join('\n') : ''));
        Nav.ir('#/riscos'); rota();
        return;
      }).catch(function (e) { alert(e && e.message && !/JSON/.test(e.message) ? e.message : 'Arquivo inválido'); });
    },
    dup: function (id) { Mapris.api('duplicar', { id: id }).then(function (r) { if (r.ok) rota(); else alert(r.erro); }); },
    del: function (id, nome) { if (!confirm('Excluir o risco "' + nome + '"? Esta ação não pode ser desfeita.')) return; Mapris.api('excluir', { id: id }).then(function (r) { if (r.ok) rota(); else alert(r.erro); }); },
    concluir: function (id) { Mapris.api('plano_status', { plano: id, status: 'Concluído' }).then(function (r) { if (r.ok) rota(); else alert(r.erro); }); },
    reprogramar: function (id) {
      var v = prompt('Novo prazo (dd/mm/aaaa):'); if (v === null) return;
      var iso = Mapris.brToIso(v); if (!iso) { alert('Data inválida. Use dd/mm/aaaa.'); return; }
      Mapris.api('plano_prazo', { plano: id, prazo: iso }).then(function (r) { if (r.ok) rota(); else alert(r.erro); });
    },
    revisar: function (id, nome) { Mapris.revisar(id, nome, function () { rota(); }); },
    planoMudar: function (id, el) { Mapris.api('plano_status', { plano: id, status: el.value }).then(function (r) { if (!r.ok) alert(r.erro); else el.style.background = '#eceff1'; }); },
    gravarConfig: function () {
      var d = {}; ['apetite', 'antecedencia', 'monit_dias', 'rev_Extremo', 'rev_Alto', 'rev_Médio', 'rev_Baixo', 'rev_Muito Baixo'].forEach(function (k) { var e = document.getElementById('c_' + k); if (e) d[k] = e.value; });
      Mapris.api('config_salvar', d).then(function (r) { document.getElementById('msg').textContent = r.ok ? 'Parâmetros salvos. Os alertas já refletem a nova configuração.' : (r.erro || 'Erro'); });
    }
  };

  // ---------- telas ----------
  var ICO_SEV = { critico: 'bi-exclamation-octagon-fill', atencao: 'bi-exclamation-triangle-fill', aviso: 'bi-info-circle-fill' };
  var CL = { 'Extremo': 'e', 'Alto': 'a', 'Médio': 'm', 'Baixo': 'b', 'Muito Baixo': 'mb' };

  function telaPainel(q) {
    var amb = (q.ambiente || '').trim(), P = E.painelDados(amb), AL = E.alertasTodos(amb), AC = E.alertasContagem(AL), apet = E.config().apetite, acima = 0;
    (amb ? DB.all('SELECT nivel_res, nivel_medio FROM riscos WHERE ambiente = ?', [amb]) : DB.all('SELECT nivel_res, nivel_medio FROM riscos')).forEach(function (x) { var n = x.nivel_res || x.nivel_medio; if (n && E.nivelOrdem(n) > E.nivelOrdem(apet)) acima++; });
    var rv = {}; AL.forEach(function (a) { if (a.cod === 'REVISAO_VENCIDA') rv[a.risco_id] = 1; }); var revV = Object.keys(rv).length;
    var c = '<div class="pagina"><form class="filtros"><div><label>Ambiente de análise</label><select name="ambiente" class="form-select" onchange="Nav.f(this.form)">' + ambOpts(amb, 'Todos os ambientes') + '</select></div></form>';
    if (P.total === 0) {
      c += '<div class="cartao"><div class="vazio"><div style="width:64px;margin:0 auto 8px">' + logoSvg() + '</div><h4 style="color:var(--verde-esc)">Bem-vindo ao Valor-E</h4><p class="mb-3">Nenhum risco cadastrado' + (amb ? ' neste ambiente' : '') + ' ainda.<br>Informe o ambiente de análise (processo, projeto ou qualquer outro), descreva o evento de risco, as causas e os controles.<br>A partir daí o Valor-E acompanha prazos, revisões e o apetite ao risco, e cobra você quando algo sair do trilho.</p><a class="btn btn-success" href="#/risco' + qs({ ambiente: amb }) + '"><i class="bi bi-plus-lg"></i> Cadastrar o primeiro risco</a></div></div>';
      return c + '</div>';
    }
    var top = AL.filter(function (a) { return a.sev !== 'aviso'; }).slice(0, 5);
    c += '<div class="cartao mb-3 ' + (AC.critico ? 'central-crit' : '') + '"><h2><i class="bi bi-bell-fill"></i> Central de atenção <span class="sp"></span><a class="btn btn-sm btn-outline-success" href="#/alertas' + qs({ ambiente: amb }) + '">Ver todos (' + (AC.critico + AC.atencao + AC.aviso) + ')</a></h2><div class="corpo">';
    if (!top.length) c += '<div class="ok-alerta"><i class="bi bi-shield-check"></i> Nenhum alerta crítico ou de atenção. Continue revisando e monitorando.</div>';
    else {
      c += '<div class="mb-2"><b>' + AC.critico + '</b> crítico(s) · <b>' + AC.atencao + '</b> de atenção · <b>' + AC.aviso + '</b> aviso(s) — em <b>' + AC.riscos_com_alerta + '</b> risco(s). Isto exige uma decisão sua hoje:</div><div class="lista-alertas">';
      top.forEach(function (a) { c += '<a class="alerta ' + a.sev + ' comp" href="#/risco?id=' + a.risco_id + '"><div class="ic"><i class="bi ' + ICO_SEV[a.sev] + '"></i></div><div class="tx"><div class="ti">' + h(a.titulo) + '</div><div class="ri">' + h(a.risco) + ' · ' + h(a.ambiente) + '</div></div></a>'; });
      c += '</div>';
    }
    c += '</div></div><div class="kpi"><div class="k"><div class="v">' + P.total + '</div><div class="t">Riscos</div></div>' +
      '<div class="k ' + (acima ? 'e' : 'b') + '"><div class="v">' + acima + '</div><div class="t">Acima do apetite (' + h(apet) + ')</div></div>' +
      '<div class="k ' + (revV ? 'a' : 'b') + '"><div class="v">' + revV + '</div><div class="t">Revisões vencidas</div></div>';
    NIVEIS.slice().reverse().forEach(function (n) { c += '<div class="k ' + CL[n] + '"><div class="v">' + P.niveis[n] + '</div><div class="t">' + n + '</div></div>'; });
    c += '<div class="k"><div class="v">' + (P.planos.total - P.planos.conc) + '</div><div class="t">Planos em aberto</div></div><div class="k ' + (P.planos.atrasados ? 'e' : '') + '"><div class="v">' + P.planos.atrasados + '</div><div class="t">Planos atrasados</div></div></div>';
    c += '<div class="grade g2"><div class="cartao"><h2><i class="bi bi-grid-3x3-gap"></i> Matriz de risco inerente</h2><div class="corpo">' + heat(P.matriz_inerente) + '</div></div><div class="cartao"><h2><i class="bi bi-shield-check"></i> Matriz de risco residual <span class="ajuda">(após controles)</span></h2><div class="corpo">' + heat(P.matriz_residual) + '</div></div></div>';
    var mx = Math.max(1, P.total);
    c += '<div class="grade g2 mt-3"><div class="cartao"><h2><i class="bi bi-bar-chart"></i> Riscos por nível — inerente × residual</h2><div class="corpo">';
    NIVEIS.slice().reverse().forEach(function (n) {
      c += '<div class="barra"><div class="r">' + nvBadge(n) + '</div><div class="b" title="Inerente: ' + P.niveis[n] + '"><span style="width:' + (100 * P.niveis[n] / mx) + '%;background:' + E.COR_NIVEL[n] + '"></span></div><div class="n">' + P.niveis[n] + '</div></div>' +
        '<div class="barra"><div class="r ajuda">&nbsp;&nbsp;residual</div><div class="b" title="Residual: ' + P.niveis_res[n] + '"><span style="width:' + (100 * P.niveis_res[n] / mx) + '%;background:' + E.COR_NIVEL[n] + ';opacity:.55"></span></div><div class="n">' + P.niveis_res[n] + '</div></div>';
    });
    c += '</div></div><div class="cartao"><h2><i class="bi bi-diagram-2"></i> Por categoria e por ambiente</h2><div class="corpo"><div class="lbl">Categorias</div>';
    P.categorias.slice(0, 8).forEach(function (x) { c += '<div class="barra"><div class="r" title="' + h(x[0]) + '">' + h(x[0]) + '</div><div class="b"><span style="width:' + (100 * x[1] / P.total) + '%"></span></div><div class="n">' + x[1] + '</div></div>'; });
    if (!amb && P.ambientes.length) {
      c += '<div class="lbl mt-3">Ambientes de análise</div>';
      P.ambientes.slice(0, 8).forEach(function (x) { c += '<div class="barra"><div class="r" title="' + h(x[0]) + '"><a href="#/' + qs({ ambiente: x[0] }) + '" class="text-decoration-none">' + h(x[0]) + '</a></div><div class="b"><span style="width:' + (100 * x[1] / P.total) + '%"></span></div><div class="n">' + x[1] + '</div></div>'; });
    }
    c += '</div></div></div><div class="grade g2 mt-3"><div class="cartao"><h2><i class="bi bi-fire"></i> Riscos mais críticos</h2><table class="tabela"><thead><tr><th>Risco</th><th>Ambiente</th><th>Inerente</th><th>Residual</th></tr></thead><tbody>';
    P.top.forEach(function (r) { c += '<tr><td><a class="text-decoration-none fw-semibold" href="#/risco?id=' + r.id + '">' + h(r.nome) + '</a></td><td class="ajuda">' + h(r.ambiente) + '</td><td>' + nvBadge(r.nivel_medio) + '</td><td>' + nvBadge(r.nivel_res) + '</td></tr>'; });
    c += '</tbody></table></div><div class="cartao"><h2><i class="bi bi-list-check"></i> Próximos planos de ação</h2>';
    if (!P.planos_proximos.length) c += '<div class="vazio" style="padding:26px">Nenhum plano em aberto.</div>';
    else {
      c += '<table class="tabela"><thead><tr><th>Plano</th><th>Risco</th><th>Prazo</th><th>Status</th></tr></thead><tbody>';
      P.planos_proximos.forEach(function (p) { var atr = p.prazo && p.prazo < E.hoje(); c += '<tr><td>' + h(trunc(p.descricao, 60)) + '</td><td class="ajuda"><a href="#/risco?id=' + p.risco_id + '">' + h(trunc(p.risco_nome, 36)) + '</a></td><td class="' + (atr ? 'text-danger fw-semibold' : '') + '">' + (p.prazo ? h(E.dataBr(p.prazo)) : '—') + '</td><td>' + h(p.status) + '</td></tr>'; });
      c += '</tbody></table>';
    }
    return c + '</div></div></div>';
  }

  function telaRiscos(q) {
    var f = { ambiente: (q.ambiente || '').trim(), nivel: q.nivel || '', status: q.status || '', categoria: q.categoria || '', processo: q.processo || '', cadeia: q.cadeia || '', q: (q.q || '').trim() };
    var lista = E.riscosListar(f), mapa = {}, hoje = E.hoje();
    E.alertasTodos(f.ambiente).forEach(function (a) { (mapa[a.risco_id] = mapa[a.risco_id] || {})[a.sev] = ((mapa[a.risco_id] || {})[a.sev] || 0) + 1; });
    var c = '<div class="pagina"><form class="filtros"><div><label>Buscar</label><input class="form-control" name="q" value="' + h(f.q) + '" placeholder="evento, descrição, responsável…"></div>' +
      '<div><label>Ambiente de análise</label><select class="form-select" name="ambiente">' + ambOpts(f.ambiente, 'Todos').replace(/ \(\d+\)</g, '<') + '</select></div>' +
      (w.Cva && Cva.cadeias && Cva.cadeias().length > 1 ? '<div><label>Cadeia de valor</label><select class="form-select" name="cadeia"><option value="">Todas</option>' + Cva.cadeias().map(function (x) { return '<option value="' + h(x) + '"' + (f.cadeia === x ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select></div>' : '') +
      '<div><label>Nível inerente</label><select class="form-select" name="nivel">' + opts(NIVEIS.slice().reverse(), f.nivel, 'Todos') + '</select></div>' +
      '<div><label>Categoria</label><select class="form-select" name="categoria">' + opts(E.CATEGORIAS, f.categoria, 'Todas') + '</select></div>' +
      '<div><label>Status</label><select class="form-select" name="status">' + opts(E.STATUS_RISCO, f.status, 'Todos') + '</select></div>' +
      '<div><button class="btn btn-success btn-sm"><i class="bi bi-funnel"></i> Filtrar</button> <a class="btn btn-outline-secondary btn-sm" href="#/riscos">Limpar</a></div>' +
      '<div class="ms-auto"><a class="btn btn-success btn-sm" href="#/risco"><i class="bi bi-plus-lg"></i> Novo risco</a></div>' +
      (f.ambiente ? '<div><button type="button" class="btn btn-outline-secondary btn-sm" onclick="Acoes.expXml(' + h(JSON.stringify(f.ambiente)) + ',0)"><i class="bi bi-filetype-xml"></i> Exportar este ambiente (.xml)</button></div>' : '') + '</form><div class="cartao">';
    if (!lista.length) c += '<div class="vazio"><i class="bi bi-shield-exclamation" style="font-size:42px"></i><p class="mt-2 mb-3">Nenhum risco encontrado.</p><a class="btn btn-success" href="#/risco"><i class="bi bi-plus-lg"></i> Novo risco</a></div>';
    else {
      c += '<table class="tabela"><thead><tr><th>Código</th><th>Análise do ambiente</th><th>Atividade (bandeira)</th><th>Evento de risco</th><th>Categoria</th><th class="text-center">Causas</th><th>Inerente</th><th>Residual</th><th>Status</th><th>Próx. revisão</th><th>Alertas</th><th class="text-center">Planos</th><th class="text-end">Ações</th></tr></thead><tbody>';
      lista.forEach(function (r) {
        var m = mapa[r.id] || {}, al;
        if (!m.critico && !m.atencao && !m.aviso) al = '<span class="ok-alerta"><i class="bi bi-check-circle"></i></span>';
        else al = (m.critico ? '<span class="selo crit" title="Críticos">' + m.critico + '</span>' : '') + (m.atencao ? '<span class="selo atn" title="Atenção">' + m.atencao + '</span>' : '') + (m.aviso ? '<span class="selo" style="background:#fbc02d;color:#4a3b00" title="Avisos">' + m.aviso + '</span>' : '');
        c += '<tr><td><b>' + h(r.codigo || '') + '</b></td><td>' + (r.projeto_id
          ? '<a class="text-decoration-none" href="#/projeto?id=' + r.projeto_id + '">' + h(r.projeto_nome || ('Projeto #' + r.projeto_id)) + '</a>'
          : (r.processo_id
            ? '<a class="text-decoration-none" href="#/diagrama?id=' + r.processo_id + '"><i class="bi bi-diagram-3"></i> ' + h(r.ambiente) + '</a>'
            : (r.ambiente ? h(r.ambiente) : '<span class="ajuda">—</span>'))) + '</td><td>' + (r.flag_id ? '<a class="text-decoration-none" href="#/diagrama?id=' + r.processo_id + '&flag=' + r.flag_id + '" title="Ver no mapa"><i class="bi bi-flag-fill flag-nv ' + (r.nivel_medio ? h(String(r.nivel_medio).replace(/ /g, '-')) : 'nd') + '" title="Risco inerente: ' + h(r.nivel_medio || 'não avaliado') + '"></i> ' + h(r.tarefa || '') + '</a>' : '<span class="ajuda">—</span>') + '</td><td><a class="fw-semibold text-decoration-none" href="#/risco?id=' + r.id + '">' + h(r.nome) + '</a>' + '</td><td>' + h(r.categoria) + '</td><td class="text-center">' + r.n_fatores + '</td>' +
          '<td>' + nvBadge(r.nivel_medio) + '</td><td>' + nvBadge(r.nivel_res) + '</td><td>' + h(r.status) + '</td>' +
          '<td class="' + (r.proxima_revisao && r.proxima_revisao < hoje ? 'text-danger fw-semibold' : '') + '">' + (r.proxima_revisao ? h(E.dataBr(r.proxima_revisao)) : '—') + '</td><td>' + al + '</td><td class="text-center">' + (r.n_planos_abertos || '—') + '</td>' +
          '<td class="acoes-col"><div class="acoes"><a class="btn btn-sm btn-success" href="#/risco?id=' + r.id + '" title="Editar"><i class="bi bi-pencil-square"></i></a>' +
          '<button class="btn btn-sm btn-outline-secondary" title="Exportar este risco (.xml)" onclick="Acoes.expXml(\'\',' + r.id + ')"><i class="bi bi-box-arrow-up"></i></button>' +
          '<button class="btn btn-sm btn-outline-secondary" title="Duplicar" onclick="Acoes.dup(' + r.id + ')"><i class="bi bi-files"></i></button>' +
          '<button class="btn btn-sm btn-outline-danger" title="Excluir" onclick="Acoes.del(' + r.id + ',' + h(JSON.stringify(r.nome)) + ')"><i class="bi bi-trash"></i></button></div></td></tr>';
      });
      c += '</tbody></table>';
    }
    return c + '</div></div>';
  }

  function telaAlertas(q) {
    var amb = (q.ambiente || '').trim(), sev = q.sev || '', todos = E.alertasTodos(amb), C = E.alertasContagem(todos);
    var nR = (amb ? DB.one('SELECT COUNT(*) n FROM riscos WHERE ambiente = ?', [amb]) : DB.one('SELECT COUNT(*) n FROM riscos')).n;
    var emDia = nR > 0 ? Math.round(100 * (nR - C.riscos_com_alerta) / nR) : 100;
    var lista = sev ? todos.filter(function (a) { return a.sev === sev; }) : todos;
    function kl(k, cls, t) { return '<a class="k ' + cls + ' kl ' + (sev === k ? 'sel' : '') + '" href="#/alertas' + qs({ ambiente: amb, sev: sev === k ? '' : k }) + '"><div class="v">' + C[k] + '</div><div class="t">' + t + '</div></a>'; }
    var c = '<div class="pagina"><form class="filtros"><div><label>Ambiente de análise</label><select class="form-select" name="ambiente" onchange="Nav.f(this.form)">' + ambOpts(amb, 'Todos os ambientes').replace(/ \(\d+\)</g, '<') + '</select></div><input type="hidden" name="sev" value="' + h(sev) + '"></form>' +
      '<div class="kpi">' + kl('critico', 'e', 'Críticos') + kl('atencao', 'a', 'Atenção') + kl('aviso', 'm', 'Avisos') + '<div class="k ' + (emDia >= 80 ? 'b' : emDia >= 50 ? 'm' : 'e') + '"><div class="v">' + emDia + '%</div><div class="t">Riscos em dia (sem crítico/atenção)</div></div></div>';
    if (!lista.length) c += '<div class="cartao"><div class="vazio"><i class="bi bi-shield-check" style="font-size:46px;color:var(--n-b)"></i><h5 class="mt-2" style="color:var(--verde-esc)">' + (nR ? 'Tudo em ordem por ora.' : 'Nenhum risco cadastrado.') + '</h5><p class="mb-0">' + (nR ? 'Nenhum alerta nesta seleção. O Valor-E continua vigiando prazos, revisões e o apetite ao risco.' : 'Cadastre o primeiro risco para o Valor-E começar a acompanhá-lo.') + '</p></div></div>';
    else {
      c += '<div class="lista-alertas">';
      lista.forEach(function (a) {
        c += '<div class="alerta ' + a.sev + '"><div class="ic"><i class="bi ' + ICO_SEV[a.sev] + '"></i></div><div class="tx"><div class="ti">' + h(a.titulo) + '</div><div class="pv">' + h(a.prov) + '</div><div class="ri"><a href="#/risco?id=' + a.risco_id + '">' + h(a.risco) + '</a> · ' + h(a.ambiente) + ' ' + (a.nivel ? nvBadge(a.nivel) : '') + '</div></div><div class="ac">' +
          (a.acao === 'revisar' ? '<button class="btn btn-sm btn-success" onclick="Acoes.revisar(' + a.risco_id + ',' + h(JSON.stringify(a.risco)) + ')"><i class="bi bi-clipboard-check"></i> Registrar revisão</button>' : '') +
          (a.acao === 'plano' ? '<button class="btn btn-sm btn-success" onclick="Acoes.concluir(' + a.plano_id + ')"><i class="bi bi-check2-circle"></i> Concluir</button><button class="btn btn-sm btn-outline-secondary" onclick="Acoes.reprogramar(' + a.plano_id + ')"><i class="bi bi-calendar-event"></i> Novo prazo</button>' : '') +
          '<a class="btn btn-sm btn-outline-secondary" href="#/risco?id=' + a.risco_id + '"><i class="bi bi-box-arrow-up-right"></i> Abrir</a></div></div>';
      });
      c += '</div>';
    }
    return c + '</div>';
  }

  function telaPlanos(q) {
    var st = q.status || 'abertos', amb = (q.amb || q.ambiente || '').trim(), wh = [], p = [];
    if (st === 'abertos') wh.push("p.status NOT IN ('Concluído','Cancelado')");
    else if (st === 'atrasados') { wh.push("p.status NOT IN ('Concluído','Cancelado') AND p.prazo IS NOT NULL AND p.prazo < ?"); p.push(E.hoje()); }
    else if (st !== 'todos') { wh.push('p.status = ?'); p.push(st); }
    if (amb) { wh.push('r.ambiente = ?'); p.push(amb); }
    var lista = DB.all('SELECT p.*, r.nome AS risco_nome, r.ambiente FROM planos p JOIN riscos r ON r.id = p.risco_id' + (wh.length ? ' WHERE ' + wh.join(' AND ') : '') + ' ORDER BY CASE WHEN p.prazo IS NULL THEN 1 ELSE 0 END, p.prazo, p.id', p);
    var sts = { abertos: 'Em aberto', atrasados: 'Atrasados', Pendente: 'Pendentes', 'Em Andamento': 'Em andamento', 'Concluído': 'Concluídos', Cancelado: 'Cancelados', todos: 'Todos' };
    var c = '<div class="pagina"><form class="filtros"><div><label>Situação</label><select class="form-select" name="status" onchange="Nav.f(this.form)">' + Object.keys(sts).map(function (k) { return '<option value="' + k + '"' + (st === k ? ' selected' : '') + '>' + sts[k] + '</option>'; }).join('') + '</select></div>' +
      '<div><label>Ambiente de análise</label><select class="form-select" name="ambiente" onchange="Nav.f(this.form)">' + ambOpts(amb, 'Todos').replace(/ \(\d+\)</g, '<') + '</select></div></form><div class="cartao">';
    if (!lista.length) c += '<div class="vazio">Nenhum plano de ação nesta seleção.<br><span class="ajuda">Os planos são cadastrados dentro de cada controle, no formulário do risco.</span></div>';
    else {
      c += '<table class="tabela"><thead><tr><th>Plano de ação</th><th>Risco / ambiente</th><th>Controle</th><th>Responsável</th><th>Prazo</th><th>Prioridade</th><th>Situação</th></tr></thead><tbody>';
      lista.forEach(function (x) {
        var atr = x.prazo && x.prazo < E.hoje() && ['Concluído', 'Cancelado'].indexOf(x.status) < 0;
        c += '<tr><td>' + h(x.descricao) + '</td><td><a class="text-decoration-none fw-semibold" href="#/risco?id=' + x.risco_id + '">' + h(x.risco_nome) + '</a><div class="ajuda">' + h(x.ambiente) + '</div></td><td class="ajuda">' + h(trunc(x.controle_desc, 50)) + '</td><td>' + h(x.responsavel) + '</td>' +
          '<td class="' + (atr ? 'text-danger fw-semibold' : '') + '">' + (x.prazo ? h(E.dataBr(x.prazo)) : '—') + (atr ? ' <i class="bi bi-exclamation-circle"></i>' : '') + '</td><td>' + h(x.prioridade) + '</td>' +
          '<td><select class="form-select form-select-sm" style="min-width:140px" onchange="Acoes.planoMudar(' + x.id + ',this)">' + opts(['Pendente', 'Em Andamento', 'Concluído', 'Cancelado'], x.status) + '</select></td></tr>';
      });
      c += '</tbody></table>';
    }
    return c + '</div></div>';
  }

  function telaDados() { return '<div class="pagina">' + Pacote.cartao() + '</div>'; }
  function telaConfig() {
    var cf = E.config();
    var c = '<div class="pagina"><div class="cartao mb-3"><h2><i class="bi bi-sliders"></i> Apetite ao risco e ciclo de revisão</h2><div class="corpo"><p class="ajuda">Estes parâmetros alimentam os alertas. O <b>apetite</b> é o nível máximo de risco residual que a organização aceita sem tratamento adicional (ABNT NBR ISO 31000 — critérios de risco).</p><div class="row g-3">' +
      '<div class="col-md-4 campo"><label>Apetite ao risco (nível máximo tolerado)</label><select class="form-select" id="c_apetite">' + opts(NIVEIS, cf.apetite) + '</select></div>' +
      '<div class="col-md-4 campo"><label>Avisar prazos com antecedência de (dias)</label><input type="number" min="1" class="form-control" id="c_antecedencia" value="' + cf.antecedencia + '"></div>' +
      '<div class="col-md-4 campo"><label>Controle implementado sem monitoramento há mais de (dias)</label><input type="number" min="1" class="form-control" id="c_monit_dias" value="' + cf.monit_dias + '"></div></div>' +
      '<h6 class="mt-4" style="color:var(--verde-esc)">Periodicidade de revisão por nível de risco (dias)</h6><div class="row g-3">';
    NIVEIS.slice().reverse().forEach(function (n) { c += '<div class="col campo"><label>' + nvBadge(n) + '</label><input type="number" min="1" class="form-control" id="c_rev_' + h(n) + '" value="' + cf['rev_' + n] + '"></div>'; });
    return c + '</div><div class="mt-4 d-flex gap-2 align-items-center"><button class="btn btn-success" onclick="Acoes.gravarConfig()"><i class="bi bi-save"></i> Salvar parâmetros</button><span class="ajuda" id="msg"></span></div></div></div></div>';
  }

  function telaMetodo() {
    var cf = E.config();
    var et = [['Estabelecimento do contexto', 'bi-bullseye', 'Defina o <b>ambiente de análise</b> (processo, projeto, unidade ou qualquer outro), os objetivos afetados, as partes interessadas e os critérios de risco (apetite).'],
      ['Identificação', 'bi-search', 'Descreva o <b>evento de risco</b>, suas <b>causas</b> (fontes de risco) e as <b>consequências</b>.'],
      ['Análise', 'bi-calculator', 'Estime a <b>probabilidade</b> e o <b>impacto</b> de cada causa. O nível do risco é o índice P × I (escala 1–5).'],
      ['Avaliação', 'bi-rulers', 'Compare o nível com o <b>apetite ao risco</b> e decida: o risco é tolerável ou exige tratamento?'],
      ['Tratamento', 'bi-shield-check', 'Escolha a <b>resposta</b> (COSO) e implemente <b>controles</b> e <b>planos de ação</b>, avaliando o risco residual.'],
      ['Monitoramento e análise crítica', 'bi-arrow-repeat', 'Acompanhe controles, planos e indicadores; <b>revise</b> periodicamente. É aqui que o Valor-E cobra você, com alertas.'],
      ['Registro e relato', 'bi-file-earmark-text', 'Tudo fica registrado: histórico de revisões, relatório imprimível e exportação em XML.']];
    var c = '<div class="pagina" style="max-width:1100px;margin-left:auto;margin-right:auto"><div class="cartao mb-3"><h2><i class="bi bi-journal-check"></i> Processo de gestão de riscos — ABNT NBR ISO 31000</h2><div class="corpo"><p class="ajuda">Comunicação e consulta e monitoramento e análise crítica acontecem durante todo o ciclo.</p><div class="etapas">';
    et.forEach(function (e, i) { c += '<div class="etapa"><div class="n">' + (i + 1) + '</div><div><div class="t"><i class="bi ' + e[1] + '"></i> ' + e[0] + '</div><div class="d">' + e[2] + '</div></div></div>'; });
    c += '</div></div></div><div class="grade g2"><div class="cartao"><h2><i class="bi bi-shield-shaded"></i> Tipos de controle</h2><div class="corpo">';
    Object.keys(E.TIPOS_CONTROLE_DESC).forEach(function (t) { c += '<p><b>' + t + 's</b> — ' + h(E.TIPOS_CONTROLE_DESC[t]) + '</p>'; });
    c += '<div class="ajuda">O <b>residual estimado</b> considera os controles preventivos e detectivos; o <b>residual definitivo</b>, os corretivos.</div></div></div><div class="cartao"><h2><i class="bi bi-signpost-split"></i> Respostas ao risco (COSO ERM)</h2><div class="corpo">';
    Object.keys(E.RESPOSTAS_DESC).forEach(function (t) { c += '<p><b>' + t + '</b> — ' + h(E.RESPOSTAS_DESC[t]) + '</p>'; });
    c += '</div></div></div><div class="grade g2 mt-3"><div class="cartao"><h2><i class="bi bi-grid-3x3-gap"></i> Níveis de risco</h2><div class="corpo"><p class="mb-2">Índice = probabilidade (1–5) × impacto (1–5).</p><table class="mini"><tr><th>Nível</th><th>Índice</th></tr>' +
      '<tr><td>' + nvBadge('Extremo') + '</td><td>20 a 25</td></tr><tr><td>' + nvBadge('Alto') + '</td><td>12 a 19</td></tr><tr><td>' + nvBadge('Médio') + '</td><td>6 a 11</td></tr><tr><td>' + nvBadge('Baixo') + '</td><td>2 a 5</td></tr><tr><td>' + nvBadge('Muito Baixo') + '</td><td>1</td></tr></table>' +
      '<p class="mt-2 mb-0 ajuda">Apetite atual: <b>' + h(cf.apetite) + '</b> — riscos acima desse nível geram alertas. <a href="#/config">Alterar</a></p></div></div>' +
      '<div class="cartao"><h2><i class="bi bi-bell"></i> O que o Valor-E vigia por você</h2><div class="corpo"><ul class="mb-0"><li>Riscos acima do apetite, sem resposta ou sem nenhum controle</li><li>Aceitação de risco sem justificativa, sem aprovação ou vencida</li><li>Revisões (análises críticas) vencidas ou próximas</li><li>Planos de ação atrasados, sem prazo ou sem responsável</li><li>Controles com implantação atrasada ou nunca verificados</li><li>Controles que não reduzem o risco; ausência de controle preventivo ou corretivo</li><li>Riscos sem proprietário ou parados nas etapas iniciais</li><li>Riscos de projeto abertos em projetos já concluídos ou cancelados</li></ul></div></div></div></div>';
    return c;
  }

  function telaRelatorio(q) {
    var amb = (q.ambiente || '').trim(), riscos = E.riscosListar(amb ? { ambiente: amb } : {}).map(function (r) { return E.riscoCarregar(r.id); }).filter(Boolean);
    var P = E.painelDados(amb), AL = E.alertasTodos(amb), AC = E.alertasContagem(AL), apet = E.config().apetite;
    var agora = new Date(), p2 = function (n) { return (n < 10 ? '0' : '') + n; };
    var c = '<div class="pagina"><form class="filtros no-print"><div><label>Ambiente de análise</label><select class="form-select" name="ambiente" onchange="Nav.f(this.form)">' + ambOpts(amb, 'Todos os ambientes').replace(/ \(\d+\)</g, '<') + '</select></div><div><button type="button" class="btn btn-success btn-sm" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir / salvar em PDF</button></div></form>' +
      '<div class="rel"><div class="d-flex align-items-center gap-3"><div style="width:52px">' + logoSvg() + '</div><div><h1>Relatório de gestão de riscos</h1><div class="ajuda">Ambiente de análise: <b>' + (amb ? h(amb) : 'todos os ambientes') + '</b> · Emitido em ' + p2(agora.getDate()) + '/' + p2(agora.getMonth() + 1) + '/' + agora.getFullYear() + ' ' + p2(agora.getHours()) + ':' + p2(agora.getMinutes()) + ' · Apetite ao risco: <b>' + h(apet) + '</b> · Metodologia: ABNT NBR ISO 31000 e COSO ERM · ' + APP_NOME + ' ' + APP_VERSAO + '</div></div></div>';
    if (!riscos.length) return c + '<p class="mt-4 ajuda">Nenhum risco cadastrado para esta seleção.</p></div></div>';
    c += '<h2>1. Resumo</h2><table class="mini"><thead><tr><th>Total de riscos</th>' + NIVEIS.slice().reverse().map(function (n) { return '<th>' + n + '</th>'; }).join('') + '<th>Planos em aberto</th><th>Planos atrasados</th><th>Alertas críticos</th></tr></thead><tbody><tr><td><b>' + P.total + '</b></td>' + NIVEIS.slice().reverse().map(function (n) { return '<td>' + P.niveis[n] + '</td>'; }).join('') + '<td>' + (P.planos.total - P.planos.conc) + '</td><td>' + P.planos.atrasados + '</td><td>' + AC.critico + '</td></tr></tbody></table>' +
      '<div class="row g-3 mt-1"><div class="col-6"><div class="lbl">Matriz inerente</div>' + heat(P.matriz_inerente) + '</div><div class="col-6"><div class="lbl">Matriz residual</div>' + heat(P.matriz_residual) + '</div></div>' +
      '<h2>2. Quadro de riscos</h2><table class="mini"><thead><tr><th>#</th><th>Ambiente</th><th>Evento de risco</th><th>Categoria</th><th>Inerente</th><th>Residual</th><th>Resposta</th><th>Status</th></tr></thead><tbody>';
    riscos.forEach(function (r, i) { c += '<tr><td>' + (i + 1) + '</td><td>' + h(r.ambiente) + '</td><td>' + h(r.nome) + '</td><td>' + h(r.categoria) + '</td><td>' + nvBadge(r.nivel_medio) + '</td><td>' + nvBadge(r.nivel_res) + ' ' + (r.indice_res == null ? '' : r.indice_res) + '</td><td>' + h(r.resposta) + '</td><td>' + h(r.status) + '</td></tr>'; });
    c += '</tbody></table><h2>3. Detalhamento</h2>';
    riscos.forEach(function (r, i) {
      c += '<div class="risco-bloco"><div class="h"><span>#' + (i + 1) + '</span><span class="flex-grow-1">' + h(r.nome) + '</span>' + nvBadge(r.nivel_medio) + '<span class="ajuda">→</span>' + nvBadge(r.nivel_res) + '</div><div class="c">' +
        '<div class="ajuda mb-1">Ambiente: <b>' + h(r.ambiente) + '</b> · Categoria: ' + h(r.categoria || '—') + ' · Proprietário: ' + h(r.responsavel || '—') + ' · Etapa: ' + h(r.status) + ' · Resposta (COSO): ' + h(r.resposta || '—') + ' · Última revisão: ' + dBr(r.ultima_revisao) + ' · Próxima: ' + dBr(r.proxima_revisao) + '</div>' +
        (r.objetivo ? '<div><b>Objetivo afetado:</b> ' + h(r.objetivo) + '</div>' : '') + (r.partes ? '<div><b>Partes interessadas:</b> ' + h(r.partes) + '</div>' : '') +
        (r.resposta_just ? '<div><b>Justificativa da resposta:</b> ' + nl2br(r.resposta_just) + (r.aceite_por ? ' — aprovada por ' + h(r.aceite_por) + (r.aceite_validade ? ' (validade ' + dBr(r.aceite_validade) + ')' : '') : '') + '</div>' : '') +
        (r.descricao ? '<div><b>Descrição:</b> ' + nl2br(r.descricao) + '</div>' : '') + (r.consequencias ? '<div><b>Consequências:</b> ' + nl2br(r.consequencias) + '</div>' : '');
      if (r.fatores.length) {
        c += '<table class="mini"><thead><tr><th>Causa</th><th>P</th><th>I</th><th>Inerente</th><th>Controles</th><th>Residual</th></tr></thead><tbody>';
        var pl = [], mo = [];
        r.fatores.forEach(function (f) {
          c += '<tr><td>' + h(f.nome) + '</td><td>' + f.probabilidade + '</td><td>' + f.impacto + '</td><td>' + nvBadge(f.nivel) + ' ' + f.indice + '</td><td>' +
            (f.controles.length ? f.controles.map(function (k) { return '<div>• <b>' + h(k.tipo_controle) + '</b> (' + h(k.status) + ', eficácia ' + Math.round(k.eficacia) + '%): ' + h(k.descricao) + '</div>'; }).join('') : '—') + '</td><td>' + (f.nivel_res ? nvBadge(f.nivel_res) + ' ' + f.indice_res : '—') + '</td></tr>';
          f.controles.forEach(function (k) { k.planos.forEach(function (x) { pl.push([k, x]); }); k.monitoramentos.forEach(function (x) { mo.push([k, x]); }); });
        });
        c += '</tbody></table>';
        if (pl.length) c += '<div class="lbl mt-2">Planos de ação</div><table class="mini"><thead><tr><th>Ação</th><th>Controle</th><th>Responsável</th><th>Prazo</th><th>Prioridade</th><th>Situação</th></tr></thead><tbody>' + pl.map(function (y) { return '<tr><td>' + h(y[1].descricao) + '</td><td>' + h(trunc(y[0].descricao, 40)) + '</td><td>' + h(y[1].responsavel) + '</td><td>' + dBr(y[1].prazo) + '</td><td>' + h(y[1].prioridade) + '</td><td>' + h(y[1].status) + '</td></tr>'; }).join('') + '</tbody></table>';
        if (mo.length) c += '<div class="lbl mt-2">Monitoramento</div><table class="mini"><thead><tr><th>Data</th><th>Controle</th><th>Ação</th><th>Resultado</th><th>Evidências</th></tr></thead><tbody>' + mo.map(function (y) { return '<tr><td>' + dBr(y[1].data) + '</td><td>' + h(trunc(y[0].descricao, 40)) + '</td><td>' + h(y[1].acao) + '</td><td>' + h(y[1].resultado) + '</td><td>' + h(y[1].evidencias) + '</td></tr>'; }).join('') + '</tbody></table>';
      }
      if (r.revisoes.length) c += '<div class="lbl mt-2">Revisões</div><table class="mini"><thead><tr><th>Data</th><th>Inerente</th><th>Residual</th><th>Parecer</th></tr></thead><tbody>' + r.revisoes.map(function (x) { return '<tr><td>' + dBr(x.data) + '</td><td>' + h(x.nivel_inerente || '—') + '</td><td>' + h(x.nivel_residual || '—') + '</td><td>' + h(x.parecer) + '</td></tr>'; }).join('') + '</tbody></table>';
      c += '</div></div>';
    });
    c += '<h2>4. Pendências e alertas</h2>';
    if (!AL.length) c += '<p class="ajuda">Nenhum alerta em aberto.</p>';
    else c += '<table class="mini"><thead><tr><th>Severidade</th><th>Risco</th><th>Alerta</th></tr></thead><tbody>' + AL.map(function (a) { return '<tr><td>' + E.SEV_ROTULO[a.sev] + '</td><td>' + h(a.risco) + '</td><td>' + h(a.titulo) + '</td></tr>'; }).join('') + '</tbody></table>';
    return c + '</div></div>';
  }

  function telaRisco(q) {
    var id = parseInt(q.id, 10) || 0, r = id > 0 ? E.riscoCarregar(id) : null;
    if (id > 0 && !r) { Nav.ir('#/riscos'); return null; }
    if (!r) r = { id: 0, processo_id: null, flag_id: null, projeto_id: null, ambiente: (q.ambiente || '').trim(), nome: '', descricao: '', consequencias: '', categoria: '', responsavel: '', status: 'Identificado', resposta: '', objetivo: '', partes: '', resposta_just: '', aceite_por: '', aceite_validade: null, ultima_revisao: null, proxima_revisao: null, revisoes: [], fatores: [] };
    var pjQ = parseInt(q.projeto, 10) || 0;
    if (!id && pjQ) { var pjN = DB.one('SELECT id, nome FROM projetos WHERE id = ?', [pjQ]); if (pjN) { r.projeto_id = pjN.id; r.ambiente = pjN.nome; } }
    // risco antigo, sem vínculo gravado: o sistema reconhece a origem pelo nome do ambiente de análise
    if (id && !r.projeto_id && !r.processo_id && (r.ambiente || '').trim()) {
      var pjM = DB.one('SELECT id FROM projetos WHERE nome = ? COLLATE NOCASE', [r.ambiente.trim()]);
      if (pjM) r.projeto_id = pjM.id;
      else { var pcM = DB.one('SELECT id FROM processos WHERE nome = ? COLLATE NOCASE', [r.ambiente.trim()]); if (pcM) r.processo_id = pcM.id; }
    }
    // risco de projeto não tem vínculo com processo/atividade: se um registro antigo tiver os dois, vale o projeto
    if (r.projeto_id) { r.processo_id = null; r.flag_id = null; }
    w.Risco = w.Risco || {};
    w.Risco.estado = { R: r, CFG: { niveis: NIVEIS, cor: E.COR_NIVEL, rotProb: E.ROT_PROB, rotImp: E.ROT_IMP, sugestoes: E.FATORES_SUGERIDOS, apetite: E.config().apetite, tiposDesc: E.TIPOS_CONTROLE_DESC, respostasDesc: E.RESPOSTAS_DESC }, ALERTAS: id ? E.alertasRisco(r) : [] };
    function o(l) { return l.map(function (v) { return '<option>' + h(v) + '</option>'; }).join(''); }
    return '<div class="pagina"><div class="d-flex align-items-center gap-2 mb-3 flex-wrap"><a class="btn btn-outline-secondary btn-sm" href="#/riscos"><i class="bi bi-arrow-left"></i> Riscos</a><h5 class="mb-0 flex-grow-1" id="tituloPag" style="color:var(--verde-esc)">' + (id ? 'Editar risco' : 'Novo risco') + '</h5><span class="ajuda" id="st">Pronto</span>' +
      '<button class="btn btn-success btn-sm" onclick="Risco.salvar(true)"><i class="bi bi-save"></i> Salvar</button><button class="btn btn-outline-secondary btn-sm" id="bDup" onclick="Risco.duplicar()" ' + (id ? '' : 'disabled') + '><i class="bi bi-files"></i> Duplicar</button><button class="btn btn-outline-danger btn-sm" id="bDel" onclick="Risco.excluir()" ' + (id ? '' : 'disabled') + '><i class="bi bi-trash"></i> Excluir</button></div>' +
      '<div class="risco-grid"><div><div class="cartao mb-3"><h2><span class="passo">1</span><i class="bi bi-bullseye"></i> Contexto e identificação do risco</h2><div class="corpo"><div class="row g-3">' +
      '<div class="col-12 vinculo-mapa"><div id="blocoOrigem"' + (r.projeto_id || r.processo_id ? ' style="display:none"' : '') + '><div class="row g-2 align-items-end"><div class="col-md-6 campo"><label><i class="bi bi-signpost-split"></i> Origem do risco</label><select class="form-select" id="f_origem"><option value="">— selecione —</option><option value="processo">Processo</option><option value="projeto">Projeto</option><option value="outro">Outro ambiente (texto livre)</option></select><div class="ajuda mt-1">Informe de onde nasce o risco: o formulário mostra só o vínculo que faz sentido.</div></div></div></div>' +
      '<div id="blocoProj"' + (r.projeto_id ? '' : ' style="display:none"') + '><div class="row g-2 align-items-end"><div class="col-md-6 campo"><label><i class="bi bi-kanban"></i> Projeto vinculado</label><select class="form-select" id="f_projeto_id"><option value="">— selecione o projeto —</option>' + DB.all('SELECT id, codigo, nome FROM projetos ORDER BY nome COLLATE NOCASE').map(function (p) { return '<option value="' + p.id + '"' + (p.id === r.projeto_id ? ' selected' : '') + '>' + h((p.codigo ? p.codigo + ' — ' : '') + p.nome) + '</option>'; }).join('') + '</select><div class="ajuda mt-1">Se o ambiente de análise é um projeto, o vínculo com processo e atividade do diagrama não se aplica.</div></div></div></div>' +
      '<div id="blocoProc"' + (r.processo_id ? '' : ' style="display:none"') + '><div class="row g-2 align-items-end mt-0"><div class="col-md-4 campo"><label><i class="bi bi-diagram-3"></i> Processo vinculado</label><select class="form-select" id="f_processo_id"><option value="">— sem processo —</option>' + E.processosListar({}).map(function (c) { return '<option value="' + c.id + '"' + (c.id === r.processo_id ? ' selected' : '') + '>' + h(c.nome) + '</option>'; }).join('') + '</select></div>' +
      '<div class="col-md-5 campo"><label><i class="bi bi-flag"></i> Atividade do diagrama (bandeira)</label><select class="form-select" id="f_flag_id"></select></div><div class="col-md-3"><a class="btn btn-outline-success w-100" id="verMapa" href="#" style="display:none"><i class="bi bi-geo-alt"></i> Abrir diagrama</a></div>' +
      '<div class="ajuda">Ao vincular a uma flag, o risco passa a aparecer no mapa do processo; renomear ou excluir vale nos dois lados. O ambiente de análise acompanha o nome do processo.</div></div></div></div>' +
      '<div class="col-md-2 campo"><label>Código</label><input class="form-control" id="f_codigo" maxlength="20" value="' + h(r.codigo || E.proximoCodigoRisco()) + '" title="Identificador do risco (R1, R2…)"></div>' +
      '<div class="col-md-4 campo"><label>Análise do ambiente *</label><input class="form-control" id="f_ambiente" list="lAmb" maxlength="500" placeholder="Ex.: Processo de Compras, Projeto Alfa, Área X…" autocomplete="off"><datalist id="lAmb">' + E.ambientesLista().map(function (a) { return '<option value="' + h(a.ambiente) + '">'; }).join('') + '</datalist><div class="ajuda mt-1">Texto livre: um processo, um projeto, uma unidade ou qualquer outro ambiente.</div></div>' +
      '<div class="col-md-6 campo"><label>Evento de risco *</label><input class="form-control" id="f_nome" maxlength="500" placeholder="O que pode acontecer?" autocomplete="off"></div>' +
      '<div class="col-md-6 campo"><label>Objetivo afetado</label><input class="form-control" id="f_objetivo" maxlength="1000" placeholder="Qual objetivo fica ameaçado se o evento ocorrer?"></div>' +
      '<div class="col-md-6 campo"><label>Partes interessadas</label><input class="form-control" id="f_partes" maxlength="1000" placeholder="Quem é afetado ou precisa ser consultado?"></div>' +
      '<div class="col-md-3 campo"><label>Categoria</label><select class="form-select" id="f_categoria"><option value=""></option>' + o(E.CATEGORIAS) + '</select></div>' +
      '<div class="col-md-3 campo"><label>Etapa / status</label><select class="form-select" id="f_status">' + o(E.STATUS_RISCO) + '</select></div>' +
      '<div class="col-md-6 campo"><label>Proprietário do risco (responsável)</label><input class="form-control" id="f_responsavel" maxlength="300" placeholder="Quem responde por este risco?"></div>' +
      '<div class="col-md-6 campo"><label>Descrição do risco</label><textarea class="form-control" id="f_descricao" rows="3"></textarea></div>' +
      '<div class="col-md-6 campo"><label>Consequências</label><textarea class="form-control" id="f_consequencias" rows="3"></textarea></div></div></div></div>' +
      '<div class="cartao mb-3"><h2><span class="passo">2</span><i class="bi bi-diagram-3"></i> Análise e controles — causas, controles e planos de ação <span class="sp"></span><button class="btn btn-success btn-sm" onclick="Risco.addFator()"><i class="bi bi-plus-lg"></i> Causa</button></h2><div class="corpo"><div class="ajuda mb-1">Cada causa tem probabilidade e impacto. Dentro dela, cadastre os controles (com a probabilidade e o impacto esperados <b>depois</b> do controle) e, em cada controle, os planos de ação e o monitoramento.</div><div class="sug" id="sug"></div><div id="fatores"></div><div class="vazio" id="semFatores" style="padding:26px">Nenhuma causa cadastrada. Use “+ Causa” ou clique numa sugestão da categoria.</div></div></div>' +
      '<div class="cartao mb-3"><h2><span class="passo">3</span><i class="bi bi-signpost-split"></i> Avaliação e resposta ao risco</h2><div class="corpo"><div class="avaliacao" id="veredito"></div><div class="row g-3 mt-1"><div class="col-md-4 campo"><label>Resposta ao risco (COSO)</label><select class="form-select" id="f_resposta">' + o(E.RESPOSTAS) + '</select></div><div class="col-md-8 campo"><div class="dica mt-3" id="dicaResposta">Escolha entre evitar, reduzir, compartilhar ou aceitar o risco.</div></div>' +
      '<div class="col-12 campo"><label>Justificativa da decisão</label><textarea class="form-control" id="f_resposta_just" rows="2" placeholder="Por que esta resposta é a adequada?"></textarea></div><div id="blocoAceite" class="col-12 row g-3 m-0 p-0" style="display:none"><div class="col-md-6 campo"><label>Aceitação aprovada por (autoridade)</label><input class="form-control" id="f_aceite_por" maxlength="300" placeholder="Quem autorizou conviver com este risco?"></div><div class="col-md-3 campo"><label>Validade da aceitação</label><div id="slotAceiteVal"></div></div></div></div></div></div>' +
      '<div class="cartao"><h2><span class="passo">4</span><i class="bi bi-arrow-repeat"></i> Monitoramento e análise crítica</h2><div class="corpo"><div class="row g-3 align-items-end"><div class="col-md-3 campo"><label>Última revisão</label><div class="form-control-plaintext fw-semibold" id="ultRev">—</div></div><div class="col-md-3 campo"><label>Próxima revisão</label><div id="slotProxRev"></div></div><div class="col-md-6"><button class="btn btn-success" onclick="Risco.revisarAgora()" id="bRev"><i class="bi bi-clipboard-check"></i> Registrar revisão agora</button></div></div><div class="mt-3" id="histRev"></div></div></div></div>' +
      '<aside><div class="cartao resumo-alertas mb-3" id="boxAlertas"><h2><i class="bi bi-bell"></i> Alertas deste risco</h2><div class="corpo" id="alertas"></div></div><div class="cartao resumo"><h2><i class="bi bi-bullseye"></i> Avaliação do risco</h2><div class="corpo" id="resumo"></div></div></aside></div></div>';
  }

  // ---------- roteador ----------
  var TELAS = { '/painelrisco': ['painelrisco', telaPainel], '/alertas': ['alertas', telaAlertas], '/riscos': ['riscos', telaRiscos], '/planos': ['planos', telaPlanos], '/relatorio': ['relatorio', telaRelatorio], '/config': ['', telaConfig], '/dados': ['', telaDados], '/metodo': ['metodo', telaMetodo], '/risco': ['riscos', telaRisco], '/folha': ['processos', function () { return FolhaHost('folha'); }], '/diagrama': ['processos', function () { return FolhaHost('diagrama'); }], '/impfolha': ['processos', function () { return FolhaHost('imprimir'); }] };
  /** Contêiner das telas do Folha (folha de dados, diagrama, impressão); o roteador as executa após montar a moldura. */
  var FOLHA_HTML_BASE = '<div class="modal fade" id="mAvisos" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title"><i class="bi bi-exclamation-triangle text-warning"></i> Pontos de atenção</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><p>O diagrama foi gerado, mas algumas coisas merecem conferência:</p><ul class="avisos" id="avLista"></ul></div><div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Voltar e corrigir</button><a class="btn btn-primary" id="avAbrir" href="#/diagrama">Abrir o diagrama</a></div></div></div></div><div id="tipo-pop"></div>';
  function FolhaHost(nome) {
    var id = parseInt(Nav.q().id, 10) || 0, c = id ? E.processoCarregar(id) : null;
    if (!c) { Nav.ir('#/processos'); return null; }
    w.__folhaTela = nome;
    return '<div id="fraiz" class="folha-host ' + (nome === 'diagrama' ? 'f-diag' : '') + '"></div>' + FOLHA_HTML_BASE;
  }
  function M_nome(id) { var c = E.processoCarregar(parseInt(id, 10) || 0); return c ? c.nome : ''; }
  /** Registro de módulos: cada módulo (cva.js, indicadores.js, valor.js…) registra suas rotas aqui.
   *  Modulos.registrar('/cva', { ativo:'cva', titulo:'CVA', html:function(q){return '<div class=pagina>…</div>';}, apos:function(q){…} }) */
  var Modulos = w.Modulos = { telas: {}, registrar: function (rota, cfg) { this.telas[rota] = cfg; } };
  Modulos.registrar('/guia', { ativo: 'guia', titulo: 'Guia do Usuário', html: function () { return w.Guia ? w.Guia.html() : ''; }, apos: function () { if (w.Guia && w.Guia.apos) w.Guia.apos(); } });
  var rotaOcupada = false;
  /** Falha ao montar uma tela: mostra o motivo e um caminho de volta (nunca deixa a janela em branco). */
  function falha(e) {
    var r = document.getElementById('raiz'); if (!r) return;
    r.insertAdjacentHTML('afterbegin', '<div class="pagina"><div class="cartao"><div class="vazio text-danger">Não foi possível montar esta tela: ' + h(e && e.message || e) + '<br><br><a class="btn btn-sm btn-outline-secondary" href="#/">Voltar ao painel</a></div></div></div>');
  }
  function rota() {
    var r = parse(), mod = Modulos.telas[r.rota] || (TELAS[r.rota] ? null : Modulos.telas['/']), t = mod ? [mod.ativo, mod.html] : TELAS[r.rota];
    if (r.rota === '/metodo') { Nav.ir('#/guia'); return; }
    var sair = w.__riscoSair ? w.__riscoSair() : Promise.resolve();
    w.__riscoSair = null;
    sair.then(function () {
      Nav.atual = location.hash;
      var corpo;
      try { corpo = t[1](r.q); } catch (e) { console.error(e); corpo = '<div class="pagina"><div class="cartao"><div class="vazio text-danger">Erro ao montar a tela: ' + h(e.message) + '</div></div></div>'; }
      if (corpo == null) return;
      moldura(t[0], mod ? mod.titulo : (tituloBase[r.rota] || APP_NOME), corpo);
      if (mod && mod.apos) { try { mod.apos(r.q); } catch (e) { console.error(e); } }
      if (r.rota === '/risco') { document.title = (w.Risco.estado.R.id ? 'Risco — ' + w.Risco.estado.R.nome : 'Novo risco') + ' — ' + APP_NOME; try { w.Risco.iniciar(); } catch (e) { console.error(e); falha(e); } }
      if (w.__folhaTela && /^\/(folha|diagrama|impfolha)$/.test(r.rota)) { var ft = w.__folhaTela; w.__folhaTela = null; document.title = (tituloBase[r.rota]) + ' — ' + APP_NOME; try { Common.executar(ft); } catch (e) { console.error(e); falha(e); } }
    }).catch(function (e) { console.error(e); falha(e); });
  }
  w.addEventListener('hashchange', function () { if (location.hash !== Nav.atual) rota(); });
  w.Rota = rota;
})(window);
