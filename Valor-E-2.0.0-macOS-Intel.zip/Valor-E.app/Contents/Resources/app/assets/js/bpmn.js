/* bpmn.js — gera o diagrama BPMN 2.0 (com raias) a partir do item 7 da Folha de Dados.
 * Port fiel de lib/bpmn_gerador.php (mesma saída, byte a byte). */
(function (w) {
  'use strict';
  var PITCH = 170, X0 = 190, POOL_X = 60, POOL_Y = 40, LANE_HDR = 30, ROW_H = 100, ART_BAND = 66;

  var T = {
    'bpmn:StartEvent': ['startEvent', 'evento', 36, 36, 'Evento de início'],
    'bpmn:IntermediateThrowEvent': ['intermediateThrowEvent', 'evento', 36, 36, 'Evento intermediário'],
    'bpmn:TimerEvent': ['intermediateCatchEvent', 'evento', 36, 36, 'Evento de tempo'],
    'bpmn:MessageEvent': ['intermediateCatchEvent', 'evento', 36, 36, 'Evento de mensagem'],
    'bpmn:EndEvent': ['endEvent', 'evento', 36, 36, 'Evento de fim'],
    'bpmn:Task': ['task', 'tarefa', 100, 80, 'Tarefa'],
    'bpmn:UserTask': ['userTask', 'tarefa', 100, 80, 'Tarefa de usuário'],
    'bpmn:ManualTask': ['manualTask', 'tarefa', 100, 80, 'Tarefa manual'],
    'bpmn:ServiceTask': ['serviceTask', 'tarefa', 100, 80, 'Tarefa de serviço (sistema)'],
    'bpmn:ScriptTask': ['scriptTask', 'tarefa', 100, 80, 'Tarefa de script'],
    'bpmn:BusinessRuleTask': ['businessRuleTask', 'tarefa', 100, 80, 'Tarefa de regra de negócio'],
    'bpmn:SendTask': ['sendTask', 'tarefa', 100, 80, 'Tarefa de envio'],
    'bpmn:ReceiveTask': ['receiveTask', 'tarefa', 100, 80, 'Tarefa de recebimento'],
    'bpmn:SubProcess': ['subProcess', 'tarefa', 100, 80, 'Subprocesso'],
    'bpmn:ExclusiveGateway': ['exclusiveGateway', 'gateway', 50, 50, 'Decisão (exclusivo)'],
    'bpmn:ParallelGateway': ['parallelGateway', 'gateway', 50, 50, 'Paralelo (E)'],
    'bpmn:InclusiveGateway': ['inclusiveGateway', 'gateway', 50, 50, 'Inclusivo (OU)'],
    'bpmn:EventBasedGateway': ['eventBasedGateway', 'gateway', 50, 50, 'Baseado em evento'],
    'bpmn:DataObject': ['dataObjectReference', 'artefato', 36, 46, 'Dados / documento'],
    'bpmn:DataStore': ['dataStoreReference', 'artefato', 40, 50, 'Armazenamento / sistema'],
    'bpmn:TextAnnotation': ['textAnnotation', 'artefato', 130, 50, 'Anotação']
  };

  // Variantes de eventos (definições do BPMN 2.0, como na paleta do bpmn.io) e elementos adicionais
  var DEFS = { message: ['messageEventDefinition', 'mensagem'], timer: ['timerEventDefinition', 'tempo'], conditional: ['conditionalEventDefinition', 'condicional'], signal: ['signalEventDefinition', 'sinal'], link: ['linkEventDefinition', 'link'], escalation: ['escalationEventDefinition', 'escalonamento'], error: ['errorEventDefinition', 'erro'], cancel: ['cancelEventDefinition', 'cancelamento'], compensation: ['compensateEventDefinition', 'compensação'], terminate: ['terminateEventDefinition', 'encerramento'] };
  T['bpmn:TimerEvent'][5] = 'timer'; T['bpmn:MessageEvent'][5] = 'message';
  [['bpmn:StartEvent', 'startEvent', 'Início', ['message', 'timer', 'conditional', 'signal']],
   ['bpmn:IntermediateCatchEvent', 'intermediateCatchEvent', 'Evento intermediário (captura)', ['message', 'timer', 'conditional', 'link', 'signal']],
   ['bpmn:IntermediateThrowEvent', 'intermediateThrowEvent', 'Evento intermediário (lançamento)', ['message', 'escalation', 'link', 'compensation', 'signal']],
   ['bpmn:EndEvent', 'endEvent', 'Fim', ['message', 'escalation', 'error', 'cancel', 'compensation', 'signal', 'terminate']]].forEach(function (g) {
    g[3].forEach(function (d) { T[g[0] + '_' + d] = [g[1], 'evento', 36, 36, g[2] + ' — ' + DEFS[d][1], d]; });
  });
  T['bpmn:CallActivity'] = ['callActivity', 'tarefa', 100, 80, 'Atividade chamada (call activity)'];
  T['bpmn:AdHocSubProcess'] = ['adHocSubProcess', 'tarefa', 100, 80, 'Subprocesso ad-hoc'];
  T['bpmn:Transaction'] = ['transaction', 'tarefa', 100, 80, 'Transação'];
  T['bpmn:ComplexGateway'] = ['complexGateway', 'gateway', 50, 50, 'Complexo'];
  function isIni(t) { return !!T[t] && T[t][0] === 'startEvent'; }
  function isFim(t) { return !!T[t] && T[t][0] === 'endEvent'; }

  // utilitários ------------------------------------------------------------
  function X(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;'); }
  function len(s) { var n = 0; for (var i = 0; i < s.length; i++) { var c = s.charCodeAt(i); if (c >= 0xD800 && c <= 0xDBFF) i++; n++; } return n; }
  function sub(s, a, b) { return Array.from(s).slice(a, b).join(''); }
  function trim(s) { return String(s).replace(/^\s+|\s+$/g, ''); }
  function str(v) { return (v === null || v === undefined) ? '' : (typeof v === 'object' ? 'Array' : String(v)); }
  function nv(v, d) { return (v === null || v === undefined) ? d : v; }
  function isObj(v) { return v !== null && typeof v === 'object'; }
  function rnd(v) { return v < 0 ? -Math.round(-v) : Math.round(v); }
  function nomeCurto(t, max) {
    max = max || 90;
    t = trim(String(t).replace(/\s+/g, ' '));
    if (len(t) <= max) return t;
    return sub(t, 0, max - 1).replace(/\s+$/, '') + '…';
  }
  function cores(tipo, cat) {
    if (isIni(tipo)) return ['#548235', '#A9D18E'];
    if (isFim(tipo)) return ['#C00000', '#F2A2A2'];
    if (cat === 'evento') return ['#C55A11', '#F8CBAD'];
    if (cat === 'gateway') return ['#BF8F00', '#FFE699'];
    if (cat === 'artefato') return ['#7F7F7F', '#F2F2F2'];
    return ['#2E74B5', '#BDD7EE'];
  }
  function isNumeric(v) {
    if (typeof v === 'number') return isFinite(v);
    if (typeof v !== 'string') return false;
    return /^\s*[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?\s*$/.test(v);
  }
  function cmp(a, b) { return a < b ? -1 : (a > b ? 1 : 0); }
  function uniq(a) { var s = {}, o = []; a.forEach(function (x) { if (!s[x]) { s[x] = 1; o.push(x); } }); return o; }

  function gerar(nomeProcesso, linhas, opts) {
    opts = opts || {};
    var avisos = [], auto = nv(opts.auto_inicio_fim, true);
    linhas = Array.isArray(linhas) ? linhas : [];

    // 1. normaliza
    var rows = [];
    linhas.forEach(function (l, pos) {
      if (!isObj(l)) return;
      var desc = trim(str(l.descricao)), tipo = str(l.tipo);
      var tem = desc !== '' || trim(str(l.entrada)) !== '' || trim(str(l.saida)) !== '';
      if (tipo === '' && !tem) return;
      if (!T[tipo]) {
        if (tipo !== '') avisos.push('Linha ' + (pos + 1) + ': tipo desconhecido «' + tipo + '» — usada Tarefa.');
        else avisos.push('Linha ' + (pos + 1) + ': tipo de elemento não escolhido — usada Tarefa.');
        tipo = 'bpmn:Task';
      }
      var ordemRaw = nv(l.ordem, '');
      var ordem = (isNumeric(ordemRaw) && ordemRaw !== '') ? parseFloat(ordemRaw) : null;
      var uid = str(l.uid).replace(/[^A-Za-z0-9]/g, '');
      if (uid === '') uid = 'r' + (pos + 1);
      rows.push({
        uid: uid, pos: pos, tipo: tipo, cat: T[tipo][1],
        ordem: ordem !== null ? ordem : (pos + 1),
        ordemTxt: ordem !== null ? ordem.toFixed(3).replace(/0+$/, '').replace(/\.+$/, '') : String(pos + 1),
        entrada: trim(str(l.entrada)), desc: desc, saida: trim(str(l.saida)), resp: trim(str(l.responsavel)),
        seq: isObj(l.seq) ? l.seq : {}, anexos: Array.isArray(l.anexos) ? l.anexos : [], auto: false
      });
    });
    if (!rows.length) return { xml: xmlVazio(nomeProcesso), avisos: ['Item 7 sem atividades: gerado diagrama vazio.'], estat: { nos: 0, raias: 1, fluxos: 0 } };
    rows.sort(function (a, b) { return cmp(a.ordem, b.ordem) || cmp(a.pos, b.pos); });

    var vistos = {};
    rows.forEach(function (r) { var k = String(r.ordem); if (vistos[k]) avisos.push('Nº de ordem ' + r.ordemTxt + ' repetido — confira a numeração.'); vistos[k] = true; });

    // 2. nós x artefatos
    var seq = [], artRows = [];
    rows.forEach(function (r) { if (r.cat === 'artefato') artRows.push(r); else seq.push(r); });
    if (!seq.length) {
      seq.push({ uid: 'auto_ini', pos: -1, tipo: 'bpmn:StartEvent', cat: 'evento', ordem: 0, ordemTxt: '0', entrada: '', desc: 'Início', saida: '', resp: '', seq: {}, anexos: [], auto: true });
      avisos.push('Só há artefatos (dados/anotações) no item 7 — adicione atividades.');
    }
    var temInicio = false, temFim = false;
    seq.forEach(function (r) { if (isIni(r.tipo)) temInicio = true; if (isFim(r.tipo)) temFim = true; });
    if (auto && !temInicio) {
      seq.unshift({ uid: 'auto_ini', pos: -1, tipo: 'bpmn:StartEvent', cat: 'evento', ordem: seq[0].ordem - 1, ordemTxt: '', entrada: '', desc: 'Início', saida: '', resp: seq[0].resp, seq: {}, anexos: [], auto: true });
      avisos.push('Evento de Início inserido automaticamente antes da primeira atividade.');
    }
    var idxFimAuto = null;
    if (auto && !temFim) {
      var ult = seq[seq.length - 1];
      seq.push({ uid: 'auto_fim', pos: 9999, tipo: 'bpmn:EndEvent', cat: 'evento', ordem: ult.ordem + 1, ordemTxt: '', entrada: '', desc: 'Fim', saida: '', resp: ult.resp, seq: {}, anexos: [], auto: true });
      idxFimAuto = seq.length - 1;
      avisos.push('Evento de Fim inserido automaticamente após a última atividade.');
    }
    var n = seq.length, porUid = {};
    seq.forEach(function (r, i) { porUid[r.uid] = i; });
    var numTarefa = {}, contTar = 0;
    seq.forEach(function (r, i) { if (r.cat === 'tarefa' && !r.auto) numTarefa[i] = ++contTar; });

    function rotuloLinha(r) { return (r.ordemTxt !== '' ? r.ordemTxt + ' — ' : '') + nomeCurto(r.desc !== '' ? r.desc : 'sem descrição', 30); }

    // 3. conexões
    var edges = [], anexosExtra = [], refRet = {}, i;
    for (i = 0; i < n; i++) anexosExtra.push([]);
    function addEdge(s, uidAlvo, rot, via, nomeVia, ramo) {
      if (uidAlvo === null || uidAlvo === undefined || uidAlvo === '') return;
      if (porUid[uidAlvo] === undefined) { avisos.push('Atividade ' + rotuloLinha(seq[s]) + ': o destino escolhido não existe mais — conexão ignorada.'); return; }
      var t = porUid[uidAlvo];
      if (t === s) { avisos.push('Atividade ' + rotuloLinha(seq[s]) + ': conexão para si mesma ignorada.'); return; }
      via = (via === 'fluxo' || via === 'mensagem' || via === 'dados') ? via : 'fluxo';
      var volta = (t < s);
      if (!volta) {
        edges.push({ s: s, t: t, rot: rot, via: 'fluxo', msg: '', ramo: ramo });
        if (via === 'fluxo') return;
        var nmx = nomeVia !== '' ? nomeVia : (via === 'dados' ? 'Documento' : 'Mensagem');
        anexosExtra[s].push({ kind: via === 'dados' ? 'dados' : 'mensagem', direcao: 'saida', nome: nmx, semAlvo: true });
        anexosExtra[t].push({ kind: via === 'dados' ? 'dados' : 'mensagem', direcao: 'entrada', nome: nmx, semAlvo: true });
        return;
      }
      var nm = nomeVia !== '' ? nomeVia : (volta ? 'Retorno' : (via === 'dados' ? 'Documento' : 'Mensagem'));
      var ref = numTarefa[t] !== undefined ? 'tarefa ' + numTarefa[t] : nomeCurto(seq[t].desc !== '' ? seq[t].desc : 'sem descrição', 30);
      var texto = (rot !== '' ? rot + ': ' : '') + nm + ' (' + (volta ? 'retorna à ' : 'segue para a ') + ref + ')';
      anexosExtra[s].push({ kind: (via === 'dados' ? 'dados' : 'mensagem'), direcao: 'saida', nome: texto, semAlvo: true });
      refRet[t] = true;
      if (via === 'fluxo') avisos.push('Atividade ' + rotuloLinha(seq[s]) + ': o retorno à ' + ref + ' foi representado por mensagem, sem linha de conexão.');
    }
    function proximoDe(i) { return (i + 1 < n) ? i + 1 : null; }

    seq.forEach(function (r, i) {
      var tipo = r.tipo, cat = r.cat, sq = r.seq;
      if (isFim(tipo)) return;
      var ehGw = (cat === 'gateway'), modo = nv(sq.modo, 'divergente');
      if (ehGw && modo !== 'convergente') {
        if (tipo === 'bpmn:ExclusiveGateway') {
          var sim = nv(sq.sim, { alvo: '', via: 'fluxo', nome: '' }), nao = nv(sq.nao, { alvo: '', via: 'fluxo', nome: '' });
          var alvoSim = nv(sim.alvo, '') !== '' ? sim.alvo : (proximoDe(i) !== null ? seq[proximoDe(i)].uid : '');
          if (alvoSim !== '' && porUid[alvoSim] !== undefined && porUid[alvoSim] <= i) {
            avisos.push('Decisão ' + rotuloLinha(r) + ': o ramo «SIM» deve apontar para uma nova atividade (à frente) — ajustado para a atividade seguinte.');
            alvoSim = proximoDe(i) !== null ? seq[proximoDe(i)].uid : '';
          }
          addEdge(i, alvoSim, 'SIM', 'fluxo', '', 0);
          if (nv(nao.alvo, '') === '') avisos.push('Decisão ' + rotuloLinha(r) + ': ramo «NÃO» sem destino definido.');
          else addEdge(i, nao.alvo, 'NÃO', str(nv(nao.via, 'fluxo')), trim(str(nv(nao.nome, ''))), 1);
        } else {
          var ramos = Array.isArray(sq.ramos) ? sq.ramos : [];
          ramos = ramos.filter(function (x) { return nv(x && x.alvo, '') !== ''; });
          if (!ramos.length) {
            var p = proximoDe(i);
            if (p !== null) addEdge(i, seq[p].uid, '', 'fluxo', '', 0);
            avisos.push('Gateway ' + rotuloLinha(r) + ': nenhum ramo definido — ligado à atividade seguinte.');
          }
          ramos.forEach(function (rm, k) { addEdge(i, rm.alvo, trim(str(nv(rm.rotulo, ''))), str(nv(rm.via, 'fluxo')), trim(str(nv(rm.nome, ''))), k > 0 ? 1 : 0); });
        }
      } else {
        var px = nv(sq.proxima, { alvo: '', via: 'fluxo', nome: '' });
        if (!isObj(px)) px = { alvo: str(px), via: 'fluxo', nome: '' };
        var alvo, pp;
        if (nv(px.alvo, '') !== '') alvo = px.alvo; else { pp = proximoDe(i); alvo = pp !== null ? seq[pp].uid : ''; }
        if (alvo === '' && !isFim(r.tipo)) { /* tratado depois */ }
        else addEdge(i, alvo, '', str(nv(px.via, 'fluxo')), trim(str(nv(px.nome, ''))), 0);
      }
    });

    var temSaida = [], temEntrada = [];
    for (i = 0; i < n; i++) { temSaida.push(false); temEntrada.push(false); }
    edges.forEach(function (e) { if (e.via === 'fluxo') { temSaida[e.s] = true; temEntrada[e.t] = true; } });
    if (idxFimAuto !== null) {
      for (i = 0; i < n; i++) {
        if (i === idxFimAuto || isFim(seq[i].tipo)) continue;
        if (!temSaida[i]) {
          var viaMsg = false;
          edges.forEach(function (e) { if (e.s === i && e.via === 'mensagem') viaMsg = true; });
          if (viaMsg) continue;
          edges.push({ s: i, t: idxFimAuto, rot: '', via: 'fluxo', msg: '', ramo: 0 });
          temSaida[i] = true; temEntrada[idxFimAuto] = true;
        }
      }
    }
    for (i = 0; i < n; i++) {
      if (isFim(seq[i].tipo)) continue;
      if (!temSaida[i]) {
        var vm = false;
        edges.forEach(function (e) { if (e.s === i && e.via !== 'fluxo') vm = true; });
        if (!vm) avisos.push('Atividade ' + rotuloLinha(seq[i]) + ' não tem saída (fluxo interrompido).');
      }
      if (!temEntrada[i] && !isIni(seq[i].tipo)) {
        var vmi = false;
        edges.forEach(function (e) { if (e.t === i && e.via !== 'fluxo') vmi = true; });
        if (refRet[i]) vmi = true;
        if (!vmi) avisos.push('Atividade ' + rotuloLinha(seq[i]) + ' não recebe nenhum fluxo (inacessível).');
      }
    }

    // 4. raias
    var raias = {}, raiaNomes = [];
    function nomeRaia(r) { return r !== '' ? r : 'Sem responsável'; }
    seq.forEach(function (r) { var nm = nomeRaia(r.resp); if (raias[nm] === undefined) { raias[nm] = raiaNomes.length; raiaNomes.push(nm); } });
    var semResp = 0;
    seq.forEach(function (r) { if (r.resp === '' && !r.auto) semResp++; });
    if (semResp && raiaNomes.length > 1) avisos.push(semResp + ' atividade(s) sem responsável foram colocadas na raia «Sem responsável».');
    var nL = raiaNomes.length, laneDe = [];
    seq.forEach(function (r, i) { laneDe[i] = raias[nomeRaia(r.resp)]; });

    // 5. artefatos
    var arts = [];
    for (i = 0; i < n; i++) arts.push([]);
    function addAnexo(i, a) {
      var kind = str(a.kind), nome = trim(str(a.nome)), dir = (nv(a.direcao, 'saida') === 'entrada') ? 'entrada' : 'saida';
      if (kind === 'mensagem') {
        var alvo = str(nv(a.alvo, '')), nomeM = nome !== '' ? nome : 'Mensagem';
        if (alvo !== '' && porUid[alvo] !== undefined && porUid[alvo] !== i && !a.semAlvo) {
          var ta = porUid[alvo];
          var o = numTarefa[ta] !== undefined ? 'tarefa ' + numTarefa[ta] : nomeCurto(seq[ta].desc !== '' ? seq[ta].desc : '?', 30);
          nomeM += ' (' + (dir === 'entrada' ? 'de' : 'para') + ' ' + o + ')';
        }
        arts[i].push({ tipo: 'bpmn:MessageEvent', nome: nomeM, dir: dir });
      } else if (kind === 'dados') arts[i].push({ tipo: 'bpmn:DataObject', nome: nome !== '' ? nome : 'Documento', dir: dir });
      else if (kind === 'sistema') arts[i].push({ tipo: 'bpmn:DataStore', nome: nome !== '' ? nome : 'Sistema', dir: dir });
      else if (kind === 'subprocesso') arts[i].push({ tipo: 'bpmn:SubProcess', nome: nome !== '' ? nome : 'Subprocesso', dir: dir });
      else if (kind === 'normativo') arts[i].push({ tipo: 'bpmn:TextAnnotation', nome: 'Normativo: ' + (nome !== '' ? nome : '—'), dir: 'saida' });
      else if (kind === 'anotacao') arts[i].push({ tipo: 'bpmn:TextAnnotation', nome: nome !== '' ? nome : 'Anotação', dir: 'saida' });
    }
    seq.forEach(function (r, i) {
      r.anexos.forEach(function (a) { if (isObj(a)) addAnexo(i, a); });
      anexosExtra[i].forEach(function (a) { addAnexo(i, a); });
    });
    artRows.forEach(function (a) {
      var alvoUid = str(nv(a.seq.assoc, '')), idx = null;
      if (alvoUid !== '' && porUid[alvoUid] !== undefined) idx = porUid[alvoUid];
      else { idx = 0; seq.forEach(function (s, k) { if (s.ordem <= a.ordem) idx = k; }); }
      var nm = a.desc !== '' ? a.desc : (a.entrada !== '' ? a.entrada : T[a.tipo][4]);
      arts[idx].push({ tipo: a.tipo, nome: nm, dir: 'saida', livre: (alvoUid === '') });
    });

    // 6. geometria
    function bloqueado(s, t) {
      var a = Math.min(s, t), b = Math.max(s, t);
      for (var k = a + 1; k < b; k++) if (laneDe[k] === laneDe[s]) return true;
      return false;
    }
    var nCanal = []; for (i = 0; i < nL; i++) nCanal.push(0);
    var todasLig = [];
    edges.forEach(function (e, ix) { todasLig.push({ tipo: 'seq', ix: ix, s: e.s, t: e.t, ramo: e.ramo, via: e.via }); });
    todasLig.forEach(function (lg) {
      var s = lg.s, t = lg.t;
      var ehGwNao = (lg.tipo === 'seq' && lg.ramo === 1 && seq[s].cat === 'gateway');
      if (t <= s) lg.classe = 'volta';
      else if (ehGwNao || bloqueado(s, t) || lg.tipo === 'msg') lg.classe = 'canal';
      else lg.classe = 'frente';
      if (lg.classe !== 'frente') lg.slot = nCanal[laneDe[s]]++;
    });

    var temArtLane = []; for (i = 0; i < nL; i++) temArtLane.push(false);
    arts.forEach(function (lst, i) { if (lst.length) temArtLane[laneDe[i]] = true; });

    var laneTop = [], laneH = [], y = POOL_Y, l;
    for (l = 0; l < nL; l++) {
      var banda = temArtLane[l] ? ART_BAND : 0, canais = Math.max(30, 16 + 10 * nCanal[l]);
      laneTop[l] = y; laneH[l] = banda + ROW_H + canais; y += laneH[l];
    }
    var poolH = y - POOL_Y, box = [];
    seq.forEach(function (r, i) {
      var w_ = T[r.tipo][2], h_ = T[r.tipo][3], ln = laneDe[i];
      var cx = X0 + 50 + i * PITCH, cy = laneTop[ln] + (temArtLane[ln] ? ART_BAND : 0) + ROW_H / 2;
      box[i] = { cx: cx, cy: cy, w: w_, h: h_, l: cx - w_ / 2, r: cx + w_ / 2, t: cy - h_ / 2, b: cy + h_ / 2 };
    });
    var poolW = LANE_HDR + (X0 - POOL_X - LANE_HDR) + (n * PITCH) + 100, xFim = POOL_X + poolW;
    function chY(lane, slot) { return laneTop[lane] + laneH[lane] - 10 - slot * 10; }
    var off = {};
    function rota(lg) {
      var s = lg.s, t = lg.t, S = box[s], Tt = box[t];
      var k = off[t] = (off[t] === undefined ? -1 : off[t]) + 1;
      var xm = Tt.l - 22 - (k % 4) * 5;
      if (lg.classe === 'frente') {
        if (Math.abs(S.cy - Tt.cy) < 2) return [[S.r, S.cy], [Tt.l, Tt.cy]];
        if (xm < S.r + 8) xm = S.r + 8;
        return [[S.r, S.cy], [xm, S.cy], [xm, Tt.cy], [Tt.l, Tt.cy]];
      }
      var cy = chY(laneDe[s], lg.slot);
      if (lg.classe === 'canal') return [[S.cx, S.b], [S.cx, cy], [xm, cy], [xm, Tt.cy], [Tt.l, Tt.cy]];
      var entra = (Tt.cy < cy) ? Tt.b : Tt.t;
      return [[S.cx, S.b], [S.cx, cy], [Tt.cx, cy], [Tt.cx, entra]];
    }
    function dimA(tipo) { if (tipo === 'bpmn:SubProcess') return [64, 46]; return [T[tipo][2], T[tipo][3]]; }
    function slotArt(a) {
      var w_ = dimA(a.tipo)[0];
      if (a.tipo === 'bpmn:TextAnnotation') return w_ + 10;
      return Math.max(w_, Math.min(130, Math.trunc(len(nomeCurto(a.nome, 70)) * 5.6))) + 12;
    }
    var artBox = [];
    for (i = 0; i < n; i++) artBox.push([]);
    for (l = 0; l < nL; l++) {
      var lista = [];
      arts.forEach(function (lst, i) {
        if (laneDe[i] !== l) return;
        var tot = 0; lst.forEach(function (a) { tot += slotArt(a); });
        var x = box[i].cx - tot / 2;
        lst.forEach(function (a, k) {
          var sw = slotArt(a), d = dimA(a.tipo);
          lista.push({ i: i, k: k, w: d[0], h: d[1], x: x, sw: sw }); x += sw;
        });
      });
      lista.sort(function (a, b) { return cmp(a.x, b.x); });
      var prevR = -1e9;
      lista.forEach(function (it) {
        var x0 = Math.max(it.x, prevR), xs = x0 + (it.sw - it.w) / 2, yy = laneTop[l] + ((it.h > 46) ? 6 : 4);
        artBox[it.i][it.k] = { x: xs, y: yy, w: it.w, h: it.h };
        prevR = x0 + it.sw; xFim = Math.max(xFim, prevR + 40);
      });
    }
    poolW = Math.max(poolW, xFim - POOL_X);

    // 7. XML
    var procId = 'Process_' + w.md5(nomeProcesso).substr(0, 10);
    function idNo(i) { var r = seq[i]; return (r.cat === 'evento' ? 'Event_' : (r.cat === 'gateway' ? 'Gateway_' : 'Activity_')) + r.uid; }
    function laneId(l) { return 'Lane_' + (l + 1); }
    var x = '<?xml version="1.0" encoding="UTF-8"?>\n';
    x += '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" '
      + 'xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" '
      + 'xmlns:bioc="http://bpmn.io/schema/bpmn/biocolor/1.0" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn">\n';
    x += '  <bpmn:collaboration id="Collaboration_1">\n';
    x += '    <bpmn:participant id="Participant_1" name="' + X(nomeProcesso) + '" processRef="' + procId + '" />\n';
    edges.forEach(function (e, ei) {
      if (e.via !== 'mensagem') return;
      x += '    <bpmn:messageFlow id="MsgFlow_E' + (ei + 1) + '" name="' + X(nomeCurto(e.msg !== '' ? e.msg : (e.rot || 'Mensagem'), 40)) + '" sourceRef="' + idNo(e.s) + '" targetRef="' + idNo(e.t) + '" />\n';
    });
    x += '  </bpmn:collaboration>\n';
    x += '  <bpmn:process id="' + procId + '" name="' + X(nomeProcesso) + '" isExecutable="false">\n';
    x += '    <bpmn:laneSet id="LaneSet_1">\n';
    raiaNomes.forEach(function (nm, l) {
      x += '      <bpmn:lane id="' + laneId(l) + '" name="' + X(nm) + '">\n';
      seq.forEach(function (r, i) { if (laneDe[i] === l) x += '        <bpmn:flowNodeRef>' + idNo(i) + '</bpmn:flowNodeRef>\n'; });
      arts.forEach(function (lst, i) { if (laneDe[i] === l) lst.forEach(function (a, k) {
        if (a.tipo === 'bpmn:MessageEvent' || a.tipo === 'bpmn:SubProcess') x += '        <bpmn:flowNodeRef>Art_' + seq[i].uid + '_' + k + '</bpmn:flowNodeRef>\n';
      }); });
      x += '      </bpmn:lane>\n';
    });
    x += '    </bpmn:laneSet>\n';

    var dadoDefs = '';
    seq.forEach(function (r, i) {
      var tag = T[r.tipo][0], id = idNo(i);
      var nome = nomeCurto(r.desc !== '' ? r.desc : (isIni(r.tipo) ? 'Início' : (isFim(r.tipo) ? 'Fim' : '')));
      var doc = [];
      if (r.entrada !== '') doc.push('Entrada: ' + r.entrada);
      if (r.saida !== '') doc.push('Saída: ' + r.saida);
      if (len(trim(r.desc.replace(/\s+/g, ' '))) > 90) doc.push('Descrição: ' + r.desc);
      var attrNum = numTarefa[i] !== undefined ? ' numero="' + numTarefa[i] + '"' : '';
      x += '    <bpmn:' + tag + ' id="' + id + '" name="' + X(nome) + '"' + attrNum + '>\n';
      if (doc.length) x += '      <bpmn:documentation>' + X(doc.join('\n')) + '</bpmn:documentation>\n';
      edges.forEach(function (e, ei) { if (e.via === 'fluxo' && e.t === i) x += '      <bpmn:incoming>Flow_' + (ei + 1) + '</bpmn:incoming>\n'; });
      edges.forEach(function (e, ei) { if (e.via === 'fluxo' && e.s === i) x += '      <bpmn:outgoing>Flow_' + (ei + 1) + '</bpmn:outgoing>\n'; });
      if (T[r.tipo][5]) x += '      <bpmn:' + DEFS[T[r.tipo][5]][0] + (T[r.tipo][5] === 'link' ? ' name="' + X(nome || 'Link') + '"' : '') + ' />\n';
      x += '    </bpmn:' + tag + '>\n';
    });
    edges.forEach(function (e, ei) {
      if (e.via !== 'fluxo') return;
      x += '    <bpmn:sequenceFlow id="Flow_' + (ei + 1) + '"' + (e.rot !== '' ? ' name="' + X(e.rot) + '"' : '') + ' sourceRef="' + idNo(e.s) + '" targetRef="' + idNo(e.t) + '" />\n';
    });
    var assocXml = '', edgesArt = '', assocN = 0;
    arts.forEach(function (lst, i) {
      lst.forEach(function (a, k) {
        var aid = 'Art_' + seq[i].uid + '_' + k, ab = artBox[i][k], nm = nomeCurto(a.nome, 70);
        if (a.tipo === 'bpmn:DataObject') {
          dadoDefs += '    <bpmn:dataObject id="DataObj_' + aid + '" />\n';
          x += '    <bpmn:dataObjectReference id="' + aid + '" name="' + X(nm) + '" dataObjectRef="DataObj_' + aid + '" />\n';
        } else if (a.tipo === 'bpmn:DataStore') x += '    <bpmn:dataStoreReference id="' + aid + '" name="' + X(nm) + '" />\n';
        else if (a.tipo === 'bpmn:TextAnnotation') x += '    <bpmn:textAnnotation id="' + aid + '"><bpmn:text>' + X(nm) + '</bpmn:text></bpmn:textAnnotation>\n';
        else if (a.tipo === 'bpmn:MessageEvent') x += '    <bpmn:intermediateCatchEvent id="' + aid + '" name="' + X(nm) + '"><bpmn:messageEventDefinition /></bpmn:intermediateCatchEvent>\n';
        else if (a.tipo === 'bpmn:SubProcess') x += '    <bpmn:subProcess id="' + aid + '" name="' + X(nm) + '" />\n';
        if (a.livre) return;
        assocN++;
        var srcRef = (a.dir === 'entrada') ? aid : idNo(i), tgtRef = (a.dir === 'entrada') ? idNo(i) : aid;
        assocXml += '    <bpmn:association id="Assoc_' + assocN + '" sourceRef="' + srcRef + '" targetRef="' + tgtRef + '" />\n';
        var nb = box[i], ax = ab.x + ab.w / 2, ay = ab.y + ab.h + (a.tipo === 'bpmn:TextAnnotation' ? 0 : 16);
        var wp = (Math.abs(ax - nb.cx) < 3) ? [[ax, ay], [nb.cx, nb.t]] : [[ax, ay], [ax, ay + 8], [nb.cx, ay + 8], [nb.cx, nb.t]];
        if (a.dir !== 'entrada') wp.reverse();
        edgesArt += '      <bpmndi:BPMNEdge id="Assoc_' + assocN + '_di" bpmnElement="Assoc_' + assocN + '">\n';
        wp.forEach(function (p) { edgesArt += '        <di:waypoint x="' + rnd(p[0]) + '" y="' + rnd(p[1]) + '" />\n'; });
        edgesArt += '      </bpmndi:BPMNEdge>\n';
      });
    });
    x += assocXml;
    x += '  </bpmn:process>\n';
    if (dadoDefs !== '') x = x.replace(/  <\/bpmn:process>\n$/, function () { return dadoDefs + '  </bpmn:process>\n'; });

    x += '  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n';
    x += '    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1">\n';
    x += '      <bpmndi:BPMNShape id="Participant_1_di" bpmnElement="Participant_1" isHorizontal="true">\n';
    x += '        <dc:Bounds x="' + POOL_X + '" y="' + POOL_Y + '" width="' + poolW + '" height="' + poolH + '" />\n';
    x += '      </bpmndi:BPMNShape>\n';
    raiaNomes.forEach(function (nm, l) {
      x += '      <bpmndi:BPMNShape id="' + laneId(l) + '_di" bpmnElement="' + laneId(l) + '" isHorizontal="true">\n';
      x += '        <dc:Bounds x="' + (POOL_X + LANE_HDR) + '" y="' + laneTop[l] + '" width="' + (poolW - LANE_HDR) + '" height="' + laneH[l] + '" />\n';
      x += '      </bpmndi:BPMNShape>\n';
    });
    seq.forEach(function (r, i) {
      var b = box[i], cat = T[r.tipo][1], c = cores(r.tipo, cat);
      x += '      <bpmndi:BPMNShape id="' + idNo(i) + '_di" bpmnElement="' + idNo(i) + '"' + (cat === 'gateway' ? ' isMarkerVisible="true"' : '') + ' bioc:stroke="' + c[0] + '" bioc:fill="' + c[1] + '">\n';
      x += '        <dc:Bounds x="' + rnd(b.l) + '" y="' + rnd(b.t) + '" width="' + b.w + '" height="' + b.h + '" />\n';
      x += '      </bpmndi:BPMNShape>\n';
    });
    arts.forEach(function (lst, i) { lst.forEach(function (a, k) {
      var aid = 'Art_' + seq[i].uid + '_' + k, ab = artBox[i][k];
      var c = cores(a.tipo, a.tipo === 'bpmn:MessageEvent' ? 'evento' : (a.tipo === 'bpmn:SubProcess' ? 'tarefa' : 'artefato'));
      x += '      <bpmndi:BPMNShape id="' + aid + '_di" bpmnElement="' + aid + '" bioc:stroke="' + c[0] + '" bioc:fill="' + c[1] + '">\n';
      x += '        <dc:Bounds x="' + rnd(ab.x) + '" y="' + rnd(ab.y) + '" width="' + ab.w + '" height="' + ab.h + '" />\n';
      x += '      </bpmndi:BPMNShape>\n';
    }); });
    var nFluxos = 0;
    edges.forEach(function (e, ei) {
      var lg = todasLig[ei], wp = rota(lg), isMsg = (e.via === 'mensagem');
      var idEdge = isMsg ? 'MsgFlow_E' + (ei + 1) : 'Flow_' + (ei + 1);
      nFluxos++;
      x += '      <bpmndi:BPMNEdge id="' + idEdge + '_di" bpmnElement="' + idEdge + '">\n';
      wp.forEach(function (p) { x += '        <di:waypoint x="' + rnd(p[0]) + '" y="' + rnd(p[1]) + '" />\n'; });
      var rot = isMsg ? nomeCurto(e.msg !== '' ? e.msg : (e.rot || 'Mensagem'), 40) : e.rot;
      if (rot !== '') {
        var lx = rnd(wp[0][0] + 5), ly = (wp[0][1] === wp[1][1]) ? rnd(wp[0][1] - 18) : rnd(wp[0][1] + 4);
        x += '        <bpmndi:BPMNLabel><dc:Bounds x="' + lx + '" y="' + ly + '" width="' + Math.max(28, Math.min(160, 7 * len(rot))) + '" height="14" /></bpmndi:BPMNLabel>\n';
      }
      x += '      </bpmndi:BPMNEdge>\n';
    });
    x += edgesArt;
    x += '    </bpmndi:BPMNPlane>\n';
    x += '  </bpmndi:BPMNDiagram>\n';
    x += '</bpmn:definitions>\n';
    return { xml: x, avisos: uniq(avisos), estat: { nos: n, raias: nL, fluxos: nFluxos } };
  }

  function xmlVazio(nome) {
    var procId = 'Process_' + w.md5(nome).substr(0, 10);
    return '<?xml version="1.0" encoding="UTF-8"?>\n'
      + '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:bioc="http://bpmn.io/schema/bpmn/biocolor/1.0" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn">\n'
      + '  <bpmn:collaboration id="Collaboration_1"><bpmn:participant id="Participant_1" name="' + X(nome) + '" processRef="' + procId + '" /></bpmn:collaboration>\n'
      + '  <bpmn:process id="' + procId + '" name="' + X(nome) + '" isExecutable="false"><bpmn:laneSet id="LaneSet_1"><bpmn:lane id="Lane_1" name="Raia 1"><bpmn:flowNodeRef>Event_ini</bpmn:flowNodeRef></bpmn:lane></bpmn:laneSet>'
      + '<bpmn:startEvent id="Event_ini" name="Início" /></bpmn:process>\n'
      + '  <bpmndi:BPMNDiagram id="BPMNDiagram_1"><bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1">'
      + '<bpmndi:BPMNShape id="Participant_1_di" bpmnElement="Participant_1" isHorizontal="true"><dc:Bounds x="60" y="40" width="600" height="170" /></bpmndi:BPMNShape>'
      + '<bpmndi:BPMNShape id="Lane_1_di" bpmnElement="Lane_1" isHorizontal="true"><dc:Bounds x="90" y="40" width="570" height="170" /></bpmndi:BPMNShape>'
      + '<bpmndi:BPMNShape id="Event_ini_di" bpmnElement="Event_ini" bioc:stroke="#548235" bioc:fill="#A9D18E"><dc:Bounds x="180" y="107" width="36" height="36" /></bpmndi:BPMNShape>'
      + '</bpmndi:BPMNPlane></bpmndi:BPMNDiagram>\n'
      + '</bpmn:definitions>\n';
  }
  w.Bpmn = { gerar: gerar, tipos: T };
})(typeof window !== 'undefined' ? window : global);
