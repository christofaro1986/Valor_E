/* folha_tpl.js — HTML da tela de edição da Folha de Dados (seções 1–13) */
(function (w) {
  'use strict';
  var esc = Common.esc;
  function sec(n, titulo, corpo) { return '<section class="secao" id="s' + n + '"><h2>' + n + '. ' + esc(titulo) + '</h2><div class="corpo">' + corpo + '</div></section>'; }
  var NAV = { 1: 'Objetivo', 2: 'Siglas e definições', 3: 'Campo de aplicação', 4: 'Responsabilidades', 5: 'Limites do processo', 6: 'Documentos de referência', 7: 'Descrição do processo', 8: 'Competências requeridas', 9: 'Registros gerados', 10: 'Pontos de alerta', 11: 'Controles do processo', 12: 'Fluxograma (BPMN)', 13: 'Controle de alterações' };
  w.FOLHA_HTML = function (d) {
    var id = d.id, h = '';
    h += '<div class="ftopbar no-print">'
      + '<a class="marca" href="#/processos" title="Voltar à lista de processos"><i class="bi bi-arrow-left-circle"></i> Processos</a>'
      + '<div class="titulo"><input class="titulo-in" id="nome" value="' + esc(d.nome) + '" title="Nome do processo"></div>'
      + '<span class="status-salvo" id="status">Salvo</span>'
      + '<a class="btn btn-outline-light btn-sm" href="#" id="bXml" title="Exportar a folha de dados em XML"><i class="bi bi-filetype-xml"></i> Exportar XML</a>'
      + '<a class="btn btn-outline-light btn-sm" href="#/indicador?novo=1&processo=' + id + '" id="bInd" title="Cadastrar indicador deste processo"><i class="bi bi-graph-up-arrow"></i> Indicador</a>'
      + '<a class="btn btn-outline-light btn-sm" href="#/impfolha?id=' + id + '" id="bImp"><i class="bi bi-printer"></i> Imprimir folha</a>'
      + '<a class="btn btn-outline-light btn-sm ' + (d.temDiagrama ? '' : 'disabled') + '" id="btnVer" href="#/diagrama?id=' + id + '"><i class="bi bi-diagram-3"></i> Ver diagrama</a>'
      + '<button class="btn btn-light btn-sm" onclick="Folha.salvar(true)"><i class="bi bi-save"></i> Salvar</button>'
      + '<button class="btn btn-warning btn-sm fw-semibold" onclick="Folha.gerar()"><i class="bi bi-magic"></i> Gerar diagrama</button></div>';
    h += '<div class="folha-wrap"><nav class="nav-secoes no-print" id="nav">';
    Object.keys(NAV).forEach(function (n) { h += '<a href="#s' + n + '">' + n + '. ' + esc(NAV[n]) + '</a>'; });
    h += '</nav><main class="folha-main">';
    h += sec(1, 'Macroprocesso e objetivo', '<div class="mb-3"><label class="form-label fw-semibold">Macroprocesso vinculante</label><select class="form-select" id="macroSel"></select><div class="form-text">Escolha na cadeia de valor (módulo CVA). <a href="#/cva">Abrir CVA</a></div></div><label class="form-label fw-semibold">Objetivo do processo</label><textarea class="form-control" rows="3" data-f="objetivo"></textarea>');
    h += sec(2, 'Siglas e definições', '<div data-tab="siglas"></div>');
    h += sec(3, 'Campo de aplicação', '<textarea class="form-control" rows="3" data-f="campo_aplicacao"></textarea>');
    h += sec(4, 'Responsabilidades', '<h3>Gestor do Processo</h3><div data-lista="gestor" data-ph="Responsabilidade do gestor"></div><h3>Executores do Processo</h3><div data-lista="executores" data-ph="Responsabilidade dos executores"></div>');
    h += sec(5, 'Limites do processo', '<h3>Escopo</h3><div class="row g-2"><div class="col-md-6"><label class="form-label small">Início</label><textarea class="form-control" rows="2" data-f="escopo_inicio"></textarea></div><div class="col-md-6"><label class="form-label small">Fim</label><textarea class="form-control" rows="2" data-f="escopo_fim"></textarea></div></div><h3>Áreas envolvidas</h3><div data-lista="areas" data-ph="Área envolvida"></div><h3>Fornecedores do processo</h3><div data-tab="fornecedores"></div><h3>Clientes do processo</h3><div data-tab="clientes"></div>');
    h += sec(6, 'Documentos de referência', '<div data-lista="documentos" data-ph="Documento / normativo de referência"></div>');
    h += '<section class="secao" id="s7"><h2>7. Descrição do processo <span class="chip">gera o diagrama BPMN</span></h2><div class="corpo">'
      + '<p class="text-muted small mb-2">Cada atividade vira um elemento do diagrama. Escolha uma atividade na lista e preencha o formulário. O <b>responsável</b> define a <b>raia</b>; o <b>nº de ordem</b> define a posição no fluxo; a <b>Sequência</b> define para onde o fluxo segue (decisões: <b>SIM</b> sempre segue para uma nova atividade; <b>NÃO</b> pode retornar por mensagem ou documento, sem linha até a atividade de retorno). Use <b>Anexos</b> para ligar documentos, sistemas, mensagens, subprocessos e anotações.</p>'
      + '<div class="d-flex flex-wrap gap-2 align-items-center mb-2 no-print"><button class="btn btn-outline-secondary btn-sm" onclick="Folha.ordenar()"><i class="bi bi-sort-numeric-down"></i> Ordenar pelo nº</button>'
      + '<button class="btn btn-outline-secondary btn-sm" onclick="Folha.renumerar()"><i class="bi bi-123"></i> Renumerar 1…n</button>'
      + '<label class="form-check ms-2 small mb-0"><input type="checkbox" class="form-check-input" id="autoIF"> Inserir Início/Fim automaticamente se faltarem</label></div>'
      + '<div class="s7-grid"><aside class="s7-lista"><div id="s7Lista"></div><button class="btn btn-success w-100 mt-2" onclick="Folha.addLinha()"><i class="bi bi-plus-lg"></i> Nova atividade</button></aside><div class="s7-form" id="s7Form"></div></div>'
      + '<datalist id="dlResp"></datalist></div></section>';
    h += sec(8, 'Competências requeridas', '<div data-tab="competencias"></div>');
    h += sec(9, 'Registros gerados', '<div class="small text-muted mb-1">Controle de registros</div><div data-tab="registros"></div>');
    h += sec(10, 'Pontos de alerta', '<div data-tab="alertas"></div>');
    h += sec(11, 'Controles do processo', '<h3>Monitoramento e medição do processo</h3><div data-tab="indicadores"></div><h3>Controles ambientais</h3><div data-tab="ambientais"></div><h3>Infraestrutura — Instalações</h3><div data-lista="instalacoes" data-ph="Instalação"></div><h3>Equipamentos</h3><div data-lista="equipamentos" data-ph="Equipamento"></div><h3>Softwares</h3><div data-lista="softwares" data-ph="Software"></div>');
    h += sec(12, 'Fluxograma (BPMN)', '<p class="mb-2">O diagrama é gerado a partir do item 7. <span id="stDiag"></span></p><div class="d-flex gap-2 no-print"><button class="btn btn-warning" onclick="Folha.gerar()"><i class="bi bi-magic"></i> Gerar / atualizar diagrama</button><a class="btn btn-outline-primary" id="btnVer2" href="#/diagrama?id=' + id + '"><i class="bi bi-diagram-3"></i> Abrir diagrama</a></div>');
    h += sec(13, 'Controle de alterações', '<div data-tab="alteracoes"></div><div class="row g-2 mt-2"><div class="col-md-6"><label class="form-label small">Elaboração</label><input class="form-control" data-f="elaboracao"></div><div class="col-md-6"><label class="form-label small">Aprovação</label><input class="form-control" data-f="aprovacao"></div></div>');
    return h + '</main></div>';
  };
})(window);
