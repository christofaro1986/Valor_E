/* sec.js — camada de segurança do Valor-E (dados em repouso, integridade, bloqueio, auditoria). */
(function (w) {
  'use strict';
  var SEC = w.SEC = {
    MAGIC: 'VMAP3ENC1',
    MAGIC2: 'VMAP3ENC2',
    MAGIC3: 'VMAP3ENC3',
    ITER_LEGADO: 210000,
    MIN_SENHA: 10,
    _ks: null,
    _falhas: 0,
    _bloqAte: 0,
    MAX_IMPORT_BYTES: 80 * 1024 * 1024,
    LOCK_MINUTES_DEFAULT: 15,
    ITERATIONS: 600000,
    _key: null,
    _locked: false,
    _timer: null,
    _cfg: null
  };

  function u8(s) { return new TextEncoder().encode(s); }
  function b64en(buf) {
    var u = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    var s = '', n = 0x8000;
    for (var i = 0; i < u.length; i += n) s += String.fromCharCode.apply(null, u.subarray(i, i + n));
    return btoa(s);
  }
  function b64de(b) {
    var s = atob(b), u = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
    return u;
  }
  function concat() {
    var parts = [].slice.call(arguments), n = 0, i;
    for (i = 0; i < parts.length; i++) n += parts[i].length;
    var o = new Uint8Array(n), p = 0;
    for (i = 0; i < parts.length; i++) { o.set(parts[i], p); p += parts[i].length; }
    return o;
  }

  SEC.isEncryptedBlob = function (b64) {
    if (!b64 || b64.length < 16) return false;
    try {
      var raw = b64de(b64);
      var mag = new TextDecoder().decode(raw.subarray(0, SEC.MAGIC.length));
      return mag === SEC.MAGIC || mag === SEC.MAGIC2 || mag === SEC.MAGIC3;
    } catch (e) { return false; }
  };

  SEC.deriveKey = function (senha, salt, iter) {
    return crypto.subtle.importKey('raw', u8(senha), 'PBKDF2', false, ['deriveKey']).then(function (base) {
      return crypto.subtle.deriveKey(
        { name: 'PBKDF2', salt: salt, iterations: iter || SEC.ITERATIONS, hash: 'SHA-256' },
        base,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
      );
    });
  };

  function u32(n) { return new Uint8Array([(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255]); }
  function rd32(u, o) { return ((u[o] << 24) | (u[o + 1] << 16) | (u[o + 2] << 8) | u[o + 3]) >>> 0; }

  // Formato 3 (envelope): MAGIC3 | iter(4) | salP(16) | ivP(12) | envP(48) | salR(16) | ivR(12) | envR(48) | IV(12) | cifra+tag.
  // Uma chave de dados (DEK) aleatória cifra o banco. A DEK é guardada duas vezes no cabeçalho: cifrada pela chave da
  // senha (PBKDF2) e cifrada pela chave de recuperação (aleatória, 125 bits). O cabeçalho inteiro é autenticado (AAD).
  var ITER_REC = 100000, ALFA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', LCAB = 165;
  function rnd(n) { return crypto.getRandomValues(new Uint8Array(n)); }
  function normRec(s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  SEC.gerarChaveRec = function () {
    var r = rnd(25), s = '';
    for (var i = 0; i < 25; i++) { s += ALFA[r[i] & 31]; if (i % 5 === 4 && i < 24) s += '-'; }
    return s;
  };
  function envolver(kek, dek) {
    var iv = rnd(12);
    return crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv, additionalData: u8(SEC.MAGIC3) }, kek, dek)
      .then(function (ct) { return { iv: iv, wrap: new Uint8Array(ct) }; });
  }
  function desenvolver(kek, iv, wrap) {
    return crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv, additionalData: u8(SEC.MAGIC3) }, kek, wrap)
      .then(function (b) { return new Uint8Array(b); });
  }
  function importDek(dek) { return crypto.subtle.importKey('raw', dek, 'AES-GCM', false, ['encrypt', 'decrypt']); }
  function novoRec(dek) {
    var chave = SEC.gerarChaveRec(), salt = rnd(16);
    return SEC.deriveKey(normRec(chave), salt, ITER_REC).then(function (kek) { return envolver(kek, dek); })
      .then(function (w) { return { chave: chave, saltR: salt, ivR: w.iv, wrapR: w.wrap }; });
  }
  function cabecalho(k) { return concat(u8(SEC.MAGIC3), u32(k.iter), k.saltP, k.ivP, k.wrapP, k.saltR, k.ivR, k.wrapR); }
  function parse3(raw) {
    if (raw.length < LCAB + 12 + 16) throw new Error('Arquivo cifrado inválido.');
    var iter = rd32(raw, 9);
    if (iter < 100000 || iter > 5000000) throw new Error('Cabeçalho inválido.');
    function cp(a, b) { return new Uint8Array(raw.subarray(a, b)); }
    return { iter: iter, saltP: cp(13, 29), ivP: cp(29, 41), wrapP: cp(41, 89), saltR: cp(89, 105), ivR: cp(105, 117),
      wrapR: cp(117, 165), head: cp(0, LCAB), iv: cp(LCAB, LCAB + 12), ct: cp(LCAB + 12, raw.length) };
  }
  function abrirCorpo(p, dek, senha) {
    return importDek(dek).then(function (dk) {
      return crypto.subtle.decrypt({ name: 'AES-GCM', iv: p.iv, additionalData: p.head }, dk, p.ct).then(function (buf) {
        SEC._key = dk; SEC._pub = null;
        SEC._ks = { senha: senha, iter: p.iter, saltP: p.saltP, ivP: p.ivP, wrapP: p.wrapP, saltR: p.saltR, ivR: p.ivR, wrapR: p.wrapR, dek: dek, dekKey: dk };
        return new Uint8Array(buf);
      });
    });
  }
  function construirKs(senha) {
    var keep = SEC._keep, saltP = rnd(16);
    var base = keep ? Promise.resolve(keep) : (function () {
      var dek = rnd(32);
      return novoRec(dek).then(function (r) { if (!SEC._chaveSis) SEC._recPendente = r.chave; return { dek: dek, saltR: r.saltR, ivR: r.ivR, wrapR: r.wrapR }; });
    })();
    return base.then(function (b) {
      return Promise.all([SEC.deriveKey(senha, saltP, SEC.ITERATIONS), importDek(b.dek)]).then(function (x) {
        return envolver(x[0], b.dek).then(function (w) {
          var k = { senha: senha, iter: SEC.ITERATIONS, saltP: saltP, ivP: w.iv, wrapP: w.wrap, saltR: b.saltR, ivR: b.ivR, wrapR: b.wrapR, dek: b.dek, dekKey: x[1] };
          SEC._keep = null; SEC._pub = null; SEC._ks = k;
          return k;
        });
      });
    });
  }

  SEC.encryptBytes = function (plainU8, senha) {
    var ks = SEC._ks;
    var pronto = (ks && ks.dekKey && ks.senha === senha && ks.iter === SEC.ITERATIONS) ? Promise.resolve(ks) : construirKs(senha);
    return pronto.then(function (k) {
      SEC._key = k.dekKey;
      var iv = rnd(12), head = cabecalho(k);
      return crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv, additionalData: head }, k.dekKey, plainU8).then(function (ct) {
        return b64en(concat(head, iv, new Uint8Array(ct)));
      });
    });
  };

  SEC.decryptBytes = function (b64, senha) {
    var raw = b64de(b64), ml = SEC.MAGIC.length;
    var mag = new TextDecoder().decode(raw.subarray(0, ml));
    if (mag === SEC.MAGIC3) {
      var p;
      try { p = parse3(raw); } catch (e) { return Promise.reject(e); }
      return SEC.deriveKey(senha, p.saltP, p.iter).then(function (kek) { return desenvolver(kek, p.ivP, p.wrapP); })
        .then(function (dek) { return abrirCorpo(p, dek, senha); });
    }
    if (mag === SEC.MAGIC2) {
      var iter = rd32(raw, ml);
      if (iter < 100000 || iter > 5000000) return Promise.reject(new Error('Cabeçalho inválido.'));
      var salt2 = raw.subarray(ml + 4, ml + 20), head = raw.subarray(0, ml + 20);
      var iv2 = raw.subarray(ml + 20, ml + 32), ct2 = raw.subarray(ml + 32);
      return SEC.deriveKey(senha, salt2, iter).then(function (key) {
        return crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv2, additionalData: head }, key, ct2);
      }).then(function (buf) { SEC._ks = null; SEC._pub = null; return new Uint8Array(buf); }); // regrava no formato 3 (com chave de recuperação)
    }
    if (mag !== SEC.MAGIC) return Promise.reject(new Error('Arquivo não está cifrado.'));
    var salt = raw.subarray(ml, ml + 16), iv = raw.subarray(ml + 16, ml + 28), ct = raw.subarray(ml + 28);
    return SEC.deriveKey(senha, salt, SEC.ITER_LEGADO).then(function (key) {
      return crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, key, ct);
    }).then(function (buf) { SEC._ks = null; SEC._pub = null; return new Uint8Array(buf); });
  };

  // Abre o arquivo com a chave de recuperação (esqueci a senha). Só vale para o formato 3.
  SEC.decryptComChave = function (b64, chave) {
    var raw = b64de(b64), p;
    if (new TextDecoder().decode(raw.subarray(0, 9)) !== SEC.MAGIC3)
      return Promise.reject(new Error('Este arquivo foi criado numa versão anterior e não tem chave de recuperação.'));
    try { p = parse3(raw); } catch (e) { return Promise.reject(e); }
    var c = normRec(chave);
    if (c.length !== 25) return Promise.reject(new Error('A chave de recuperação tem 25 letras e números (5 grupos de 5).'));
    return SEC.deriveKey(c, p.saltR, ITER_REC).then(function (kek) { return desenvolver(kek, p.ivR, p.wrapR); })
      .catch(function () { throw new Error('Chave de recuperação incorreta.'); })
      .then(function (dek) { return abrirCorpo(p, dek, null); });
  };

  // Nova chave de recuperação (invalida a anterior). Exige a sessão desbloqueada.
  SEC.novaChaveRec = function () {
    var ks = SEC._ks;
    if (!ks || !ks.dek) { alert('Os dados ainda não foram gravados nesta sessão. Aguarde alguns segundos e tente de novo.'); return; }
    if (!confirm('Gerar uma nova chave de recuperação invalida a anterior. Continuar?')) return;
    novoRec(ks.dek).then(function (r) {
      ks.saltR = r.saltR; ks.ivR = r.ivR; ks.wrapR = r.wrapR;
      SEC.audit('chave_recuperacao', 'nova chave gerada');
      if (w.DB && DB.sujo) DB.sujo();
      return (w.DB && DB.flush ? DB.flush() : Promise.resolve()).then(function () { SEC.mostrarChaveRec(r.chave); });
    });
  };

  SEC.mostrarChaveRec = function (chave) {
    var d = document.createElement('div');
    d.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(8,20,40,.97);display:flex;align-items:center;justify-content:center';
    d.innerHTML = '<div style="max-width:460px;width:92%;background:#0f2744;border-radius:12px;padding:24px;color:#fff;font-family:system-ui,sans-serif">' +
      '<h2 style="margin:0 0 8px;font-size:1.15rem">Chave de recuperação</h2>' +
      '<p style="opacity:.9;font-size:.9rem;margin:0 0 12px">Se você esquecer a senha, <b>esta chave é a única forma de abrir os dados</b>. Anote-a (papel, cofre ou gerenciador de senhas) e guarde <b>separada</b> do computador. Quem tiver a chave abre seus dados.</p>' +
      '<div id="sec-rk" style="font:700 1.25rem ui-monospace,Menlo,Consolas,monospace;letter-spacing:.06em;background:#0a1a2e;border:1px solid #345;border-radius:8px;padding:12px;text-align:center;user-select:all">' + chave + '</div>' +
      '<button id="sec-rk-cp" type="button" style="margin:8px 0;padding:6px 12px;border-radius:8px;border:1px solid #456;background:transparent;color:#fff;cursor:pointer">Copiar</button>' +
      '<p style="font-size:.85rem;margin:6px 0">Para confirmar que anotou, digite a chave abaixo:</p>' +
      '<input id="sec-rk-in" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid #345;background:#0a1a2e;color:#fff;text-transform:uppercase">' +
      '<div id="sec-rk-err" style="color:#f88;font-size:.85rem;min-height:1.2em"></div>' +
      '<button id="sec-rk-ok" type="button" style="width:100%;margin-top:8px;padding:10px;border-radius:8px;border:0;background:#0a6fc2;color:#fff;font-weight:600;cursor:pointer">Anotei a chave, continuar</button></div>';
    document.body.appendChild(d);
    d.querySelector('#sec-rk-cp').onclick = function () {
      try { navigator.clipboard.writeText(chave); } catch (e) {
        var r = document.createRange(); r.selectNodeContents(d.querySelector('#sec-rk')); var s = getSelection(); s.removeAllRanges(); s.addRange(r); try { document.execCommand('copy'); } catch (x) {}
      }
      d.querySelector('#sec-rk-cp').textContent = 'Copiado';
    };
    function ok() {
      if (normRec(d.querySelector('#sec-rk-in').value) !== normRec(chave)) { d.querySelector('#sec-rk-err').textContent = 'A chave digitada não confere. Confira o que anotou.'; return; }
      d.remove();
      try { var cc = SEC.cfg(); cc.recRegistrada = true; SEC.saveCfg(cc); } catch (e) {}
    }
    d.querySelector('#sec-rk-ok').onclick = ok;
    d.querySelector('#sec-rk-in').addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); });
    return d;
  };

  // Tela de abertura do arquivo cifrado: senha, com a opção "Esqueci a senha" (chave de recuperação).
  SEC.abrirCifrado = function (b64) {
    var K = SEC._chaveSis;
    if (!K) return SEC._abrirCifradoManual(b64);
    return SEC.unwrapFromHost(b64, K).then(function (plain) {
      SEC._sessionPassword = K;
      if (!SEC.modoSistema()) { var c = SEC.cfg(); c.modo = 'sistema'; c.senhaAtiva = true; delete c.verifier; delete c.verifier2; SEC.saveCfg(c); }
      return plain;
    }, function () { return SEC._abrirCifradoManual(b64); });
  };
  SEC._abrirCifradoManual = function (b64) {
    return new Promise(function (resolve) {
      var d = document.createElement('div'), modo = 'senha';
      d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(8,20,40,.97);display:flex;align-items:center;justify-content:center';
      d.innerHTML = '<div style="max-width:420px;width:90%;background:#0f2744;border-radius:12px;padding:24px;color:#fff;font-family:system-ui,sans-serif">' +
        '<h2 style="margin:0 0 8px;font-size:1.15rem">Dados protegidos</h2>' +
        '<p id="sec-o-txt" style="opacity:.85;font-size:.9rem;margin:0 0 14px">Os dados não abriram com a chave deste computador (arquivo vindo de outro computador ou usuário, ou criado com senha). Informe a senha do Valor-E ou use a chave de recuperação.</p>' +
        '<input id="sec-o-in" type="password" autocomplete="current-password" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid #345;margin-bottom:8px;background:#0a1a2e;color:#fff">' +
        '<div id="sec-o-err" style="color:#f88;font-size:.85rem;min-height:1.2em"></div>' +
        '<button id="sec-o-ok" type="button" style="width:100%;margin-top:8px;padding:10px;border-radius:8px;border:0;background:#0a6fc2;color:#fff;font-weight:600;cursor:pointer">Entrar</button>' +
        '<button id="sec-o-alt" type="button" style="width:100%;margin-top:8px;padding:8px;border:0;background:transparent;color:#9cc2ff;cursor:pointer;text-decoration:underline">Esqueci a senha</button></div>';
      document.body.appendChild(d);
      var inp = d.querySelector('#sec-o-in'), er = d.querySelector('#sec-o-err');
      function err(m) { er.textContent = m; }
      d.querySelector('#sec-o-alt').onclick = function () {
        modo = modo === 'senha' ? 'chave' : 'senha';
        inp.value = ''; err('');
        inp.type = modo === 'senha' ? 'password' : 'text';
        inp.placeholder = modo === 'senha' ? '' : 'XXXXX-XXXXX-XXXXX-XXXXX-XXXXX';
        d.querySelector('#sec-o-txt').textContent = modo === 'senha' ? 'Os dados não abriram com a chave deste computador. Informe a senha do Valor-E ou use a chave de recuperação.' : 'Digite a chave de recuperação (25 letras e números) que você anotou. Os dados passarão a usar a chave deste computador.';
        d.querySelector('#sec-o-alt').textContent = modo === 'senha' ? 'Esqueci a senha' : 'Voltar e usar a senha';
        inp.focus();
      };
      function ok() {
        var v = inp.value; if (!v) return;
        if (Date.now() < SEC._bloqAte) { err('Aguarde ' + Math.ceil((SEC._bloqAte - Date.now()) / 1000) + ' s para tentar novamente.'); return; }
        if (modo === 'senha') {
          SEC.unwrapFromHost(b64, v).then(function (plain) {
            SEC._falhas = 0; SEC._sessionPassword = v; d.remove();
            (SEC._chaveSis ? SEC.ativarSistema() : Promise.resolve()).then(function () { resolve(plain); });
          }).catch(function () {
            SEC._falhas++;
            if (SEC._falhas >= 3) SEC._bloqAte = Date.now() + Math.min(300, Math.pow(2, SEC._falhas - 2)) * 1000;
            err('Senha incorreta. Se a esqueceu, use "Esqueci a senha".');
          });
        } else {
          SEC.decryptComChave(b64, v).then(function (u) {
            SEC._falhas = 0; d.remove();
            if (SEC._chaveSis) return SEC.ativarSistema().then(function () { resolve(b64en(u)); });
            return SEC.exigirSenha('Defina uma nova senha', 'Chave aceita. Crie agora uma nova senha (mínimo ' + SEC.MIN_SENHA + ' caracteres, sem ser só números). A chave de recuperação continua valendo.').then(function () { resolve(b64en(u)); });
          }).catch(function (e) {
            SEC._falhas++;
            if (SEC._falhas >= 3) SEC._bloqAte = Date.now() + Math.min(300, Math.pow(2, SEC._falhas - 2)) * 1000;
            err((e && e.message) || 'Chave de recuperação incorreta.');
          });
        }
      }
      d.querySelector('#sec-o-ok').onclick = ok;
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); });
      setTimeout(function () { inp.focus(); }, 50);
    });
  };

  // Verificador da senha: PBKDF2 com sal próprio (nunca um hash simples).
  function pbkdfBits(senha, salt, iter) {
    return crypto.subtle.importKey('raw', u8(senha), 'PBKDF2', false, ['deriveBits']).then(function (base) {
      return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: salt, iterations: iter, hash: 'SHA-256' }, base, 256);
    }).then(function (b) { return new Uint8Array(b); });
  }
  function iguais(a, b) { if (a.length !== b.length) return false; var d = 0; for (var i = 0; i < a.length; i++) d |= a[i] ^ b[i]; return d === 0; }
  SEC.criarVerificador = function (senha) {
    var salt = crypto.getRandomValues(new Uint8Array(16));
    return pbkdfBits(senha, salt, SEC.ITERATIONS).then(function (h) {
      return { v: 2, iter: SEC.ITERATIONS, salt: b64en(salt), hash: b64en(h) };
    });
  };
  SEC.conferirVerificador = function (senha, ver) {
    return pbkdfBits(senha, b64de(ver.salt), ver.iter).then(function (h) { return iguais(h, b64de(ver.hash)); });
  };

  SEC.sha256Hex = function (text) {
    return crypto.subtle.digest('SHA-256', u8(text)).then(function (buf) {
      return Array.prototype.map.call(new Uint8Array(buf), function (b) {
        return ('0' + b.toString(16)).slice(-2);
      }).join('');
    });
  };

  SEC.cfg = function () {
    if (SEC._cfg) return SEC._cfg;
    try {
      SEC._cfg = JSON.parse((localStorage.getItem('valore_sec') || localStorage.getItem('vmap3_sec')) || '{}');
    } catch (e) { SEC._cfg = {}; }
    if (SEC._cfg.lockMin == null) SEC._cfg.lockMin = SEC.LOCK_MINUTES_DEFAULT;
    if (SEC._cfg.audit == null) SEC._cfg.audit = true;
    return SEC._cfg;
  };
  SEC.modoSistema = function () { return SEC.cfg().modo === 'sistema'; };
  SEC.saveCfg = function (c) {
    SEC._cfg = c;
    localStorage.setItem('valore_sec', JSON.stringify(c));
  };

  SEC.audit = function (acao, detalhe) {
    try {
      if (!SEC.cfg().audit || !w.DB || !DB.db) return;
      DB.db.run(
        "CREATE TABLE IF NOT EXISTS sec_auditoria (id INTEGER PRIMARY KEY AUTOINCREMENT, em TEXT DEFAULT (datetime('now','localtime')), usuario TEXT, acao TEXT, detalhe TEXT)"
      );
      var u = (SEC.usuario && SEC.usuario.login) || '';
      DB.db.run('INSERT INTO sec_auditoria (usuario, acao, detalhe) VALUES (?, ?, ?)', [u, String(acao || '').slice(0, 80), String(detalhe || '').slice(0, 500)]);
      if (DB.sujo) DB.sujo();
    } catch (e) {}
  };

  SEC.touch = function () {
    if (SEC._locked) return;
    clearTimeout(SEC._timer);
    var min = SEC.cfg().lockMin || 0;
    if (min <= 0 || !SEC.cfg().senhaAtiva || SEC.modoSistema()) return;
    SEC._timer = setTimeout(function () { SEC.lock(); }, min * 60 * 1000);
  };

  SEC.lock = function () {
    if (!SEC.cfg().senhaAtiva || SEC.modoSistema()) return;
    SEC._locked = true;
    if (SEC._ks && SEC._ks.dek) { var q = SEC._ks; SEC._pub = { iter: q.iter, saltP: q.saltP, ivP: q.ivP, wrapP: q.wrapP, saltR: q.saltR, ivR: q.ivR, wrapR: q.wrapR }; }
    SEC._key = null; SEC._ks = null; SEC._keep = null; SEC._sessionPassword = null;
    var el = document.getElementById('sec-lock');
    if (el) { el.style.display = 'flex'; return; }
    var d = document.createElement('div');
    d.id = 'sec-lock';
    d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(8,20,40,.92);display:flex;align-items:center;justify-content:center;flex-direction:column;color:#fff;font-family:system-ui,sans-serif';
    d.innerHTML = '<div style="max-width:360px;width:90%;background:#0f2744;border-radius:12px;padding:24px;box-shadow:0 12px 40px rgba(0,0,0,.4)">' +
      '<h2 style="margin:0 0 8px;font-size:1.2rem">Valor-E bloqueado</h2>' +
      '<p style="opacity:.85;font-size:.9rem;margin:0 0 16px">Sessão bloqueada por inatividade. Informe a senha de proteção dos dados.</p>' +
      '<input id="sec-lock-pwd" type="password" autocomplete="current-password" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid #345;margin-bottom:12px;background:#0a1a2e;color:#fff">' +
      '<div id="sec-lock-err" style="color:#f88;font-size:.85rem;min-height:1.2em;margin-bottom:8px"></div>' +
      '<button id="sec-lock-ok" style="width:100%;padding:10px;border:0;border-radius:8px;background:#0a6fc2;color:#fff;font-weight:600;cursor:pointer">Desbloquear</button></div>';
    document.body.appendChild(d);
    function tryUnlock() {
      var p = document.getElementById('sec-lock-pwd').value;
      SEC.unlockWithPassword(p).then(function () {
        SEC._locked = false;
        d.remove();
        if (w.DB && DB.sujo) DB.sujo();
        SEC.touch();
        SEC.audit('desbloqueio', 'sessão');
      }).catch(function (e) {
        document.getElementById('sec-lock-err').textContent = (e && e.message && e.message !== 'senha') ? e.message : 'Senha incorreta.';
      });
    }
    document.getElementById('sec-lock-ok').onclick = tryUnlock;
    document.getElementById('sec-lock-pwd').addEventListener('keydown', function (e) { if (e.key === 'Enter') tryUnlock(); });
  };

  SEC.unlockWithPassword = function (senha) {
    var agora = Date.now();
    if (agora < SEC._bloqAte) return Promise.reject(new Error('Aguarde ' + Math.ceil((SEC._bloqAte - agora) / 1000) + ' s para tentar novamente.'));
    var c = SEC.cfg();
    function falha() {
      SEC._falhas++;
      if (SEC._falhas >= 3) SEC._bloqAte = Date.now() + Math.min(300, Math.pow(2, SEC._falhas - 2)) * 1000;
      SEC.audit('senha_incorreta', 'tentativa ' + SEC._falhas);
      return Promise.reject(new Error('senha'));
    }
    function ok() {
      SEC._falhas = 0; SEC._bloqAte = 0; SEC._sessionPassword = senha;
      var q = SEC._pub;
      if (!q || SEC._ks) return Promise.resolve();
      return SEC.deriveKey(senha, q.saltP, q.iter).then(function (kek) { return desenvolver(kek, q.ivP, q.wrapP); })
        .then(function (dek) { return importDek(dek).then(function (dk) {
          SEC._key = dk; SEC._pub = null;
          SEC._ks = { senha: senha, iter: q.iter, saltP: q.saltP, ivP: q.ivP, wrapP: q.wrapP, saltR: q.saltR, ivR: q.ivR, wrapR: q.wrapR, dek: dek, dekKey: dk };
        }); })
        .catch(function () { SEC._sessionPassword = null; return falha(); });
    }
    if (c.verifier2) return SEC.conferirVerificador(senha, c.verifier2).then(function (b) { return b ? ok() : falha(); });
    if (c.verifier) { // legado (SHA-256 simples): confere e migra para o verificador PBKDF2
      return SEC.sha256Hex('vmap3|' + senha).then(function (h) {
        if (h !== c.verifier) return falha();
        return SEC.criarVerificador(senha).then(function (v) { var cc = SEC.cfg(); cc.verifier2 = v; delete cc.verifier; SEC.saveCfg(cc); return ok(); });
      });
    }
    return ok();
  };

  SEC.promptPassword = function (titulo, texto, minLen) {
    return new Promise(function (resolve, reject) {
      var d = document.createElement('div');
      d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(8,20,40,.92);display:flex;align-items:center;justify-content:center';
      d.innerHTML = '<div style="max-width:400px;width:90%;background:#0f2744;border-radius:12px;padding:24px;color:#fff;font-family:system-ui,sans-serif">' +
        '<h2 style="margin:0 0 8px;font-size:1.15rem">' + (titulo || 'Senha') + '</h2>' +
        '<p style="opacity:.85;font-size:.9rem;margin:0 0 14px">' + (texto || '') + '</p>' +
        '<input id="sec-pw" type="password" autocomplete="current-password" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid #345;margin-bottom:10px;background:#0a1a2e;color:#fff">' +
        '<div id="sec-pw-err" style="color:#f88;font-size:.85rem;min-height:1.2em"></div>' +
        '<div style="display:flex;gap:8px;margin-top:10px">' +
        '<button id="sec-pw-cancel" style="flex:1;padding:10px;border-radius:8px;border:1px solid #456;background:transparent;color:#fff;cursor:pointer">Cancelar</button>' +
        '<button id="sec-pw-ok" style="flex:1;padding:10px;border-radius:8px;border:0;background:#0a6fc2;color:#fff;font-weight:600;cursor:pointer">Continuar</button></div></div>';
      document.body.appendChild(d);
      var inp = d.querySelector('#sec-pw');
      function ok() {
        var v = inp.value;
        var mn = minLen == null ? 1 : minLen;
        if (!v || v.length < mn) { d.querySelector('#sec-pw-err').textContent = 'Use ao menos ' + mn + ' caracteres.'; return; }
        if (mn > 1 && (/^(.)\1+$/.test(v) || /^\d+$/.test(v))) { d.querySelector('#sec-pw-err').textContent = 'Senha fraca: misture letras, números ou símbolos.'; return; }
        d.remove(); resolve(v);
      }
      d.querySelector('#sec-pw-ok').onclick = ok;
      d.querySelector('#sec-pw-cancel').onclick = function () { d.remove(); reject(new Error('cancelado')); };
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); });
      setTimeout(function () { inp.focus(); }, 50);
    });
  };

  // Criação obrigatória de senha (sem cancelar). Resolve depois de cifrar.
  SEC.exigirSenha = function (titulo, texto) {
    return new Promise(function (resolve) {
      var d = document.createElement('div');
      d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(8,20,40,.96);display:flex;align-items:center;justify-content:center';
      d.innerHTML = '<div style="max-width:430px;width:90%;background:#0f2744;border-radius:12px;padding:24px;color:#fff;font-family:system-ui,sans-serif">' +
        '<h2 style="margin:0 0 8px;font-size:1.15rem">' + (titulo || 'Crie a senha do Valor-E') + '</h2>' +
        '<p style="opacity:.85;font-size:.9rem;margin:0 0 14px">' + (texto || 'Seus dados serão cifrados com esta senha. Mínimo de ' + SEC.MIN_SENHA + ' caracteres, sem ser só números. Depois você receberá uma <b>chave de recuperação</b>, para o caso de esquecer a senha.') + '</p>' +
        '<input id="sec-n1" type="password" placeholder="Nova senha" autocomplete="new-password" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid #345;margin-bottom:8px;background:#0a1a2e;color:#fff">' +
        '<input id="sec-n2" type="password" placeholder="Repita a senha" autocomplete="new-password" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid #345;margin-bottom:8px;background:#0a1a2e;color:#fff">' +
        '<div id="sec-n-err" style="color:#f88;font-size:.85rem;min-height:1.2em"></div>' +
        '<button id="sec-n-ok" style="width:100%;margin-top:10px;padding:10px;border-radius:8px;border:0;background:#0a6fc2;color:#fff;font-weight:600;cursor:pointer">Definir senha e continuar</button></div>';
      document.body.appendChild(d);
      var a = d.querySelector('#sec-n1'), b = d.querySelector('#sec-n2'), er = d.querySelector('#sec-n-err');
      function ok() {
        var v = a.value;
        if (v.length < SEC.MIN_SENHA) { er.textContent = 'Use ao menos ' + SEC.MIN_SENHA + ' caracteres.'; return; }
        if (/^(.)\1+$/.test(v) || /^\d+$/.test(v)) { er.textContent = 'Senha fraca: misture letras, números ou símbolos.'; return; }
        if (v !== b.value) { er.textContent = 'As senhas não coincidem.'; return; }
        SEC._sessionPassword = v;
        SEC.enablePassword(v).then(function () { d.remove(); resolve(v); });
      }
      d.querySelector('#sec-n-ok').onclick = ok;
      [a, b].forEach(function (i) { i.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); }); });
      setTimeout(function () { a.focus(); }, 50);
    });
  };

  SEC.enablePassword = function (senha) {
    var q = SEC._ks;
    SEC._keep = (q && q.dek) ? { dek: q.dek, saltR: q.saltR, ivR: q.ivR, wrapR: q.wrapR } : null;
    SEC._ks = null;
    return SEC.criarVerificador(senha).then(function (v) {
      var c = SEC.cfg();
      c.senhaAtiva = true;
      c.verifier2 = v;
      delete c.verifier;
      SEC.saveCfg(c);
      SEC.audit('senha_ativada', 'proteção de dados em repouso');
    });
  };

  // Chave do sistema (v2): a chave aleatória guardada pelo aplicativo nativo cifra os dados, sem senha para o usuário.
  SEC.ativarSistema = function () {
    SEC._sessionPassword = SEC._chaveSis;
    return SEC.enablePassword(SEC._chaveSis).then(function () {
      var c = SEC.cfg(); c.modo = 'sistema'; delete c.verifier; delete c.verifier2; SEC.saveCfg(c);
      SEC.audit('cifra_sistema', 'chave do sistema ativada');
    });
  };

  SEC.disablePassword = function () {
    var c = SEC.cfg();
    c.senhaAtiva = false;
    delete c.verifier; delete c.verifier2;
    SEC.saveCfg(c);
    SEC._key = null; SEC._ks = null;
    SEC.audit('senha_desativada', '');
  };

  SEC.wrapForHost = function (plainB64) {
    var c = SEC.cfg();
    if (!c.senhaAtiva || !c._plainPassword) {
      // if senha ativa, password must be in session
      if (!c.senhaAtiva) return Promise.resolve(plainB64);
    }
    var senha = SEC._sessionPassword;
    if (!senha) return Promise.reject(new Error('Dados bloqueados: nada foi gravado em claro.'));
    var plain = (function () {
      var s = atob(plainB64), u = new Uint8Array(s.length);
      for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
      return u;
    })();
    return SEC.encryptBytes(plain, senha).then(function (b) {
      if (SEC._recPendente) { var ch = SEC._recPendente; SEC._recPendente = null; setTimeout(function () { SEC.mostrarChaveRec(ch); }, 0); }
      return b;
    });
  };

  SEC.unwrapFromHost = function (b64, senha) {
    if (!SEC.isEncryptedBlob(b64)) return Promise.resolve(b64);
    return SEC.decryptBytes(b64, senha).then(function (u8a) {
      SEC._sessionPassword = senha;
      var c = SEC.cfg();
      var adota = (!c.senhaAtiva || !(c.verifier2 || c.verifier)) ? SEC.enablePassword(senha) : Promise.resolve();
      return adota.then(function () { return b64en(u8a); });
    });
  };

  /* Sanitização de HTML (rich text) importado. XML (BPMN/Folha) é preservado. */
  var RE_HTML = /<\/?(p|div|span|ul|ol|li|br|h[1-6]|strong|b|em|i|u|s|a|img|table|thead|tbody|tr|td|th|blockquote|pre|code|script|iframe|svg|style|object|embed|form|input|button|link|meta|base)\b/i;
  var RE_XML = /^\s*<\?xml|xmlns|<bpmn|<definitions|<folha|<vmap/i;
  SEC.sanitizarTexto = function (t) {
    if (typeof t !== 'string' || t.indexOf('<') < 0 || !w.DOMPurify) return t;
    if (RE_XML.test(t) || !RE_HTML.test(t)) return t;
    return w.DOMPurify.sanitize(t, {
      ALLOWED_TAGS: ['p','div','span','br','ul','ol','li','h1','h2','h3','h4','h5','h6','strong','b','em','i','u','s','a','img','table','thead','tbody','tr','td','th','blockquote','pre','code','sub','sup','hr'],
      ALLOWED_ATTR: ['href','src','alt','title','class','style','colspan','rowspan','target','rel'],
      ALLOWED_URI_REGEXP: /^(?:https?:|mailto:|data:image\/(?:png|jpe?g|gif|webp);base64,|#)/i,
      FORBID_TAGS: ['style','script','iframe','object','embed','form','input','button','link','meta','base','svg']
    });
  };
  SEC.sanitizarObjeto = function (o, prof) {
    prof = prof || 0; if (prof > 12) return o;
    if (typeof o === 'string') return SEC.sanitizarTexto(o);
    if (Array.isArray(o)) { for (var i = 0; i < o.length; i++) o[i] = SEC.sanitizarObjeto(o[i], prof + 1); return o; }
    if (o && typeof o === 'object') { Object.keys(o).forEach(function (k) { o[k] = SEC.sanitizarObjeto(o[k], prof + 1); }); }
    return o;
  };

  SEC.validateImportText = function (txt) {
    if (txt == null) throw new Error('Arquivo vazio.');
    if (typeof txt !== 'string') throw new Error('Formato inválido.');
    if (txt.length > SEC.MAX_IMPORT_BYTES) throw new Error('Arquivo acima do limite de segurança (' + Math.round(SEC.MAX_IMPORT_BYTES / 1024 / 1024) + ' MB).');
    // bloqueia padrões perigosos óbvios em pacotes
    if (/<\s*script/i.test(txt) && /axia-pacote|nomika-pacote|tabelas/.test(txt) === false) {
      // allow only if it's not a package - still strip
    }
    if (/\u0000/.test(txt.slice(0, 10000))) throw new Error('Arquivo contém bytes nulos — importação recusada.');
    return true;
  };


  /* ---------- usuários locais (admin / editor / leitor) ---------- */






  SEC.pode = function (minPapel) { return true; };
  SEC.exigir = function (minPapel, msg) { return true; };




  SEC.gateLogin = function () { return Promise.resolve(); };

  /* Cifra de campo sensível (AES-GCM com chave derivada da senha de sessão ou da senha do banco) */
  SEC.cifrarCampo = function (texto) {
    var senha = SEC._sessionPassword || (SEC.usuario && SEC.usuario.login);
    if (!senha || texto == null || texto === '') return Promise.resolve(texto);
    var plain = u8(String(texto));
    var salt = crypto.getRandomValues(new Uint8Array(16));
    var iv = crypto.getRandomValues(new Uint8Array(12));
    return SEC.deriveKey(String(senha) + '|campo', salt).then(function (key) {
      return crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, plain);
    }).then(function (ct) {
      return 'ENC1:' + b64en(concat(salt, iv, new Uint8Array(ct)));
    });
  };
  SEC.decifrarCampo = function (blob) {
    if (!blob || String(blob).indexOf('ENC1:') !== 0) return Promise.resolve(blob);
    var senha = SEC._sessionPassword || (SEC.usuario && SEC.usuario.login);
    if (!senha) return Promise.reject(new Error('Sem chave de sessão para decifrar.'));
    var raw = b64de(String(blob).slice(5));
    var salt = raw.subarray(0, 16), iv = raw.subarray(16, 28), ct = raw.subarray(28);
    return SEC.deriveKey(String(senha) + '|campo', salt).then(function (key) {
      return crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, key, ct);
    }).then(function (buf) { return new TextDecoder().decode(buf); });
  };


  SEC.installActivityWatchers = function () {
    ['click', 'keydown', 'mousemove', 'scroll', 'touchstart'].forEach(function (ev) {
      document.addEventListener(ev, function () { SEC.touch(); }, { passive: true });
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && SEC.cfg().senhaAtiva && SEC.cfg().lockOnHide) SEC.lock();
    });
  };

  SEC.cartaoUI = function (h) {
    h = h || function (s) { return String(s); };
    var c = SEC.cfg();
    if (SEC.modoSistema()) {
      return '<div class="cartao mb-3"><h2><i class="bi bi-shield-lock"></i> Segurança</h2><div class="corpo">' +
        '<p class="ajuda">Os dados em disco são <b>cifrados automaticamente</b>, sem nenhuma ação sua e sem senha para digitar. Nada é enviado a servidor algum.</p>' +
        '<ul class="small mb-3">' +
        '<li><b>Cifragem AES-256-GCM</b> do arquivo de dados, com chave aleatória guardada pelo sistema (no Windows, protegida pela conta do usuário via DPAPI; no macOS e no Linux, em arquivo restrito ao usuário)</li>' +
        '<li>O arquivo de dados, copiado sozinho (e-mail, nuvem, backup, pen drive), não abre em outro computador</li>' +
        '<li>Integridade SHA-256 nos pacotes de exportação, auditoria local e HTML importado sanitizado (DOMPurify)</li></ul>' +
        '<p class="ajuda mb-0"><b>Backup:</b> para trocar de computador ou reinstalar o sistema, use <b>Exportar tudo</b> (logo abaixo) e guarde o arquivo em local seguro. Sem a chave deste computador e sem um backup, os dados não podem ser abertos (não existe acesso reserva).</p>' +
        '</div></div>';
    }
    return '<div class="cartao mb-3"><h2><i class="bi bi-shield-lock"></i> Segurança</h2><div class="corpo">' +
      '<p class="ajuda">Proteção local dos dados do Valor-E. A senha <b>não é enviada a nenhum servidor</b> — só existe neste equipamento.</p>' +
      '<ul class="small mb-3">' +
      '<li><b>Cifragem AES-256-GCM</b> do arquivo de dados, chave por PBKDF2-SHA-256 (600 mil iterações) e cabeçalho autenticado</li><li><b>Chave de recuperação</b> (125 bits) para redefinir a senha esquecida</li>' +
      '<li>Bloqueio automático por inatividade</li>' +
      '<li>Integridade SHA-256 nos pacotes de exportação</li>' +
      '<li>Auditoria local de ações sensíveis</li>' +
      '<li>Limite e validação na importação; HTML importado é sanitizado (DOMPurify)</li><li>Bloqueio com espera crescente após senhas erradas</li></ul>' +
      '<p><b>Status:</b> ' + (c.senhaAtiva ? '<span class="text-success">proteção por senha ativa</span>' : '<span class="text-danger">sem senha — defina agora</span>') + '</p>' +
      '<div class="d-flex flex-wrap gap-2 mb-2">' +
      (c.senhaAtiva
        ? '<button type="button" class="btn btn-outline-primary btn-sm" onclick="SEC.uiAlterar()">Alterar senha</button><button type="button" class="btn btn-outline-secondary btn-sm" onclick="SEC.lock()">Bloquear agora</button><button type="button" class="btn btn-outline-warning btn-sm" onclick="SEC.novaChaveRec()">Nova chave de recuperação</button>'
        : '<button type="button" class="btn btn-success btn-sm" onclick="SEC.uiAtivar()">Definir senha e cifrar dados</button>') +
      '</div>' +
      '<div class="row g-2 align-items-end">' +
      '<div class="col-auto"><label class="form-label small mb-0">Bloquear após (minutos)</label>' +
      '<input type="number" min="0" max="240" class="form-control form-control-sm" id="sec-lock-min" value="' + (c.lockMin || 0) + '" style="width:90px"></div>' +
      '<div class="col-auto"><div class="form-check mt-3"><input class="form-check-input" type="checkbox" id="sec-lock-hide"' + (c.lockOnHide ? ' checked' : '') + '><label class="form-check-label small" for="sec-lock-hide">Bloquear ao minimizar/ocultar</label></div></div>' +
      '<div class="col-auto"><div class="form-check mt-3"><input class="form-check-input" type="checkbox" id="sec-audit"' + (c.audit !== false ? ' checked' : '') + '><label class="form-check-label small" for="sec-audit">Registrar auditoria</label></div></div>' +
      '<div class="col-auto"><button type="button" class="btn btn-outline-primary btn-sm" onclick="SEC.uiSalvarPrefs()">Salvar preferências</button></div>' +
      '</div>' +
      '<p class="ajuda mt-2 mb-0">0 minutos = sem bloqueio por tempo. Se esquecer a senha, abra o aplicativo e use <b>Esqueci a senha</b> com a chave de recuperação. <b>Sem a senha e sem a chave, os dados não podem ser recuperados</b> (não existe acesso reserva).</p>' +
      '</div></div>';
  };

  SEC.uiAtivar = function () {
    SEC.promptPassword('Definir senha', 'Mínimo 10 caracteres, sem ser só números. Guarde-a com segurança — sem ela os dados cifrados não abrem.', SEC.MIN_SENHA).then(function (s1) {
      return SEC.promptPassword('Confirmar senha', 'Digite a mesma senha novamente.', 1).then(function (s2) {
        if (s1 !== s2) { alert('As senhas não coincidem.'); return; }
        SEC._sessionPassword = s1;
        return SEC.enablePassword(s1).then(function () {
          if (w.DB && DB.sujo) DB.sujo();
          alert('Proteção ativada. Os próximos salvamentos gravarão o banco cifrado.');
          if (w.Nav && Nav.ir) Nav.ir('#/dados');
        });
      });
    }).catch(function () {});
  };
  SEC.uiAlterar = function () {
    SEC.promptPassword('Alterar senha', 'Informe a senha atual.').then(function (atual) {
      return SEC.unlockWithPassword(atual).then(function () {
        SEC.exigirSenha('Nova senha', 'Defina a nova senha (mínimo ' + SEC.MIN_SENHA + ' caracteres). Os dados serão regravados com a nova chave.').then(function () {
          if (w.DB && DB.sujo) DB.sujo();
          alert('Senha alterada.');
        });
      });
    }).catch(function (e) { if (e && e.message !== 'cancelado') alert(e.message && e.message !== 'senha' ? e.message : 'Senha incorreta.'); });
  };
  SEC.uiDesativar = function () { alert('A proteção por senha é obrigatória no Valor-E e não pode ser removida.'); };
  SEC._uiDesativarLegado = function () {
    SEC.promptPassword('Remover senha', 'Informe a senha atual para gravar o banco sem cifra.').then(function (s) {
      return SEC.unlockWithPassword(s).then(function () {
        SEC._sessionPassword = null;
        SEC.disablePassword();
        if (w.DB && DB.sujo) DB.sujo();
        alert('Senha removida. O arquivo de dados será gravado sem cifra da aplicação.');
        if (w.Nav && Nav.ir) Nav.ir('#/dados');
      });
    }).catch(function (e) { if (e && e.message !== 'cancelado') alert('Senha incorreta.'); });
  };
  SEC.uiSalvarPrefs = function () {
    var c = SEC.cfg();
    c.lockMin = parseInt((document.getElementById('sec-lock-min') || {}).value, 10) || 0;
    c.lockOnHide = !!(document.getElementById('sec-lock-hide') || {}).checked;
    c.audit = !!(document.getElementById('sec-audit') || {}).checked;
    SEC.saveCfg(c);
    SEC.touch();
    alert('Preferências de segurança salvas.');
  };
})(window);
