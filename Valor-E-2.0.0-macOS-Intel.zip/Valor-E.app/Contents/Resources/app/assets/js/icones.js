/* Ícones BPMN 24px (paleta) + catálogo de tipos para o item 7 */
(function (g) {
  var S = 'width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"';
  var TK = '<rect x="3" y="5" width="18" height="14" rx="2.5" fill="#ddebf7" stroke="#2e74b5" stroke-width="1.6"/>';
  var GW = '<polygon points="12,2.5 21.5,12 12,21.5 2.5,12" fill="#fff2cc" stroke="#bf8f00" stroke-width="1.6"/>';
  var EV = '<circle cx="12" cy="12" r="8" fill="#fff2e8" stroke="#c55a11" stroke-width="1.8"/>';
  var B = {
    'bpmn:StartEvent': '<circle cx="12" cy="12" r="8" fill="#e2f0d9" stroke="#548235" stroke-width="1.8"/>',
    'bpmn:EndEvent': '<circle cx="12" cy="12" r="8" fill="#fde9e7" stroke="#c00000" stroke-width="2.6"/>',
    'bpmn:IntermediateThrowEvent': EV + '<circle cx="12" cy="12" r="5.6" fill="none" stroke="#c55a11" stroke-width="1.3"/>',
    'bpmn:TimerEvent': EV + '<circle cx="12" cy="12" r="5.6" fill="none" stroke="#c55a11" stroke-width="1.2"/><path d="M12 12V8.5M12 12l3 1.8" fill="none" stroke="#c55a11" stroke-width="1.5" stroke-linecap="round"/>',
    'bpmn:MessageEvent': EV + '<rect x="7" y="9" width="10" height="7" rx="1" fill="none" stroke="#c55a11" stroke-width="1.3"/><path d="M7.3 9.5L12 13l4.7-3.5" fill="none" stroke="#c55a11" stroke-width="1.3"/>',
    'bpmn:Task': TK,
    'bpmn:UserTask': TK + '<circle cx="8" cy="10" r="1.7" fill="none" stroke="#2e74b5" stroke-width="1.2"/><path d="M5.7 15c.7-2 4-2 4.7 0" fill="none" stroke="#2e74b5" stroke-width="1.2"/>',
    'bpmn:ManualTask': TK + '<path d="M6 13V9.5a1 1 0 0 1 2 0V12V8.5a1 1 0 0 1 2 0V12V9a1 1 0 0 1 2 0v4c0 2-1.3 3-3 3-1.4 0-2.4-.9-3-2z" fill="none" stroke="#2e74b5" stroke-width="1.1" stroke-linejoin="round"/>',
    'bpmn:ServiceTask': TK + '<circle cx="8" cy="12" r="2.2" fill="none" stroke="#2e74b5" stroke-width="1.2"/><path d="M8 8.5v1M8 14.5v1M4.5 12h1M10.5 12h1M5.5 9.5l.7.7M9.8 13.8l.7.7M10.5 9.5l-.7.7M6.2 13.8l-.7.7" stroke="#2e74b5" stroke-width="1"/>',
    'bpmn:ScriptTask': TK + '<path d="M7 9h10M7 12h7M7 15h5" stroke="#2e74b5" stroke-width="1.2"/>',
    'bpmn:BusinessRuleTask': TK + '<rect x="6" y="8" width="12" height="8" fill="none" stroke="#2e74b5" stroke-width="1.1"/><path d="M6 10.7h12M6 13.3h12M10 8v8" stroke="#2e74b5" stroke-width="1"/>',
    'bpmn:SendTask': TK + '<rect x="6.5" y="9" width="11" height="7" rx="1" fill="#2e74b5" stroke="#2e74b5" stroke-width="1"/><path d="M6.8 9.4L12 13.2l5.2-3.8" fill="none" stroke="#fff" stroke-width="1.1"/>',
    'bpmn:ReceiveTask': TK + '<rect x="6.5" y="9" width="11" height="7" rx="1" fill="none" stroke="#2e74b5" stroke-width="1.2"/><path d="M6.8 9.4L12 13.2l5.2-3.8" fill="none" stroke="#2e74b5" stroke-width="1.1"/>',
    'bpmn:SubProcess': TK + '<rect x="9" y="14" width="6" height="4" fill="#fff" stroke="#2e74b5" stroke-width="1"/><path d="M12 14.8v2.4M10.8 16h2.4" stroke="#2e74b5" stroke-width="1"/>',
    'bpmn:ExclusiveGateway': GW + '<path d="M8.3 8.3l7.4 7.4M15.7 8.3l-7.4 7.4" stroke="#bf8f00" stroke-width="1.8" stroke-linecap="round"/>',
    'bpmn:ParallelGateway': GW + '<path d="M12 7v10M7 12h10" stroke="#bf8f00" stroke-width="1.8" stroke-linecap="round"/>',
    'bpmn:InclusiveGateway': GW + '<circle cx="12" cy="12" r="3.7" fill="none" stroke="#bf8f00" stroke-width="1.8"/>',
    'bpmn:EventBasedGateway': GW + '<circle cx="12" cy="12" r="4.2" fill="none" stroke="#bf8f00" stroke-width="1.2"/><circle cx="12" cy="12" r="1.4" fill="#bf8f00"/>',
    'bpmn:DataObject': '<path d="M6 3.5h8l4 4v13H6z" fill="#f2f2f2" stroke="#7f7f7f" stroke-width="1.4"/><path d="M14 3.5v4h4" fill="none" stroke="#7f7f7f" stroke-width="1.1"/>',
    'bpmn:DataStore': '<ellipse cx="12" cy="7" rx="7" ry="3" fill="#f2f2f2" stroke="#7f7f7f" stroke-width="1.4"/><path d="M5 7v9c0 1.7 3.1 3 7 3s7-1.3 7-3V7" fill="#f2f2f2" stroke="#7f7f7f" stroke-width="1.4"/><path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3" fill="none" stroke="#7f7f7f" stroke-width="1.1"/>',
    'bpmn:TextAnnotation': '<path d="M9.5 4.5H6v15h3.5" fill="none" stroke="#7f7f7f" stroke-width="1.4" stroke-linecap="square"/><path d="M9.5 9.5h8M9.5 12.5h8M9.5 15.5h5" stroke="#7f7f7f" stroke-width="1.1" stroke-linecap="round"/>'
  };
  // ---- variantes de eventos (marcadores) ----
  var MK = {
    message: function (c, f) { return '<rect x="7.2" y="9" width="9.6" height="6.4" rx="1" fill="' + (f ? c : 'none') + '" stroke="' + c + '" stroke-width="1.2"/><path d="M7.4 9.4L12 13l4.6-3.6" fill="none" stroke="' + (f ? '#fff' : c) + '" stroke-width="1.1"/>'; },
    timer: function (c) { return '<circle cx="12" cy="12" r="4.4" fill="none" stroke="' + c + '" stroke-width="1.1"/><path d="M12 12V9M12 12l2 1.4" fill="none" stroke="' + c + '" stroke-width="1.2" stroke-linecap="round"/>'; },
    conditional: function (c) { return '<rect x="8.5" y="8" width="7" height="8" fill="none" stroke="' + c + '" stroke-width="1.1"/><path d="M9.7 10.2h4.6M9.7 12h4.6M9.7 13.8h4.6" stroke="' + c + '" stroke-width="1"/>'; },
    signal: function (c, f) { return '<path d="M12 8l4.2 7.6H7.8z" fill="' + (f ? c : 'none') + '" stroke="' + c + '" stroke-width="1.2" stroke-linejoin="round"/>'; },
    link: function (c, f) { return '<path d="M8 10.5h4V8.5l4 3.5-4 3.5v-2H8z" fill="' + (f ? c : 'none') + '" stroke="' + c + '" stroke-width="1.1" stroke-linejoin="round"/>'; },
    escalation: function (c, f) { return '<path d="M12 7.5l4 8.3-4-2.4-4 2.4z" fill="' + (f ? c : 'none') + '" stroke="' + c + '" stroke-width="1.1" stroke-linejoin="round"/>'; },
    error: function (c, f) { return '<path d="M8 15.8l2.3-6.3 2.2 3.8 3.5-5.3-2 8.1-2.3-3.8z" fill="' + (f ? c : 'none') + '" stroke="' + c + '" stroke-width="1" stroke-linejoin="round"/>'; },
    cancel: function (c, f) { return '<path d="M8.6 8.6l6.8 6.8M15.4 8.6l-6.8 6.8" stroke="' + c + '" stroke-width="' + (f ? 2 : 1.4) + '" stroke-linecap="round"/>'; },
    compensation: function (c, f) { return '<path d="M12 12l4-2.7v5.4zM8 12l4-2.7v5.4z" fill="' + (f ? c : 'none') + '" stroke="' + c + '" stroke-width="1.1" stroke-linejoin="round"/>'; },
    terminate: function (c) { return '<circle cx="12" cy="12" r="4" fill="' + c + '"/>'; }
  };
  [['bpmn:StartEvent', '#e2f0d9', '#548235', 1.8, 0, 0], ['bpmn:IntermediateCatchEvent', '#fff2e8', '#c55a11', 1.8, 1, 0], ['bpmn:IntermediateThrowEvent', '#fff2e8', '#c55a11', 1.8, 1, 1], ['bpmn:EndEvent', '#fde9e7', '#c00000', 2.6, 0, 1]].forEach(function (g) {
    ['message', 'timer', 'conditional', 'signal', 'link', 'escalation', 'error', 'cancel', 'compensation', 'terminate'].forEach(function (d) {
      B[g[0] + '_' + d] = '<circle cx="12" cy="12" r="8" fill="' + g[1] + '" stroke="' + g[2] + '" stroke-width="' + g[3] + '"/>' + (g[4] ? '<circle cx="12" cy="12" r="5.6" fill="none" stroke="' + g[2] + '" stroke-width="1.2"/>' : '') + MK[d](g[2], g[5]);
    });
  });
  B['bpmn:CallActivity'] = TK.replace('stroke-width="1.6"', 'stroke-width="2.8"') + '<rect x="9" y="14" width="6" height="4" fill="#fff" stroke="#2e74b5" stroke-width="1"/>';
  B['bpmn:AdHocSubProcess'] = TK + '<path d="M7 16c1-1.6 2-1.6 3 0s2 1.6 3 0" fill="none" stroke="#2e74b5" stroke-width="1.2"/>';
  B['bpmn:Transaction'] = TK + '<rect x="5" y="7" width="14" height="10" rx="1.5" fill="none" stroke="#2e74b5" stroke-width="1"/>';
  B['bpmn:ComplexGateway'] = GW + '<path d="M12 7v10M7 12h10M8.4 8.4l7.2 7.2M15.6 8.4l-7.2 7.2" stroke="#bf8f00" stroke-width="1.5" stroke-linecap="round"/>';
  g.BPMN_ICON = function (t) { return '<svg ' + S + '>' + (B[t] || '<rect x="4" y="4" width="16" height="16" rx="3" fill="#f2f2f2" stroke="#888"/>') + '</svg>'; };
  var EVR = function (b, nomes) { return nomes.map(function (n) { return [b + '_' + n[0], n[1]]; }); };
  g.BPMN_GRUPOS = [
    { g: 'Eventos de início', itens: [['bpmn:StartEvent', 'Início (nenhum)']].concat(EVR('bpmn:StartEvent', [['message', 'Início por mensagem'], ['timer', 'Início por tempo'], ['conditional', 'Início condicional'], ['signal', 'Início por sinal']])) },
    { g: 'Eventos intermediários', itens: [['bpmn:IntermediateThrowEvent', 'Intermediário (nenhum)'], ['bpmn:TimerEvent', 'Captura: tempo'], ['bpmn:MessageEvent', 'Captura: mensagem']].concat(EVR('bpmn:IntermediateCatchEvent', [['conditional', 'Captura: condicional'], ['link', 'Captura: link'], ['signal', 'Captura: sinal']]), EVR('bpmn:IntermediateThrowEvent', [['message', 'Lançamento: mensagem'], ['escalation', 'Lançamento: escalonamento'], ['link', 'Lançamento: link'], ['compensation', 'Lançamento: compensação'], ['signal', 'Lançamento: sinal']])) },
    { g: 'Eventos de fim', itens: [['bpmn:EndEvent', 'Fim (nenhum)']].concat(EVR('bpmn:EndEvent', [['message', 'Fim: mensagem'], ['escalation', 'Fim: escalonamento'], ['error', 'Fim: erro'], ['cancel', 'Fim: cancelamento'], ['compensation', 'Fim: compensação'], ['signal', 'Fim: sinal'], ['terminate', 'Fim: encerramento']])) },
    { g: 'Atividades', itens: [['bpmn:Task', 'Tarefa'], ['bpmn:UserTask', 'Tarefa de usuário'], ['bpmn:ManualTask', 'Tarefa manual'], ['bpmn:ServiceTask', 'Tarefa de serviço (sistema)'], ['bpmn:ScriptTask', 'Tarefa de script'], ['bpmn:BusinessRuleTask', 'Tarefa de regra de negócio'], ['bpmn:SendTask', 'Tarefa de envio'], ['bpmn:ReceiveTask', 'Tarefa de recebimento'], ['bpmn:SubProcess', 'Subprocesso'], ['bpmn:CallActivity', 'Atividade chamada (call activity)'], ['bpmn:AdHocSubProcess', 'Subprocesso ad-hoc'], ['bpmn:Transaction', 'Transação']] },
    { g: 'Gateways', itens: [['bpmn:ExclusiveGateway', 'Decisão (exclusivo)'], ['bpmn:ParallelGateway', 'Paralelo (E)'], ['bpmn:InclusiveGateway', 'Inclusivo (OU)'], ['bpmn:EventBasedGateway', 'Baseado em evento'], ['bpmn:ComplexGateway', 'Complexo']] },
    { g: 'Artefatos', itens: [['bpmn:DataObject', 'Dados / documento'], ['bpmn:DataStore', 'Armazenamento / sistema'], ['bpmn:TextAnnotation', 'Anotação']] }
  ];
  g.BPMN_ROTULO = {};
  g.BPMN_GRUPOS.forEach(function (gr) { gr.itens.forEach(function (i) { g.BPMN_ROTULO[i[0]] = i[1]; }); });
  g.BPMN_CAT = function (t) {
    if (/Event/.test(t)) return 'evento';
    if (/Gateway/.test(t)) return 'gateway';
    if (/DataObject|DataStore|TextAnnotation/.test(t)) return 'artefato';
    return t ? 'tarefa' : '';
  };
})(window);
