/* pacote.js — exportar / importar TUDO (todas as tabelas, todos os módulos) em JSON ou XML, com remapeamento de vínculos (modo "mesclar") ou restauração integral (modo "substituir"). */
(function (w) {
  'use strict';
  var h = E.esc, FORMATO = 'axia-pacote', VERSAO = '4.0';
  // vínculos lógicos (além das FKs declaradas): tabela.coluna -> tabela pai
  var LOGICAS = {
    '*.processo_id': 'processos', '*.flag_id': 'flags', '*.macro_id': 'macroprocessos', '*.risco_id': 'riscos', '*.objetivo_id': 'objetivos_estrategicos',
    '*.capacidade_id': 'capacidades', '*.acao_id': 'acoes_estrategicas', '*.iniciativa_id': 'iniciativas_estrategicas', 'projetos.mapa_id': 'me_mapas', '*.projeto_id': 'projetos', 'proj_deps.pred_id': 'proj_tarefas', 'proj_deps.succ_id': 'proj_tarefas', 'proj_tarefas.parent_id': 'proj_tarefas', 'proj_tarefas.recurso_id': 'proj_recursos', 'projetos.mapa_id': 'me_mapas', '*.indicador_id': 'indicadores', '*.item_id': 'indicador_itens', '*.validado_ciclo_id': 'cva_ciclos',
    'controles.fator_id': 'fatores', 'indicador_fatores.fator_id': 'fatores_determinantes', 'fatores_determinantes.capacidade_id': 'capacidades',
    'me_perspectivas.mapa_id': 'me_mapas', 'me_temas.perspectiva_id': 'me_perspectivas', 'me_objetivos.perspectiva_id': 'me_perspectivas', 'me_objetivos.tema_id': 'me_temas', 'me_objetivos.oe_id': 'objetivos_estrategicos',
    'macroprocessos.ciclo_id': 'cva_ciclos', 'cva_validacoes.ciclo_id': 'cva_ciclos', 'planos.controle_id': 'controles', 'monitoramentos.controle_desc': 'controles'
  };
  // chave natural de cada tabela: se já existe um registro com os mesmos valores (após refazer os vínculos), ele é ATUALIZADO; senão é criado
  var CHAVES = {
    projetos: ['codigo', 'nome'], proj_tarefas: ['projeto_id', 'parent_id', 'nome', 'inicio', 'fim', 'ordem'], proj_recursos: ['projeto_id', 'nome'], proj_baseline: ['projeto_id', 'nome', 'salvo_em'], proj_deps: ['pred_id', 'succ_id'],
    cva_ciclos: ['cadeia', 'nome'], macroprocessos: ['ciclo_id', 'tipo', 'nome'], processos: ['nome', 'macro_id'], flags: ['processo_id', 'elemento'],
    riscos: ['nome', 'processo_id', 'ambiente'], fatores: ['risco_id', 'nome'], controles: ['fator_id', 'descricao'], planos: ['risco_id', 'descricao'],
    revisoes: ['risco_id', 'data'], monitoramentos: ['risco_id', 'data', 'acao'],
    indicadores: ['codigo', 'nome', 'processo_id'], indicador_itens: ['indicador_id', 'nome'], ind_ciclos: ['indicador_id', 'data_inicio', 'data_fim'],
    ciclos_meta_indicador: ['indicador_id', 'data_inicio', 'data_fim'], lanc_ind: ['indicador_id', 'mes_ano'], lanc_itm: ['item_id', 'mes_ano'],
    lancamentos_indicador: ['indicador_id', 'ciclo_id', 'mes_ano'], lancamentos_item: ['item_id', 'ciclo_id', 'mes_ano'], metas_indicador_ciclo: ['indicador_id', 'ciclo_id'],
    series_historicas: ['indicador_id', 'data_observacao'], indicador_capacidades: ['indicador_id', 'capacidade_id'], indicador_fatores: ['indicador_id', 'fator_id'],
    capacidades: ['nome'], fatores_determinantes: ['capacidade_id', 'nome'], objetivos_estrategicos: ['nome'], objetivo_capacidades: ['objetivo_id', 'capacidade_id'],
    ciclos_estrategicos: ['nome'], periodos_ciclo: ['ciclo_id', 'codigo'], metas_objetivo_ciclo: ['objetivo_id', 'ciclo_id'],
    me_mapas: ['nome'], va_planos: ['objetivo_id', 'titulo', 'ciclo_id'], acoes_estrategicas: ['objetivo_id', 'nome'], iniciativas_estrategicas: ['acao_id', 'nome'], me_perspectivas: ['mapa_id', 'nome'], me_temas: ['perspectiva_id', 'nome'], me_objetivos: ['perspectiva_id', 'oe_id'],
    planos_intervencao: ['tipo_alvo', 'alvo_id', 'titulo'], cva_validacoes: ['ciclo_id', 'alvo', 'ref_id', 'em']
  };
  var GENERICOS_CICLO = { 'ciclo_id': 'ciclos_estrategicos' };
  function tabelas() { return DB.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").map(function (t) { return t.name; }); }
  function colunas(t) { return DB.all('PRAGMA table_info(' + t + ')').map(function (c) { return c.name; }); }
  function pai(t, c) {
    if (LOGICAS[t + '.' + c]) return LOGICAS[t + '.' + c];
    var fk = DB.all('PRAGMA foreign_key_list(' + t + ')').filter(function (f) { return f.from === c; })[0];
    if (fk) return fk.table;
    if (LOGICAS['*.' + c]) return LOGICAS['*.' + c];
    if (GENERICOS_CICLO[c]) return GENERICOS_CICLO[c];
    return null;
  }
  function ordenar(ts) {
    var dep = {}, out = [], vis = {};
    ts.forEach(function (t) { dep[t] = colunas(t).map(function (c) { return pai(t, c); }).filter(function (p) { return p && p !== t && ts.indexOf(p) >= 0; }); });
    function v(t) { if (vis[t]) return; vis[t] = 1; dep[t].forEach(v); out.push(t); }
    ts.forEach(v); return out;
  }

  function coletar() {
    var o = { formato: FORMATO, versao: VERSAO, aplicativo: 'Valor-E ' + (w.APP_VERSAO || ''), gerado_em: new Date().toISOString(), tabelas: {}, seguranca: { integridade: 'sha256' } };
    tabelas().forEach(function (t) {
      if (!/^[a-z0-9_]+$/i.test(t)) return; // só nomes de tabela seguros
      var cs = colunas(t).filter(function (c) { return /^[a-z0-9_]+$/i.test(c); });
      o.tabelas[t] = { colunas: cs, linhas: DB.all('SELECT * FROM ' + t).map(function (r) { return cs.map(function (c) { return r[c]; }); }) };
    });
    return o;
  }

  /* ===== Exportação segmentada: Processos | Projetos | Riscos | Indicadores (os vínculos acompanham) ===== */
  var ESCOPOS = { itens: 'Itens selecionados', cadeia: 'Cadeia de Valor Agregado', mapa: 'Mapa Estratégico (inclui Valor Estratégico)' };
  var FILHAS_RISCO = [['fatores', 'risco_id'], ['planos', 'risco_id'], ['monitoramentos', 'risco_id'], ['revisoes', 'risco_id']];
  var FILHAS_IND = [['indicador_itens', 'indicador_id'], ['ind_ciclos', 'indicador_id'], ['lanc_ind', 'indicador_id'], ['lanc_itm', 'indicador_id'], ['ciclos_meta_indicador', 'indicador_id'], ['series_historicas', 'indicador_id'], ['lancamentos_indicador', 'indicador_id'], ['lancamentos_item', 'indicador_id'], ['metas_indicador_ciclo', 'indicador_id']];
  function inList(ids) { return '(' + ids.map(function (i) { return parseInt(i, 10) || 0; }).join(',') + ')'; }
  function existe(t) { return tabelas().indexOf(t) >= 0; }
  /** Lista os registros de cada escopo para a tela de seleção. */
  function listarCadeias() {
    try { return DB.all("SELECT DISTINCT COALESCE(cadeia,'Principal') AS nome FROM cva_ciclos ORDER BY nome").map(function (r) { return r.nome; }); }
    catch (e) { return ['Principal']; }
  }
  function listarMapas() {
    try { return DB.all('SELECT id, nome FROM me_mapas ORDER BY nome, id'); } catch (e) { return []; }
  }
  function listar(esc) { return []; }
  function coletarSeg(esc, ids) {
    if (!ESCOPOS[esc]) throw new Error('Módulo desconhecido.');
    var sel = {}; // tabela -> {id: true}
    function pegar(t, where, par) {
      if (!existe(t)) return [];
      var rs = DB.all('SELECT * FROM ' + t + (where ? ' WHERE ' + where : ''), par || []); sel[t] = sel[t] || {};
      rs.forEach(function (r) { if (r.id !== undefined) sel[t][r.id] = true; else sel[t]['#' + Object.keys(sel[t]).length] = r; });
      return rs;
    }
    function idsDe(rs) { return rs.map(function (r) { return r.id; }); }
    function riscosCom(rs) {
      if (!rs.length) return;
      FILHAS_RISCO.forEach(function (f) { var fr = pegar(f[0], f[1] + ' IN ' + inList(idsDe(rs))); if (f[0] === 'fatores' && fr.length) pegar('controles', 'fator_id IN ' + inList(idsDe(fr))); });
    }
    function indicadoresCom(rs) { if (!rs.length) return; FILHAS_IND.forEach(function (f) { pegar(f[0], f[1] + ' IN ' + inList(idsDe(rs))); }); }
    function ancestraisProcessos(ps) {
      var ms = ps.filter(function (p) { return p.macro_id; }).map(function (p) { return p.macro_id; });
      if (!ms.length) return;
      var mm = pegar('macroprocessos', 'id IN ' + inList(ms));
      var cs = mm.filter(function (m) { return m.ciclo_id; }).map(function (m) { return m.ciclo_id; });
      if (cs.length) pegar('cva_ciclos', 'id IN ' + inList(cs));
    }
    var todos = !ids || !ids.length, vis = {}, EXCL = { config: 1, usuarios: 1, organizacoes: 1, historico: 1, ahp_registros: 1 }, TT = tabelas();
    function numCol(t, c) { var r = DB.all('PRAGMA table_info(' + t + ')').filter(function (x) { return x.name === c; })[0]; return !!r && numerico(r.type); }
    /** Desce pelos vínculos: tudo que depende (por FK ou vínculo lógico) dos registros já coletados acompanha. */
    function descer(t, rs) {
      vis[t] = vis[t] || {}; rs = rs.filter(function (r) { if (r.id === undefined || vis[t][r.id]) return false; vis[t][r.id] = 1; return true; });
      if (!rs.length) return;
      var lst = inList(idsDe(rs));
      TT.forEach(function (c) {
        if (EXCL[c] || !/^[a-z0-9_]+$/i.test(c)) return;
        colunas(c).forEach(function (col) {
          if (col === 'id' || pai(c, col) !== t || !numCol(c, col)) return;
          if (c === t && col !== 'parent_id') return;
          var fr = pegar(c, col + ' IN ' + lst); if (fr.length) descer(c, fr);
        });
      });
      if (t === 'proj_tarefas') pegar('proj_deps', 'pred_id IN ' + lst + ' OR succ_id IN ' + lst);
    }
    /** Sobe pelos vínculos: os "pais" dos registros coletados (macroprocesso, ciclo, processo, projeto, mapa...) acompanham, sem arrastar os irmãos. */
    function subir() {
      var mudou = true, guarda = 0;
      while (mudou && guarda++ < 12) {
        mudou = false;
        Object.keys(sel).forEach(function (t) {
          colunas(t).forEach(function (col) {
            if (col === 'id' || !numCol(t, col)) return;
            var p = pai(t, col); if (!p || p === t || !existe(p) || EXCL[p]) return;
            var v = []; Object.keys(sel[t]).forEach(function (k) { if (k.charAt(0) === '#') return; var r = DB.one('SELECT ' + col + ' AS v FROM ' + t + ' WHERE id = ?', [k]); if (r && r.v) v.push(r.v); });
            v = v.filter(function (x) { return !(sel[p] && sel[p][x]); }); if (!v.length) return;
            var n0 = Object.keys(sel[p] || {}).length; pegar(p, 'id IN ' + inList(v)); if (Object.keys(sel[p] || {}).length > n0) mudou = true;
          });
        });
      }
    }
    if (esc === 'cadeia') {
      var nomeCad = (ids && ids[0] != null && ids[0] !== '') ? String(ids[0]) : '';
      if (!nomeCad) throw new Error('Selecione a cadeia de valor a exportar.');
      var ciclos = pegar('cva_ciclos', "COALESCE(cadeia,'Principal') = ?", [nomeCad]);
      if (!ciclos.length) throw new Error('Nenhum ciclo encontrado para a cadeia "' + nomeCad + '".');
      var idCiclos = idsDe(ciclos);
      var macros = pegar('macroprocessos', 'ciclo_id IN ' + inList(idCiclos));
      var idMacros = idsDe(macros);
      var processos = idMacros.length ? pegar('processos', 'macro_id IN ' + inList(idMacros)) : [];
      var idProcs = idsDe(processos);
      if (idProcs.length) {
        try { pegar('flags', 'processo_id IN ' + inList(idProcs)); } catch (e) {}
        descer('processos', processos);
        var riscos = pegar('riscos', 'processo_id IN ' + inList(idProcs));
        riscosCom(riscos); descer('riscos', riscos);
        var inds = pegar('indicadores', 'processo_id IN ' + inList(idProcs));
        indicadoresCom(inds); descer('indicadores', inds);
      }
      if (idCiclos.length) {
        try { pegar('cva_validacoes', 'ciclo_id IN ' + inList(idCiclos)); } catch (e) {}
        try { pegar('cva_documentos', 'ciclo_id IN ' + inList(idCiclos)); } catch (e) {}
      }
    } else if (esc === 'mapa') {
      var mid = parseInt(ids && ids[0], 10);
      if (!mid) throw new Error('Selecione o mapa estratégico a exportar.');
      var mapasR = pegar('me_mapas', 'id = ?', [mid]);
      if (!mapasR.length) throw new Error('Mapa estratégico não encontrado.');
      var pers = pegar('me_perspectivas', 'mapa_id = ?', [mid]);
      var idPers = idsDe(pers);
      if (idPers.length) {
        try { pegar('me_temas', 'perspectiva_id IN ' + inList(idPers)); } catch (e) {}
        pegar('me_objetivos', 'perspectiva_id IN ' + inList(idPers));
      }
      var oeIds = [];
      try {
        oeIds = DB.all('SELECT oe_id FROM me_objetivos WHERE perspectiva_id IN (SELECT id FROM me_perspectivas WHERE mapa_id = ?)', [mid])
          .map(function (r) { return r.oe_id; }).filter(Boolean);
      } catch (e) { oeIds = []; }
      if (oeIds.length) {
        pegar('objetivos_estrategicos', 'id IN ' + inList(oeIds));
        try { pegar('acoes_estrategicas', 'objetivo_id IN ' + inList(oeIds)); } catch (e) {}
        try {
          var ocs = pegar('objetivo_capacidades', 'objetivo_id IN ' + inList(oeIds));
          var capIds = ocs.map(function (r) { return r.capacidade_id; }).filter(Boolean);
          if (capIds.length) {
            pegar('capacidades', 'id IN ' + inList(capIds));
            var dims = pegar('fatores_determinantes', 'capacidade_id IN ' + inList(capIds));
            var dimIds = idsDe(dims);
            if (dimIds.length) {
              var ifs = pegar('indicador_fatores', 'fator_id IN ' + inList(dimIds));
              var indIds = ifs.map(function (r) { return r.indicador_id; }).filter(Boolean);
              if (indIds.length) {
                var indsV = pegar('indicadores', 'id IN ' + inList(indIds));
                indicadoresCom(indsV); descer('indicadores', indsV);
              }
            }
          }
        } catch (e) {}
      }
      var projetos = [];
      try {
        projetos = oeIds.length
          ? pegar('projetos', 'mapa_id = ? OR objetivo_id IN ' + inList(oeIds), [mid])
          : pegar('projetos', 'mapa_id = ?', [mid]);
      } catch (e) {
        try { projetos = pegar('projetos', 'mapa_id = ?', [mid]); } catch (e2) { projetos = []; }
      }
      if (projetos.length) {
        descer('projetos', projetos);
        var idProjs = idsDe(projetos);
        try {
          var riscosP = pegar('riscos', 'projeto_id IN ' + inList(idProjs));
          riscosCom(riscosP); descer('riscos', riscosP);
        } catch (e) {}
        var cods = idProjs.map(function (i) { return "'PRJ-PROG-" + (parseInt(i, 10) || 0) + "'"; }).join(',');
        if (cods) {
          var pg = pegar('indicadores', 'codigo IN (' + cods + ')');
          indicadoresCom(pg); descer('indicadores', pg);
        }
      }
    } else {
      throw new Error('Tipo de exportação não suportado: ' + esc);
    }
    subir();
    var o = { formato: FORMATO, versao: VERSAO, escopo: esc, aplicativo: 'Valor-E ' + (w.APP_VERSAO || ''), gerado_em: new Date().toISOString(), tabelas: {}, seguranca: { integridade: 'sha256' } };
    Object.keys(sel).forEach(function (t) {
      if (!/^[a-z0-9_]+$/i.test(t)) return;
      var cs = colunas(t).filter(function (c) { return /^[a-z0-9_]+$/i.test(c); }), idsT = Object.keys(sel[t]).filter(function (k) { return k.charAt(0) !== '#'; });
      var rows = idsT.length ? DB.all('SELECT * FROM ' + t + ' WHERE id IN ' + inList(idsT) + ' ORDER BY id') : Object.keys(sel[t]).map(function (k) { return sel[t][k]; });
      if (rows.length) o.tabelas[t] = { colunas: cs, linhas: rows.map(function (r) { return cs.map(function (c) { return r[c]; }); }) };
    });
    return o;
  }

  /* ===== Exportar / importar por itens (fragmentado) ===== */
  var SELEC = { cva_ciclos: 1, macroprocessos: 1, processos: 1, riscos: 1, indicadores: 1, projetos: 1, me_objetivos: 1, objetivos_estrategicos: 1, acoes_estrategicas: 1, iniciativas_estrategicas: 1, capacidades: 1 };
  var LIGACOES = { indicador_capacidades: 1, indicador_fatores: 1, objetivo_capacidades: 1 };
  var EXCLUIDAS = { config: 1, usuarios: 1, organizacoes: 1, historico: 1, ahp_registros: 1 };
  function linhasDe(o, t) {
    var X = o.tabelas[t]; if (!X) return [];
    return X.linhas.map(function (l) { var r = {}; X.colunas.forEach(function (c, i) { r[c] = l[i]; }); return r; });
  }
  function igual(a, b) { return a !== null && a !== undefined && a !== '' && String(a) === String(b); }
  /** Árvore de itens selecionáveis a partir de um pacote (o do banco atual ou o de um arquivo). */
  function arvoreItens(o) {
    var L = function (t) { return linhasDe(o, t); };
    function rot(x) { return (x.codigo ? x.codigo + ' — ' : '') + (x.nome || x.titulo || ('#' + x.id)); }
    function no(t, x, f, r) { return { t: t, id: x.id, r: r || rot(x), f: f || [] }; }
    function filtro(rs, col, v) { return rs.filter(function (x) { return igual(x[col], v); }); }
    var G = [];
    // 1. Cadeia de valor: cadeia → ciclo → macroprocesso → processo
    var ciclos = L('cva_ciclos'), macros = L('macroprocessos'), procs = L('processos'), cad = {};
    ciclos.forEach(function (c) { var k = c.cadeia || 'Principal'; (cad[k] = cad[k] || []).push(c); });
    var fc = Object.keys(cad).sort().map(function (k) {
      return { r: 'Cadeia: ' + k, f: cad[k].map(function (c) {
        return no('cva_ciclos', c, filtro(macros, 'ciclo_id', c.id).map(function (m) {
          return no('macroprocessos', m, filtro(procs, 'macro_id', m.id).map(function (p) { return no('processos', p); }), (m.tipo ? m.tipo + ' · ' : '') + m.nome);
        }), c.nome || ('Ciclo ' + c.id));
      }) };
    });
    var semMacro = procs.filter(function (p) { return !p.macro_id; });
    if (semMacro.length) fc.push({ r: 'Processos sem macroprocesso', f: semMacro.map(function (p) { return no('processos', p); }) });
    G.push({ r: 'Cadeia de Valor e Processos', f: fc });
    // 2. Mapa estratégico: mapa → objetivo → ação → iniciativa
    var mapas = L('me_mapas'), pers = L('me_perspectivas'), mobj = L('me_objetivos'), oes = L('objetivos_estrategicos'), acs = L('acoes_estrategicas'), inis = L('iniciativas_estrategicas'), usados = {};
    function nodeObj(oe) {
      return no('objetivos_estrategicos', oe, filtro(acs, 'objetivo_id', oe.id).map(function (a) {
        return no('acoes_estrategicas', a, filtro(inis, 'acao_id', a.id).map(function (i) { return no('iniciativas_estrategicas', i); }));
      }));
    }
    var fm = mapas.map(function (m) {
      var filhos = [];
      filtro(pers, 'mapa_id', m.id).forEach(function (p) { filtro(mobj, 'perspectiva_id', p.id).forEach(function (mo) { var oe = oes.filter(function (x) { return igual(x.id, mo.oe_id) && !usados[m.id + ':' + x.id]; })[0]; if (oe) { usados[m.id + ':' + oe.id] = 1; usados['*' + oe.id] = 1; filhos.push(nodeObj(oe)); } }); });
      return no('me_mapas', m, filhos, 'Mapa: ' + m.nome);
    });
    var soltos = oes.filter(function (x) { return !usados['*' + x.id]; });
    if (soltos.length) fm.push({ r: 'Objetivos fora de mapas', f: soltos.map(nodeObj) });
    G.push({ r: 'Mapa Estratégico (objetivos, ações e iniciativas)', f: fm });
    // 3-6. listas planas
    function lista(titulo, t, extra) { var rs = L(t); if (extra) rs = rs.filter(extra); G.push({ r: titulo, f: rs.map(function (x) { return no(t, x); }) }); }
    lista('Projetos', 'projetos'); lista('Riscos', 'riscos'); lista('Indicadores', 'indicadores', function (x) { return !/^PRJ-PROG-/.test(String(x.codigo || '')); }); lista('Capacidades (Valor Estratégico)', 'capacidades');
    return G;
  }
  function contaFolhas(n) { return n.t ? 1 : 0 + (n.f || []).reduce(function (s, x) { return s + contaFolhas(x); }, 0); }
  function htmlNo(n) {
    var inp = n.t ? '<input type="checkbox" class="xi-ck" data-t="' + n.t + '" data-i="' + E.esc(String(n.id)) + '"> ' : '<input type="checkbox" class="xi-ck xi-grp"> ';
    if (!n.f || !n.f.length) return '<div class="xi-leaf"><label>' + inp + E.esc(n.r) + '</label></div>';
    return '<details class="xi-no"><summary><label onclick="event.stopPropagation()">' + inp + '<b>' + E.esc(n.r) + '</b></label></summary><div class="xi-fil">' + n.f.map(htmlNo).join('') + '</div></details>';
  }
  function itensUI(id, o) {
    var box = document.getElementById(id); if (!box) return;
    var G = arvoreItens(o), vazio = true;
    box.innerHTML = G.map(function (g) { if (g.f.length) vazio = false; return g.f.length ? htmlNo(g) : ''; }).join('') || '<p class="text-muted small mb-0">Nada para listar.</p>';
    box.onchange = function (e) {
      var el = e.target; if (!el || !el.classList || !el.classList.contains('xi-ck')) return;
      var cont = el.closest('details'); if (cont) Array.prototype.forEach.call(cont.querySelectorAll('.xi-fil .xi-ck'), function (c) { c.checked = el.checked; });
      // marca/desmarca o "pai" conforme os filhos
      var d = cont ? cont.parentNode.closest('details') : el.closest('details');
      while (d) { var sm = d.querySelector('summary .xi-ck'), fl = d.querySelectorAll('.xi-fil .xi-ck'), todos = true, algum = false; Array.prototype.forEach.call(fl, function (c) { if (c.checked) algum = true; else todos = false; }); if (sm) { sm.checked = todos && fl.length > 0; sm.indeterminate = algum && !todos; } d = d.parentNode.closest('details'); }
    };
  }
  function itensMarcados(id) {
    return Array.prototype.map.call(document.querySelectorAll('#' + id + ' .xi-ck[data-t]:checked'), function (c) { return { t: c.getAttribute('data-t'), id: c.getAttribute('data-i') }; });
  }
  /** Recorta um pacote: os itens marcados + seus dados próprios (descendentes não selecionáveis) + os "pais" necessários (sem irmãos). */
  function filtrarPacote(o, seeds) {
    var T = {}, sel = {}, fila = [], ancs = [], ix = {};
    Object.keys(o.tabelas).forEach(function (t) { if (!/^[a-z0-9_]+$/i.test(t) || EXCLUIDAS[t]) return; T[t] = linhasDe(o, t); });
    function chave(t, r) { return (r.id !== undefined && r.id !== null) ? 'i' + r.id : 'p' + T[t].indexOf(r); }
    function add(t, r) { sel[t] = sel[t] || {}; var k = chave(t, r); if (sel[t][k]) return false; sel[t][k] = r; return true; }
    function indice(t, col) { var k = t + '.' + col; if (!ix[k]) { var m = {}; T[t].forEach(function (r) { var v = r[col]; if (v !== null && v !== undefined && v !== '') (m[v] = m[v] || []).push(r); }); ix[k] = m; } return ix[k]; }
    function porId(t, v) { var m = indice(t, 'id'); return (m[v] || [])[0]; }
    function semente(t, r) { if (add(t, r)) fila.push([t, r]); }
    seeds.forEach(function (s) { if (T[s.t]) { var r = porId(s.t, s.id); if (r) semente(s.t, r); } });
    // indicador de progresso de cada projeto escolhido
    if (T.indicadores && T.projetos) Object.keys(sel.projetos || {}).forEach(function (k) { var pid = sel.projetos[k].id; (T.indicadores).forEach(function (r) { if (String(r.codigo) === 'PRJ-PROG-' + pid) semente('indicadores', r); }); });
    // objetivo escolhido leva a sua posição no mapa (perspectiva/tema/mapa sobem como "pais")
    if (T.me_objetivos) Object.keys(sel.objetivos_estrategicos || {}).forEach(function (k) { var oid = sel.objetivos_estrategicos[k].id; T.me_objetivos.forEach(function (r) { if (igual(r.oe_id, oid) && add('me_objetivos', r)) ancs.push(['me_objetivos', r]); }); });
    // descer: dados próprios (tabelas que não são itens selecionáveis)
    while (fila.length) {
      var it = fila.shift(), t = it[0], r = it[1];
      Object.keys(T).forEach(function (c) {
        if (SELEC[c] || LIGACOES[c]) return;
        Object.keys(T[c][0] || {}).forEach(function (col) {
          if (col === 'id' || pai(c, col) !== t) return;
          if (c === t && col !== 'parent_id') return;
          (indice(c, col)[r.id] || []).forEach(function (f) { semente(c, f); });
        });
      });
      if (t === 'proj_tarefas' && T.proj_deps) T.proj_deps.forEach(function (d) { if (igual(d.pred_id, r.id) || igual(d.succ_id, r.id)) semente('proj_deps', d); });
    }
    Object.keys(sel).forEach(function (t) { Object.keys(sel[t]).forEach(function (k) { ancs.push([t, sel[t][k]]); }); });
    // subir: pais de tudo que foi coletado (macroprocesso, ciclo, mapa, ação, projeto...), sem arrastar os irmãos
    while (ancs.length) {
      var a = ancs.shift(), ta = a[0], ra = a[1];
      Object.keys(ra).forEach(function (col) {
        if (col === 'id' || ra[col] === null || ra[col] === '' || ra[col] === undefined) return;
        var p = pai(ta, col); if (!p || !T[p] || EXCLUIDAS[p] || (p === ta && col !== 'parent_id')) return;
        var pr = porId(p, ra[col]); if (pr && add(p, pr)) ancs.push([p, pr]);
      });
    }
    // tabelas de ligação (indicador↔capacidade, indicador↔dimensão, objetivo↔capacidade): só se os dois lados foram escolhidos
    Object.keys(LIGACOES).forEach(function (c) {
      if (!T[c]) return;
      T[c].forEach(function (r) {
        var ok = true, tem = false;
        Object.keys(r).forEach(function (col) { var p = col === 'id' ? null : pai(c, col); if (p && T[p] && r[col] !== null && r[col] !== '') { tem = true; var k = 'i' + r[col]; if (!(sel[p] && sel[p][k])) ok = false; } });
        if (ok && tem) add(c, r);
      });
    });
    var out = { formato: FORMATO, versao: VERSAO, escopo: 'itens', aplicativo: o.aplicativo || ('Valor-E ' + (w.APP_VERSAO || '')), gerado_em: new Date().toISOString(), tabelas: {}, seguranca: { integridade: 'sha256' } };
    Object.keys(sel).forEach(function (t) {
      var X = o.tabelas[t], ks = sel[t], linhas = [];
      T[t].forEach(function (r, i) { if (ks[chave(t, r)]) linhas.push(X.linhas[i]); });
      if (linhas.length) out.tabelas[t] = { colunas: X.colunas, linhas: linhas };
    });
    return out;
  }
  function parsePacote(txt) {
    if (w.SEC) SEC.validateImportText(txt);
    var o = null;
    if (txt.trim().charAt(0) === '<') o = deXml(txt); else { try { o = JSON.parse(txt); } catch (e) { throw new Error('Arquivo inválido.'); } }
    if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote') || !o.tabelas) throw new Error('Arquivo não reconhecido como pacote do Valor-E.');
    if (w.SEC && SEC.sanitizarObjeto) o = SEC.sanitizarObjeto(o);
    Object.keys(o.tabelas).forEach(function (t) { if (!/^[a-z0-9_]+$/i.test(t)) throw new Error('Pacote rejeitado: nome de tabela inválido (' + t + ').'); });
    return o;
  }
  var PKG_LIDO = null;
  function bytesParaB64(u) { var s = '', n = 0x8000; for (var i = 0; i < u.length; i += n) s += String.fromCharCode.apply(null, u.subarray(i, i + n)); return btoa(s); }
  function jsonStr(o) { return JSON.stringify(o, function (k, v) { return (v instanceof Uint8Array) ? { __b64: bytesParaB64(v) } : v; }); }
  function xesc(s) { return String(s).replace(/[&<>"\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, function (c) { return c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '"' ? '&quot;' : ''; }); }
  function xml(o) {
    var s = '<?xml version="1.0" encoding="UTF-8"?>\n<axia-pacote formato="' + FORMATO + '" versao="' + VERSAO + '"' + (o.escopo ? ' escopo="' + o.escopo + '"' : '') + ' gerado_em="' + o.gerado_em + '">\n';
    Object.keys(o.tabelas).forEach(function (t) {
      var T = o.tabelas[t]; s += '  <tabela nome="' + t + '" colunas="' + xesc(T.colunas.join(',')) + '">\n';
      T.linhas.forEach(function (l) { s += '    <linha>' + l.map(function (v) { return v === null || v === undefined ? '<c n="1"/>' : (v instanceof Uint8Array ? '<c b="1">' + bytesParaB64(v) + '</c>' : '<c>' + xesc(v) + '</c>'); }).join('') + '</linha>\n'; });
      s += '  </tabela>\n';
    });
    return s + '</axia-pacote>\n';
  }
  function deXml(txt) {
    var d = new DOMParser().parseFromString(txt, 'application/xml');
    if (d.getElementsByTagName('parsererror').length) throw new Error('O arquivo não é um XML válido.');
    var r = d.documentElement; if (r.nodeName !== 'axia-pacote' && r.nodeName !== 'nomika-pacote') return null;
    var o = { formato: FORMATO, versao: r.getAttribute('versao'), escopo: r.getAttribute('escopo') || null, tabelas: {} };
    Array.prototype.forEach.call(r.getElementsByTagName('tabela'), function (t) {
      var cs = (t.getAttribute('colunas') || '').split(',');
      o.tabelas[t.getAttribute('nome')] = { colunas: cs, linhas: Array.prototype.map.call(t.getElementsByTagName('linha'), function (l) {
        return Array.prototype.map.call(l.getElementsByTagName('c'), function (c) { if (c.getAttribute('n')) return null; if (c.getAttribute('b')) return { __b64: c.textContent }; return c.textContent; });
      }) };
    });
    return o;
  }
  function numerico(def) { return /INT|REAL|NUM|FLOA|DOUB/i.test(def || ''); }
  function aplicar(o, modo) {
    var res = { tabelas: {}, atualizados: {}, avisos: [] };
    if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote') || !o.tabelas) throw new Error('Arquivo não reconhecido como pacote do Valor-E.');
    if (o.escopo && modo === 'substituir') throw new Error('Pacote parcial (' + (ESCOPOS[o.escopo] || o.escopo) + ') só pode ser importado no modo Mesclar.');
    var existentes = tabelas(), nomes = ordenar(Object.keys(o.tabelas).filter(function (t) { return existentes.indexOf(t) >= 0; }));
    Object.keys(o.tabelas).forEach(function (t) { if (existentes.indexOf(t) < 0) res.avisos.push('Tabela desconhecida ignorada: ' + t); });
    var mapa = {}; DB.db.run('PRAGMA foreign_keys = OFF');
    try {
      DB.db.run('BEGIN');
      if (modo === 'substituir') existentes.forEach(function (t) { DB.db.run('DELETE FROM ' + t); });
      nomes.forEach(function (t) {
        var T = o.tabelas[t], cols = colunas(t), tipos = {}; DB.all('PRAGMA table_info(' + t + ')').forEach(function (c) { tipos[c.name] = c.type; });
        var temId = cols.indexOf('id') >= 0, n = 0, at = 0, pais = {}; cols.forEach(function (c) { pais[c] = pai(t, c); });
        mapa[t] = mapa[t] || {};
        T.linhas.forEach(function (l) {
          var reg = {}; T.colunas.forEach(function (c, i) { if (cols.indexOf(c) >= 0) { var v = l[i]; reg[c] = (v && typeof v === 'object' && v.__b64 !== undefined) ? (function (b) { var s = atob(b), u = new Uint8Array(s.length); for (var k = 0; k < s.length; k++) u[k] = s.charCodeAt(k); return u; })(v.__b64) : v; } });
          var antigo = reg.id;
          if (modo === 'mesclar') {
            cols.forEach(function (c) {
              if (c === 'id' || !pais[c] || reg[c] === null || reg[c] === undefined || reg[c] === '') return;
              if (o.escopo && !o.tabelas[pais[c]] && tipos[c] !== undefined && numerico(tipos[c])) { reg[c] = null; return; } // pai fora do pacote parcial
              var m = mapa[pais[c]]; if (!m) return;
              var novo = m[reg[c]]; reg[c] = novo !== undefined ? (numerico(tipos[c]) ? novo : String(novo)) : (numerico(tipos[c]) ? null : reg[c]);
            });
            if (t === 'cva_ciclos' && !reg.cadeia) reg.cadeia = 'Principal';
            if (t === 'config') { if (DB.one('SELECT 1 AS x FROM config WHERE chave = ?', [reg.chave])) return; }
            if (t === 'organizacoes' || t === 'usuarios') return;
            if (t === 'ahp_registros' || t === 'historico') return;
            // já existe? então atualiza (chave natural — evita duplicar)
            var ch = CHAVES[t], ex = null;
            if (temId) {
              // Indicadores: prioriza código (único); senão nome + processo
              if (t === 'indicadores') {
                if (reg.codigo) {
                  ex = DB.one('SELECT id FROM indicadores WHERE codigo IS ? COLLATE NOCASE', [String(reg.codigo)]);
                }
                if (!ex && reg.nome) {
                  if (reg.processo_id != null && reg.processo_id !== '') {
                    ex = DB.one('SELECT id FROM indicadores WHERE nome IS ? COLLATE NOCASE AND processo_id IS ?', [String(reg.nome), reg.processo_id]);
                  } else {
                    ex = DB.one("SELECT id FROM indicadores WHERE nome IS ? COLLATE NOCASE AND (processo_id IS NULL OR processo_id = 0 OR processo_id = '')", [String(reg.nome)]);
                  }
                }
              } else if (t === 'riscos') {
                if (reg.codigo) {
                  ex = DB.one('SELECT id FROM riscos WHERE codigo IS ? COLLATE NOCASE', [String(reg.codigo)]);
                }
                if (!ex && reg.nome) {
                  ex = DB.one('SELECT id FROM riscos WHERE nome IS ? COLLATE NOCASE', [String(reg.nome)]);
                }
              } else if (t === 'capacidades' && reg.codigo) {
                ex = DB.one('SELECT id FROM capacidades WHERE codigo IS ? COLLATE NOCASE', [String(reg.codigo)]);
              } else if (t === 'objetivos_estrategicos' && reg.codigo) {
                ex = DB.one('SELECT id FROM objetivos_estrategicos WHERE codigo IS ? COLLATE NOCASE', [String(reg.codigo)]);
              } else if (ch) {
                var kk = ch.filter(function (c) { return cols.indexOf(c) >= 0; });
                if (kk.length && kk.some(function (c) { return reg[c] !== null && reg[c] !== undefined && reg[c] !== ''; })) {
                  ex = DB.one('SELECT id FROM ' + t + ' WHERE ' + kk.map(function (c) { return c + ' IS ? COLLATE NOCASE'; }).join(' AND '), kk.map(function (c) { return reg[c] === undefined ? null : reg[c]; }));
                }
              }
            }
            if (ex) {
              var up = Object.keys(reg).filter(function (c) { return c !== 'id' && c !== 'criado_em' && !(t === 'riscos' && c === 'codigo'); });
              try {
                if (up.length) DB.db.run('UPDATE ' + t + ' SET ' + up.map(function (c) { return c + ' = ?'; }).join(', ') + ' WHERE id = ?', up.map(function (c) { return reg[c]; }).concat([ex.id]));
                mapa[t][antigo] = ex.id; at++;
              } catch (e) { if (res.avisos.length < 12) res.avisos.push(t + ': ' + e.message); }
              return;
            }
            if (t === 'riscos' && reg.codigo && !E.codigoRiscoLivre(reg.codigo)) reg.codigo = E.proximoCodigoRisco();
            if (temId) delete reg.id;
          }
          var ks = Object.keys(reg);
          try {
            DB.db.run('INSERT INTO ' + t + ' (' + ks.join(',') + ') VALUES (' + ks.map(function () { return '?'; }).join(',') + ')', ks.map(function (c) { return reg[c]; }));
            if (temId) mapa[t][antigo] = modo === 'mesclar' ? DB.one('SELECT last_insert_rowid() AS i').i : antigo;
            n++;
          } catch (e) { if (res.avisos.length < 12) res.avisos.push(t + ': ' + e.message); }
        });
        res.tabelas[t] = n; res.atualizados[t] = at;
      });
      // indicadores de progresso de projetos: o código acompanha o novo id do projeto
      if (modo === 'mesclar' && mapa.projetos && mapa.indicadores && o.tabelas.indicadores) {
        var ic = o.tabelas.indicadores.colunas, ii = ic.indexOf('id'), ik = ic.indexOf('codigo'), mv = [];
        o.tabelas.indicadores.linhas.forEach(function (l) { var mm = /^PRJ-PROG-(\d+)$/.exec(String(l[ik] || '')); if (mm && mapa.projetos[mm[1]] !== undefined && mapa.indicadores[l[ii]] !== undefined) mv.push([mapa.indicadores[l[ii]], 'PRJ-PROG-' + mapa.projetos[mm[1]]]); });
        mv.forEach(function (p, k) { DB.db.run('UPDATE indicadores SET codigo = ? WHERE id = ?', ['~tmp' + k, p[0]]); });
        mv.forEach(function (p, k) { var outro = DB.one('SELECT id FROM indicadores WHERE codigo = ? AND id != ?', [p[1], p[0]]); if (outro) DB.db.run('DELETE FROM indicadores WHERE id = ?', [outro.id]); DB.db.run('UPDATE indicadores SET codigo = ? WHERE id = ?', [p[1], p[0]]); });
      }
      // vínculos que apontam para tabelas importadas depois (ex.: processos.validado_ciclo_id) já foram resolvidos pela ordem topológica
      DB.db.run('COMMIT');
    } catch (e) { try { DB.db.run('ROLLBACK'); } catch (x) {} DB.db.run('PRAGMA foreign_keys = ON'); throw e; }
    DB.db.run('PRAGMA foreign_keys = ON'); DB.sujo();
    return res;
  }
  var Pacote = w.Pacote = {
    coletar: coletar,
    exportarJson: function () {
      var o = coletar(), body = jsonStr(o);
      function baixa(txt) { Mapris.baixar('valore-' + E.hoje() + '.json', txt, 'application/json'); if (w.SEC) SEC.audit('exportar', 'json'); }
      if (w.SEC && SEC.sha256Hex) {
        SEC.sha256Hex(body).then(function (hash) {
          try { var j = JSON.parse(body); j.seguranca = j.seguranca || {}; j.seguranca.sha256 = hash; baixa(JSON.stringify(j)); }
          catch (e) { baixa(body); }
        });
      } else baixa(body);
    },
    itensUI: itensUI, filtrarPacote: filtrarPacote, arvoreItens: arvoreItens,
    itensMarcar: function (id, v) { Array.prototype.forEach.call(document.querySelectorAll('#' + id + ' .xi-ck'), function (c) { c.checked = v; c.indeterminate = false; }); },
    itensExportar: function (fmt) {
      var res = document.getElementById('segRes');
      try {
        var seeds = itensMarcados('itLista'); if (!seeds.length) throw new Error('Marque ao menos um item.');
        var o = filtrarPacote(coletar(), seeds);
        Mapris.baixar('valore-itens-' + E.hoje() + (fmt === 'json' ? '.json' : '.xml'), fmt === 'json' ? jsonStr(o) : xml(o), fmt === 'json' ? 'application/json' : 'application/xml');
        if (w.SEC) SEC.audit('exportar', 'itens ' + (fmt || 'xml'));
        res.textContent = 'Exportado: ' + seeds.length + ' item(ns) marcado(s) + vínculos necessários.\n' + Object.keys(o.tabelas).map(function (tb) { return tb + ': ' + o.tabelas[tb].linhas.length; }).join('\n');
      } catch (e) { res.textContent = 'Erro: ' + e.message; }
    },
    itensLer: function () {
      var f = document.getElementById('pArq').files[0], box = document.getElementById('itImp'); if (!f) return alert('Escolha um arquivo.');
      if (/\.(sqlite|db)$/i.test(f.name)) return alert('Arquivos .sqlite restauram o banco inteiro. Para escolher itens, use um arquivo .json ou .xml exportado pelo Valor-E.');
      var fr = new FileReader(); fr.onload = function () {
        try {
          PKG_LIDO = parsePacote(String(fr.result));
          box.innerHTML = '<div class="xi-quadro"><b>Conteúdo do arquivo</b> — marque o que deseja importar (os itens “acima” e os dados próprios acompanham; o que já existe é atualizado, sem duplicar).' +
            '<div class="my-2"><button class="btn btn-sm btn-outline-secondary" onclick="Pacote.itensMarcar(\'itImpLista\',true)">Marcar tudo</button> <button class="btn btn-sm btn-outline-secondary" onclick="Pacote.itensMarcar(\'itImpLista\',false)">Limpar</button></div>' +
            '<div id="itImpLista" class="xi-box"></div><div class="mt-2"><button class="btn btn-warning" onclick="Pacote.itensImportar()"><i class="bi bi-upload"></i> Importar itens marcados</button></div></div>';
          itensUI('itImpLista', PKG_LIDO);
        } catch (e) { document.getElementById('pRes').textContent = 'Erro: ' + e.message; }
      }; fr.readAsText(f);
    },
    itensImportar: function () {
      try {
        var seeds = itensMarcados('itImpLista'); if (!seeds.length) throw new Error('Marque ao menos um item.');
        if (w.SEC) SEC.audit('importar', 'itens');
        var r = aplicar(filtrarPacote(PKG_LIDO, seeds), 'mesclar');
        document.getElementById('pRes').textContent = 'Importação concluída (' + seeds.length + ' item(ns) marcado(s), modo mesclar).\n' + Pacote.resumo(r);
      } catch (e) { document.getElementById('pRes').textContent = 'Erro: ' + e.message; }
    },
    escopos: ESCOPOS, listar: listar, listarCadeias: listarCadeias, listarMapas: listarMapas, coletarSeg: coletarSeg,
    exportarSeg: function (esc, ids, fmt) {
      var o = coletarSeg(esc, ids), ref = (ids && ids[0] != null) ? String(ids[0]).replace(/[^A-Za-z0-9_-]+/g, '_').slice(0, 40) : 'item', nome = 'valore-' + esc + '-' + ref + '-' + E.hoje();
      if (fmt === 'json') { Mapris.baixar(nome + '.json', jsonStr(o), 'application/json'); } else Mapris.baixar(nome + '.xml', xml(o), 'application/xml');
      if (w.SEC) SEC.audit('exportar', esc + ' ' + (fmt || 'xml'));
      return o;
    },
    segUI: function () {
      var esc = (document.getElementById('segEsc') || {}).value || 'cadeia';
      var box = document.getElementById('segLista');
      var dica = document.getElementById('segDica');
      if (!box) return;
      if (esc === 'cadeia') {
        if (dica) dica.textContent = 'Exporta a cadeia selecionada com ciclos, macroprocessos, processos, indicadores e riscos vinculados.';
        var cads = listarCadeias();
        if (!cads.length) { box.innerHTML = '<p class="text-muted small mb-0">Nenhuma cadeia de valor cadastrada.</p>'; return; }
        box.innerHTML = cads.map(function (n) {
          return '<label class="d-block mb-1"><input type="radio" name="segItem" value="' + E.esc(n) + '"> <b>' + E.esc(n) + '</b></label>';
        }).join('');
        var first = box.querySelector('input[name=segItem]'); if (first) first.checked = true;
      } else {
        if (dica) dica.textContent = 'Exporta o mapa com objetivos, ações, projetos, indicadores e riscos vinculados, e o Valor Estratégico (capacidades e dimensões) dos objetivos deste mapa.';
        var mapas = listarMapas();
        if (!mapas.length) { box.innerHTML = '<p class="text-muted small mb-0">Nenhum mapa estratégico cadastrado.</p>'; return; }
        box.innerHTML = mapas.map(function (m) {
          return '<label class="d-block mb-1"><input type="radio" name="segItem" value="' + m.id + '"> <b>' + E.esc(m.nome) + '</b></label>';
        }).join('');
        var first = box.querySelector('input[name=segItem]'); if (first) first.checked = true;
      }
    },
    segExportar: function (fmt) {
      try {
        var esc = (document.getElementById('segEsc') || {}).value || 'cadeia';
        var sel = document.querySelector('input[name=segItem]:checked');
        if (!sel) throw new Error('Selecione um item para exportar.');
        var o = Pacote.exportarSeg(esc, [sel.value], fmt);
        document.getElementById('segRes').textContent = 'Exportado (' + (ESCOPOS[esc] || esc) + ').\n' + Object.keys(o.tabelas).map(function (tb) { return tb + ': ' + o.tabelas[tb].linhas.length; }).join('\n');
      } catch (e) { document.getElementById('segRes').textContent = 'Erro: ' + e.message; }
    },
    exportarXml: function () { Mapris.baixar('valore-' + E.hoje() + '.xml', xml(coletar()), 'application/xml'); if (w.SEC) SEC.audit('exportar', 'xml'); },
    /** Lê o texto do arquivo, detecta o formato e importa. Retorna {res, legado}. */
    importarTexto: function (txt, modo) {
      if (w.SEC) SEC.validateImportText(txt);
      var xmlTxt = txt.trim().charAt(0) === '<', o = null;
      if (xmlTxt) o = deXml(txt); else { try { o = JSON.parse(txt); } catch (e) { throw new Error('Arquivo inválido.'); } }
      if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote')) return null;
      if (w.SEC && SEC.sanitizarObjeto) o = SEC.sanitizarObjeto(o);
      // rejeita tabelas com nomes suspeitos
      if (o.tabelas) {
        Object.keys(o.tabelas).forEach(function (t) {
          if (!/^[a-z0-9_]+$/i.test(t)) throw new Error('Pacote rejeitado: nome de tabela inválido (' + t + ').');
        });
      }
      if (w.SEC) SEC.audit('importar', (modo || 'mesclar') + ' pacote');
      return aplicar(o, modo);
    },
    resumo: function (r) { var ls = Object.keys(r.tabelas).filter(function (t) { return r.tabelas[t] || (r.atualizados && r.atualizados[t]); }).map(function (t) { return t + ': ' + r.tabelas[t] + ' novo(s), ' + ((r.atualizados && r.atualizados[t]) || 0) + ' atualizado(s)'; }); return ls.join('\n') + (r.avisos.length ? '\n\nAvisos:\n' + r.avisos.join('\n') : ''); },
    /** Cartão da tela de configurações. */
    cartao: function () {
      setTimeout(function () { if (document.getElementById('itLista')) Pacote.itensUI('itLista', coletar()); }, 30);
      var n = tabelas().reduce(function (s, t) { return s + DB.one('SELECT COUNT(*) AS n FROM ' + t).n; }, 0);
      var sec = (w.SEC && SEC.cartaoUI) ? SEC.cartaoUI(h) : '';
      return sec + '<div class="cartao mb-3"><h2><i class="bi bi-arrow-left-right"></i> Exportar e importar tudo</h2><div class="corpo">' +
        '<p class="ajuda">Inclui <b>todos os módulos</b>: CVA, processos (Folha de dados e diagramas), bandeiras e riscos, indicadores e registros, Valor Estratégico (objetivos, capacidades, dimensões, pesos) e parâmetros. Hoje há ' + n + ' registro(s).</p>' +
        '<div class="d-flex flex-wrap gap-2 mb-3"><button class="btn btn-success" onclick="Pacote.exportarJson()"><i class="bi bi-filetype-json"></i> Exportar tudo (.json)</button><button class="btn btn-outline-success" onclick="Pacote.exportarXml()"><i class="bi bi-filetype-xml"></i> Exportar tudo (.xml)</button><button class="btn btn-outline-secondary" onclick="Acoes.expBanco()"><i class="bi bi-database"></i> Cópia do banco (.sqlite)</button></div>' +
        '<h6>Exportar por itens</h6><p class="ajuda mb-2">Marque exatamente o que deseja levar: uma cadeia, um ciclo, macroprocessos ou processos isolados; um mapa, objetivos, ações ou iniciativas; projetos, riscos, indicadores e capacidades. Ao marcar um item, os itens “acima” dele (ex.: o macroprocesso de um processo) e os seus dados próprios (ex.: tarefas de um projeto, registros de um indicador) acompanham o arquivo.</p>' +
        '<div class="mb-2"><button class="btn btn-sm btn-outline-secondary" onclick="Pacote.itensMarcar(\'itLista\',true)">Marcar tudo</button> <button class="btn btn-sm btn-outline-secondary" onclick="Pacote.itensMarcar(\'itLista\',false)">Limpar</button></div><div id="itLista" class="xi-box"></div><div class="mt-2"><button class="btn btn-success" onclick="Pacote.itensExportar(\'xml\')"><i class="bi bi-filetype-xml"></i> Exportar itens marcados (.xml)</button> <button class="btn btn-outline-success" onclick="Pacote.itensExportar(\'json\')"><i class="bi bi-filetype-json"></i> .json</button></div><pre id="segRes" class="small" style="white-space:pre-wrap"></pre>' +
        '<h6>Importar</h6><p class="ajuda mb-1">Serve para pacotes completos e parciais. Use <b>Escolher itens do arquivo…</b> para ler o arquivo, ver o que ele contém e importar apenas o que interessa (sempre em <b>Mesclar</b>); os vínculos (riscos, indicadores, tarefas…) são refeitos.</p><div class="mb-2"><label class="me-3"><input type="radio" name="pmodo" value="mesclar" checked> <b>Mesclar</b> — o que já existe é <b>atualizado</b> e o que não existe é <b>criado</b> (vínculos são refeitos)</label><label><input type="radio" name="pmodo" value="substituir"> <b>Substituir tudo</b> — restaura o pacote e apaga o conteúdo atual</label></div>' +
        '<input type="file" class="form-control" id="pArq" accept=".json,.xml,.sqlite,.db" style="max-width:420px"><div class="mt-2"><button class="btn btn-warning" onclick="Pacote.importarArquivo()"><i class="bi bi-upload"></i> Importar arquivo inteiro</button> <button class="btn btn-outline-primary" onclick="Pacote.itensLer()"><i class="bi bi-list-check"></i> Escolher itens do arquivo…</button></div><div id="itImp" class="mt-2"></div><pre id="pRes" class="small mt-2" style="white-space:pre-wrap"></pre></div></div>';
    },
    importarArquivo: function () {
      var f = document.getElementById('pArq').files[0]; if (!f) return alert('Escolha um arquivo.');
      var modo = document.querySelector('input[name=pmodo]:checked').value;
      if (/\.(sqlite|db)$/i.test(f.name)) {
        if (f.size > ((w.SEC && SEC.MAX_IMPORT_BYTES) || 80*1024*1024)) return alert('Arquivo acima do limite de segurança.');
        if (!confirm('Substituir TODO o banco atual por este arquivo? Esta ação não pode ser desfeita.')) return;
        var fr0 = new FileReader(); fr0.onload = function () {
          try {
            var u = new Uint8Array(fr0.result);
            // SQLite magic "SQLite format 3"
            var mag = String.fromCharCode.apply(null, u.subarray(0, 15));
            if (mag.indexOf('SQLite format 3') !== 0) throw new Error('Não é um arquivo SQLite válido.');
            DB.substituir(u);
            if (w.SEC) SEC.audit('importar', 'sqlite substituir');
            alert('Banco restaurado.'); Nav.ir('#/');
          } catch (e) { alert('Arquivo inválido: ' + e.message); }
        }; fr0.readAsArrayBuffer(f); return;
      }
      if (modo === 'substituir' && !confirm('Isto APAGA o conteúdo atual e restaura o pacote. Continuar?')) return;
      var fr = new FileReader(); fr.onload = function () {
        try {
          var r = Pacote.importarTexto(String(fr.result), modo);
          if (r) { document.getElementById('pRes').textContent = 'Importação concluída (' + (modo === 'substituir' ? 'substituir' : 'mesclar') + ').\n' + Pacote.resumo(r); return; }
          Acoes.importar(f);   // formatos anteriores (riscos .xml/.json, processos)
        } catch (e) { document.getElementById('pRes').textContent = 'Erro: ' + e.message; }
      };
      fr.readAsText(f);
    }
  };
})(window);
