/**
 * VMAP Diagram - Biblioteca de diagramação BPMN estilo Bizagi
 * Compatível com a API do bpmn-js para facilitar a migração
 * VERSÃO CORRIGIDA - Conexão automática e movimentação facilitada
 */
(function (global) {
    'use strict';

    // ================================================================
    // CONFIGURAÇÕES
    // ================================================================
    var CONFIG = {
        laneHeight: 140,
        laneWidth: 700,
        taskWidth: 100,
        taskHeight: 80,
        gatewaySize: 50,
        gatewayBranchGap: 14,
        gatewayExitLength: 24,
        eventSize: 36,
        spacing: 60,
        padding: 24,
        minLaneHeight: 70,
        minLaneWidth: 200
    };

    var TAMANHOS = {
        'bpmn:StartEvent': { w: 36, h: 36 },
        'bpmn:EndEvent': { w: 36, h: 36 },
        'bpmn:IntermediateThrowEvent': { w: 36, h: 36 },
        'bpmn:IntermediateCatchEvent': { w: 36, h: 36 },
        'bpmn:TimerEvent': { w: 36, h: 36 },
        'bpmn:MessageEvent': { w: 36, h: 36 },
        'bpmn:Task': { w: 100, h: 80 },
        'bpmn:ManualTask': { w: 100, h: 80 },
        'bpmn:ServiceTask': { w: 100, h: 80 },
        'bpmn:UserTask': { w: 100, h: 80 },
        'bpmn:ScriptTask': { w: 100, h: 80 },
        'bpmn:BusinessRuleTask': { w: 100, h: 80 },
        'bpmn:SendTask': { w: 100, h: 80 },
        'bpmn:ReceiveTask': { w: 100, h: 80 },
        'bpmn:SubProcess': { w: 100, h: 80 },
        'bpmn:CallActivity': { w: 100, h: 80 },
        'bpmn:AdHocSubProcess': { w: 100, h: 80 },
        'bpmn:Transaction': { w: 100, h: 80 },
        'bpmn:ExclusiveGateway': { w: 50, h: 50 },
        'bpmn:ParallelGateway': { w: 50, h: 50 },
        'bpmn:InclusiveGateway': { w: 50, h: 50 },
        'bpmn:EventBasedGateway': { w: 50, h: 50 },
        'bpmn:ComplexGateway': { w: 50, h: 50 },
        'bpmn:TextAnnotation': { w: 100, h: 50 },
        'bpmn:DataObject': { w: 36, h: 46 },
        'bpmn:DataStore': { w: 40, h: 50 },
        'bpmn:Group': { w: 200, h: 120 },
        'bpmn:Participant': { w: 700, h: 140 },
        'bpmn:Lane': { w: 650, h: 120 }
    };

    var CORES = {
        'bpmn:StartEvent': { stroke: '#548235', fill: '#A9D18E' },
        'bpmn:EndEvent': { stroke: '#C00000', fill: '#F2A2A2' },
        'bpmn:IntermediateThrowEvent': { stroke: '#C55A11', fill: '#F8CBAD' },
        'bpmn:IntermediateCatchEvent': { stroke: '#C55A11', fill: '#F8CBAD' },
        'bpmn:TimerEvent': { stroke: '#C55A11', fill: '#F8CBAD' },
        'bpmn:MessageEvent': { stroke: '#C55A11', fill: '#F8CBAD' },
        'bpmn:Task': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:ManualTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:ServiceTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:UserTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:ScriptTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:BusinessRuleTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:SendTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:ReceiveTask': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:SubProcess': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:CallActivity': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:AdHocSubProcess': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:Transaction': { stroke: '#2E74B5', fill: '#BDD7EE' },
        'bpmn:ExclusiveGateway': { stroke: '#BF8F00', fill: '#FFE699' },
        'bpmn:ParallelGateway': { stroke: '#BF8F00', fill: '#FFE699' },
        'bpmn:InclusiveGateway': { stroke: '#BF8F00', fill: '#FFE699' },
        'bpmn:EventBasedGateway': { stroke: '#BF8F00', fill: '#FFE699' },
        'bpmn:ComplexGateway': { stroke: '#BF8F00', fill: '#FFE699' },
        'bpmn:TextAnnotation': { stroke: '#2E74B5', fill: '#DEEBF7' },
        'bpmn:DataObject': { stroke: '#7F7F7F', fill: '#F2F2F2' },
        'bpmn:DataStore': { stroke: '#7F7F7F', fill: '#F2F2F2' },
        'bpmn:Group': { stroke: '#7F7F7F', fill: 'transparent' },
        'bpmn:Lane': { stroke: '#8EA9DB', fill: '#F3F7FC' },
        'bpmn:Participant': { stroke: '#44546A', fill: '#ffffff' }
    };

    var SVG_NS = 'http://www.w3.org/2000/svg';
    var LANE_LABEL_LARGURA = 30;
    var POOL_HEADER_LARGURA = 30;

    // ================================================================
    // DIREÇÃO PADRÃO DE CONEXÃO ENTRE TAREFA/GATEWAY E EVENTO/ARTEFATO
    // ================================================================
    var TIPOS_DIRECAO_ENTRADA = {
        'bpmn:StartEvent': true,
        'bpmn:IntermediateCatchEvent': true,
        'bpmn:TimerEvent': true,
        'bpmn:MessageEvent': true,
        'bpmn:DataStore': true
    };
    var TIPOS_DIRECAO_SAIDA = {
        'bpmn:EndEvent': true,
        'bpmn:IntermediateThrowEvent': true,
        'bpmn:TextAnnotation': true,
        'bpmn:DataObject': true
    };

    var TIPOS_ANEXAVEIS = {
        'bpmn:IntermediateThrowEvent': true,
        'bpmn:IntermediateCatchEvent': true,
        'bpmn:TimerEvent': true,
        'bpmn:MessageEvent': true,
        'bpmn:TextAnnotation': true,
        'bpmn:DataObject': true,
        'bpmn:DataStore': true
    };

    // ================================================================
    // UTILITÁRIOS
    // ================================================================
    function el(tag, attrs, parent) {
        var e = document.createElementNS(SVG_NS, tag);
        if (attrs) {
            for (var k in attrs) {
                if (Object.prototype.hasOwnProperty.call(attrs, k)) {
                    e.setAttribute(k, attrs[k]);
                }
            }
        }
        if (parent) parent.appendChild(e);
        return e;
    }

    function escapeXml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    }

    function gerarId() {
        return Math.random().toString(36).slice(2, 10);
    }

    // ================================================================
    // EVENT BUS
    // ================================================================
    function EventBus() {
        this._h = {};
    }
    EventBus.prototype.on = function (evt, cb) {
        (this._h[evt] = this._h[evt] || []).push(cb);
    };
    EventBus.prototype.off = function (evt, cb) {
        if (this._h[evt]) {
            this._h[evt] = this._h[evt].filter(function(c) { return c !== cb; });
        }
    };
    EventBus.prototype.fire = function (evt, payload) {
        (this._h[evt] || []).forEach(function (cb) { cb(payload); });
    };

    // ================================================================
    // MODELO DO DIAGRAMA
    // ================================================================
    function Diagram(container) {
        this.container = container;
        this.elements = {};
        this.flows = {};
        this.lanes = [];
        this.participant = null;
        this.processId = 'Process_' + gerarId();
        this.processName = 'Processo';
        this._counter = 0;
        this._taskSeq = 0; // contador sequencial de tarefas (exibido no canto superior direito)
        this.selectedIds = [];
        this.hoveredId = null;
        this._edicaoInlineEl = null;
        this.events = new EventBus();
        this.scale = 1;
        this.vbX = 0;
        this.vbY = 0;
        this.vbW = 1200;
        this.vbH = 800;
        this._connectionSource = null;
        this._isConnecting = false;
        this._draggingElement = null;
        this._draggingConnection = null;
        this._draggingLane = null;
        this._clipboard = null;
        this._toolAtiva = null;
        this._modoInserir = null;
        this._modoConexao = null;
        this._overlaysAtivos = {};
        this._initialized = false;
        this._painelRiscosEl = null;
        this._ultimoElementoSelecionado = null;
        this._expandindoRaia = null;
        this._arrastandoConexao = false;
        this._ultimoPontoConexao = null;
        this._arrastandoExtremidadeConexao = null;
        this._conectandoLivre = false;
        this._menuInsercaoEl = null;
        this._insertMenu = null;
        this._insertMenuOrigemId = null;
        this._contextMenu = null;
        this._contextMenuElementId = null;
    }

    // ================================================================
    // INICIALIZAÇÃO
    // ================================================================
    Diagram.prototype.init = function () {
        if (this._initialized) return;
        this._initialized = true;
        
        this._buildDom();
        this._bindEvents();
        this._buildPalette();
        this._buildContextMenu();
        this._buildInsertContextMenu();
        this._buildZoomControls();
        this._ajustarParaCaber();
    };

    Diagram.prototype._buildDom = function () {
        this.container.style.position = 'relative';
        this.container.style.overflow = 'auto';
        this.container.style.width = '100%';
        this.container.style.height = '100%';
        this.container.style.minHeight = '500px';
        this.container.style.background = '#f0f2f5';
        this.container.style.outline = 'none';
        this.container.style.cursor = 'default';

        var existingSvg = this.container.querySelector('svg.vmap-svg');
        if (existingSvg) {
            this.svg = existingSvg;
            this.gViewport = this.svg.querySelector('.viewport') || el('g', { class: 'viewport' }, this.svg);
            this.gLanes = this.svg.querySelector('.vmap-lanes') || el('g', { class: 'vmap-lanes' }, this.gViewport);
            this.gConnections = this.svg.querySelector('.vmap-connections') || el('g', { class: 'vmap-connections' }, this.gViewport);
            this.gShapes = this.svg.querySelector('.vmap-shapes') || el('g', { class: 'vmap-shapes' }, this.gViewport);
            
            var vb = this.svg.getAttribute('viewBox');
            if (vb) {
                var parts = vb.split(' ').map(Number);
                if (parts.length === 4) {
                    this.vbX = parts[0];
                    this.vbY = parts[1];
                    this.vbW = parts[2];
                    this.vbH = parts[3];
                }
            }
            
            this.overlayLayer = this.container.querySelector('.vmap-overlay-layer');
            if (!this.overlayLayer) {
                this.overlayLayer = document.createElement('div');
                this.overlayLayer.className = 'vmap-overlay-layer';
                this.overlayLayer.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none;width:100%;height:100%;';
                this.container.appendChild(this.overlayLayer);
            }
            
            this.svg.style.width = '100%';
            this.svg.style.height = '100%';
            this.svg.style.display = 'block';
            
            this._connectionLine = this.gConnections.querySelector('.vmap-connection-line');
            if (!this._connectionLine) {
                this._connectionLine = el('path', {
                    fill: 'none',
                    stroke: '#0a6fc2',
                    'stroke-width': 2,
                    'stroke-dasharray': '6,4',
                    'pointer-events': 'none',
                    display: 'none',
                    class: 'vmap-connection-line'
                }, this.gConnections);
            }
            
            return;
        }

        this.container.innerHTML = '';
        this.container.classList.add('djs-container', 'vmap-container');

        var svgWrapper = document.createElement('div');
        svgWrapper.style.cssText = 'width:100%;height:100%;overflow:auto;position:relative;';
        this.container.appendChild(svgWrapper);

        this.svg = el('svg', {
            style: 'display:block;min-width:800px;min-height:500px;',
            class: 'vmap-svg'
        }, svgWrapper);

        var defs = el('defs', {}, this.svg);
        
        var marker = el('marker', {
            id: 'vmap-arrow', viewBox: '0 0 10 10', refX: '9', refY: '5',
            markerWidth: '8', markerHeight: '8', orient: 'auto-start-reverse'
        }, defs);
        el('path', { d: 'M0,0 L10,5 L0,10 z', fill: '#5a6b7d' }, marker);

        var markerSel = el('marker', {
            id: 'vmap-arrow-selected', viewBox: '0 0 10 10', refX: '9', refY: '5',
            markerWidth: '8', markerHeight: '8', orient: 'auto-start-reverse'
        }, defs);
        el('path', { d: 'M0,0 L10,5 L0,10 z', fill: '#0a6fc2' }, markerSel);

        this.gViewport = el('g', { class: 'viewport' }, this.svg);
        this.gLanes = el('g', { class: 'vmap-lanes' }, this.gViewport);
        this.gConnections = el('g', { class: 'vmap-connections' }, this.gViewport);
        this.gShapes = el('g', { class: 'vmap-shapes' }, this.gViewport);

        this.overlayLayer = document.createElement('div');
        this.overlayLayer.className = 'vmap-overlay-layer';
        this.overlayLayer.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none;width:100%;height:100%;';
        svgWrapper.appendChild(this.overlayLayer);

        this._connectionLine = el('path', {
            fill: 'none',
            stroke: '#0a6fc2',
            'stroke-width': 2,
            'stroke-dasharray': '6,4',
            'pointer-events': 'none',
            display: 'none',
            class: 'vmap-connection-line'
        }, this.gConnections);

        this._atualizarViewport();
    };

    Diagram.prototype._atualizarViewport = function () {
        var w = Math.max(1200, this.vbW * this.scale + 200);
        var h = Math.max(800, this.vbH * this.scale + 200);
        this.svg.setAttribute('viewBox', 
            this.vbX + ' ' + this.vbY + ' ' + this.vbW + ' ' + this.vbH
        );
        this.svg.setAttribute('width', w);
        this.svg.setAttribute('height', h);
        
        if (this.overlayLayer) {
            this.overlayLayer.style.width = w + 'px';
            this.overlayLayer.style.height = h + 'px';
        }
    };

    // ================================================================
    // CONTROLES DE ZOOM
    // ================================================================
    Diagram.prototype._buildZoomControls = function () {
        var self = this;
        
        var zoomContainer = document.createElement('div');
        zoomContainer.className = 'vmap-zoom-controls';
        zoomContainer.style.cssText = 
            'position:absolute;bottom:20px;right:20px;z-index:100;' +
            'display:flex;flex-direction:column;gap:2px;' +
            'background:#fff;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,0.15);' +
            'padding:4px;';
        
        var btnZoomIn = document.createElement('button');
        btnZoomIn.innerHTML = '<i class="bi bi-zoom-in"></i>';
        btnZoomIn.style.cssText = 
            'width:32px;height:32px;border:none;background:transparent;' +
            'border-radius:4px;cursor:pointer;font-size:16px;color:#4a86c5;' +
            'display:flex;align-items:center;justify-content:center;';
        btnZoomIn.title = 'Aumentar zoom (Ctrl + Scroll)';
        btnZoomIn.addEventListener('click', function() {
            self.scale = Math.min(4, self.scale * 1.2);
            self._atualizarViewport();
            self._render();
            if (self._atualizarZoomLabel) self._atualizarZoomLabel();
        });
        
        var btnZoomOut = document.createElement('button');
        btnZoomOut.innerHTML = '<i class="bi bi-zoom-out"></i>';
        btnZoomOut.style.cssText = 
            'width:32px;height:32px;border:none;background:transparent;' +
            'border-radius:4px;cursor:pointer;font-size:16px;color:#4a86c5;' +
            'display:flex;align-items:center;justify-content:center;';
        btnZoomOut.title = 'Diminuir zoom (Ctrl + Scroll)';
        btnZoomOut.addEventListener('click', function() {
            self.scale = Math.max(0.15, self.scale / 1.2);
            self._atualizarViewport();
            self._render();
            if (self._atualizarZoomLabel) self._atualizarZoomLabel();
        });
        
        var btnZoomFit = document.createElement('button');
        btnZoomFit.innerHTML = '<i class="bi bi-arrows-angle-contract"></i>';
        btnZoomFit.style.cssText = 
            'width:32px;height:32px;border:none;background:transparent;' +
            'border-radius:4px;cursor:pointer;font-size:16px;color:#4a86c5;' +
            'display:flex;align-items:center;justify-content:center;';
        btnZoomFit.title = 'Ajustar à tela';
        btnZoomFit.addEventListener('click', function() {
            self._ajustarParaCaber();
        });
        
        var zoomLabel = document.createElement('div');
        zoomLabel.id = 'vmap-zoom-label';
        zoomLabel.style.cssText = 
            'font-size:11px;color:#6c757d;text-align:center;padding:2px 0;';
        zoomLabel.textContent = Math.round(self.scale * 100) + '%';
        
        zoomContainer.appendChild(btnZoomIn);
        zoomContainer.appendChild(zoomLabel);
        zoomContainer.appendChild(btnZoomOut);
        zoomContainer.appendChild(btnZoomFit);
        
        this.container.appendChild(zoomContainer);
        this._zoomLabel = zoomLabel;
        
        this._atualizarZoomLabel = function() {
            if (self._zoomLabel) {
                self._zoomLabel.textContent = Math.round(self.scale * 100) + '%';
            }
        };
    };

    // ================================================================
    // PALETA DE FERRAMENTAS
    // ================================================================
    /**
     * Ícones vetoriais próprios, inspirados na notação BPMN/Bizagi.
     * Não dependem de emoji, fonte instalada ou Bootstrap Icons, evitando
     * diferenças visuais entre Windows, macOS e navegadores.
     */
    function paletteIcon(tipo, cor) {
        cor = cor || '#3b6ea8';
        var c = '#ffffff';
        var sw = 1.7;
        var common = 'width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"';
        var body = '';
        switch (tipo) {
            case 'bpmn:StartEvent':
                body = '<circle cx="12" cy="12" r="8" fill="#e2f0d9" stroke="#548235" stroke-width="1.8"/>';
                break;
            case 'bpmn:EndEvent':
                body = '<circle cx="12" cy="12" r="8" fill="#fde9e7" stroke="#c00000" stroke-width="2"/><circle cx="12" cy="12" r="5.3" fill="none" stroke="#c00000" stroke-width="1.5"/>';
                break;
            case 'bpmn:IntermediateThrowEvent':
            case 'bpmn:IntermediateCatchEvent':
                body = '<circle cx="12" cy="12" r="8" fill="#fff2e8" stroke="#c55a11" stroke-width="1.8"/><circle cx="12" cy="12" r="5.6" fill="none" stroke="#c55a11" stroke-width="1.3"/>';
                break;
            case 'bpmn:TimerEvent':
                body = '<circle cx="12" cy="12" r="8" fill="#fff2e8" stroke="#c55a11" stroke-width="1.8"/><circle cx="12" cy="12" r="5.6" fill="none" stroke="#c55a11" stroke-width="1.2"/><path d="M12 12V8.5M12 12l3 1.8M9 3.8h6" fill="none" stroke="#c55a11" stroke-width="1.5" stroke-linecap="round"/>';
                break;
            case 'bpmn:MessageEvent':
                body = '<circle cx="12" cy="12" r="8" fill="#fff2e8" stroke="#c55a11" stroke-width="1.8"/><rect x="7" y="9" width="10" height="7" rx="1" fill="none" stroke="#c55a11" stroke-width="1.3"/><path d="M7.3 9.5L12 13l4.7-3.5" fill="none" stroke="#c55a11" stroke-width="1.3"/>';
                break;
            case 'bpmn:Task':
                body = '<rect x="3" y="5" width="18" height="14" rx="2.5" fill="#ddebf7" stroke="#2e74b5" stroke-width="1.6"/>';
                break;
            case 'bpmn:UserTask':
                body = '<rect x="3" y="5" width="18" height="14" rx="2.5" fill="#ddebf7" stroke="#2e74b5" stroke-width="1.6"/><circle cx="8" cy="10" r="1.7" fill="none" stroke="#2e74b5" stroke-width="1.2"/><path d="M5.7 15c.7-2 4-2 4.7 0" fill="none" stroke="#2e74b5" stroke-width="1.2"/>';
                break;
            case 'bpmn:ServiceTask':
                body = '<rect x="3" y="5" width="18" height="14" rx="2.5" fill="#ddebf7" stroke="#2e74b5" stroke-width="1.6"/><circle cx="8" cy="12" r="2.2" fill="none" stroke="#2e74b5" stroke-width="1.2"/><path d="M8 8.5v1M8 14.5v1M4.5 12h1M10.5 12h1M5.5 9.5l.7.7M9.8 13.8l.7.7M10.5 9.5l-.7.7M6.2 13.8l-.7.7" stroke="#2e74b5" stroke-width="1"/>';
                break;
            case 'bpmn:ScriptTask':
                body = '<rect x="3" y="5" width="18" height="14" rx="2.5" fill="#ddebf7" stroke="#2e74b5" stroke-width="1.6"/><path d="M7 9h10M7 12h7M7 15h5" stroke="#2e74b5" stroke-width="1.2"/>';
                break;
            case 'bpmn:SubProcess':
                body = '<rect x="3" y="5" width="18" height="14" rx="2.5" fill="#ddebf7" stroke="#2e74b5" stroke-width="1.6"/><rect x="9" y="14" width="6" height="4" fill="#fff" stroke="#2e74b5" stroke-width="1"/><path d="M12 14.8v2.4M10.8 16h2.4" stroke="#2e74b5" stroke-width="1"/>';
                break;
            case 'bpmn:ExclusiveGateway':
                body = '<polygon points="12,2.5 21.5,12 12,21.5 2.5,12" fill="#fff2cc" stroke="#bf8f00" stroke-width="1.6"/><path d="M8.3 8.3l7.4 7.4M15.7 8.3l-7.4 7.4" stroke="#bf8f00" stroke-width="1.8" stroke-linecap="round"/>';
                break;
            case 'bpmn:ParallelGateway':
                body = '<polygon points="12,2.5 21.5,12 12,21.5 2.5,12" fill="#fff2cc" stroke="#bf8f00" stroke-width="1.6"/><path d="M12 7v10M7 12h10" stroke="#bf8f00" stroke-width="1.8" stroke-linecap="round"/>';
                break;
            case 'bpmn:InclusiveGateway':
                body = '<polygon points="12,2.5 21.5,12 12,21.5 2.5,12" fill="#fff2cc" stroke="#bf8f00" stroke-width="1.6"/><circle cx="12" cy="12" r="3.7" fill="none" stroke="#bf8f00" stroke-width="1.8"/>';
                break;
            case 'bpmn:EventBasedGateway':
                body = '<polygon points="12,2.5 21.5,12 12,21.5 2.5,12" fill="#fff2cc" stroke="#bf8f00" stroke-width="1.6"/><circle cx="12" cy="12" r="4.2" fill="none" stroke="#bf8f00" stroke-width="1.2"/><circle cx="12" cy="12" r="1.4" fill="#bf8f00"/>';
                break;
            case 'bpmn:TextAnnotation':
                // Formato correto de anotação BPMN: colchete aberto à
                // direita (sem preenchimento sólido), bem mais discreto
                // que um ícone de "documento" cheio.
                body = '<path d="M9.5 4.5H6v15h3.5" fill="none" stroke="#7f7f7f" stroke-width="1.4" stroke-linecap="square"/><path d="M9.5 9.5h8M9.5 12.5h8M9.5 15.5h5" stroke="#7f7f7f" stroke-width="1.1" stroke-linecap="round"/>';
                break;
            case 'bpmn:DataObject':
                body = '<path d="M6 3.5h8l4 4v13H6z" fill="#f2f2f2" stroke="#7f7f7f" stroke-width="1.4"/><path d="M14 3.5v4h4" fill="none" stroke="#7f7f7f" stroke-width="1.1"/>';
                break;
            case 'bpmn:DataStore':
                body = '<ellipse cx="12" cy="7" rx="7" ry="3" fill="#f2f2f2" stroke="#7f7f7f" stroke-width="1.4"/><path d="M5 7v9c0 1.7 3.1 3 7 3s7-1.3 7-3V7" fill="#f2f2f2" stroke="#7f7f7f" stroke-width="1.4"/><path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3" fill="none" stroke="#7f7f7f" stroke-width="1.1"/>';
                break;
            case 'bpmn:Group':
                body = '<rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="#7f7f7f" stroke-width="1.4" stroke-dasharray="4 2"/><path d="M7 9h6M10 6v6" stroke="#7f7f7f" stroke-width="1.1"/>';
                break;
            case 'sequenceFlow':
                body = '<path d="M3 12h15" stroke="#5a6b7d" stroke-width="1.7"/><path d="M14 8l5 4-5 4" fill="none" stroke="#5a6b7d" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>';
                break;
            case 'association':
                body = '<path d="M3 12h17" stroke="#7f7f7f" stroke-width="1.5" stroke-dasharray="3 2"/>';
                break;
            case 'lane':
                body = '<rect x="3" y="4" width="18" height="16" rx="1" fill="#f3f7fc" stroke="#8ea9db" stroke-width="1.4"/><path d="M8 4v16" stroke="#8ea9db" stroke-width="1.2"/>';
                break;
            case 'divide-lane':
                body = '<rect x="3" y="4" width="18" height="16" rx="1" fill="#f3f7fc" stroke="#8ea9db" stroke-width="1.4"/><path d="M12 4v16M8 10l4 4 4-4" fill="none" stroke="#8ea9db" stroke-width="1.2"/>';
                break;
            case 'risk':
                body = '<path d="M6 20V4" stroke="#c00000" stroke-width="1.7"/><path d="M7 5c4-2 6 2 11 0v7c-5 2-7-2-11 0z" fill="#f2a2a2" stroke="#c00000" stroke-width="1.4"/>';
                break;
            case 'hand':
                body = '<path d="M8 11V6.5a1.5 1.5 0 0 1 3 0V10V5.5a1.5 1.5 0 0 1 3 0V10V7a1.5 1.5 0 0 1 3 0v6.2c0 4.2-2.7 6.8-6.5 6.8-2.8 0-4.8-1.7-6.2-4.3L3.5 13a1.6 1.6 0 0 1 2.8-1.2L8 14z" fill="#f2f2f2" stroke="#5a6b7d" stroke-width="1.2" stroke-linejoin="round"/>';
                break;
            default:
                body = '<rect x="4" y="4" width="16" height="16" rx="3" fill="#f2f2f2" stroke="' + cor + '" stroke-width="1.5"/>';
        }
        return '<svg ' + common + '>' + body + '</svg>';
    }

    // Inserção de elementos só pela Folha de Dados do Processo (item 7): o editor não cria elementos nem conexões.
    var BLOQUEAR_INSERCAO = true;

    Diagram.prototype._buildPalette = function () {
        var self = this;
        
        var existing = this.container.querySelector('.djs-palette.vmap-palette');
        if (existing) existing.remove();

        this.paletteEl = document.createElement('div');
        this.paletteEl.className = 'djs-palette vmap-palette';
        this.paletteEl.style.cssText = 
            'position:absolute;left:10px;top:10px;z-index:100;' +
            'background:#fff;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,0.15);' +
            'padding:4px;user-select:none;max-height:calc(100vh - 40px);overflow-y:auto;';
        
        var entries = document.createElement('div');
        entries.className = 'djs-palette-entries';
        this.paletteEl.appendChild(entries);

        var elementosPorGrupo = {
            'eventos': [
                { tipo: 'bpmn:StartEvent', label: 'Início', icone: '▶' },
                { tipo: 'bpmn:EndEvent', label: 'Fim', icone: '●' },
                { tipo: 'bpmn:IntermediateThrowEvent', label: 'Evento', icone: '◉' },
                { tipo: 'bpmn:TimerEvent', label: 'Timer', icone: '⏱' },
                { tipo: 'bpmn:MessageEvent', label: 'Mensagem', icone: '✉' }
            ],
            'atividades': [
                { tipo: 'bpmn:Task', label: 'Tarefa', icone: '▭' },
                { tipo: 'bpmn:UserTask', label: 'Tarefa Usuário', icone: '👤' },
                { tipo: 'bpmn:ServiceTask', label: 'Tarefa Serviço', icone: '⚙' },
                { tipo: 'bpmn:ScriptTask', label: 'Tarefa Script', icone: '◊' },
                { tipo: 'bpmn:SubProcess', label: 'Subprocesso', icone: '⊞' }
            ],
            'gateways': [
                { tipo: 'bpmn:ExclusiveGateway', label: 'Decisão', icone: '◇' },
                { tipo: 'bpmn:ParallelGateway', label: 'Paralelo', icone: '⬡' },
                { tipo: 'bpmn:InclusiveGateway', label: 'Inclusivo', icone: '⬢' },
                { tipo: 'bpmn:EventBasedGateway', label: 'Baseado em Evento', icone: '✦' }
            ],
            'artefatos': [
                { tipo: 'bpmn:TextAnnotation', label: 'Anotação', icone: '📝' },
                { tipo: 'bpmn:DataObject', label: 'Dados', icone: '📄' },
                { tipo: 'bpmn:DataStore', label: 'Armazenamento', icone: '💾' },
                { tipo: 'bpmn:Group', label: 'Grupo', icone: '⊕' }
            ],
            'conexoes': [
                { tipo: 'sequenceFlow', label: 'Fluxo', icone: '➡' },
                { tipo: 'association', label: 'Associação', icone: '⋯' }
            ],
            'raias': [
                { tipo: 'lane', label: 'Adicionar Raia', icone: '⊟' },
                { tipo: 'divide-lane', label: 'Dividir Raia', icone: '⊝' }
            ],
            'risco': [
                { tipo: 'risk', label: 'Risco', icone: '⚑' }
            ],
            'ferramentas': [
                { tipo: 'hand', label: 'Mão', icone: '☝' },
                { tipo: 'risk', label: 'Risco — arraste a bandeira até uma atividade', icone: '⚑' }
            ]
        };

        var grupos = [
            { id: 'ferramentas', label: 'Ferramentas' }
        ];

        grupos.forEach(function(g) {
            var groupDiv = document.createElement('div');
            groupDiv.className = 'group';
            groupDiv.dataset.group = g.id;
            groupDiv.style.cssText = 'padding:2px 0;border-bottom:1px solid #e9ecef;';
            
            var label = document.createElement('div');
            label.className = 'group-label';
            label.textContent = g.label;
            label.style.cssText = 'font-size:9px;color:#6c757d;text-align:center;padding:2px 0;';
            groupDiv.appendChild(label);

            (elementosPorGrupo[g.id] || []).forEach(function(item) {
                var entry = document.createElement('div');
                entry.className = 'entry';
                entry.title = item.label;
                entry.setAttribute('aria-label', item.label);
                var cor = item.tipo === 'risk' ? '#c00000' : '#3b6ea8';
                var bg = item.tipo === 'risk' ? '#fff5f5' : '#f8fafc';
                entry.innerHTML = paletteIcon(item.tipo, cor);
                entry.style.cssText = 
                    'width:42px;height:38px;display:flex;align-items:center;justify-content:center;' +
                    'border-radius:5px;cursor:pointer;color:' + cor + ';' +
                    'transition:background 0.15s,box-shadow 0.15s,border-color 0.15s;margin:1px auto;background:' + bg + ';' +
                    'border:1px solid transparent;';
                
                entry.addEventListener('mouseenter', function() {
                    this.style.background = '#e9ecef';
                    this.style.border = '1px solid #0a6fc2';
                });
                entry.addEventListener('mouseleave', function() {
                    this.style.background = bg;
                    this.style.border = '1px solid transparent';
                });
                
                if (item.tipo === 'risk') { self._ligarFerramentaRisco(entry); }
                else entry.addEventListener('click', function(ev) {
                    ev.stopPropagation();
                    self._ativarFerramenta(item.tipo, item.label);
                });
                
                groupDiv.appendChild(entry);
            });

            entries.appendChild(groupDiv);
        });

        this.container.appendChild(this.paletteEl);
    };

    Diagram.prototype._ativarFerramenta = function(tipo, label) {
        this._toolAtiva = tipo;
        this._toolLabel = label;
        
        var entries = this.paletteEl.querySelectorAll('.entry');
        entries.forEach(function(el) {
            el.style.background = 'transparent';
            el.style.border = '1px solid transparent';
        });
        
        var target = this.paletteEl.querySelector('.entry[title="' + label + '"]');
        if (target) {
            target.style.background = '#cfe2ff';
            target.style.border = '1px solid #0a6fc2';
        }

        if (tipo === 'hand') {
            this.container.style.cursor = 'grab';
            this._modoInserir = null;
            this._modoConexao = null;
            this._modoRisco = false;
        } else if (tipo === 'sequenceFlow' || tipo === 'association') {
            this.container.style.cursor = 'crosshair';
            this._modoInserir = null;
            this._modoConexao = tipo;
            this._modoRisco = false;
        } else if (tipo === 'risk') {
            this.container.style.cursor = 'pointer';
            this._modoInserir = null;
            this._modoConexao = null;
            this._modoRisco = true;
            this._abrirPainelRiscos();
        } else if (tipo === 'lane') {
            this.container.style.cursor = 'default';
            this._modoInserir = null;
            this._modoConexao = null;
            this._modoRisco = false;
            this._adicionarRaia();
            this._toolAtiva = null;
            this._toolLabel = null;
            var target2 = this.paletteEl.querySelector('.entry[title="' + label + '"]');
            if (target2) {
                target2.style.background = 'transparent';
                target2.style.border = '1px solid transparent';
            }
        } else if (tipo === 'divide-lane') {
            this.container.style.cursor = 'default';
            this._modoInserir = null;
            this._modoConexao = null;
            this._modoRisco = false;
            this._dividirRaiaSelecionada();
            this._toolAtiva = null;
            this._toolLabel = null;
            var target2 = this.paletteEl.querySelector('.entry[title="' + label + '"]');
            if (target2) {
                target2.style.background = 'transparent';
                target2.style.border = '1px solid transparent';
            }
        } else {
            this.container.style.cursor = 'crosshair';
            this._modoInserir = tipo;
            this._modoConexao = null;
            this._modoRisco = false;
        }

        this.events.fire('toolChanged', { tool: tipo, label: label });
    };

    /**
     * Desativa a ferramenta de inserção/conexão ativa e devolve o
     * diagrama ao modo padrão de seleção (comportamento "usar uma vez").
     * Chamado depois que um elemento é inserido a partir da paleta, para
     * que um novo clique no canvas não crie outro elemento do mesmo tipo.
     */
    Diagram.prototype._desativarFerramenta = function () {
        this._toolAtiva = null;
        this._toolLabel = null;
        this._modoInserir = null;
        this._modoConexao = null;
        this._modoRisco = false;
        this.container.style.cursor = 'default';

        if (this.paletteEl) {
            var entries = this.paletteEl.querySelectorAll('.entry');
            entries.forEach(function (el) {
                el.style.background = 'transparent';
                el.style.border = '1px solid transparent';
            });
        }

        this.events.fire('toolChanged', { tool: null, label: null });
    };

    // ================================================================
    // PAINEL DE RISCOS
    // ================================================================
    /** Risco do elemento selecionado (menu de contexto): pede ao hospedeiro que abra o modal de riscos da atividade. */
    Diagram.prototype._abrirPainelRiscos = function () {
        var id = this.selectedIds && this.selectedIds[0];
        this._modoRisco = false;
        if (!id || !this.elements[id]) { alert('Selecione uma atividade do diagrama e depois use o botão de risco.'); return; }
        this.events.fire('flag.drop', { elementId: id });
    };

    // ---- ferramenta "Risco": arrastar a bandeira e soltar sobre uma atividade ----
    var FLAG_SVG = '<svg width="30" height="36" viewBox="0 0 30 36" xmlns="http://www.w3.org/2000/svg"><line x1="4" y1="3" x2="4" y2="32" stroke="#7a1010" stroke-width="2.6" stroke-linecap="round"/><path d="M5,4 C11,0 16,7 25,4 L25,18 C16,21 11,14 5,18 Z" fill="#dc3545" stroke="#8b0000" stroke-width="1.4" stroke-linejoin="round"/><circle cx="4" cy="32" r="2.4" fill="#7a1010"/></svg>';
    Diagram.prototype._ligarFerramentaRisco = function (entry) {
        var self = this;
        entry.addEventListener('pointerdown', function (ev) {
            if (ev.button) return; ev.preventDefault(); ev.stopPropagation();
            if (self._flagArr) { self._flagCancelar(); return; }
            self._flagIniciar(ev.clientX, ev.clientY);
        });
    };
    Diagram.prototype._flagIniciar = function (x, y) {
        var self = this, gh = document.createElement('div');
        gh.className = 'vmap-flag-ghost'; gh.innerHTML = FLAG_SVG;
        gh.style.cssText = 'position:fixed;z-index:100000;pointer-events:none;width:30px;height:36px;filter:drop-shadow(0 3px 5px rgba(0,0,0,.35));left:' + (x - 4) + 'px;top:' + (y - 33) + 'px;';
        document.body.appendChild(gh);
        var dica = document.createElement('div');
        dica.style.cssText = 'position:fixed;z-index:100000;pointer-events:none;background:#33404d;color:#fff;font:12px/1.2 sans-serif;padding:5px 9px;border-radius:6px;left:' + (x + 22) + 'px;top:' + (y - 30) + 'px;white-space:nowrap';
        dica.textContent = 'Solte sobre a atividade'; document.body.appendChild(dica);
        var st = { gh: gh, dica: dica, x0: x, y0: y, moveu: false, armado: false };
        this._flagArr = st;
        st.mv = function (ev) {
            gh.style.left = (ev.clientX - 4) + 'px'; gh.style.top = (ev.clientY - 33) + 'px'; dica.style.left = (ev.clientX + 22) + 'px'; dica.style.top = (ev.clientY - 30) + 'px';
            if (Math.abs(ev.clientX - st.x0) + Math.abs(ev.clientY - st.y0) > 8) st.moveu = true;
        };
        st.up = function (ev) {
            if (st.moveu) { var ok = self._flagSoltar(ev.clientX, ev.clientY); self._flagCancelar(); return; }
            st.armado = true; dica.textContent = 'Clique na atividade (Esc cancela)';   // clique simples: fica armada até o próximo clique
        };
        st.dn = function (ev) {
            if (!st.armado) return;
            if (ev.target && ev.target.closest && ev.target.closest('.vmap-palette')) return;
            ev.preventDefault(); ev.stopPropagation(); self._flagSoltar(ev.clientX, ev.clientY); self._flagCancelar();
        };
        st.kd = function (ev) { if (ev.key === 'Escape') self._flagCancelar(); };
        document.addEventListener('pointermove', st.mv, true); document.addEventListener('pointerup', st.up, true);
        document.addEventListener('pointerdown', st.dn, true); document.addEventListener('keydown', st.kd, true);
    };
    Diagram.prototype._flagCancelar = function () {
        var st = this._flagArr; if (!st) return;
        document.removeEventListener('pointermove', st.mv, true); document.removeEventListener('pointerup', st.up, true);
        document.removeEventListener('pointerdown', st.dn, true); document.removeEventListener('keydown', st.kd, true);
        if (st.gh.parentNode) st.gh.parentNode.removeChild(st.gh); if (st.dica.parentNode) st.dica.parentNode.removeChild(st.dica);
        this._flagArr = null;
    };
    Diagram.prototype._flagSoltar = function (x, y) {
        var alvo = document.elementFromPoint(x, y), sh = alvo && alvo.closest ? alvo.closest('[data-element-kind="shape"]') : null;
        var id = sh ? sh.getAttribute('data-element-id') : null, eo = id && this.elements[id];
        if (!eo || eo.type === 'bpmn:TextAnnotation' || eo.type === 'bpmn:Group') { this.events.fire('flag.invalid', {}); return false; }
        this.events.fire('flag.drop', { elementId: id }); return true;
    };

    // ================================================================
    // EDIÇÃO (RENOMEAR)
    // ================================================================
    Diagram.prototype._renomearSelecionado = function () {
        var self = this;
        if (!this.selectedIds || !this.selectedIds.length) return;
        var id = this.selectedIds[0];

        var alvo = this.elements[id];
        var tipoAlvo = 'elemento';
        if (!alvo) {
            alvo = this.flows[id];
            tipoAlvo = 'fluxo';
        }
        if (!alvo) {
            alvo = this.lanes.find(function (l) { return l.id === id; });
            tipoAlvo = 'raia';
        }
        if (!alvo) return;

        var anterior = document.querySelector('.vmap-rename-input');
        if (anterior) anterior.remove();

        var pt;
        if (tipoAlvo === 'elemento' && alvo.type && alvo.type.indexOf('Gateway') !== -1) {
            // Nos gateways o rótulo (a pergunta da decisão) é exibido acima
            // do losango, não centralizado sobre a forma — a caixa de
            // edição precisa aparecer no mesmo lugar do texto renderizado.
            pt = this._modeloParaSvg(alvo.x + alvo.w / 2, alvo.y - 6);
        } else if (tipoAlvo === 'elemento') {
            pt = this._modeloParaSvg(alvo.x + alvo.w / 2, alvo.y + alvo.h / 2);
        } else if (tipoAlvo === 'raia') {
            pt = this._modeloParaSvg(alvo.x + 70, alvo.y + Math.min(alvo.h / 2, 40));
        } else {
            var pontos = this._rotaConexao(alvo);
            if (!pontos.length) return;
            var meio = pontos[Math.floor((pontos.length - 1) / 2)];
            pt = this._modeloParaSvg(meio.x, meio.y);
        }

        // Campo de edição com largura dinâmica: cresce conforme o usuário
        // digita (até um limite razoável), em vez de uma caixa fixa de
        // 150px que obrigava a cortar/rolar nomes de tarefa mais longos.
        var FONTE_EDICAO = '12px -apple-system, "Segoe UI", Roboto, Arial, sans-serif';
        var LARGURA_MIN = 150;
        var LARGURA_MAX = 480;
        var _canvasMedicao = null;
        function medirLarguraTexto(texto) {
            if (!_canvasMedicao) _canvasMedicao = document.createElement('canvas');
            var ctx = _canvasMedicao.getContext('2d');
            ctx.font = FONTE_EDICAO;
            return ctx.measureText(texto || '').width;
        }
        function calcularLargura(texto) {
            var largura = Math.ceil(medirLarguraTexto(texto)) + 28; // + padding/cursor
            return Math.max(LARGURA_MIN, Math.min(LARGURA_MAX, largura));
        }
        function posicionar(input, largura) {
            var left = Math.round(pt.x - largura / 2);
            var margemTela = 8;
            var maxLeft = window.innerWidth - margemTela - largura;
            if (left < margemTela) left = margemTela;
            if (left > maxLeft) left = Math.max(margemTela, maxLeft);
            input.style.left = left + 'px';
            input.style.width = largura + 'px';
        }

        var input = document.createElement('input');
        input.type = 'text';
        input.className = 'vmap-rename-input';
        input.value = alvo.name || '';
        var larguraInicial = calcularLargura(input.value);
        input.style.cssText =
            'position:fixed;z-index:10002;top:' + Math.round(pt.y - 12) + 'px;' +
            'font:' + FONTE_EDICAO + ';padding:4px 6px;border:1.5px solid #0a6fc2;border-radius:4px;' +
            'box-shadow:0 2px 10px rgba(0,0,0,.18);text-align:center;background:#fff;color:#212529;';
        posicionar(input, larguraInicial);

        document.body.appendChild(input);
        this._edicaoInlineEl = input;
        input.focus();
        input.select();

        function fechar() {
            if (input.parentNode) input.parentNode.removeChild(input);
            self._edicaoInlineEl = null;
            document.removeEventListener('mousedown', aoClicarFora);
        }
        function commitar() {
            alvo.name = input.value.trim();
            fechar();
            self._render();
        }
        function aoClicarFora(ev) {
            if (ev.target !== input) commitar();
        }

        input.addEventListener('input', function () {
            posicionar(input, calcularLargura(input.value));
        });
        input.addEventListener('keydown', function (ev) {
            ev.stopPropagation();
            if (ev.key === 'Enter') { ev.preventDefault(); commitar(); }
            else if (ev.key === 'Escape') { ev.preventDefault(); fechar(); }
        });
        input.addEventListener('mousedown', function (ev) { ev.stopPropagation(); });
        setTimeout(function () { document.addEventListener('mousedown', aoClicarFora); }, 0);
    };

    // ================================================================
    // MOVER ELEMENTO SELECIONADO
    // ================================================================
    Diagram.prototype._nudgeSelecionado = function (deltaY) {
        var self = this;
        if (!this.selectedIds || !this.selectedIds.length) return;
        this.selectedIds.forEach(function (id) {
            var elemento = self.elements[id];
            if (!elemento) return;
            elemento.y += deltaY;
            self._reatribuirRaia(id);
        });
        this._render();
    };
    Diagram.prototype._moverElementoParaCima = function () {
        this._nudgeSelecionado(-20);
    };
    Diagram.prototype._moverElementoParaBaixo = function () {
        this._nudgeSelecionado(20);
    };

    // ================================================================
    // COPIAR / COLAR
    // ================================================================
    Diagram.prototype._copiarSelecionado = function () {
        var self = this;
        var copiaveis = this.selectedIds
            .map(function (id) { return self.elements[id]; })
            .filter(Boolean);
        if (!copiaveis.length) return;
        this._clipboard = copiaveis.map(function (elemento) {
            return JSON.parse(JSON.stringify(elemento));
        });
    };
    Diagram.prototype._colar = function () {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        if (!this._clipboard || !this._clipboard.length) return;
        var novosIds = [];
        var deslocamento = 30;
        this._clipboard.forEach(function (original) {
            var novoId = self._nextId((original.type || 'Task').replace('bpmn:', ''));
            var copia = JSON.parse(JSON.stringify(original));
            copia.id = novoId;
            copia.x += deslocamento;
            copia.y += deslocamento;
            copia.riscos = copia.riscos || [];
            self.elements[novoId] = copia;
            self._reatribuirRaia(novoId);
            novosIds.push(novoId);
        });
        this._selecionar(novosIds);
        this._render();
    };

    // ================================================================
    // MENU DE INSERÇÃO POR CLIQUE DIREITO
    // ================================================================
    Diagram.prototype._buildInsertContextMenu = function () {
        var self = this;
        
        var existing = document.querySelector('.vmap-insert-menu');
        if (existing) existing.remove();

        this._insertMenu = document.createElement('div');
        this._insertMenu.className = 'vmap-insert-menu';
        this._insertMenu.style.cssText = 
            'position:fixed;z-index:10001;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.15);padding:4px 0;' +
            'min-width:200px;display:none;max-height:400px;overflow-y:auto;';

        var categorias = [
            { id: 'eventos', label: 'Eventos' },
            { id: 'atividades', label: 'Atividades' },
            { id: 'gateways', label: 'Gateways' },
            { id: 'artefatos', label: 'Artefatos' },
            { id: 'conexoes', label: 'Conexões' }
        ];

        var itensPorCategoria = {
            'eventos': [
                { tipo: 'bpmn:StartEvent', label: 'Início', icone: '▶' },
                { tipo: 'bpmn:EndEvent', label: 'Fim', icone: '●' },
                { tipo: 'bpmn:IntermediateThrowEvent', label: 'Evento', icone: '◉' },
                { tipo: 'bpmn:TimerEvent', label: 'Timer', icone: '⏱' },
                { tipo: 'bpmn:MessageEvent', label: 'Mensagem', icone: '✉' }
            ],
            'atividades': [
                { tipo: 'bpmn:Task', label: 'Tarefa', icone: '▭' },
                { tipo: 'bpmn:UserTask', label: 'Tarefa Usuário', icone: '👤' },
                { tipo: 'bpmn:ServiceTask', label: 'Tarefa Serviço', icone: '⚙' },
                { tipo: 'bpmn:ScriptTask', label: 'Tarefa Script', icone: '◊' },
                { tipo: 'bpmn:SubProcess', label: 'Subprocesso', icone: '⊞' }
            ],
            'gateways': [
                { tipo: 'bpmn:ExclusiveGateway', label: 'Decisão', icone: '◇' },
                { tipo: 'bpmn:ParallelGateway', label: 'Paralelo', icone: '⬡' },
                { tipo: 'bpmn:InclusiveGateway', label: 'Inclusivo', icone: '⬢' },
                { tipo: 'bpmn:EventBasedGateway', label: 'Baseado em Evento', icone: '✦' }
            ],
            'riscos': [
                { tipo: '__risco__', label: 'Gerenciar riscos do elemento', icone: '⚑' }
            ],
            'artefatos': [
                { tipo: 'bpmn:TextAnnotation', label: 'Anotação', icone: '📝' },
                { tipo: 'bpmn:DataObject', label: 'Dados', icone: '📄' },
                { tipo: 'bpmn:DataStore', label: 'Armazenamento', icone: '💾' },
                { tipo: 'bpmn:Group', label: 'Grupo', icone: '⊕' }
            ],
            'conexoes': [
                { tipo: 'sequenceFlow', label: 'Fluxo', icone: '➡' },
                { tipo: 'association', label: 'Associação', icone: '⋯' }
            ]
        };

        categorias.forEach(function(cat, catIndex) {
            var groupDiv = document.createElement('div');
            groupDiv.className = 'insert-group';
            groupDiv.style.cssText = 'padding:2px 0;' + (catIndex > 0 ? 'border-top:1px solid #e9ecef;' : '');
            
            var label = document.createElement('div');
            label.className = 'insert-group-label';
            label.textContent = cat.label;
            label.style.cssText = 'font-size:9px;color:#6c757d;padding:2px 10px;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;';
            groupDiv.appendChild(label);

            var itens = itensPorCategoria[cat.id] || [];
            itens.forEach(function(item) {
                var div = document.createElement('div');
                div.className = 'insert-item';
                var cor = '#2E74B5';
                div.style.cssText = 
                    'display:flex;align-items:center;gap:8px;padding:5px 12px;cursor:pointer;' +
                    'font-size:13px;color:#212529;transition:background 0.1s;';
                div.innerHTML = '<span style="width:26px;height:26px;display:flex;align-items:center;justify-content:center;">' + paletteIcon(item.tipo, cor) + '</span> ' + item.label;
                
                div.addEventListener('mouseenter', function() {
                    this.style.background = '#f1f5fb';
                });
                div.addEventListener('mouseleave', function() {
                    this.style.background = 'transparent';
                });
                
                div.addEventListener('click', function(ev) {
                    ev.stopPropagation();
                    self._insertMenu.style.display = 'none';
                    if (self._insertMenuOrigemId) {
                        if (item.tipo === '__risco__') {
                            self._selecionar([self._insertMenuOrigemId]);
                            self._abrirPainelRiscos();
                            self._insertMenuOrigemId = null;
                        } else if (TIPOS_ANEXAVEIS[item.tipo]) {
                            var origemAnex = self._insertMenuOrigemId;
                            self._insertMenuOrigemId = null;
                            self._escolherDirecaoAnexo(origemAnex, item.tipo);
                        } else {
                            self._inserirConectado(self._insertMenuOrigemId, item.tipo, 'sequenceFlow');
                            self._insertMenuOrigemId = null;
                        }
                    }
                });
                
                groupDiv.appendChild(div);
            });

            self._insertMenu.appendChild(groupDiv);
        });

        document.body.appendChild(this._insertMenu);

        document.addEventListener('mousedown', function(ev) {
            if (self._insertMenu.style.display !== 'none' && 
                !self._insertMenu.contains(ev.target)) {
                self._insertMenu.style.display = 'none';
                self._insertMenuOrigemId = null;
            }
        });
    };

    // ================================================================
    // CONTEXT MENU
    // ================================================================
    Diagram.prototype._buildContextMenu = function () {
        var self = this;
        var existing = document.querySelector('.vmap-context-menu');
        if (existing) existing.remove();
        this._contextMenu = document.createElement('div');
        this._contextMenu.className = 'vmap-context-menu';
        this._contextMenu.style.cssText =
            'position:fixed;z-index:10000;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.15);padding:4px 0;' +
            'min-width:180px;display:none;';
        document.body.appendChild(this._contextMenu);
        document.addEventListener('mousedown', function(ev) {
            if (self._contextMenu.style.display !== 'none' &&
                !self._contextMenu.contains(ev.target)) {
                self._fecharContextMenu();
            }
        });
    };

    // ================================================================
    // INSERIR CONECTADO
    // ================================================================
    Diagram.prototype._direcaoPadraoConexao = function (tipoNovoElemento) {
        if (TIPOS_DIRECAO_ENTRADA[tipoNovoElemento]) return 'entrada';
        if (TIPOS_DIRECAO_SAIDA[tipoNovoElemento]) return 'saida';
        return null;
    };

    Diagram.prototype._resolverDirecaoConexao = function (origemId, novoId, tipoNovoElemento, tipoConexaoSolicitado) {
        var direcao = this._direcaoPadraoConexao(tipoNovoElemento);
        if (direcao === 'entrada') {
            return { sourceId: novoId, targetId: origemId, tipoConexao: 'eventoArtefato' };
        }
        if (direcao === 'saida') {
            return { sourceId: origemId, targetId: novoId, tipoConexao: 'eventoArtefato' };
        }
        return { sourceId: origemId, targetId: novoId, tipoConexao: tipoConexaoSolicitado || 'sequenceFlow' };
    };

    Diagram.prototype._inserirConectado = function (origemId, tipo, tipoConexao, direcaoAnexo) {
        if (BLOQUEAR_INSERCAO) return null;
        var origem = this.elements[origemId];
        if (!origem) return null;

        var tam = TAMANHOS[tipo] || { w: 100, h: 80 };
        var cx, cy;
        var espacamento = 40;
        var direcaoUsada = direcaoAnexo || null;

        if (tipo === 'bpmn:SubProcess') {
            cx = origem.x + origem.w / 2;
            cy = origem.y + origem.h + espacamento + tam.h / 2;
            var tent = 0;
            while (tent < 8 && this._colideComElemento(cx, cy, tam)) {
                cy += tam.h + 16; tent++;
            }
        } else if (TIPOS_ANEXAVEIS[tipo]) {
            var pos = this._posicaoAnexoLivre(origem, tipo, tam, direcaoUsada);
            cx = pos.x; cy = pos.y;
            direcaoUsada = pos.direcao || direcaoUsada || this._direcaoPadraoConexao(tipo) || 'saida';
        } else {
            var deslocamento = tam.w + espacamento;
            this._empurrarElementosADireita(origem, deslocamento);
            cx = origem.x + origem.w + espacamento + tam.w / 2;
            cy = origem.y + (origem.h / 2);

            // Gateways (Decisão etc.): cada ramo de saída deve ocupar posição
            // independente. O primeiro ramo fica alinhado ao centro; os
            // seguintes descem (ou sobem se colidirem) para não sobrepor o
            // ramo "Sim" e permitir modelar o "Não" com uma nova tarefa/mensagem.
            if (origem.type && origem.type.indexOf('Gateway') !== -1) {
                var selfPos = this;
                var saidasExistentes = Object.keys(this.flows).filter(function (fid) {
                    var f = selfPos.flows[fid];
                    return f && !f.associacao && f.tipo !== 'association' &&
                        f.tipo !== 'eventoArtefato' && f.sourceId === origemId;
                });
                if (saidasExistentes.length > 0) {
                    var gap = (CONFIG.gatewayBranchGap || 14) + tam.h;
                    cy = origem.y + origem.h / 2 + gap * saidasExistentes.length;
                    var tent = 0;
                    while (tent < 10 && this._colideComElemento(cx, cy, tam)) {
                        cy += gap;
                        tent++;
                    }
                }
            }
        }

        var novoId = this._criarElemento(tipo, cx, cy);
        if (!novoId) return null;

        // Intercala no fluxo APENAS quando a origem tem exatamente UMA saída
        // sequenceFlow "para frente" (destino à direita). Nunca intercalar:
        //  - em Gateways (cada saída é ramo independente Sim/Não);
        //  - quando já existe fluxo de retorno (destino à esquerda) — senão
        //    a próxima tarefa ficaria "presa" na linha de retorno;
        //  - quando há múltiplas saídas.
        var intercalou = false;
        var origemEhGateway = origem.type && origem.type.indexOf('Gateway') !== -1;
        if (!origemEhGateway && !TIPOS_ANEXAVEIS[tipo] && tipo !== 'bpmn:SubProcess' &&
            (tipoConexao || 'sequenceFlow') === 'sequenceFlow') {
            var selfIns = this;
            var saidas = Object.keys(this.flows).filter(function (fid) {
                var f = selfIns.flows[fid];
                return f && !f.associacao && f.tipo !== 'association' &&
                    f.tipo !== 'eventoArtefato' && f.sourceId === origemId;
            });
            if (saidas.length === 1) {
                var fUnica = selfIns.flows[saidas[0]];
                var destUnico = fUnica ? selfIns.elements[fUnica.targetId] : null;
                // Só intercala se o destino existente está à frente (não é retorno)
                var ehRetorno = destUnico && destUnico.x + destUnico.w / 2 < origem.x;
                if (fUnica && destUnico && !ehRetorno) {
                    intercalou = true;
                    var antigoDestino = fUnica.targetId;
                    fUnica.targetId = novoId;
                    fUnica.waypoints = [];
                    delete fUnica._labelPos;
                    if (antigoDestino && antigoDestino !== novoId) {
                        selfIns._criarConexao(novoId, antigoDestino, 'sequenceFlow');
                    }
                }
            }
        }

        if (!intercalou) {
            if (TIPOS_ANEXAVEIS[tipo] && direcaoUsada) {
                // Conexão artefato/mensagem: direção definida pelo usuário
                // entrada = anexo → tarefa; saída = tarefa → anexo
                if (direcaoUsada === 'entrada') {
                    this._criarConexao(novoId, origemId, 'eventoArtefato');
                } else {
                    this._criarConexao(origemId, novoId, 'eventoArtefato');
                }
            } else {
                var resolucao = this._resolverDirecaoConexao(origemId, novoId, tipo, tipoConexao);
                this._criarConexao(resolucao.sourceId, resolucao.targetId, resolucao.tipoConexao);
            }
        }

        var laneDoNovo = this.lanes.find(function (l) {
            return l.refs && l.refs.indexOf(novoId) !== -1;
        });
        if (laneDoNovo && typeof this._ajustarRaiaParaConteudo === 'function') {
            this._ajustarRaiaParaConteudo(laneDoNovo.id);
        }

        this._ultimoElementoSelecionado = novoId;
        this._selecionar([novoId]);
        this._render();

        // Ramo "Não" do gateway exclusivo → nova tarefa: oferece inserir
        // mensagem/documento de saída com o número da tarefa de retorno.
        if (origemEhGateway && origem.type === 'bpmn:ExclusiveGateway' &&
            !TIPOS_ANEXAVEIS[tipo] && tipo !== 'bpmn:SubProcess') {
            var selfApos = this;
            var saidasSeq = Object.keys(this.flows).filter(function (fid) {
                var f = selfApos.flows[fid];
                return f && !f.associacao && f.tipo !== 'association' &&
                    f.tipo !== 'eventoArtefato' && f.sourceId === origemId;
            });
            var fluxoNovo = null;
            saidasSeq.forEach(function (fid) {
                if (selfApos.flows[fid].targetId === novoId) fluxoNovo = selfApos.flows[fid];
            });
            var ehRamoNao = fluxoNovo && (fluxoNovo.name === 'Não' || saidasSeq.length >= 2);
            var tiposTarefaNao = {
                'bpmn:Task': 1, 'bpmn:UserTask': 1, 'bpmn:ServiceTask': 1,
                'bpmn:ScriptTask': 1, 'bpmn:ManualTask': 1
            };
            if (ehRamoNao && tiposTarefaNao[tipo]) {
                setTimeout(function () {
                    selfApos._oferecerArtefatoRetornoNao(novoId);
                }, 80);
            }
        }

        return novoId;
    };

    Diagram.prototype._empurrarElementosADireita = function (origem, deslocamento) {
        if (!origem || !(deslocamento > 0)) return;
        var self = this;
        var laneOrigem = this.lanes.find(function (l) {
            return l.refs && l.refs.indexOf(origem.id) !== -1;
        });
        var limiarX = origem.x + origem.w - 1;
        var idsMovidos = {};

        Object.keys(this.elements).forEach(function (id) {
            if (id === origem.id) return;
            var el = self.elements[id];
            if (!el || el.x < limiarX) return;
            if (laneOrigem) {
                var naMesmaRaia = laneOrigem.refs.indexOf(id) !== -1;
                var faixaY = Math.abs((el.y + el.h / 2) - (origem.y + origem.h / 2)) < Math.max(origem.h, 80);
                if (!naMesmaRaia && !faixaY) return;
            }
            el.x += deslocamento;
            idsMovidos[id] = true;
        });

        if (laneOrigem) {
            var maxX = laneOrigem.x + laneOrigem.w;
            Object.keys(self.elements).forEach(function (id) {
                var el = self.elements[id];
                if (el) maxX = Math.max(maxX, el.x + el.w + 40);
            });
            if (maxX > laneOrigem.x + laneOrigem.w) {
                var novaW = maxX - laneOrigem.x;
                self.lanes.forEach(function (l) {
                    if (Math.abs(l.x - laneOrigem.x) < 2) l.w = Math.max(l.w, novaW);
                });
            }
        }

        Object.keys(this.flows).forEach(function (fid) {
            var f = self.flows[fid];
            if (!f) return;
            if (idsMovidos[f.sourceId] || idsMovidos[f.targetId] ||
                f.sourceId === origem.id || f.targetId === origem.id) {
                f.waypoints = [];
                delete f._labelPos;
            }
        });
    };

    Diagram.prototype._inserirConectadoEm = function (origemId, tipo, cx, cy, tipoConexao) {
        if (BLOQUEAR_INSERCAO) return null;
        var origem = this.elements[origemId];
        if (!origem) return null;
        
        if (cx === undefined || cy === undefined) {
            var tam = TAMANHOS[tipo] || { w: 100, h: 80 };
            if (TIPOS_ANEXAVEIS[tipo]) {
                var pos = this._posicaoAnexoLivre(origem, tipo, tam);
                cx = pos.x; cy = pos.y;
            } else {
                var espacamento = 40;
                cx = origem.x + origem.w + espacamento + tam.w / 2;
                cy = origem.y + (origem.h / 2);
            }
        }
        
        var novoId = this._criarElemento(tipo, cx, cy);
        if (!novoId) return null;
        
        var resolucao = this._resolverDirecaoConexao(origemId, novoId, tipo, tipoConexao);
        this._criarConexao(resolucao.sourceId, resolucao.targetId, resolucao.tipoConexao);
        this._ultimoElementoSelecionado = novoId;
        this._selecionar([novoId]);
        this._render();
        return novoId;
    };

    Diagram.prototype._posicaoAnexoLivre = function (origem, tipo, tam, direcaoForcada) {
        // Sempre no centro da aresta superior (entrada) ou inferior (saída)
        // da tarefa/gateway, para manter o diagrama limpo e legível.
        var direcao = direcaoForcada || this._direcaoPadraoConexao(tipo) || 'saida';
        var espacamento = 40;
        var cx = origem.x + origem.w / 2;
        var cy;
        if (direcao === 'entrada') {
            cy = origem.y - espacamento - tam.h / 2;
        } else {
            cy = origem.y + origem.h + espacamento + tam.h / 2;
        }

        var tentativas = 0;
        var deslocX = 0;
        while (tentativas < 10 && this._colideComElemento(cx + deslocX, cy, tam)) {
            // Se colidir, desloca horizontalmente em zigue-zague mantendo
            // o alinhamento vertical (centro superior/inferior).
            deslocX = (tentativas % 2 === 0 ? 1 : -1) * (Math.floor(tentativas / 2) + 1) * (tam.w + 12);
            tentativas++;
        }
        return { x: cx + deslocX, y: cy, direcao: direcao };
    };

    Diagram.prototype._colideComElemento = function (cx, cy, tam) {
        var x1 = cx - tam.w / 2, x2 = cx + tam.w / 2;
        var y1 = cy - tam.h / 2, y2 = cy + tam.h / 2;
        var margem = 6;
        return Object.keys(this.elements).some(function (id) {
            var elemento = this.elements[id];
            var ex1 = elemento.x - margem, ex2 = elemento.x + elemento.w + margem;
            var ey1 = elemento.y - margem, ey2 = elemento.y + elemento.h + margem;
            return x1 < ex2 && x2 > ex1 && y1 < ey2 && y2 > ey1;
        }, this);
    };

    /**
     * Escolha de direção ao inserir mensagem/dado/artefato em uma tarefa
     * ou gateway: Entrando (centro superior) ou Saindo (centro inferior).
     * No gateway exclusivo com ramo "Não", após inserir mensagem/dado
     * oferece indicar a tarefa de destino do vínculo.
     */
    Diagram.prototype._escolherDirecaoAnexo = function (origemId, tipo) {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        var origem = this.elements[origemId];
        if (!origem) return;

        var existente = document.querySelector('.vmap-direcao-anexo');
        if (existente) existente.remove();

        var painel = document.createElement('div');
        painel.className = 'vmap-direcao-anexo';
        painel.style.cssText =
            'position:fixed;z-index:10050;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:14px;' +
            'width:300px;font-family:inherit;left:50%;top:22%;transform:translateX(-50%);';

        var titulo = document.createElement('div');
        titulo.style.cssText = 'font-size:14px;font-weight:600;margin-bottom:6px;color:#212529;';
        titulo.textContent = 'Direção da conexão';
        painel.appendChild(titulo);

        var hint = document.createElement('div');
        hint.style.cssText = 'font-size:12px;color:#6c757d;margin-bottom:12px;';
        hint.textContent = 'O elemento será posicionado no centro superior (entrando) ou inferior (saindo) de "' +
            (origem.name || origem.id) + '".';
        painel.appendChild(hint);

        function botao(texto, direcao, cor) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.textContent = texto;
            btn.style.cssText =
                'display:block;width:100%;text-align:left;padding:10px 12px;margin:0 0 6px 0;' +
                'border:1px solid #e9ecef;border-radius:6px;background:#f8fafc;cursor:pointer;' +
                'font-size:13px;color:#212529;';
            btn.addEventListener('mouseenter', function () {
                btn.style.background = '#e7f1ff'; btn.style.borderColor = cor || '#0a6fc2';
            });
            btn.addEventListener('mouseleave', function () {
                btn.style.background = '#f8fafc'; btn.style.borderColor = '#e9ecef';
            });
            btn.addEventListener('click', function () {
                painel.remove();
                var novoId = self._inserirConectado(origemId, tipo, 'eventoArtefato', direcao);
                // Gateway exclusivo + mensagem/dado no ramo "Não":
                // oferece indicar a tarefa à qual vincular o artefato.
                if (novoId && origem.type === 'bpmn:ExclusiveGateway' &&
                    (tipo === 'bpmn:MessageEvent' || tipo === 'bpmn:DataObject' ||
                     tipo === 'bpmn:DataStore' || tipo === 'bpmn:IntermediateThrowEvent')) {
                    var saidasGw = Object.keys(self.flows).filter(function (fid) {
                        var f = self.flows[fid];
                        return f && !f.associacao && f.tipo !== 'association' &&
                            f.tipo !== 'eventoArtefato' && f.sourceId === origemId;
                    });
                    // Se já existe pelo menos um ramo de sequência (Sim),
                    // este anexo é o caminho "Não" — perguntar tarefa.
                    if (saidasGw.length >= 1) {
                        self._perguntarTarefaVinculoAnexo(novoId, origemId);
                    }
                }
            });
            return btn;
        }

        painel.appendChild(botao('↑ Entrando na tarefa (centro superior)', 'entrada', '#198754'));
        painel.appendChild(botao('↓ Saindo da tarefa (centro inferior)', 'saida', '#0a6fc2'));

        var cancelar = document.createElement('button');
        cancelar.type = 'button';
        cancelar.textContent = 'Cancelar';
        cancelar.style.cssText =
            'margin-top:6px;width:100%;padding:8px;border:1px solid #ced4da;border-radius:6px;' +
            'background:#fff;cursor:pointer;font-size:13px;';
        cancelar.addEventListener('click', function () { painel.remove(); });
        painel.appendChild(cancelar);

        document.body.appendChild(painel);
        var fecharFora = function (ev) {
            if (!painel.contains(ev.target)) {
                painel.remove();
                document.removeEventListener('mousedown', fecharFora);
            }
        };
        setTimeout(function () { document.addEventListener('mousedown', fecharFora); }, 50);
    };

    /**
     * Após criar a tarefa do ramo "Não", oferece inserir mensagem ou
     * documento de saída e escolher o número da tarefa de retorno.
     */
    Diagram.prototype._oferecerArtefatoRetornoNao = function (tarefaId) {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        var tarefa = this.elements[tarefaId];
        if (!tarefa) return;

        var existente = document.querySelector('.vmap-artefato-retorno-nao');
        if (existente) existente.remove();

        var painel = document.createElement('div');
        painel.className = 'vmap-artefato-retorno-nao';
        painel.style.cssText =
            'position:fixed;z-index:10050;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:14px;' +
            'width:340px;font-family:inherit;left:50%;top:18%;transform:translateX(-50%);';

        var titulo = document.createElement('div');
        titulo.style.cssText = 'font-size:14px;font-weight:600;margin-bottom:6px;color:#212529;';
        titulo.textContent = 'Ramo “Não” — comunicar a decisão';
        painel.appendChild(titulo);

        var hint = document.createElement('div');
        hint.style.cssText = 'font-size:12px;color:#6c757d;margin-bottom:12px;';
        hint.textContent = 'A tarefa do “Não” pode emitir uma mensagem ou documento informando o retorno. Escolha o tipo e a tarefa de destino.';
        painel.appendChild(hint);

        function opcaoArtefato(label, tipoArtefato) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.textContent = label;
            btn.style.cssText =
                'display:block;width:100%;text-align:left;padding:10px 12px;margin:0 0 6px 0;' +
                'border:1px solid #e9ecef;border-radius:6px;background:#f8fafc;cursor:pointer;' +
                'font-size:13px;color:#212529;';
            btn.addEventListener('mouseenter', function () {
                btn.style.background = '#e7f1ff'; btn.style.borderColor = '#0a6fc2';
            });
            btn.addEventListener('mouseleave', function () {
                btn.style.background = '#f8fafc'; btn.style.borderColor = '#e9ecef';
            });
            btn.addEventListener('click', function () {
                painel.remove();
                // Insere artefato saindo da tarefa (centro inferior)
                var anexoId = self._inserirConectado(tarefaId, tipoArtefato, 'eventoArtefato', 'saida');
                if (anexoId) {
                    self._escolherNumeroTarefaRetorno(anexoId);
                }
            });
            return btn;
        }

        painel.appendChild(opcaoArtefato('✉ Mensagem de saída (com nº da tarefa de retorno)', 'bpmn:MessageEvent'));
        painel.appendChild(opcaoArtefato('📄 Documento / dados de saída (com nº da tarefa de retorno)', 'bpmn:DataObject'));

        var pular = document.createElement('button');
        pular.type = 'button';
        pular.textContent = 'Não inserir agora';
        pular.style.cssText =
            'margin-top:6px;width:100%;padding:8px;border:1px solid #ced4da;border-radius:6px;' +
            'background:#fff;cursor:pointer;font-size:13px;';
        pular.addEventListener('click', function () { painel.remove(); });
        painel.appendChild(pular);

        document.body.appendChild(painel);
        var fecharFora = function (ev) {
            if (!painel.contains(ev.target)) {
                painel.remove();
                document.removeEventListener('mousedown', fecharFora);
            }
        };
        setTimeout(function () { document.addEventListener('mousedown', fecharFora); }, 50);
    };

    /**
     * Escolhe o número da tarefa de retorno e grava no artefato
     * (exibido no mesmo estilo do badge sequencial das tarefas).
     */
    Diagram.prototype._escolherNumeroTarefaRetorno = function (anexoId) {
        var self = this;
        var anexo = this.elements[anexoId];
        if (!anexo) return;

        var tiposTarefa = {
            'bpmn:Task': 1, 'bpmn:ManualTask': 1, 'bpmn:ServiceTask': 1,
            'bpmn:UserTask': 1, 'bpmn:ScriptTask': 1, 'bpmn:BusinessRuleTask': 1,
            'bpmn:SendTask': 1, 'bpmn:ReceiveTask': 1, 'bpmn:SubProcess': 1
        };
        var candidatos = [];
        Object.keys(this.elements).forEach(function (id) {
            if (id === anexoId) return;
            var el = self.elements[id];
            if (el && tiposTarefa[el.type] && typeof el.numero === 'number') {
                candidatos.push(el);
            }
        });
        candidatos.sort(function (a, b) { return a.numero - b.numero; });

        var existente = document.querySelector('.vmap-numero-retorno');
        if (existente) existente.remove();

        var painel = document.createElement('div');
        painel.className = 'vmap-numero-retorno';
        painel.style.cssText =
            'position:fixed;z-index:10050;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:12px;' +
            'width:320px;max-height:400px;overflow:auto;font-family:inherit;' +
            'left:50%;top:16%;transform:translateX(-50%);';

        var titulo = document.createElement('div');
        titulo.style.cssText = 'font-size:14px;font-weight:600;margin-bottom:6px;color:#212529;';
        titulo.textContent = 'Número da tarefa de retorno';
        painel.appendChild(titulo);

        var hint = document.createElement('div');
        hint.style.cssText = 'font-size:12px;color:#6c757d;margin-bottom:10px;';
        hint.textContent = candidatos.length
            ? 'Selecione a tarefa para a qual esta mensagem/documento indica o retorno. O número aparecerá no artefato.'
            : 'Ainda não há tarefas numeradas no diagrama.';
        painel.appendChild(hint);

        candidatos.forEach(function (el) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.style.cssText =
                'display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:8px 10px;margin:0 0 4px 0;' +
                'border:1px solid #e9ecef;border-radius:6px;background:#f8fafc;cursor:pointer;' +
                'font-size:13px;color:#212529;';
            btn.innerHTML =
                '<span style="display:inline-flex;align-items:center;justify-content:center;' +
                'min-width:22px;height:22px;border-radius:50%;background:#c55a11;color:#fff;' +
                'font-size:11px;font-weight:700;">' + el.numero + '</span>' +
                '<span><strong>' + (el.name || '(sem nome)') + '</strong></span>';
            btn.addEventListener('mouseenter', function () {
                btn.style.background = '#fff2e8'; btn.style.borderColor = '#c55a11';
            });
            btn.addEventListener('mouseleave', function () {
                btn.style.background = '#f8fafc'; btn.style.borderColor = '#e9ecef';
            });
            btn.addEventListener('click', function () {
                anexo.retornoNumero = el.numero;
                anexo.retornoTarefaId = el.id;
                // Atualiza nome padrão se ainda for genérico
                if (!anexo.name || anexo.name === 'Mensagem' || anexo.name === 'Dados' ||
                    anexo.name === 'Nova tarefa' || anexo.name.indexOf('retorno') === -1) {
                    var base = anexo.type === 'bpmn:MessageEvent' ? 'Mensagem' : 'Documento';
                    anexo.name = base + ' → tarefa ' + el.numero;
                }
                painel.remove();
                self._selecionar([anexoId]);
                self._render();
            });
            painel.appendChild(btn);
        });

        var pular = document.createElement('button');
        pular.type = 'button';
        pular.textContent = candidatos.length ? 'Não indicar número agora' : 'OK';
        pular.style.cssText =
            'margin-top:8px;width:100%;padding:8px;border:1px solid #ced4da;border-radius:6px;' +
            'background:#fff;cursor:pointer;font-size:13px;';
        pular.addEventListener('click', function () { painel.remove(); });
        painel.appendChild(pular);

        document.body.appendChild(painel);
        var fecharFora = function (ev) {
            if (!painel.contains(ev.target)) {
                painel.remove();
                document.removeEventListener('mousedown', fecharFora);
            }
        };
        setTimeout(function () { document.addEventListener('mousedown', fecharFora); }, 50);
    };

    /**
     * Após inserir mensagem/dado no ramo "Não" de um gateway, permite
     * indicar a tarefa à qual o artefato deve se vincular (associação).
     */
    Diagram.prototype._perguntarTarefaVinculoAnexo = function (anexoId, gatewayId) {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        var anexo = this.elements[anexoId];
        if (!anexo) return;

        var tiposTarefa = {
            'bpmn:Task': 1, 'bpmn:ManualTask': 1, 'bpmn:ServiceTask': 1,
            'bpmn:UserTask': 1, 'bpmn:ScriptTask': 1, 'bpmn:BusinessRuleTask': 1,
            'bpmn:SendTask': 1, 'bpmn:ReceiveTask': 1, 'bpmn:SubProcess': 1
        };
        var candidatos = [];
        Object.keys(this.elements).forEach(function (id) {
            if (id === anexoId || id === gatewayId) return;
            var el = self.elements[id];
            if (el && tiposTarefa[el.type]) candidatos.push(el);
        });
        candidatos.sort(function (a, b) {
            return (a.x - b.x) || (a.y - b.y);
        });

        var existente = document.querySelector('.vmap-vinculo-anexo');
        if (existente) existente.remove();

        var painel = document.createElement('div');
        painel.className = 'vmap-vinculo-anexo';
        painel.style.cssText =
            'position:fixed;z-index:10050;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:12px;' +
            'width:320px;max-height:380px;overflow:auto;font-family:inherit;' +
            'left:50%;top:18%;transform:translateX(-50%);';

        var titulo = document.createElement('div');
        titulo.style.cssText = 'font-size:14px;font-weight:600;margin-bottom:6px;color:#212529;';
        titulo.textContent = 'Vincular ao ramo “Não”';
        painel.appendChild(titulo);

        var hint = document.createElement('div');
        hint.style.cssText = 'font-size:12px;color:#6c757d;margin-bottom:10px;';
        hint.textContent = candidatos.length
            ? 'Indique a tarefa à qual esta mensagem/dado deve se relacionar (opcional).'
            : 'Não há tarefas no diagrama para vincular. O elemento foi inserido normalmente.';
        painel.appendChild(hint);

        candidatos.forEach(function (el) {
            var btn = document.createElement('button');
            btn.type = 'button';
            var num = typeof el.numero === 'number' ? el.numero + '. ' : '';
            btn.style.cssText =
                'display:block;width:100%;text-align:left;padding:8px 10px;margin:0 0 4px 0;' +
                'border:1px solid #e9ecef;border-radius:6px;background:#f8fafc;cursor:pointer;' +
                'font-size:13px;color:#212529;';
            btn.innerHTML = '<strong>' + num + (el.name || '(sem nome)') + '</strong>' +
                ' <span style="color:#6c757d;font-size:11px;">' + (el.type || '').replace('bpmn:', '') + '</span>';
            btn.addEventListener('mouseenter', function () {
                btn.style.background = '#e7f1ff'; btn.style.borderColor = '#0a6fc2';
            });
            btn.addEventListener('mouseleave', function () {
                btn.style.background = '#f8fafc'; btn.style.borderColor = '#e9ecef';
            });
            btn.addEventListener('click', function () {
                // Associação pontilhada anexo ↔ tarefa (não sequence flow de retorno)
                self._criarConexao(anexoId, el.id, 'association');
                painel.remove();
                self._selecionar([anexoId]);
                self._render();
            });
            painel.appendChild(btn);
        });

        var pular = document.createElement('button');
        pular.type = 'button';
        pular.textContent = candidatos.length ? 'Não vincular agora' : 'OK';
        pular.style.cssText =
            'margin-top:8px;width:100%;padding:8px;border:1px solid #ced4da;border-radius:6px;' +
            'background:#fff;cursor:pointer;font-size:13px;';
        pular.addEventListener('click', function () { painel.remove(); });
        painel.appendChild(pular);

        document.body.appendChild(painel);
        var fecharFora = function (ev) {
            if (!painel.contains(ev.target)) {
                painel.remove();
                document.removeEventListener('mousedown', fecharFora);
            }
        };
        setTimeout(function () { document.addEventListener('mousedown', fecharFora); }, 50);
    };

    // ================================================================
    // RESOLUÇÃO AUTOMÁTICA DE DIREÇÃO/ESTILO
    // ================================================================
    Diagram.prototype._tipoElementoConexao = function (sourceId, targetId, tipoSolicitado) {
        var origem = this.elements[sourceId];
        var destino = this.elements[targetId];
        if (!origem || !destino) {
            return { sourceId: sourceId, targetId: targetId, tipo: tipoSolicitado || 'sequenceFlow' };
        }

        // EVENTOS INÍCIO E FIM SEMPRE USAM LINHA CHEIA (sequenceFlow)
        var isStartEvent = origem.type === 'bpmn:StartEvent' || destino.type === 'bpmn:StartEvent';
        var isEndEvent = origem.type === 'bpmn:EndEvent' || destino.type === 'bpmn:EndEvent';
        
        if (isStartEvent || isEndEvent) {
            return { sourceId: sourceId, targetId: targetId, tipo: 'sequenceFlow' };
        }

        // Direção explícita (entrada/saída escolhida pelo usuário):
        // respeita a ordem source→target já definida e só marca o tipo.
        // Assim a seta aponta no sentido correto (entrando ou saindo).
        if (tipoSolicitado === 'eventoArtefato') {
            return { sourceId: sourceId, targetId: targetId, tipo: 'eventoArtefato' };
        }

        var origemAnexavel = !!TIPOS_ANEXAVEIS[origem.type];
        var destinoAnexavel = !!TIPOS_ANEXAVEIS[destino.type];

        if (origemAnexavel === destinoAnexavel || (tipoSolicitado === 'association')) {
            return { sourceId: sourceId, targetId: targetId, tipo: tipoSolicitado || 'sequenceFlow' };
        }

        var elementoAnexo = origemAnexavel ? origem : destino;
        var elementoBase = origemAnexavel ? destino : origem;
        var direcao = this._direcaoPadraoConexao(elementoAnexo.type);

        if (direcao === 'entrada') {
            return { sourceId: elementoAnexo.id, targetId: elementoBase.id, tipo: 'eventoArtefato' };
        }
        if (direcao === 'saida') {
            return { sourceId: elementoBase.id, targetId: elementoAnexo.id, tipo: 'eventoArtefato' };
        }
        return { sourceId: sourceId, targetId: targetId, tipo: tipoSolicitado || 'sequenceFlow' };
    };

    // ================================================================
    // CRIAÇÃO DE CONEXÃO
    // ================================================================
    Diagram.prototype._criarConexao = function (sourceId, targetId, tipo) {
        if (BLOQUEAR_INSERCAO) return null;
        var resolvido = this._tipoElementoConexao(sourceId, targetId, tipo);
        sourceId = resolvido.sourceId;
        targetId = resolvido.targetId;
        tipo = resolvido.tipo;

        var source = this.elements[sourceId];
        var target = this.elements[targetId];
        
        if (!source || !target) {
            console.warn('Conexão não criada: origem ou destino inválido', sourceId, targetId);
            return null;
        }
        
        var existente = Object.keys(this.flows).some(function(fid) {
            var f = this.flows[fid];
            return (f.sourceId === sourceId && f.targetId === targetId) ||
                   (f.sourceId === targetId && f.targetId === sourceId);
        }, this);
        
        if (existente) {
            console.warn('Conexão já existe entre', sourceId, 'e', targetId);
            return null;
        }
        
        var id = this._nextId('SequenceFlow');
        var ehAssociacao = tipo === 'association';

        this.flows[id] = {
            id: id,
            isFlow: true,
            sourceId: sourceId,
            targetId: targetId,
            name: '',
            tipo: tipo || 'sequenceFlow',
            associacao: ehAssociacao,
            waypoints: []
        };

        // Rótulo padrão "Sim"/"Não" para o fluxo de decisão binário mais
        // comum: gateway exclusivo (Decisão) com apenas dois ramos de saída.
        // Só se aplica a sequence flows (não associações) e não sobrescreve
        // nomes já definidos pelo usuário em outros fluxos.
        if (!ehAssociacao && (tipo || 'sequenceFlow') === 'sequenceFlow' &&
            source.type === 'bpmn:ExclusiveGateway') {
            var self = this;
            var saidas = Object.keys(this.flows).filter(function (fid) {
                var f = self.flows[fid];
                return f && !f.associacao && f.tipo !== 'association' && f.sourceId === sourceId;
            });
            var ordinal = saidas.length; // 1 = primeiro ramo criado, 2 = segundo...
            if (ordinal === 1) {
                this.flows[id].name = 'Sim';
            } else if (ordinal === 2) {
                this.flows[id].name = 'Não';
            }
        }

        this.events.fire('connection.added', { 
            connection: this._elementoPublico(this.flows[id]) 
        });
        
        this._render();
        return id;
    };

    // ================================================================
    // ABRIR MENU DE INSERÇÃO
    // ================================================================
    Diagram.prototype._abrirInsertMenuFromContext = function() {
        if (BLOQUEAR_INSERCAO) return;
        var id = this._contextMenuElementId || this.selectedIds[0];
        if (!id) {
            alert('Selecione um elemento primeiro.');
            return;
        }
        var elemento = this.elements[id];
        if (!elemento) {
            alert('Selecione um elemento válido (tarefa, gateway, etc.).');
            return;
        }
        
        var pt = this._modeloParaSvg(elemento.x + elemento.w + 20, elemento.y + elemento.h / 2);
        this._insertMenuOrigemId = id;
        this._insertMenu.style.display = 'block';
        var left = Math.min(pt.x, window.innerWidth - 220);
        var top = Math.min(pt.y, window.innerHeight - 350);
        this._insertMenu.style.left = Math.max(10, left) + 'px';
        this._insertMenu.style.top = Math.max(10, top) + 'px';
        this._fecharContextMenu();
    };

    Diagram.prototype._abrirInsertMenu = function(ev, elementId) {
        if (BLOQUEAR_INSERCAO) return;
        this._insertMenuOrigemId = elementId;
        this._insertMenu.style.display = 'block';
        var left = Math.min(ev.clientX, window.innerWidth - 220);
        var top = Math.min(ev.clientY, window.innerHeight - 350);
        this._insertMenu.style.left = Math.max(10, left) + 'px';
        this._insertMenu.style.top = Math.max(10, top) + 'px';
    };

    Diagram.prototype._fecharInsertMenu = function() {
        if (this._insertMenu) {
            this._insertMenu.style.display = 'none';
        }
        this._insertMenuOrigemId = null;
    };

    // ================================================================
    // CONTEXT MENU - ABRIR/FECHAR
    // ================================================================
    Diagram.prototype._abrirContextMenu = function(ev, elementId) {
        this._fecharContextMenu();
        this._fecharInsertMenu();
        var ehRaia = false;
        if (elementId) {
            var el = this.elements[elementId] || this.flows[elementId] ||
                     this.lanes.find(function(l) { return l.id === elementId; });
            if (el) {
                this._selecionar([elementId]);
                this._contextMenuElementId = elementId;
                ehRaia = this.lanes.some(function(l) { return l.id === elementId; });
            } else {
                this._contextMenuElementId = null;
            }
        } else {
            this._contextMenuElementId = null;
        }
        this._popularContextMenu(ehRaia);
        this._contextMenu.style.display = 'block';
        var left = Math.min(ev.clientX, window.innerWidth - 200);
        var top = Math.min(ev.clientY, window.innerHeight - 300);
        this._contextMenu.style.left = Math.max(10, left) + 'px';
        this._contextMenu.style.top = Math.max(10, top) + 'px';
    };

    Diagram.prototype._popularContextMenu = function (ehRaia) {
        var self = this;
        if (!this._contextMenu) return;
        this._contextMenu.innerHTML = '';
        var itens = [];
        if (ehRaia) {
            itens.push({ id: 'edit', label: 'Renomear Raia', icone: '✎', acao: '_renomearSelecionado' });
            itens.push({ id: 'delete', label: 'Excluir Raia', icone: '✕', acao: '_excluirRaiaSelecionada' });
        } else {
            itens.push({ id: 'edit', label: 'Editar', icone: '✎', acao: '_renomearSelecionado' });
            itens.push({ id: 'delete', label: 'Excluir', icone: '✕', acao: '_excluirSelecionado' });
            itens.push({ id: 'separator2', label: '', icone: '', acao: null });
            itens.push({ id: 'move-up', label: 'Mover para cima', icone: '↑', acao: '_moverElementoParaCima' });
            itens.push({ id: 'move-down', label: 'Mover para baixo', icone: '↓', acao: '_moverElementoParaBaixo' });
        }
        itens.forEach(function(item) {
            if (item.id.indexOf('separator') === 0) {
                var sep = document.createElement('div');
                sep.style.cssText = 'height:1px;background:#e9ecef;margin:4px 8px;';
                self._contextMenu.appendChild(sep);
                return;
            }
            var div = document.createElement('div');
            var cor = item.id === 'risk' ? '#dc3545' : '#212529';
            var iconeCor = item.id === 'risk' ? '#dc3545' : '#6c757d';
            div.style.cssText =
                'display:flex;align-items:center;gap:8px;padding:6px 14px;cursor:pointer;' +
                'font-size:13px;color:' + cor + ';';
            div.innerHTML = '<span style="font-size:16px;color:' + iconeCor +
                ';width:20px;text-align:center;">' + item.icone + '</span> ' + item.label;
            div.addEventListener('mouseenter', function() { this.style.background = '#f1f5fb'; });
            div.addEventListener('mouseleave', function() { this.style.background = 'transparent'; });
            if (item.acao) {
                div.addEventListener('click', function(e) {
                    e.stopPropagation();
                    self._fecharContextMenu();
                    if (typeof self[item.acao] === 'function') self[item.acao]();
                });
            }
            self._contextMenu.appendChild(div);
        });
    };

    Diagram.prototype._excluirRaiaSelecionada = function () {
        var laneId = this._contextMenuElementId || (this.selectedIds || [])[0];
        if (!laneId || !this.lanes.some(function(l) { return l.id === laneId; })) {
            alert('Selecione uma raia para excluir.');
            return;
        }
        if (this.lanes.length <= 1) {
            alert('O diagrama precisa manter ao menos uma raia.');
            return;
        }
        if (!confirm('Excluir esta raia? Os elementos serão movidos para a raia vizinha.')) return;
        this._excluirRaia(laneId);
    };


    /**
     * "Retornar para…" — cria um sequence flow da origem selecionada até
     * um elemento já existente no diagrama (caminho de retorno, ex.: ramo
     * "Não" de uma decisão voltando a uma tarefa anterior).
     *
     * No BPMN isso é modelado com sequence flow de retorno (ou, em
     * diagramas grandes, Link Intermediate Events). Aqui usamos o fluxo
     * de sequência, que a biblioteca já roteia como retorno.
     */
    Diagram.prototype._abrirRetornarPara = function () {
        var self = this;
        var origemId = this._contextMenuElementId || (this.selectedIds || [])[0];
        if (!origemId || !this.elements[origemId]) {
            alert('Selecione um elemento de origem (tarefa, gateway ou evento).');
            return;
        }
        var origem = this.elements[origemId];

        // Lista candidatos: tarefas, gateways e início (não o próprio, não fim)
        var candidatos = [];
        Object.keys(this.elements).forEach(function (id) {
            if (id === origemId) return;
            var el = self.elements[id];
            if (!el) return;
            var t = el.type || '';
            if (t === 'bpmn:EndEvent' || t === 'bpmn:TextAnnotation' ||
                t === 'bpmn:DataObject' || t === 'bpmn:DataStore' || t === 'bpmn:Group') {
                return;
            }
            candidatos.push(el);
        });
        candidatos.sort(function (a, b) {
            return (a.x - b.x) || (a.y - b.y);
        });
        if (!candidatos.length) {
            alert('Não há outros elementos no diagrama para retornar.');
            return;
        }

        var existente = document.querySelector('.vmap-retornar-para');
        if (existente) existente.remove();

        var painel = document.createElement('div');
        painel.className = 'vmap-retornar-para';
        painel.style.cssText =
            'position:fixed;z-index:10050;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:12px;' +
            'width:320px;max-height:360px;overflow:auto;font-family:inherit;' +
            'left:50%;top:20%;transform:translateX(-50%);';

        var titulo = document.createElement('div');
        titulo.style.cssText = 'font-size:14px;font-weight:600;margin-bottom:8px;color:#212529;';
        titulo.innerHTML = '↩ Retornar para… <span style="font-weight:400;color:#6c757d;font-size:12px;">a partir de "' +
            (origem.name || origem.id) + '"</span>';
        painel.appendChild(titulo);

        var hint = document.createElement('div');
        hint.style.cssText = 'font-size:12px;color:#6c757d;margin-bottom:10px;';
        hint.textContent = 'Escolha o elemento de destino. Será criado um fluxo de retorno (sequence flow).';
        painel.appendChild(hint);

        candidatos.forEach(function (el) {
            var tipoCurto = (el.type || '').replace('bpmn:', '');
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.style.cssText =
                'display:block;width:100%;text-align:left;padding:8px 10px;margin:0 0 4px 0;' +
                'border:1px solid #e9ecef;border-radius:6px;background:#f8fafc;cursor:pointer;' +
                'font-size:13px;color:#212529;';
            btn.innerHTML = '<strong>' + (el.name || '(sem nome)') + '</strong>' +
                ' <span style="color:#6c757d;font-size:11px;">' + tipoCurto + '</span>';
            btn.addEventListener('mouseenter', function () { btn.style.background = '#e7f1ff'; btn.style.borderColor = '#0a6fc2'; });
            btn.addEventListener('mouseleave', function () { btn.style.background = '#f8fafc'; btn.style.borderColor = '#e9ecef'; });
            btn.addEventListener('click', function () {
                // Cria conexão origem → destino (retorno)
                var fid = self._criarConexao(origemId, el.id, 'sequenceFlow');
                if (fid && self.flows[fid]) {
                    // Limpa waypoints para o auto-route de retorno atuar
                    self.flows[fid].waypoints = [];
                    delete self.flows[fid]._labelPos;
                    self.flows[fid].retorno = true;
                    // Rótulo "Não" quando é o 2º ramo de um gateway exclusivo
                    var origemTipo = origem.type || '';
                    if (origemTipo === 'bpmn:ExclusiveGateway' && !self.flows[fid].name) {
                        self.flows[fid].name = 'Não';
                    }
                }
                // Libera estado de inserção/conexão: a linha de retorno
                // não deve "prender" a próxima tarefa inserida.
                self._insertMenuOrigemId = null;
                self._connectionSource = null;
                self._isConnecting = false;
                self._modoConexao = null;
                self._modoInserir = null;
                self._fecharInsertMenu();
                self._fecharContextMenu();
                painel.remove();
                // Seleciona o destino do retorno para o usuário poder
                // continuar o fluxo a partir dele (ou do gateway) livremente.
                self._selecionar([el.id]);
                self._ultimoElementoSelecionado = el.id;
                self._render();
            });
            painel.appendChild(btn);
        });

        var cancelar = document.createElement('button');
        cancelar.type = 'button';
        cancelar.textContent = 'Cancelar';
        cancelar.style.cssText =
            'margin-top:8px;width:100%;padding:8px;border:1px solid #ced4da;border-radius:6px;' +
            'background:#fff;cursor:pointer;font-size:13px;';
        cancelar.addEventListener('click', function () { painel.remove(); });
        painel.appendChild(cancelar);

        document.body.appendChild(painel);

        var fecharFora = function (ev) {
            if (!painel.contains(ev.target)) {
                painel.remove();
                document.removeEventListener('mousedown', fecharFora);
            }
        };
        setTimeout(function () {
            document.addEventListener('mousedown', fecharFora);
        }, 50);
    };

    Diagram.prototype._abrirInsertMenuFromContextLane = function () {
        if (BLOQUEAR_INSERCAO) return;
        var laneId = this._contextMenuElementId || (this.selectedIds || [])[0];
        var lane = this.lanes.find(function(l) { return l.id === laneId; });
        if (!lane) {
            alert('Selecione uma raia primeiro.');
            return;
        }
        var cx = lane.x + Math.min(180, lane.w * 0.3);
        var cy = lane.y + lane.h / 2;
        var ptSvg = this._modeloParaSvg(cx, cy);
        this._abrirMenuInsercao(ptSvg.x, ptSvg.y, null, { x: cx, y: cy }, null, true);
    };

    Diagram.prototype._fecharContextMenu = function() {
        if (this._contextMenu) {
            this._contextMenu.style.display = 'none';
        }
        this._contextMenuElementId = null;
    };

    // ================================================================
    // EVENTOS DO DIAGRAMA
    // ================================================================
    Diagram.prototype._bindEvents = function () {
        var self = this;
        var arrastando = null;

        this.container.addEventListener('wheel', function (ev) {
            if (ev.ctrlKey || ev.metaKey) {
                ev.preventDefault();
                var fator = ev.deltaY < 0 ? 1.1 : 0.9;
                self.scale = Math.min(4, Math.max(0.15, self.scale * fator));
                self._atualizarViewport();
                self._render();
                if (self._atualizarZoomLabel) {
                    self._atualizarZoomLabel();
                }
            }
        }, { passive: false });

        this.svg.addEventListener('contextmenu', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            
            var target = ev.target;
            var shapeEl = target.closest('[data-element-id]');
            var kind = shapeEl ? shapeEl.getAttribute('data-element-kind') : null;
            
            self._fecharContextMenu();
            self._fecharInsertMenu();
            
            if (shapeEl && (kind === 'shape' || kind === 'connection' || kind === 'lane')) {
                self._abrirContextMenu(ev, shapeEl.getAttribute('data-element-id'));
            } else {
                self._abrirContextMenu(ev, null);
            }
        });

        this.svg.addEventListener('mousedown', function (ev) {
            self._fecharContextMenu();
            self._fecharInsertMenu();
            
            if (ev.button === 2) {
                return;
            }
            
            var target = ev.target;
            var shapeEl = target.closest('[data-element-id]');
            var kind = shapeEl ? shapeEl.getAttribute('data-element-kind') : null;

            if (self._modoConexao && shapeEl && kind === 'shape') {
                var id = shapeEl.getAttribute('data-element-id');
                if (!self._connectionSource) {
                    self._connectionSource = id;
                    self._selecionar([id]);
                    self._isConnecting = true;
                    if (self._connectionLine) {
                        self._connectionLine.style.display = 'block';
                    }
                    var pt = self._pontoSvgParaModelo(ev);
                    if (self._connectionLine) {
                        self._connectionLine.setAttribute('d', 'M' + pt.x + ',' + pt.y + ' L' + pt.x + ',' + pt.y);
                    }
                    return;
                } else if (self._connectionSource !== id) {
                    self._criarConexao(self._connectionSource, id, self._modoConexao);
                    self._connectionSource = null;
                    self._isConnecting = false;
                    if (self._connectionLine) {
                        self._connectionLine.style.display = 'none';
                    }
                    return;
                }
            }

            if (self._modoInserir && !shapeEl) {
                var pt = self._pontoSvgParaModelo(ev);
                self._criarElemento(self._modoInserir, pt.x, pt.y);
                // Após inserir um elemento, a ferramenta é desativada e o
                // diagrama volta ao modo de seleção — assim um novo clique
                // no canvas não insere outro elemento do mesmo tipo.
                self._desativarFerramenta();
                return;
            }

            if (shapeEl && kind === 'shape') {
                var id = shapeEl.getAttribute('data-element-id');
                var elemento = self.elements[id];
                
                if (elemento) {
                    if (!ev.ctrlKey && !ev.metaKey) {
                        self._selecionar([id]);
                    } else {
                        var idx = self.selectedIds.indexOf(id);
                        if (idx === -1) {
                            self.selectedIds.push(id);
                        } else {
                            self.selectedIds.splice(idx, 1);
                        }
                        self._render();
                    }
                    
                    self._ultimoElementoSelecionado = id;
                    
                    var pt = self._pontoSvgParaModelo(ev);
                    arrastando = {
                        id: id,
                        offX: pt.x - elemento.x,
                        offY: pt.y - elemento.y
                    };
                    self._draggingElement = true;
                    self.container.style.cursor = 'grabbing';
                    ev.preventDefault();
                }
            } else if (shapeEl && kind === 'connection') {
                var cid = shapeEl.getAttribute('data-element-id');
                self._selecionar([cid]);
                ev.preventDefault();

                var flowClicado = self.flows[cid];
                var ptClique = self._pontoSvgParaModelo(ev);
                var extremidade = null;
                if (flowClicado) {
                    var rota = self._rotaConexao(flowClicado);
                    if (rota.length >= 2) {
                        var tolerancia = 14 / (self.scale || 1);
                        var pOrig = rota[0], pDest = rota[rota.length - 1];
                        var distOrig = Math.hypot(ptClique.x - pOrig.x, ptClique.y - pOrig.y);
                        var distDest = Math.hypot(ptClique.x - pDest.x, ptClique.y - pDest.y);
                        if (distOrig <= tolerancia && distOrig <= distDest) {
                            extremidade = 'origem';
                        } else if (distDest <= tolerancia) {
                            extremidade = 'destino';
                        }
                    }
                }

                if (extremidade && flowClicado) {
                    self._arrastandoExtremidadeConexao = { flowId: cid, extremidade: extremidade };
                    self.container.style.cursor = 'crosshair';
                } else {
                    self._arrastandoConexao = true;
                    self._draggingConnection = cid;
                    self._ultimoPontoConexao = ptClique;
                    self.container.style.cursor = 'move';
                }
            } else if (shapeEl && kind === 'lane') {
                var laneId = shapeEl.getAttribute('data-element-id');
                var lane = self.lanes.find(function(l) { return l.id === laneId; });
                if (lane) {
                    self._selecionar([laneId]);
                    var pt = self._pontoSvgParaModelo(ev);
                    self._draggingLane = {
                        id: laneId,
                        offsetY: pt.y - lane.y
                    };
                    self.container.style.cursor = 'row-resize';
                    ev.preventDefault();
                }
            } else {
                if (!ev.ctrlKey && !ev.metaKey) {
                    self._selecionar([]);
                }
            }
        });

        document.addEventListener('mousemove', function (ev) {
            var pt = self._pontoSvgParaModelo(ev);
            
            if (self._isConnecting && self._connectionSource && self._connectionLine) {
                var src = self.elements[self._connectionSource];
                if (src) {
                    var dock = self._pontoBordaMaisProximo(src, pt);
                    self._connectionLine.setAttribute('d', 
                        'M' + dock.x + ',' + dock.y + 
                        ' L' + pt.x + ',' + pt.y
                    );
                }
                return;
            }

            if (arrastando) {
                var elemento = self.elements[arrastando.id];
                if (elemento) {
                    elemento.x = pt.x - arrastando.offX;
                    elemento.y = pt.y - arrastando.offY;
                    // Durante o arraste, limpa waypoints das conexões ligadas
                    // para que as extremidades permaneçam ancoradas (não "soltas")
                    Object.keys(self.flows).forEach(function (fid) {
                        var f = self.flows[fid];
                        if (f.sourceId === arrastando.id || f.targetId === arrastando.id) {
                            f.waypoints = [];
                            delete f._labelPos;
                        }
                    });
                    self._render();
                }
                return;
            }

            if (self._arrastandoExtremidadeConexao) {
                var infoExtremidade = self._arrastandoExtremidadeConexao;
                var flowExt = self.flows[infoExtremidade.flowId];
                if (flowExt) {
                    if (!flowExt.waypoints || flowExt.waypoints.length < 2) {
                        var pontosAtuais = self._rotaConexao(flowExt);
                        flowExt.waypoints = pontosAtuais.map(function(p) { return { x: p.x, y: p.y }; });
                    }
                    var elementoAlvo = infoExtremidade.extremidade === 'origem'
                        ? self.elements[flowExt.sourceId]
                        : self.elements[flowExt.targetId];
                    if (elementoAlvo) {
                        var pontoEncaixado = self._pontoNaBordaParaArraste(elementoAlvo, pt);
                        if (infoExtremidade.extremidade === 'origem') {
                            flowExt.waypoints[0] = { x: pontoEncaixado.x, y: pontoEncaixado.y };
                        } else {
                            flowExt.waypoints[flowExt.waypoints.length - 1] = { x: pontoEncaixado.x, y: pontoEncaixado.y };
                        }
                        self._render();
                    }
                }
                return;
            }

            if (self._arrastandoConexao && self._draggingConnection) {
                var flow = self.flows[self._draggingConnection];
                if (flow) {
                    if (!flow.waypoints || flow.waypoints.length < 2) {
                        var pontos = self._rotaConexao(flow);
                        flow.waypoints = pontos.map(function(p) { return { x: p.x, y: p.y }; });
                    }
                    if (self._ultimoPontoConexao) {
                        var dx = pt.x - self._ultimoPontoConexao.x;
                        var dy = pt.y - self._ultimoPontoConexao.y;
                        for (var i = 1; i < flow.waypoints.length - 1; i++) {
                            flow.waypoints[i].x += dx;
                            flow.waypoints[i].y += dy;
                        }
                    }
                    self._ultimoPontoConexao = { x: pt.x, y: pt.y };
                    self._render();
                }
                return;
            }

            if (self._draggingLane) {
                var lane = self.lanes.find(function(l) { return l.id === self._draggingLane.id; });
                if (lane) {
                    var deltaY = pt.y - (lane.y + self._draggingLane.offsetY);
                    if (Math.abs(deltaY) > 2) {
                        var idx = self.lanes.indexOf(lane);
                        lane.y += deltaY;
                        lane.refs.forEach(function(elId) {
                            var elemento = self.elements[elId];
                            if (elemento) elemento.y += deltaY;
                        });
                        for (var i = idx + 1; i < self.lanes.length; i++) {
                            self.lanes[i].y += deltaY;
                            self.lanes[i].refs.forEach(function(elId) {
                                var elemento = self.elements[elId];
                                if (elemento) elemento.y += deltaY;
                            });
                        }
                        self._draggingLane.offsetY = pt.y - lane.y;
                        Object.keys(self.flows).forEach(function (fid) {
                            self.flows[fid].waypoints = [];
                            delete self.flows[fid]._labelPos;
                        });
                        self._render();
                    }
                }
                return;
            }

            var target = ev.target;
            var shapeEl = target.closest('[data-element-id]');
            var novoHover = shapeEl ? shapeEl.getAttribute('data-element-id') : null;
            if (novoHover !== self.hoveredId) {
                self.hoveredId = novoHover;
                self._render();
            }

            if (shapeEl && shapeEl.getAttribute('data-element-kind') === 'shape') {
                self.container.style.cursor = 'grab';
            } else if (shapeEl && shapeEl.getAttribute('data-element-kind') === 'connection') {
                self.container.style.cursor = 'move';
            } else if (shapeEl && shapeEl.getAttribute('data-element-kind') === 'lane') {
                self.container.style.cursor = 'row-resize';
            } else {
                if (!self._modoInserir && !self._modoConexao && !self._modoRisco) {
                    self.container.style.cursor = 'default';
                }
            }
        });

        document.addEventListener('mouseup', function (ev) {
            if (arrastando) {
                self._reatribuirRaia(arrastando.id);
                self._render();
                arrastando = null;
                self._draggingElement = false;
                self.container.style.cursor = 'default';
            }
            
            if (self._isConnecting) {
                var target = document.elementFromPoint(ev.clientX, ev.clientY);
                var shapeEl = target ? target.closest('[data-element-kind="shape"]') : null;
                if (shapeEl && self._connectionSource) {
                    var id = shapeEl.getAttribute('data-element-id');
                    if (id !== self._connectionSource) {
                        self._criarConexao(self._connectionSource, id, self._modoConexao || 'sequenceFlow');
                    }
                }
                self._connectionSource = null;
                self._isConnecting = false;
                if (self._connectionLine) {
                    self._connectionLine.style.display = 'none';
                }
            }

            if (self._arrastandoConexao) {
                self._arrastandoConexao = false;
                self._draggingConnection = null;
                self._ultimoPontoConexao = null;
                self.container.style.cursor = 'default';
            }

            if (self._arrastandoExtremidadeConexao) {
                self._arrastandoExtremidadeConexao = null;
                self.container.style.cursor = 'default';
            }

            if (self._draggingLane) {
                self._draggingLane = null;
                self.container.style.cursor = 'default';
            }
        });

        document.addEventListener('keydown', function (ev) {
            if (ev.target.tagName === 'INPUT' || ev.target.tagName === 'TEXTAREA') return;
            
            if (ev.key === 'Delete' || ev.key === 'Backspace') {
                if (self.selectedIds && self.selectedIds.length > 0) {
                    ev.preventDefault();
                    self._excluirSelecionado();
                }
            }
            
            if (ev.key === 'Escape') {
                self._modoInserir = null;
                self._modoConexao = null;
                self._modoRisco = false;
                self._connectionSource = null;
                self._isConnecting = false;
                if (self._connectionLine) {
                    self._connectionLine.style.display = 'none';
                }
                self.container.style.cursor = 'default';
                self._fecharContextMenu();
                self._fecharInsertMenu();
                if (self._painelRiscosEl) {
                    self._painelRiscosEl.remove();
                    self._painelRiscosEl = null;
                }
            }

            if (ev.key === 'c' && (ev.ctrlKey || ev.metaKey)) {
                self._copiarSelecionado();
                ev.preventDefault();
            }
            
            if (ev.key === 'v' && (ev.ctrlKey || ev.metaKey)) {
                self._colar();
                ev.preventDefault();
            }

            if (ev.key === 'a' && (ev.ctrlKey || ev.metaKey)) {
                self._selecionarTudo();
                ev.preventDefault();
            }
        });

        this.svg.addEventListener('dblclick', function (ev) {
            var target = ev.target;
            var shapeEl = target.closest('[data-element-id]');
            if (shapeEl && (shapeEl.getAttribute('data-element-kind') === 'shape' || 
                           shapeEl.getAttribute('data-element-kind') === 'lane')) {
                var id = shapeEl.getAttribute('data-element-id');
                self._selecionar([id]);
                self._renomearSelecionado();
            }
        });
    };

    // ================================================================
    // CONEXÃO LIVRE
    // ================================================================
    Diagram.prototype._pertoDaBorda = function (pt, elemento) {
        var margem = 12 / this.scale;
        var relX = pt.x - elemento.x;
        var relY = pt.y - elemento.y;
        if (relX < -margem || relX > elemento.w + margem || relY < -margem || relY > elemento.h + margem) return false;
        return relX <= margem || relX >= elemento.w - margem || relY <= margem || relY >= elemento.h - margem;
    };

    Diagram.prototype._iniciarConexaoLivre = function (origemId, evInicial) {
        var self = this;
        var origem = this.elements[origemId];
        if (!origem) return;

        this._fecharMenuInsercao();
        this._selecionar([origemId]);
        this._conectandoLivre = true;
        this.svg.style.cursor = 'crosshair';

        var pontoInicial = self._pontoSvgParaModelo(evInicial);
        var linha = el('line', {
            x1: pontoInicial.x, y1: pontoInicial.y, 
            x2: pontoInicial.x, y2: pontoInicial.y,
            stroke: '#0a6fc2', 'stroke-width': 2, 'stroke-dasharray': '6,4', 'pointer-events': 'none'
        }, this.gConnections);

        function mover(ev) {
            var pt = self._pontoSvgParaModelo(ev);
            linha.setAttribute('x2', pt.x);
            linha.setAttribute('y2', pt.y);
        }

        function soltar(ev) {
            window.removeEventListener('mousemove', mover);
            window.removeEventListener('mouseup', soltar);
            linha.remove();
            self._conectandoLivre = false;
            self._atualizarCursor();

            var dist = Math.hypot(ev.clientX - evInicial.clientX, ev.clientY - evInicial.clientY);
            if (dist < 6) return;

            var alvoEl = document.elementFromPoint(ev.clientX, ev.clientY);
            var grupoAlvo = alvoEl && alvoEl.closest && alvoEl.closest('[data-element-kind="shape"]');
            var destinoId = grupoAlvo ? grupoAlvo.getAttribute('data-element-id') : null;

            if (destinoId && destinoId !== origemId && self.elements[destinoId]) {
                self._criarConexao(origemId, destinoId, 'sequenceFlow');
            } else {
                var pt = self._pontoSvgParaModelo(ev);
                self._abrirMenuInsercao(ev.clientX, ev.clientY, origemId, pt, null, true);
            }
        }

        window.addEventListener('mousemove', mover);
        window.addEventListener('mouseup', soltar);
    };

    Diagram.prototype._fecharMenuInsercao = function () {
        if (this._menuInsercaoEl) {
            this._menuInsercaoEl.remove();
            this._menuInsercaoEl = null;
        }
    };

    // ================================================================
    // MENU DE INSERÇÃO
    // ================================================================
    var TIPOS_MENU_INSERCAO = [
        { tipo: 'bpmn:Task', label: 'Tarefa', icone: '▭' },
        { tipo: 'bpmn:ExclusiveGateway', label: 'Decisão', icone: '◇' },
        { tipo: 'bpmn:ParallelGateway', label: 'Paralelo', icone: '⬡' },
        { tipo: 'bpmn:InclusiveGateway', label: 'Inclusivo', icone: '⬢' },
        { tipo: 'bpmn:SubProcess', label: 'Subprocesso', icone: '⊞' },
        { tipo: 'bpmn:IntermediateThrowEvent', label: 'Evento', icone: '◉' },
        { tipo: 'bpmn:TimerEvent', label: 'Evento Timer', icone: '⏱' },
        { tipo: 'bpmn:MessageEvent', label: 'Evento Mensagem', icone: '✉' },
        { tipo: 'bpmn:EndEvent', label: 'Fim', icone: '●' },
        { tipo: 'bpmn:TextAnnotation', label: 'Anotação', icone: '📝' },
        { tipo: 'bpmn:DataObject', label: 'Dados', icone: '📄' }
    ];

    Diagram.prototype._abrirMenuInsercao = function (clientX, clientY, origemId, pontoModelo, direcao, posicaoExata) {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        this._fecharMenuInsercao();

        var lista = TIPOS_MENU_INSERCAO;
        var origem = origemId ? this.elements[origemId] : null;

        var menu = document.createElement('div');
        menu.className = 'vmap-menu-insercao';
        menu.style.cssText = 'position:fixed;z-index:10000;background:#fff;border:1px solid #d7dde4;' +
            'border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,.18);padding:6px;min-width:190px;' +
            'font-family:inherit;left:' + clientX + 'px;top:' + clientY + 'px;';

        if (origem) {
            var titulo = document.createElement('div');
            titulo.style.cssText = 'font-size:11px;color:#8a97a5;padding:4px 8px 6px;border-bottom:1px solid #eef1f4;margin-bottom:4px;';
            titulo.textContent = 'Inserir e conectar a partir de "' + (origem.name || origem.id) + '"';
            menu.appendChild(titulo);
        }

        lista.forEach(function (item) {
            var opcao = document.createElement('div');
            opcao.style.cssText = 'display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:6px;cursor:pointer;font-size:13px;color:#212529;';
            opcao.innerHTML = '<span style="width:26px;height:26px;display:flex;align-items:center;justify-content:center;">' + paletteIcon(item.tipo, '#3b6ea8') + '</span><span>' + item.label + '</span>';
            opcao.addEventListener('mouseenter', function () { opcao.style.background = '#f1f5fb'; });
            opcao.addEventListener('mouseleave', function () { opcao.style.background = ''; });
            opcao.addEventListener('mousedown', function (ev) { ev.stopPropagation(); });
            opcao.addEventListener('click', function (ev) {
                ev.stopPropagation();
                self._fecharMenuInsercao();
                if (origemId) {
                    if (TIPOS_ANEXAVEIS[item.tipo]) {
                        self._escolherDirecaoAnexo(origemId, item.tipo);
                    } else {
                        self._inserirConectado(origemId, item.tipo, 'sequenceFlow');
                    }
                } else if (pontoModelo) {
                    self._criarElemento(item.tipo, pontoModelo.x, pontoModelo.y);
                }
            });
            menu.appendChild(opcao);
        });

        document.body.appendChild(menu);
        this._menuInsercaoEl = menu;
    };

    Diagram.prototype._atualizarCursor = function () {
        this.svg.style.cursor = (this.insertType || this.connectMode) ? 'crosshair' : 'default';
    };

    // ================================================================
    // OPERAÇÕES DE SELEÇÃO
    // ================================================================
    Diagram.prototype._selecionar = function (ids) {
        this.selectedIds = ids || [];
        this.events.fire('selection.changed', { 
            elements: this.selectedIds.map(function(id) {
                return this.elements[id] || this.flows[id];
            }, this).filter(Boolean)
        });
        this._render();
    };

    Diagram.prototype._selecionarTudo = function () {
        var ids = Object.keys(this.elements);
        this._selecionar(ids);
    };

    // ================================================================
    // OPERAÇÕES DE ELEMENTOS
    // ================================================================
    Diagram.prototype._criarElemento = function (tipo, cx, cy) {
        if (BLOQUEAR_INSERCAO) return null;
        var tam = TAMANHOS[tipo] || { w: 100, h: 80 };
        var id = this._nextId(tipo.replace('bpmn:', ''));
        
        var nomePadrao = {
            'bpmn:StartEvent': 'Início',
            'bpmn:EndEvent': 'Fim',
            'bpmn:IntermediateThrowEvent': 'Evento',
            'bpmn:TimerEvent': 'Aguardar',
            'bpmn:MessageEvent': 'Mensagem',
            'bpmn:Task': 'Nova tarefa',
            'bpmn:UserTask': 'Tarefa usuário',
            'bpmn:ServiceTask': 'Tarefa serviço',
            'bpmn:ScriptTask': 'Tarefa script',
            'bpmn:SubProcess': 'Subprocesso',
            'bpmn:ExclusiveGateway': 'Decisão',
            'bpmn:ParallelGateway': 'Paralelo',
            'bpmn:InclusiveGateway': 'Inclusivo',
            'bpmn:EventBasedGateway': 'Evento',
            'bpmn:TextAnnotation': 'Anotação',
            'bpmn:DataObject': 'Dados',
            'bpmn:DataStore': 'Armazenamento',
            'bpmn:Group': 'Grupo'
        }[tipo] || '';

        var elemento = {
            id: id,
            type: tipo,
            x: Math.round(cx - tam.w / 2),
            y: Math.round(cy - tam.h / 2),
            w: tam.w,
            h: tam.h,
            name: nomePadrao,
            riscos: []
        };

        // Numeração sequencial para tarefas (exibida no canto superior direito)
        var tiposTarefa = {
            'bpmn:Task': true,
            'bpmn:ManualTask': true,
            'bpmn:ServiceTask': true,
            'bpmn:UserTask': true,
            'bpmn:ScriptTask': true,
            'bpmn:BusinessRuleTask': true,
            'bpmn:SendTask': true,
            'bpmn:ReceiveTask': true
        };
        if (tiposTarefa[tipo]) {
            this._taskSeq = (this._taskSeq || 0) + 1;
            elemento.numero = this._taskSeq;
        }

        this.elements[id] = elemento;
        if (this.lanes.length) {
            this._reatribuirRaia(id);
        }
        this._render();
        this._selecionar([id]);
        this.events.fire('element.added', { element: this._elementoPublico(elemento) });
        
        return id;
    };

    // ================================================================
    // EXCLUIR SELEÇÃO
    // ================================================================
    Diagram.prototype._excluirSelecionado = function () {
        var self = this;
        var idsParaExcluir = this.selectedIds.slice();
        
        idsParaExcluir.forEach(function(id) {
            if (self.elements[id]) {
                delete self.elements[id];
                Object.keys(self.flows).forEach(function(fid) {
                    var f = self.flows[fid];
                    if (f.sourceId === id || f.targetId === id) {
                        delete self.flows[fid];
                    }
                });
                self.lanes.forEach(function(lane) {
                    var i = lane.refs.indexOf(id);
                    if (i !== -1) lane.refs.splice(i, 1);
                });
            }
            else if (self.flows[id]) {
                delete self.flows[id];
            }
            else if (self.lanes.some(function(l) { return l.id === id; })) {
                self._excluirRaia(id);
            }
        });
        
        // Reordena a numeração sequencial das tarefas restantes para
        // não deixar hiatos (1, 2, 3… contínuo a partir da última inserida).
        this._renumerarTarefas();

        this.selectedIds = [];
        this._render();
        this.events.fire('element.removed', { ids: idsParaExcluir });
    };

    /**
     * Renumeração sequencial das tarefas restantes (sem hiatos).
     * Ordena pela numeração anterior e, em empate, pela posição no diagrama.
     */
    Diagram.prototype._renumerarTarefas = function () {
        var tiposTarefa = {
            'bpmn:Task': true, 'bpmn:ManualTask': true, 'bpmn:ServiceTask': true,
            'bpmn:UserTask': true, 'bpmn:ScriptTask': true, 'bpmn:BusinessRuleTask': true,
            'bpmn:SendTask': true, 'bpmn:ReceiveTask': true
        };
        var lista = [];
        var self = this;
        Object.keys(this.elements).forEach(function (id) {
            var el = self.elements[id];
            if (el && tiposTarefa[el.type]) lista.push(el);
        });
        lista.sort(function (a, b) {
            var na = typeof a.numero === 'number' ? a.numero : 1e9;
            var nb = typeof b.numero === 'number' ? b.numero : 1e9;
            if (na !== nb) return na - nb;
            return (a.x - b.x) || (a.y - b.y);
        });
        lista.forEach(function (el, i) {
            el.numero = i + 1;
        });
        this._taskSeq = lista.length;
    };

    // ================================================================
    // OPERAÇÕES DE RAIAS
    // ================================================================
    Diagram.prototype._adicionarRaia = function () {
        if (BLOQUEAR_INSERCAO) return;
        if (!this.participant) {
            this.participant = { 
                id: this._nextId('Participant'), 
                name: this.processName || 'Processo' 
            };
        }

        var ultimaLane = this.lanes[this.lanes.length - 1];
        var x = ultimaLane ? ultimaLane.x : 60;
        var w = ultimaLane ? ultimaLane.w : CONFIG.laneWidth;
        var y = ultimaLane ? (ultimaLane.y + ultimaLane.h + 10) : 50;

        var id = this._nextId('Lane');
        this.lanes.push({
            id: id,
            name: 'Raia ' + (this.lanes.length + 1),
            x: x,
            y: y,
            w: w,
            h: CONFIG.laneHeight,
            refs: []
        });
        
        this._render();
        this._selecionar([id]);
    };

    Diagram.prototype._excluirRaia = function (laneId) {
        var self = this;
        var idx = this.lanes.findIndex(function(l) { return l.id === laneId; });
        if (idx === -1) return;
        
        var lane = this.lanes[idx];
        var deltaY = lane.h;
        this.lanes.splice(idx, 1);

        var destino = this.lanes[idx] || this.lanes[idx - 1] || null;
        if (destino) {
            lane.refs.forEach(function(elId) {
                var elemento = self.elements[elId];
                if (elemento) {
                    elemento.y = destino.y + 20;
                }
                destino.refs.push(elId);
            });
        }

        for (var i = idx; i < this.lanes.length; i++) {
            this.lanes[i].y -= deltaY;
            this.lanes[i].refs.forEach(function(elId) {
                var elemento = self.elements[elId];
                if (elemento) elemento.y -= deltaY;
            });
        }

        this._render();
    };

    Diagram.prototype._dividirRaiaSelecionada = function () {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        var laneId = this.selectedIds.find(function(id) {
            return self.lanes.some(function(l) { return l.id === id; });
        });
        if (!laneId) {
            alert('Selecione a raia que deseja dividir (clique sobre ela) e tente novamente.');
            return;
        }
        this._dividirRaia(laneId);
    };

    Diagram.prototype._dividirRaia = function (laneId) {
        if (BLOQUEAR_INSERCAO) return;
        var self = this;
        var idx = this.lanes.findIndex(function(l) { return l.id === laneId; });
        if (idx === -1) return;
        var lane = this.lanes[idx];

        if (lane.h < CONFIG.minLaneHeight * 2) {
            alert('Aumente a altura da raia antes de dividir (mínimo de ' + (CONFIG.minLaneHeight * 2) + 'px).');
            return;
        }

        var alturaSuperior = Math.round(lane.h / 2);
        var linhaCorte = lane.y + alturaSuperior;

        var refsSuperior = [];
        var refsInferior = [];
        lane.refs.forEach(function(elId) {
            var elemento = self.elements[elId];
            var centro = elemento ? (elemento.y + elemento.h / 2) : lane.y;
            if (centro < linhaCorte) refsSuperior.push(elId);
            else refsInferior.push(elId);
        });

        var novaLane = {
            id: this._nextId('Lane'),
            name: (lane.name || 'Raia') + ' (2)',
            x: lane.x,
            y: linhaCorte,
            w: lane.w,
            h: lane.h - alturaSuperior,
            refs: refsInferior
        };

        lane.h = alturaSuperior;
        lane.refs = refsSuperior;
        this.lanes.splice(idx + 1, 0, novaLane);

        this._ajustarRaiaParaConteudo(lane.id);
        this._ajustarRaiaParaConteudo(novaLane.id);

        this._render();
        this._selecionar([lane.id]);
    };

    Diagram.prototype._reatribuirRaia = function (elementoId) {
        if (!this.lanes.length) return;
        var elemento = this.elements[elementoId];
        if (!elemento) return;

        var centroY = elemento.y + elemento.h / 2;
        var laneAlvo = this.lanes.find(function(l) {
            return centroY >= l.y && centroY <= (l.y + l.h);
        });

        if (!laneAlvo) {
            laneAlvo = this.lanes.reduce(function(maisProxima, l) {
                var distAtual = Math.abs(centroY - (l.y + l.h/2));
                var distMelhor = Math.abs(centroY - (maisProxima.y + maisProxima.h/2));
                return distAtual < distMelhor ? l : maisProxima;
            }, this.lanes[0]);
        }

        this.lanes.forEach(function(l) {
            var i = l.refs.indexOf(elementoId);
            if (i !== -1) l.refs.splice(i, 1);
        });
        
        laneAlvo.refs.push(elementoId);
        this._ajustarRaiaParaConteudo(laneAlvo.id);
        this._relayoutConexoesDoElemento(elementoId);
    };

    /**
     * Após mover um elemento, limpa waypoints manuais das conexões ligadas
     * para que o roteamento ortogonal recalcule e as extremidades fiquem ancoradas
     * (comportamento similar ao bpmn-js / diagram-js).
     */
    Diagram.prototype._relayoutConexoesDoElemento = function (elementoId) {
        var self = this;
        Object.keys(this.flows).forEach(function (fid) {
            var f = self.flows[fid];
            if (f.sourceId === elementoId || f.targetId === elementoId) {
                f.waypoints = [];
                delete f._labelPos;
            }
        });
    };

    Diagram.prototype._ajustarRaiaParaConteudo = function (laneId) {
        var self = this;
        var idx = this.lanes.findIndex(function(l) { return l.id === laneId; });
        if (idx === -1) return;
        var lane = this.lanes[idx];

        // Altura mínima baseada no conteúdo (estilo bpmn-js: lane não fica menor que os elementos)
        var maxY = lane.y;
        var minY = Infinity;
        lane.refs.forEach(function(elId) {
            var elemento = self.elements[elId];
            if (elemento) {
                maxY = Math.max(maxY, elemento.y + elemento.h);
                minY = Math.min(minY, elemento.y);
            }
        });
        var alturaNecessaria = Math.max(CONFIG.minLaneHeight, 
            Math.round((maxY - lane.y) + CONFIG.padding));
        
        if (alturaNecessaria > lane.h) {
            var diferenca = alturaNecessaria - lane.h;
            lane.h = alturaNecessaria;
            
            for (var i = idx + 1; i < this.lanes.length; i++) {
                this.lanes[i].y += diferenca;
                this.lanes[i].refs.forEach(function(elId) {
                    var elemento = self.elements[elId];
                    if (elemento) elemento.y += diferenca;
                });
            }
        }

        // Todas as raias compartilham a mesma largura (pool único)
        var maxX = lane.x;
        this.lanes.forEach(function(l) {
            l.refs.forEach(function(elId) {
                var elemento = self.elements[elId];
                if (elemento) maxX = Math.max(maxX, elemento.x + elemento.w);
            });
        });
        var larguraNecessaria = Math.max(CONFIG.minLaneWidth,
            Math.round((maxX - (this.lanes[0] ? this.lanes[0].x : lane.x)) + CONFIG.padding));
        
        if (larguraNecessaria > (this.lanes[0] ? this.lanes[0].w : lane.w)) {
            this.lanes.forEach(function(l) { l.w = larguraNecessaria; });
        }

        // Pool (nome do processo) acompanha sempre a expansão das raias
        this._sincronizarBoundsParticipant();
    };

    /**
     * Mantém o retângulo do participant (campo do nome do processo) alinhado
     * às raias atuais — largura e altura. Evita a raia "estourar" o pool.
     */
    Diagram.prototype._sincronizarBoundsParticipant = function () {
        if (!this.lanes || !this.lanes.length) return;
        var box = this._bboxParticipant();
        if (!box || !(box.w > 0 && box.h > 0)) return;

        if (this.participant) {
            this.participant.bounds = { x: box.x, y: box.y, w: box.w, h: box.h };
        }

        if (!this.participants || !this.participants.length) return;

        if (this.participants.length === 1) {
            this.participants[0].bounds = { x: box.x, y: box.y, w: box.w, h: box.h };
            return;
        }

        // Multi-pool: cada participant cobre as raias cuja faixa vertical
        // intersecta o bounds atual (expandido).
        var self = this;
        this.participants.forEach(function (p) {
            if (!p.bounds) {
                p.bounds = { x: box.x, y: box.y, w: box.w, h: box.h };
                return;
            }
            var py1 = p.bounds.y;
            var py2 = p.bounds.y + p.bounds.h;
            var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
            var achou = false;
            self.lanes.forEach(function (l) {
                var mid = l.y + l.h / 2;
                if (mid < py1 - 8 || mid > py2 + 8) return;
                achou = true;
                minX = Math.min(minX, l.x - 30);
                minY = Math.min(minY, l.y);
                maxX = Math.max(maxX, l.x + l.w);
                maxY = Math.max(maxY, l.y + l.h);
            });
            if (achou) {
                p.bounds = { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
            } else {
                // Fallback: acompanha largura global das raias
                p.bounds.w = Math.max(p.bounds.w, box.w);
                p.bounds.x = Math.min(p.bounds.x, box.x);
            }
        });
    };

    /**
     * Altura mínima de uma raia considerando seus elementos (não pode encolher abaixo do conteúdo).
     */
    Diagram.prototype._alturaMinimaRaia = function (lane) {
        var self = this;
        var maxBottom = lane.y;
        (lane.refs || []).forEach(function (elId) {
            var el = self.elements[elId];
            if (el) maxBottom = Math.max(maxBottom, el.y + el.h);
        });
        return Math.max(CONFIG.minLaneHeight, Math.round((maxBottom - lane.y) + CONFIG.padding));
    };

    /**
     * Redimensiona raia com empurrão balanceado das raias seguintes (estilo bpmn-js ResizeLane).
     * direction: 's' (sul / borda inferior).
     */
    Diagram.prototype._redimensionarRaia = function (laneId, novaAltura) {
        var self = this;
        var idx = this.lanes.findIndex(function (l) { return l.id === laneId; });
        if (idx === -1) return;
        var lane = this.lanes[idx];
        var minH = this._alturaMinimaRaia(lane);
        novaAltura = Math.max(minH, Math.round(novaAltura));
        var diferenca = novaAltura - lane.h;
        if (Math.abs(diferenca) < 0.5) return;
        lane.h = novaAltura;
        for (var i = idx + 1; i < this.lanes.length; i++) {
            this.lanes[i].y += diferenca;
            this.lanes[i].refs.forEach(function (elId) {
                var elemento = self.elements[elId];
                if (elemento) elemento.y += diferenca;
            });
        }
        // Relayout de conexões que cruzam raias afetadas
        Object.keys(this.flows).forEach(function (fid) {
            var f = self.flows[fid];
            f.waypoints = [];
            delete f._labelPos;
        });
    };

    // ================================================================
    // ROTEAMENTO DE CONECTORES
    // ================================================================
    /**
     * Retorna as saídas de um gateway em uma ordem visual estável.
     *
     * A versão anterior ancorava TODAS as saídas no mesmo vértice direito
     * do losango. Isso é matematicamente válido, mas produz a sobreposição
     * mostrada no diagrama: SIM e NÃO compartilham o mesmo primeiro trecho.
     *
     * O padrão adotado aqui é o de uma modelagem BPMN mais limpa: as saídas
     * são distribuídas na metade direita do gateway e cada ramo recebe sua
     * própria linha de saída antes da mudança vertical/horizontal.
     */
    Diagram.prototype._saidasGatewayOrdenadas = function (gatewayId) {
        var self = this;
        return Object.keys(this.flows).map(function (id) {
            return self.flows[id];
        }).filter(function (f) {
            return f && !f.associacao && f.sourceId === gatewayId;
        }).sort(function (a, b) {
            var ta = self.elements[a.targetId];
            var tb = self.elements[b.targetId];
            var ya = ta ? ta.y + ta.h / 2 : 0;
            var yb = tb ? tb.y + tb.h / 2 : 0;
            if (Math.abs(ya - yb) > 0.5) return ya - yb;
            return String(a.id).localeCompare(String(b.id));
        });
    };

    /**
     * Calcula o ponto de saída de um gateway BPMN.
     *
     * Regra BPMN: todas as sequence flows que saem de um gateway devem se
     * conectar ao MESMO ponto — o vértice direito do losango — e não a
     * pontos distribuídos ao longo da aresta diagonal. É essa ancoragem
     * única que faz o losango ser reconhecível como o ponto de decisão;
     * pontos espalhados pela borda quebram essa leitura e "furam" o
     * contorno da forma.
     *
     * O primeiro trecho de cada ramo (saindo do vértice) pode se sobrepor
     * visualmente por um curto espaço antes de divergir — isso é esperado
     * e é como ferramentas BPMN de referência (Bizagi, Camunda) desenham
     * múltiplas saídas de um mesmo gateway.
     */
    Diagram.prototype._pontoSaidaGateway = function (gateway, flow) {
        var cy = gateway.y + gateway.h / 2;
        return { x: gateway.x + gateway.w, y: cy, lado: 'right', indice: 0, total: 1 };
    };

    Diagram.prototype._rotaConexao = function (flow) {
        var s = this.elements[flow.sourceId];
        var t = this.elements[flow.targetId];
        if (!s || !t) return [];

        // Waypoints manuais: reancora extremidades nas bordas atuais (evita conectores "soltos")
        if (flow.waypoints && flow.waypoints.length >= 2) {
            var wps = flow.waypoints.map(function (wp) { return { x: wp.x, y: wp.y }; });
            // Re-dock início e fim nos elementos (comportamento de cropping do bpmn-js)
            var mid1 = wps.length > 2 ? wps[1] : { x: t.x + t.w / 2, y: t.y + t.h / 2 };
            var midN = wps.length > 2 ? wps[wps.length - 2] : { x: s.x + s.w / 2, y: s.y + s.h / 2 };
            var dockOrigem = this._pontoBordaMaisProximo(s, mid1);
            var dockDestino = this._pontoBordaMaisProximo(t, midN);
            wps[0] = { x: dockOrigem.x, y: dockOrigem.y };
            wps[wps.length - 1] = { x: dockDestino.x, y: dockDestino.y };
            return wps;
        }

        // Ancoragem inteligente nas bordas (Manhattan / bpmn-js style).
        // Gateways recebem tratamento especial para distribuir múltiplas
        // saídas e impedir a sobreposição dos ramos logo após o losango.
        var pOrigem = this._pontoBordaInteligente(s, t);
        var pDestino = this._pontoBordaInteligente(t, s);

        // Início/Fim em fluxo LTR: ancora sempre direita → esquerda, linha
        // horizontal no centro. Prioridade máxima (inclusive sobre artefato
        // legado classificado incorretamente).
        var origemEhInicio = s.type === 'bpmn:StartEvent';
        var destinoEhFim = t.type === 'bpmn:EndEvent';
        if ((origemEhInicio || destinoEhFim) && t.x >= s.x - 8 && !flow.associacao) {
            if (flow.tipo === 'eventoArtefato') flow.tipo = 'sequenceFlow';
            var pO = this._pontoBordaPorLado(s, 'right');
            var pD = this._pontoBordaPorLado(t, 'left');
            pO.y = s.y + s.h / 2;
            pD.y = t.y + t.h / 2;
            if (Math.abs(pO.y - pD.y) < 4) {
                pD.y = pO.y;
                return [pO, pD];
            }
            var xM = (pO.x + pD.x) / 2;
            return [pO, { x: xM, y: pO.y }, { x: xM, y: pD.y }, pD];
        }

        // Associações/artefatos (anotação, objeto de dado, etc.) são conexões
        // de apoio, não fluxo de processo — sempre devem sair pela base do
        // elemento de origem e entrar pelo topo do elemento anexado (ou o
        // inverso, quando o anexo fica posicionado acima). Isso precisa vir
        // ANTES da regra de "mudança de raia" abaixo: como esses elementos
        // costumam ficar posicionados perto do limite inferior da raia, sem
        // esse tratamento a rota era tratada como travessia de raia e saía
        // pela direita/entrava pela esquerda, gerando o zigue-zague em L.
        // Nunca trate Início/Fim como artefato (mesmo com tipo legado errado).
        var envolveInicioFim = (s.type === 'bpmn:StartEvent' || s.type === 'bpmn:EndEvent' ||
            t.type === 'bpmn:StartEvent' || t.type === 'bpmn:EndEvent');
        var ehConexaoDeArtefato = !envolveInicioFim && (
            flow.associacao || flow.tipo === 'association' || flow.tipo === 'eventoArtefato'
        );
        if (ehConexaoDeArtefato) {
            // Sempre no centro superior/inferior, para clareza do diagrama.
            var alvoAbaixo = (t.y + t.h / 2) >= (s.y + s.h / 2);
            var xCentroOrigem = s.x + s.w / 2;
            var xCentroDestino = t.x + t.w / 2;
            var pOrigemArt = alvoAbaixo
                ? { x: xCentroOrigem, y: s.y + s.h, lado: 'bottom' }
                : { x: xCentroOrigem, y: s.y, lado: 'top' };
            var pDestinoArt = alvoAbaixo
                ? { x: xCentroDestino, y: t.y, lado: 'top' }
                : { x: xCentroDestino, y: t.y + t.h, lado: 'bottom' };
            return this._rotaOrtogonalEntre(pOrigemArt, pDestinoArt);
        }

        var origemEhGateway = s.type === 'bpmn:ExclusiveGateway' ||
            s.type === 'bpmn:InclusiveGateway' ||
            s.type === 'bpmn:ParallelGateway' ||
            s.type === 'bpmn:EventBasedGateway' ||
            s.type === 'bpmn:ComplexGateway';

        if (origemEhGateway && t.x >= s.x - 8 && !flow.associacao) {
            pOrigem = this._pontoSaidaGateway(s, flow);

            // Para gateways, a entrada do alvo continua preferencialmente
            // pela esquerda quando o fluxo avança horizontalmente.
            if (t.x >= s.x) {
                pDestino = this._pontoBordaPorLado(t, 'left');
            }

            var saidaX = Math.max(pOrigem.x + CONFIG.gatewayExitLength, pOrigem.x + 12);
            var destinoY = pDestino.y;

            // Se o alvo estiver praticamente alinhado, uma linha simples.
            if (Math.abs(pOrigem.y - destinoY) < 3) {
                return [pOrigem, pDestino];
            }

            // Cada ramo recebe sua própria saída horizontal e somente depois
            // muda de direção. Isso elimina o trecho compartilhado mostrado
            // no problema original.
            return [
                pOrigem,
                { x: saidaX, y: pOrigem.y },
                { x: saidaX, y: destinoY },
                pDestino
            ];
        }

        // Retorno (destino à esquerda da origem). Em processos que só avançam,
        // este caminho é raro; mantido para diagramas importados legados.
        var ehRetorno = (t.x + t.w < s.x - 8);

        // Mudança de raia com avanço: força âncoras right→left e rota em L/Z
        var laneS = this.lanes.find(function (l) { return l.refs.indexOf(flow.sourceId) !== -1; });
        var laneT = this.lanes.find(function (l) { return l.refs.indexOf(flow.targetId) !== -1; });
        var mudaRaia = laneS && laneT && laneS !== laneT;
        if (!ehRetorno && mudaRaia) {
            pOrigem = this._pontoBordaPorLado(s, 'right');
            pDestino = this._pontoBordaPorLado(t, 'left');
            return this._rotaOrtogonalEntre(pOrigem, pDestino);
        }

        if (ehRetorno) {
            var laneOrigem = this.lanes.find(function (l) {
                return l.refs.indexOf(flow.sourceId) !== -1;
            });
            var laneDestino = this.lanes.find(function (l) {
                return l.refs.indexOf(flow.targetId) !== -1;
            });

            // Sai pela base da origem, desce a um corredor DENTRO da raia e
            // entra pela esquerda do destino. O corredor nunca extrapola a raia:
            // se faltar espaço, a raia (e o pool) expandem para caber.
            var xSaida = s.x + s.w / 2;
            var ySaida = s.y + s.h;
            pOrigem = { x: xSaida, y: ySaida, lado: 'bottom' };

            var margemCorredor = 24;
            var margemFundo = 14;
            var fundoConteudo = Math.max(s.y + s.h, t.y + t.h);
            var laneRef = laneOrigem || laneDestino;

            if (laneOrigem && laneDestino) {
                var idxOrigem = this.lanes.indexOf(laneOrigem);
                var idxDestino = this.lanes.indexOf(laneDestino);
                var minIdx = Math.min(idxOrigem, idxDestino);
                var maxIdx = Math.max(idxOrigem, idxDestino);
                fundoConteudo = -Infinity;
                for (var li = minIdx; li <= maxIdx; li++) {
                    var laneAtual = this.lanes[li];
                    laneAtual.refs.forEach(function (elId) {
                        var elRef = this.elements[elId];
                        if (elRef) fundoConteudo = Math.max(fundoConteudo, elRef.y + elRef.h);
                    }, this);
                }
                if (fundoConteudo === -Infinity) {
                    fundoConteudo = this.lanes[maxIdx].y + CONFIG.minLaneHeight * 0.6;
                }
                laneRef = this.lanes[maxIdx];
            } else if (laneRef) {
                laneRef.refs.forEach(function (elId) {
                    var elRef = this.elements[elId];
                    if (elRef) fundoConteudo = Math.max(fundoConteudo, elRef.y + elRef.h);
                }, this);
            }

            var retornosMesmoDestino = Object.keys(this.flows).filter(function (fid) {
                var f = this.flows[fid];
                var destino = this.elements[f.targetId];
                var origem = this.elements[f.sourceId];
                return destino === t && origem && (origem.x > destino.x + destino.w - 1);
            }, this).sort();

            var indiceRetorno = Math.max(0, retornosMesmoDestino.indexOf(flow.id));
            var corredorY = fundoConteudo + margemCorredor + indiceRetorno * 18;

            // Garante que o corredor fique DENTRO da raia; se precisar, expande a raia
            if (laneRef) {
                var fundoRaiaNecessario = corredorY + margemFundo;
                if (fundoRaiaNecessario > laneRef.y + laneRef.h) {
                    var idxLane = this.lanes.indexOf(laneRef);
                    var extra = fundoRaiaNecessario - (laneRef.y + laneRef.h);
                    laneRef.h += extra;
                    for (var j = idxLane + 1; j < this.lanes.length; j++) {
                        this.lanes[j].y += extra;
                        this.lanes[j].refs.forEach(function (elId) {
                            var elM = this.elements[elId];
                            if (elM) elM.y += extra;
                        }, this);
                    }
                    this._sincronizarBoundsParticipant();
                }
                // Trava o corredor no limite interno da raia (não extrapola)
                var limiteInferior = laneRef.y + laneRef.h - margemFundo;
                if (corredorY > limiteInferior) corredorY = limiteInferior;
                if (corredorY < fundoConteudo + 8) corredorY = Math.min(limiteInferior, fundoConteudo + 8);
            }

            var proporcoes = [0.5, 0.28, 0.72, 0.18, 0.82];
            var entryY = t.y + t.h * proporcoes[indiceRetorno % proporcoes.length];
            if (laneDestino) {
                entryY = Math.max(laneDestino.y + 8, Math.min(laneDestino.y + laneDestino.h - 8, entryY));
            }

            pDestino = { x: t.x, y: entryY, lado: 'left' };
            var xAproximacao = t.x - 24 - (indiceRetorno * 10);
            if (laneDestino) {
                // Mantém a aproximação dentro da raia (não invade o header do pool)
                xAproximacao = Math.max(laneDestino.x + 10, Math.min(xAproximacao, t.x - 12));
            }

            var pontosRetorno = [
                { x: xSaida, y: ySaida },
                { x: xSaida, y: corredorY },
                { x: xAproximacao, y: corredorY },
                { x: xAproximacao, y: entryY },
                { x: pDestino.x, y: entryY }
            ];

            var maiorSegmento = 0;
            var indiceMaiorSegmento = 0;
            for (var i = 0; i < pontosRetorno.length - 1; i++) {
                var dx = pontosRetorno[i + 1].x - pontosRetorno[i].x;
                var dy = pontosRetorno[i + 1].y - pontosRetorno[i].y;
                var comprimento = Math.sqrt(dx * dx + dy * dy);
                if (comprimento > maiorSegmento) {
                    maiorSegmento = comprimento;
                    indiceMaiorSegmento = i;
                }
            }
            var p1 = pontosRetorno[indiceMaiorSegmento];
            var p2 = pontosRetorno[indiceMaiorSegmento + 1];
            flow._labelPos = { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 };

            return pontosRetorno;
        }

        return this._rotaOrtogonalEntre(pOrigem, pDestino);
    };

    /**
     * Escolhe o melhor lado da borda para conectar dois elementos (estilo Manhattan bpmn-js).
     */
    Diagram.prototype._pontoBordaInteligente = function (elemento, outro) {
        var cx = elemento.x + elemento.w / 2;
        var cy = elemento.y + elemento.h / 2;
        var ox = outro.x + outro.w / 2;
        var oy = outro.y + outro.h / 2;
        var dx = ox - cx;
        var dy = oy - cy;

        // Preferência horizontal quando |dx| >= |dy| * 0.55 (fluxo LTR típico BPMN)
        var preferHorizontal = Math.abs(dx) >= Math.abs(dy) * 0.55;

        var lado, px, py;
        if (preferHorizontal) {
            if (dx >= 0) {
                lado = 'right';
                px = elemento.x + elemento.w;
                py = cy;
                if (Math.abs(dx) > 1) {
                    py = Math.max(elemento.y + 6, Math.min(elemento.y + elemento.h - 6, cy + dy * 0.15));
                }
            } else {
                lado = 'left';
                px = elemento.x;
                py = Math.max(elemento.y + 6, Math.min(elemento.y + elemento.h - 6, cy + dy * 0.15));
            }
        } else {
            if (dy >= 0) {
                lado = 'bottom';
                py = elemento.y + elemento.h;
                px = Math.max(elemento.x + 6, Math.min(elemento.x + elemento.w - 6, cx + dx * 0.15));
            } else {
                lado = 'top';
                py = elemento.y;
                px = Math.max(elemento.x + 6, Math.min(elemento.x + elemento.w - 6, cx + dx * 0.15));
            }
        }
        return { x: px, y: py, lado: lado };
    };

    Diagram.prototype._pontoBorda = function (elemento, outroElemento, pontoReferencia) {
        var cx = elemento.x + elemento.w / 2;
        var cy = elemento.y + elemento.h / 2;
        var dx = pontoReferencia.x - cx;
        var dy = pontoReferencia.y - cy;
        
        if (dx === 0 && dy === 0) dx = 1;

        var halfW = elemento.w / 2 || 1;
        var halfH = elemento.h / 2 || 1;
        var escalaX = halfW / Math.abs(dx || 1e-6);
        var escalaY = halfH / Math.abs(dy || 1e-6);

        var lado, px, py;
        
        // Escolhe o lado pela interseção do ray com o retângulo (mais estável)
        if (escalaX <= escalaY) {
            lado = dx >= 0 ? 'right' : 'left';
            px = dx >= 0 ? elemento.x + elemento.w : elemento.x;
            py = cy + dy * escalaX;
        } else {
            lado = dy >= 0 ? 'bottom' : 'top';
            py = dy >= 0 ? elemento.y + elemento.h : elemento.y;
            px = cx + dx * escalaY;
        }

        px = Math.max(elemento.x, Math.min(elemento.x + elemento.w, px));
        py = Math.max(elemento.y, Math.min(elemento.y + elemento.h, py));
        
        return { x: px, y: py, lado: lado };
    };

    // ================================================================
    // ANCORAGEM FLEXÍVEL DE CONEXÕES
    // ================================================================
    Diagram.prototype._pontoBordaMaisProximo = function (elemento, ponto) {
        var cx = elemento.x + elemento.w / 2;
        var cy = elemento.y + elemento.h / 2;
        var dx = ponto.x - cx;
        var dy = ponto.y - cy;
        if (dx === 0 && dy === 0) dx = 1;

        var halfW = elemento.w / 2 || 1;
        var halfH = elemento.h / 2 || 1;
        var escalaX = halfW / Math.abs(dx || 1e-6);
        var escalaY = halfH / Math.abs(dy || 1e-6);

        var lado, px, py;
        if (escalaX <= escalaY) {
            lado = dx >= 0 ? 'right' : 'left';
            px = dx >= 0 ? elemento.x + elemento.w : elemento.x;
            py = cy + dy * escalaX;
        } else {
            lado = dy >= 0 ? 'bottom' : 'top';
            py = dy >= 0 ? elemento.y + elemento.h : elemento.y;
            px = cx + dx * escalaY;
        }

        px = Math.max(elemento.x, Math.min(elemento.x + elemento.w, px));
        py = Math.max(elemento.y, Math.min(elemento.y + elemento.h, py));
        return { x: px, y: py, lado: lado };
    };

    Diagram.prototype._pontoNaBordaParaArraste = function (elemento, ponto) {
        var relX = elemento.w ? (ponto.x - elemento.x) / elemento.w : 0.5;
        var relY = elemento.h ? (ponto.y - elemento.y) / elemento.h : 0.5;

        var distEsquerda = Math.abs(relX - 0);
        var distDireita = Math.abs(relX - 1);
        var distTopo = Math.abs(relY - 0);
        var distBase = Math.abs(relY - 1);

        var foraX = relX < 0 || relX > 1;
        var foraY = relY < 0 || relY > 1;

        var lado;
        if (foraX && !foraY) {
            lado = relX < 0 ? 'left' : 'right';
        } else if (foraY && !foraX) {
            lado = relY < 0 ? 'top' : 'bottom';
        } else {
            var minDist = Math.min(distEsquerda, distDireita, distTopo, distBase);
            if (minDist === distEsquerda) lado = 'left';
            else if (minDist === distDireita) lado = 'right';
            else if (minDist === distTopo) lado = 'top';
            else lado = 'bottom';
        }

        var t = (lado === 'left' || lado === 'right') ? relY : relX;
        t = Math.max(0.06, Math.min(0.94, t));

        var px, py;
        if (lado === 'left') { px = elemento.x; py = elemento.y + elemento.h * t; }
        else if (lado === 'right') { px = elemento.x + elemento.w; py = elemento.y + elemento.h * t; }
        else if (lado === 'top') { px = elemento.x + elemento.w * t; py = elemento.y; }
        else { px = elemento.x + elemento.w * t; py = elemento.y + elemento.h; }

        return { x: px, y: py, lado: lado };
    };

    /**
     * Retorna um ponto exatamente no lado solicitado do elemento.
     * Mantém a ancoragem estável para conexões ortogonais e evita que o
     * roteador escolha topo/base quando o fluxo deve entrar pela esquerda
     * (especialmente importante para atividades após um gateway).
     */
    Diagram.prototype._pontoBordaPorLado = function (elemento, lado) {
        if (!elemento) return { x: 0, y: 0, lado: lado || 'right' };

        var margem = 0;
        var cx = elemento.x + elemento.w / 2;
        var cy = elemento.y + elemento.h / 2;

        switch (String(lado || '').toLowerCase()) {
            case 'left':
                return {
                    x: elemento.x - margem,
                    y: cy,
                    lado: 'left'
                };
            case 'right':
                return {
                    x: elemento.x + elemento.w + margem,
                    y: cy,
                    lado: 'right'
                };
            case 'top':
                return {
                    x: cx,
                    y: elemento.y - margem,
                    lado: 'top'
                };
            case 'bottom':
                return {
                    x: cx,
                    y: elemento.y + elemento.h + margem,
                    lado: 'bottom'
                };
            default:
                return {
                    x: elemento.x + elemento.w,
                    y: cy,
                    lado: 'right'
                };
        }
    };

    Diagram.prototype._rotaOrtogonalEntre = function (pOrigem, pDestino) {
        // Conectores sempre em ângulos de 90° (Manhattan / L / Z).
        if (Math.abs(pOrigem.x - pDestino.x) < 2 && Math.abs(pOrigem.y - pDestino.y) < 2) {
            return [pOrigem, pDestino];
        }
        // Mesma linha horizontal ou vertical: segmento único
        if (Math.abs(pOrigem.y - pDestino.y) < 2 || Math.abs(pOrigem.x - pDestino.x) < 2) {
            return [pOrigem, pDestino];
        }

        var origemH = pOrigem.lado === 'left' || pOrigem.lado === 'right' || !pOrigem.lado;
        var destinoH = pDestino.lado === 'left' || pDestino.lado === 'right' || !pDestino.lado;

        // Preferência: saída pela direita → meio → entrada pela esquerda (fluxo à frente)
        if (pOrigem.lado === 'right' || (origemH && pDestino.x >= pOrigem.x)) {
            var midX = pOrigem.x + (pDestino.x - pOrigem.x) / 2;
            if (pDestino.x > pOrigem.x) {
                midX = Math.max(pOrigem.x + 16, Math.min(pDestino.x - 16, midX));
            } else {
                // destino à esquerda: ainda assim L ortogonal (mudança de raia)
                midX = pOrigem.x + 24;
            }
            return [
                pOrigem,
                { x: midX, y: pOrigem.y },
                { x: midX, y: pDestino.y },
                pDestino
            ];
        }

        // Ambos verticais: V-H-V
        if (!origemH && !destinoH) {
            var midY = pOrigem.y + (pDestino.y - pOrigem.y) / 2;
            return [
                pOrigem,
                { x: pOrigem.x, y: midY },
                { x: pDestino.x, y: midY },
                pDestino
            ];
        }

        // Misto: L (dois segmentos)
        if (origemH) {
            return [
                pOrigem,
                { x: pDestino.x, y: pOrigem.y },
                pDestino
            ];
        }
        return [
            pOrigem,
            { x: pOrigem.x, y: pDestino.y },
            pDestino
        ];
    };

    // ================================================================
    // RENDERIZAÇÃO
    // ================================================================
    Diagram.prototype._render = function () {
        // Antes de desenhar, garante que a área visível (viewBox) acompanha
        // o conteúdo atual. Sem isso, a raia crescia no modelo de dados
        // (ver _ajustarRaiaParaConteudo) mas a borda direita só "aparecia"
        // de fato depois de um ajuste manual de zoom, pois o SVG recorta
        // tudo que fica fora do viewBox atual.
        this._garantirViewportContemConteudo();

        // Renderização segura: primeiro reconstruímos as formas e somente
        // depois os conectores. Um erro isolado no rótulo de um fluxo (por
        // exemplo, SIM/NÃO) não pode apagar todas as formas do diagrama.
        try {
            if (this.gLanes) this.gLanes.innerHTML = '';
            if (this.gShapes) this.gShapes.innerHTML = '';
            if (this.gConnections) {
                var connectionLine = this.gConnections.querySelector('.vmap-connection-line');
                this.gConnections.innerHTML = '';
                if (connectionLine) {
                    this.gConnections.appendChild(connectionLine);
                    this._connectionLine = connectionLine;
                }
            }

            this._renderLanes();
            this._renderElementos();
            try {
                this._renderConexoes();
            } catch (errConexoes) {
                console.error('[VMAP] Erro ao renderizar conexões:', errConexoes);
            }
            this._renderSelecao();
            if (this._atualizarZoomLabel) this._atualizarZoomLabel();
        } catch (err) {
            console.error('[VMAP] Erro ao renderizar diagrama:', err);
        }
    };

    Diagram.prototype._renderLanes = function () {
        var self = this;

        // Garante que o pool (nome do processo) acompanhe o tamanho atual das raias
        this._sincronizarBoundsParticipant();

        var listaPools = (this.participants && this.participants.length)
            ? this.participants
            : (this.participant ? [this.participant] : []);

        listaPools.forEach(function(pInfo) {
            var box = (pInfo && pInfo.bounds) ? pInfo.bounds : null;
            if (!box || !(box.w > 0 && box.h > 0)) {
                box = self._bboxParticipant();
            }
            if (!box || !(box.w > 0 && box.h > 0)) return;

            var g = el('g', {
                class: 'djs-shape participant',
                'data-element-id': pInfo.id,
                'data-element-kind': 'participant'
            }, self.gLanes);
            el('rect', {
                x: box.x, y: box.y, width: box.w, height: box.h,
                fill: '#ffffff', stroke: '#44546A', 'stroke-width': 1.5, rx: 4
            }, g);

            var label = pInfo.name || self.processName || 'Processo';
            var nome = el('text', {
                x: box.x + 8,
                y: box.y + box.h / 2,
                'font-size': 12,
                'font-weight': 600,
                fill: '#212529',
                'text-anchor': 'middle',
                'dominant-baseline': 'central',
                'transform': 'rotate(-90, ' + (box.x + 8) + ', ' + (box.y + box.h / 2) + ')'
            }, g);
            nome.textContent = label;
        });

        this.lanes.forEach(function(lane) {
            var g = el('g', { class: 'djs-shape lane', 'data-element-id': lane.id, 'data-element-kind': 'lane' }, self.gLanes);
            var cor = CORES['bpmn:Lane'];
            var selecionada = self.selectedIds.indexOf(lane.id) !== -1;
            
            el('rect', {
                x: lane.x, y: lane.y, width: lane.w, height: lane.h,
                fill: cor.fill, stroke: selecionada ? '#0a6fc2' : cor.stroke,
                'stroke-width': selecionada ? 2.5 : 1,
                rx: 2
            }, g);

            // NOME DA RAIA NA VERTICAL (rotacionado -90°)
            var nome = el('text', {
                x: lane.x + 8, 
                y: lane.y + lane.h / 2,
                'font-size': 11, 
                fill: '#2E4C6D',
                'text-anchor': 'middle',
                'dominant-baseline': 'central',
                'transform': 'rotate(-90, ' + (lane.x + 8) + ', ' + (lane.y + lane.h/2) + ')'
            }, g);
            nome.textContent = lane.name || '';

            var gripY = lane.y + lane.h - 8;
            var gripX = lane.x + lane.w / 2;
            
            var gripGroup = el('g', {
                transform: 'translate(' + gripX + ',' + gripY + ')',
                style: 'cursor:row-resize; opacity:0.6;'
            }, g);
            
            el('rect', {
                x: -20, y: -6, width: 40, height: 12,
                fill: '#e9ecef', rx: 4, stroke: '#ced4da', 'stroke-width': 1
            }, gripGroup);
            
            el('line', {
                x1: -12, y1: 0, x2: 12, y2: 0,
                stroke: '#6c757d', 'stroke-width': 1.5, 'stroke-linecap': 'round'
            }, gripGroup);
            
            el('polygon', {
                points: '-4,-4 0,-7 4,-4',
                fill: '#6c757d', stroke: 'none'
            }, gripGroup);
            
            el('polygon', {
                points: '-4,4 0,7 4,4',
                fill: '#6c757d', stroke: 'none'
            }, gripGroup);

            el('rect', {
                x: -25, y: -12, width: 50, height: 24,
                fill: 'transparent', 'pointer-events': 'all'
            }, gripGroup);

            gripGroup.addEventListener('mouseenter', function() {
                this.setAttribute('opacity', '1');
                this.querySelector('rect').setAttribute('fill', '#dee2e6');
            });
            gripGroup.addEventListener('mouseleave', function() {
                this.setAttribute('opacity', '0.6');
                this.querySelector('rect').setAttribute('fill', '#e9ecef');
            });

            var dragging = false;
            var startY, startHeight, laneOriginal;
            
            gripGroup.addEventListener('mousedown', function (ev) {
                ev.stopPropagation();
                ev.preventDefault();
                dragging = true;
                startY = ev.clientY;
                laneOriginal = self.lanes.find(function(l) { return l.id === lane.id; });
                startHeight = laneOriginal ? laneOriginal.h : lane.h;
                self._expandindoRaia = lane.id;
                
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });

            function onMouseMove(ev) {
                if (!dragging || !laneOriginal) return;
                var deltaY = (ev.clientY - startY) / self.scale;
                var minH = self._alturaMinimaRaia(laneOriginal);
                var novaAltura = Math.max(minH, startHeight + deltaY);
                var diferenca = novaAltura - laneOriginal.h;
                
                if (Math.abs(diferenca) > 0.5) {
                    laneOriginal.h = novaAltura;
                    
                    var achou = false;
                    self.lanes.forEach(function(l) {
                        if (l.id === laneOriginal.id) { achou = true; return; }
                        if (achou) {
                            l.y += diferenca;
                            l.refs.forEach(function(elId) {
                                var elemento = self.elements[elId];
                                if (elemento) elemento.y += diferenca;
                            });
                        }
                    });
                    // Limpa waypoints para reconectar após expansão da raia
                    Object.keys(self.flows).forEach(function (fid) {
                        self.flows[fid].waypoints = [];
                        delete self.flows[fid]._labelPos;
                    });
                    self._render();
                }
            }

            function onMouseUp() {
                dragging = false;
                self._expandindoRaia = null;
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
            }

            var btnX = lane.x + lane.w - 16;
            var btnY = lane.y + 4;
            var btn = el('g', {
                class: 'lane-delete',
                transform: 'translate(' + btnX + ',' + btnY + ')',
                style: 'cursor:pointer;opacity:0.3;'
            }, g);
            el('circle', { cx: 6, cy: 6, r: 6, fill: '#fff', stroke: '#dc3545', 'stroke-width': 1 }, btn);
            el('text', { x: 6, y: 9, 'text-anchor': 'middle', 'font-size': 10, fill: '#dc3545' }, btn).textContent = '×';
            
            btn.addEventListener('mouseenter', function() { this.setAttribute('opacity', '1'); });
            btn.addEventListener('mouseleave', function() { this.setAttribute('opacity', '0.3'); });
            btn.addEventListener('click', function(ev) {
                ev.stopPropagation();
                if (confirm('Excluir esta raia?')) {
                    self._excluirRaia(lane.id);
                }
            });
        });
    };

    // ================================================================
    // RENDERIZAÇÃO DOS ELEMENTOS
    // ================================================================

    // ================================================================
    // MARCADORES DE EVENTO / TIPOS DE ATIVIDADE / BANDEIRA DE RISCO (mesma paleta de cores da biblioteca)
    // ================================================================
    var DEF_TAG = { message: 'messageEventDefinition', timer: 'timerEventDefinition', conditional: 'conditionalEventDefinition', signal: 'signalEventDefinition', link: 'linkEventDefinition', escalation: 'escalationEventDefinition', error: 'errorEventDefinition', cancel: 'cancelEventDefinition', compensation: 'compensateEventDefinition', terminate: 'terminateEventDefinition' };
    var TAG_DEF = {}; Object.keys(DEF_TAG).forEach(function (k) { TAG_DEF[DEF_TAG[k]] = k; });

    Diagram.prototype._marcadorEvento = function (g, eo, cor, cheio) {
        var def = eo.def; if (!def) return;
        var k = eo.w / 36, c = eo.w / 2, f = cheio ? cor : 'none', sw = 1.4;
        function P(x, y) { return (c + x * k).toFixed(1) + ',' + (c + y * k).toFixed(1); }
        switch (def) {
            case 'message':
                el('rect', { x: c - 7 * k, y: c - 5 * k, width: 14 * k, height: 10 * k, rx: 1, fill: f, stroke: cor, 'stroke-width': sw }, g);
                el('polyline', { points: P(-7, -5) + ' ' + P(0, 1) + ' ' + P(7, -5), fill: 'none', stroke: cheio ? '#fff' : cor, 'stroke-width': sw }, g); break;
            case 'timer':
                el('circle', { cx: c, cy: c, r: 8 * k, fill: 'none', stroke: cor, 'stroke-width': sw }, g);
                el('line', { x1: c, y1: c, x2: c, y2: c - 6 * k, stroke: cor, 'stroke-width': sw, 'stroke-linecap': 'round' }, g);
                el('line', { x1: c, y1: c, x2: c + 4 * k, y2: c + 2 * k, stroke: cor, 'stroke-width': sw, 'stroke-linecap': 'round' }, g); break;
            case 'conditional':
                el('rect', { x: c - 6 * k, y: c - 7 * k, width: 12 * k, height: 14 * k, fill: 'none', stroke: cor, 'stroke-width': sw }, g);
                [-3.5, 0, 3.5].forEach(function (y) { el('line', { x1: c - 4 * k, y1: c + y * k, x2: c + 4 * k, y2: c + y * k, stroke: cor, 'stroke-width': 1 }, g); }); break;
            case 'signal':
                el('polygon', { points: P(0, -7) + ' ' + P(7, 6) + ' ' + P(-7, 6), fill: f, stroke: cor, 'stroke-width': sw, 'stroke-linejoin': 'round' }, g); break;
            case 'link':
                el('polygon', { points: P(-7, -3) + ' ' + P(0, -3) + ' ' + P(0, -7) + ' ' + P(8, 0) + ' ' + P(0, 7) + ' ' + P(0, 3) + ' ' + P(-7, 3), fill: f, stroke: cor, 'stroke-width': sw, 'stroke-linejoin': 'round' }, g); break;
            case 'escalation':
                el('polygon', { points: P(0, -8) + ' ' + P(6, 7) + ' ' + P(0, 3) + ' ' + P(-6, 7), fill: f, stroke: cor, 'stroke-width': sw, 'stroke-linejoin': 'round' }, g); break;
            case 'error':
                el('polygon', { points: P(-7, 7) + ' ' + P(-3.5, -4) + ' ' + P(0, 3) + ' ' + P(3.5, -7) + ' ' + P(7, 4) + ' ' + P(3, -1) + ' ' + P(0, 7) + ' ' + P(-3.5, 1), fill: f, stroke: cor, 'stroke-width': 1.2, 'stroke-linejoin': 'round' }, g); break;
            case 'cancel':
                el('path', { d: 'M' + P(-6, -6) + ' L' + P(6, 6) + ' M' + P(6, -6) + ' L' + P(-6, 6), stroke: cor, 'stroke-width': cheio ? 3.2 : 2, 'stroke-linecap': 'round', fill: 'none' }, g); break;
            case 'compensation':
                el('polygon', { points: P(-1, 0) + ' ' + P(-8, -5) + ' ' + P(-8, 5), fill: f, stroke: cor, 'stroke-width': sw, 'stroke-linejoin': 'round' }, g);
                el('polygon', { points: P(8, 0) + ' ' + P(0, -5) + ' ' + P(0, 5), fill: f, stroke: cor, 'stroke-width': sw, 'stroke-linejoin': 'round' }, g); break;
            case 'terminate':
                el('circle', { cx: c, cy: c, r: 8.5 * k, fill: cor, stroke: cor, 'stroke-width': 1 }, g); break;
        }
    };

    /** Ícone do tipo de atividade (canto superior esquerdo) e acabamentos de call activity / transação / ad-hoc. */
    Diagram.prototype._decorarAtividade = function (g, eo, cor) {
        var x = 6, y = 5, t = eo.type;
        function L(x1, y1, x2, y2, w) { el('line', { x1: x1, y1: y1, x2: x2, y2: y2, stroke: cor, 'stroke-width': w || 1.3, 'stroke-linecap': 'round' }, g); }
        if (t === 'bpmn:UserTask') {
            el('circle', { cx: x + 6, cy: y + 4, r: 3, fill: '#fff', stroke: cor, 'stroke-width': 1.2 }, g);
            el('path', { d: 'M' + (x) + ',' + (y + 13) + ' q0,-5 6,-5 q6,0 6,5 z', fill: '#fff', stroke: cor, 'stroke-width': 1.2 }, g);
        } else if (t === 'bpmn:ServiceTask') {
            el('circle', { cx: x + 6, cy: y + 6, r: 3.2, fill: '#fff', stroke: cor, 'stroke-width': 1.3 }, g);
            for (var a = 0; a < 8; a++) { var r = a * Math.PI / 4; L(x + 6 + Math.cos(r) * 4.2, y + 6 + Math.sin(r) * 4.2, x + 6 + Math.cos(r) * 6.2, y + 6 + Math.sin(r) * 6.2, 2); }
        } else if (t === 'bpmn:ScriptTask') {
            el('path', { d: 'M' + (x + 3) + ',' + y + ' h9 v13 h-9 q3,-3 0,-6.5 q-3,-3.5 0,-6.5 z', fill: '#fff', stroke: cor, 'stroke-width': 1.1 }, g);
            L(x + 4, y + 4, x + 10, y + 4, 1); L(x + 4, y + 7, x + 10, y + 7, 1); L(x + 4, y + 10, x + 8, y + 10, 1);
        } else if (t === 'bpmn:ManualTask') {
            el('path', { d: 'M' + x + ',' + (y + 6) + ' h7 l3,-2 q2,0 1,2 l-3,2 h2 q2,0 1,2 l-4,1 h-4 l-4,-1 z', fill: '#fff', stroke: cor, 'stroke-width': 1.1, 'stroke-linejoin': 'round' }, g);
        } else if (t === 'bpmn:BusinessRuleTask') {
            el('rect', { x: x, y: y, width: 14, height: 12, fill: '#fff', stroke: cor, 'stroke-width': 1.1 }, g);
            el('rect', { x: x, y: y, width: 14, height: 3.5, fill: cor, opacity: .55 }, g); L(x, y + 7, x + 14, y + 7, 1); L(x + 5, y + 3.5, x + 5, y + 12, 1);
        } else if (t === 'bpmn:SendTask' || t === 'bpmn:ReceiveTask') {
            var cheio = t === 'bpmn:SendTask';
            el('rect', { x: x, y: y + 1, width: 14, height: 10, rx: 1, fill: cheio ? cor : '#fff', stroke: cor, 'stroke-width': 1.1 }, g);
            el('polyline', { points: x + ',' + (y + 1) + ' ' + (x + 7) + ',' + (y + 7) + ' ' + (x + 14) + ',' + (y + 1), fill: 'none', stroke: cheio ? '#fff' : cor, 'stroke-width': 1.1 }, g);
        } else if (t === 'bpmn:CallActivity') {
            el('rect', { x: 0, y: 0, width: eo.w, height: eo.h, rx: 6, fill: 'none', stroke: cor, 'stroke-width': 3.4 }, g);
            el('rect', { x: eo.w / 2 - 8, y: eo.h - 18, width: 16, height: 16, fill: '#fff', stroke: cor, 'stroke-width': 1, rx: 2 }, g);
            L(eo.w / 2 - 4, eo.h - 10, eo.w / 2 + 4, eo.h - 10, 1.5); L(eo.w / 2, eo.h - 14, eo.w / 2, eo.h - 6, 1.5);
        } else if (t === 'bpmn:Transaction') {
            el('rect', { x: 3.5, y: 3.5, width: eo.w - 7, height: eo.h - 7, rx: 4, fill: 'none', stroke: cor, 'stroke-width': 1.2 }, g);
        } else if (t === 'bpmn:AdHocSubProcess') {
            el('rect', { x: 3, y: 3, width: eo.w - 6, height: eo.h - 6, rx: 4, fill: 'none', stroke: cor, 'stroke-width': 1, 'stroke-dasharray': '2,2' }, g);
            el('path', { d: 'M' + (eo.w / 2 - 8) + ',' + (eo.h - 10) + ' q2,-4 4,0 t4,0 t4,0 t4,0', fill: 'none', stroke: cor, 'stroke-width': 1.5, 'stroke-linecap': 'round' }, g);
        }
    };

    /** Bandeira de risco vermelha, presa ao canto superior direito do elemento. */
    Diagram.prototype._desenharBandeira = function (g, eo, info) {
        var self = this, id = eo.id, bx = eo.w - 4, by = -26;
        var fg = el('g', { class: 'vmap-flag', 'data-flag-element': id, transform: 'translate(' + bx + ',' + by + ')', style: 'cursor:pointer' }, g);
        el('title', {}, fg).textContent = (info && info.titulo) || 'Risco(s) desta atividade — clique para abrir';
        el('rect', { x: -4, y: -2, width: 30, height: 32, fill: 'transparent' }, fg);
        el('line', { x1: 2, y1: 2, x2: 2, y2: 28, stroke: '#7a1010', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, fg);
        el('path', { d: 'M3,3 C8,0 12,6 19,3 L19,15 C12,18 8,12 3,15 Z', fill: '#dc3545', stroke: '#8b0000', 'stroke-width': 1.3, 'stroke-linejoin': 'round' }, fg);
        el('circle', { cx: 2, cy: 28, r: 2.2, fill: '#7a1010' }, fg);
        var n = (info && info.n) || 0;
        if (n > 0) {
            var b = el('g', { transform: 'translate(20,-1)' }, fg);
            el('circle', { cx: 0, cy: 0, r: 7, fill: '#33404d', stroke: '#fff', 'stroke-width': 1.2 }, b);
            el('text', { x: 0, y: 3, 'text-anchor': 'middle', 'font-size': n > 9 ? 7.5 : 9, 'font-weight': 700, fill: '#fff' }, b).textContent = n > 9 ? '9+' : String(n);
        }
        fg.addEventListener('mousedown', function (ev) { ev.stopPropagation(); });
        fg.addEventListener('click', function (ev) { ev.stopPropagation(); self.events.fire('flag.click', { elementId: id }); });
    };

    /** O hospedeiro informa, por elemento, quantos riscos há: {idDoElemento: {n, titulo}}. */
    Diagram.prototype.setFlags = function (mapa) { this._flags = mapa || {}; this._render(); };

    Diagram.prototype._renderElementos = function () {
        var self = this;
        Object.keys(this.elements).forEach(function(id) {
            var eo = self.elements[id];
            var cor = CORES[eo.type] || CORES['bpmn:Task'];
            var selecionado = self.selectedIds.indexOf(id) !== -1;
            var hover = self.hoveredId === id;

            var g = el('g', {
                class: 'djs-shape',
                'data-element-id': id,
                'data-element-kind': 'shape',
                transform: 'translate(' + eo.x + ',' + eo.y + ')'
            }, self.gShapes);

            var strokeColor = selecionado ? '#0a6fc2' : (hover ? '#0a6fc2' : cor.stroke);
            var strokeWidth = selecionado ? 2.5 : (hover ? 2 : 1.5);

            if (eo.type === 'bpmn:StartEvent') {
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 2,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                self._marcadorEvento(g, eo, strokeColor, false);
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:EndEvent') {
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 2,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 6,
                    fill: 'none', stroke: strokeColor, 'stroke-width': eo.def ? 1 : 2.5
                }, g);
                self._marcadorEvento(g, eo, strokeColor, true);
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:IntermediateThrowEvent' || eo.type === 'bpmn:IntermediateCatchEvent') {
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 2,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 5,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1.5
                }, g);
                self._marcadorEvento(g, eo, strokeColor, eo.type === 'bpmn:IntermediateThrowEvent');
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:TimerEvent') {
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 2,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 5,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1.5
                }, g);
                var tc = eo.w/2, tr = eo.w/2 - 10;
                el('line', {
                    x1: tc, y1: tc, x2: tc, y2: tc - tr,
                    stroke: strokeColor, 'stroke-width': 1.5, 'stroke-linecap': 'round'
                }, g);
                el('line', {
                    x1: tc, y1: tc, x2: tc + tr * 0.6, y2: tc,
                    stroke: strokeColor, 'stroke-width': 1.5, 'stroke-linecap': 'round'
                }, g);
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:MessageEvent') {
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 2,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('circle', {
                    cx: eo.w/2, cy: eo.h/2, r: eo.w/2 - 5,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1.5
                }, g);
                var ex = eo.w * 0.25, ey = eo.h * 0.3, ew = eo.w * 0.5, eh = eo.h * 0.4;
                el('rect', {
                    x: ex, y: ey, width: ew, height: eh,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1.2, rx: 1
                }, g);
                el('polyline', {
                    points: ex + ',' + ey + ' ' + (ex + ew/2) + ',' + (ey + eh * 0.6) + ' ' + (ex + ew) + ',' + ey,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1.2
                }, g);
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type.indexOf('Gateway') !== -1) {
                var points = (eo.w/2) + ',0 ' + eo.w + ',' + (eo.h/2) + ' ' + 
                    (eo.w/2) + ',' + eo.h + ' 0,' + (eo.h/2);
                el('polygon', {
                    points: points,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                
                if (eo.type === 'bpmn:ParallelGateway') {
                    var cx = eo.w/2, cy = eo.h/2, br = eo.w * 0.2;
                    el('line', {
                        x1: cx, y1: cy - br, x2: cx, y2: cy + br,
                        stroke: strokeColor, 'stroke-width': 2
                    }, g);
                    el('line', {
                        x1: cx - br, y1: cy, x2: cx + br, y2: cy,
                        stroke: strokeColor, 'stroke-width': 2
                    }, g);
                } else if (eo.type === 'bpmn:InclusiveGateway') {
                    el('circle', {
                        cx: eo.w/2, cy: eo.h/2, r: eo.w * 0.18,
                        fill: 'none', stroke: strokeColor, 'stroke-width': 2
                    }, g);
                } else if (eo.type === 'bpmn:ComplexGateway') {
                    var cx2 = eo.w/2, cy2 = eo.h/2, br2 = eo.w * 0.2;
                    el('path', { d: 'M' + cx2 + ',' + (cy2 - br2) + ' L' + cx2 + ',' + (cy2 + br2) + ' M' + (cx2 - br2) + ',' + cy2 + ' L' + (cx2 + br2) + ',' + cy2 + ' M' + (cx2 - br2 * .72) + ',' + (cy2 - br2 * .72) + ' L' + (cx2 + br2 * .72) + ',' + (cy2 + br2 * .72) + ' M' + (cx2 + br2 * .72) + ',' + (cy2 - br2 * .72) + ' L' + (cx2 - br2 * .72) + ',' + (cy2 + br2 * .72), stroke: strokeColor, 'stroke-width': 2, 'stroke-linecap': 'round', fill: 'none' }, g);
                } else if (eo.type === 'bpmn:EventBasedGateway') {
                    el('circle', {
                        cx: eo.w/2, cy: eo.h/2, r: eo.w * 0.15,
                        fill: strokeColor, stroke: strokeColor, 'stroke-width': 1
                    }, g);
                }
                
                if (eo.type.indexOf('Gateway') !== -1 && eo.name) {
                    el('text', {
                        x: eo.w/2, y: -6,
                        'text-anchor': 'middle', 'font-size': 10,
                        'font-weight': 600, fill: '#8a6d00'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:SubProcess') {
                el('rect', {
                    x: 0, y: 0, width: eo.w, height: eo.h, rx: 6,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('rect', {
                    x: 3, y: 3, width: eo.w - 6, height: eo.h - 6, rx: 4,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1, 'stroke-dasharray': '2,2'
                }, g);
                el('rect', {
                    x: eo.w/2 - 8, y: eo.h - 18, width: 16, height: 16,
                    fill: '#fff', stroke: strokeColor, 'stroke-width': 1, rx: 2
                }, g);
                el('line', {
                    x1: eo.w/2 - 4, y1: eo.h - 10, x2: eo.w/2 + 4, y2: eo.h - 10,
                    stroke: strokeColor, 'stroke-width': 1.5
                }, g);
                el('line', {
                    x1: eo.w/2, y1: eo.h - 14, x2: eo.w/2, y2: eo.h - 6,
                    stroke: strokeColor, 'stroke-width': 1.5
                }, g);
                if (eo.name) {
                    var linhas = self._quebrarTexto(eo.name, 14);
                    var baseY = (eo.h / 2) - ((linhas.length - 1) * 7) - 10;
                    linhas.forEach(function(linha, i) {
                        el('text', {
                            x: eo.w/2, y: baseY + i * 14,
                            'text-anchor': 'middle', 'font-size': 10,
                            'font-weight': 500, fill: '#212529'
                        }, g).textContent = linha;
                    });
                }
            } else if (eo.type === 'bpmn:TextAnnotation') {
                el('rect', {
                    x: 0, y: 0, width: eo.w, height: eo.h, rx: 4,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth,
                    'stroke-dasharray': '3,2'
                }, g);
                var dobra = 10;
                el('line', {
                    x1: eo.w - dobra, y1: 0, x2: eo.w - dobra, y2: dobra,
                    stroke: strokeColor, 'stroke-width': 1
                }, g);
                el('line', {
                    x1: eo.w - dobra, y1: dobra, x2: eo.w, y2: dobra,
                    stroke: strokeColor, 'stroke-width': 1
                }, g);
                if (eo.name) {
                    var linhas = self._quebrarTexto(eo.name, 16);
                    var baseY = (eo.h / 2) - ((linhas.length - 1) * 7);
                    linhas.forEach(function(linha, i) {
                        el('text', {
                            x: eo.w/2, y: baseY + i * 14,
                            'text-anchor': 'middle', 'font-size': 10,
                            'font-weight': 400, fill: '#212529'
                        }, g).textContent = linha;
                    });
                }
            } else if (eo.type === 'bpmn:DataObject') {
                var dobra = eo.w * 0.3;
                el('path', {
                    d: 'M0,0 L' + (eo.w - dobra) + ',0 L' + eo.w + ',' + dobra + 
                       ' L' + eo.w + ',' + eo.h + ' L0,' + eo.h + ' Z',
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('path', {
                    d: 'M' + (eo.w - dobra) + ',0 L' + (eo.w - dobra) + ',' + dobra + 
                       ' L' + eo.w + ',' + dobra,
                    fill: 'none', stroke: strokeColor, 'stroke-width': 1
                }, g);
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:DataStore') {
                el('path', {
                    d: 'M0,' + (eo.h/2) + ' C0,' + (eo.h*0.1) + ' ' + eo.w + ',' + (eo.h*0.1) + 
                       ' ' + eo.w + ',' + (eo.h/2) + ' C' + eo.w + ',' + (eo.h*0.9) + ' 0,' + 
                       (eo.h*0.9) + ' 0,' + (eo.h/2) + ' Z',
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                el('line', {
                    x1: eo.w * 0.15, y1: eo.h * 0.3, x2: eo.w * 0.85, y2: eo.h * 0.3,
                    stroke: strokeColor, 'stroke-width': 1
                }, g);
                el('line', {
                    x1: eo.w * 0.15, y1: eo.h * 0.5, x2: eo.w * 0.85, y2: eo.h * 0.5,
                    stroke: strokeColor, 'stroke-width': 1
                }, g);
                if (eo.name) {
                    el('text', {
                        x: eo.w/2, y: eo.h + 14,
                        'text-anchor': 'middle', 'font-size': 9,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else if (eo.type === 'bpmn:Group') {
                el('rect', {
                    x: 0, y: 0, width: eo.w, height: eo.h, rx: 8,
                    fill: 'none', stroke: strokeColor, 'stroke-width': strokeWidth,
                    'stroke-dasharray': '6,4'
                }, g);
                if (eo.name) {
                    el('text', {
                        x: 8, y: 16, 'font-size': 10,
                        'font-weight': 500, fill: '#6c757d'
                    }, g).textContent = eo.name;
                }
            } else {
                el('rect', {
                    x: 0, y: 0, width: eo.w, height: eo.h, rx: 6,
                    fill: cor.fill, stroke: strokeColor, 'stroke-width': strokeWidth
                }, g);
                self._decorarAtividade(g, eo, strokeColor);

                // Número sequencial da tarefa no canto superior direito
                if (typeof eo.numero === 'number' && eo.numero > 0) {
                    var numStr = String(eo.numero);
                    var badgeR = 9;
                    var badgeCx = eo.w - badgeR - 3;
                    var badgeCy = badgeR + 3;
                    el('circle', {
                        cx: badgeCx, cy: badgeCy, r: badgeR,
                        fill: '#2E74B5', stroke: '#1a4f7a', 'stroke-width': 1
                    }, g);
                    el('text', {
                        x: badgeCx, y: badgeCy + 3.5,
                        'text-anchor': 'middle', 'font-size': numStr.length > 2 ? 8 : 10,
                        'font-weight': 700, fill: '#ffffff'
                    }, g).textContent = numStr;
                }

                if (eo.name) {
                    // Texto com fonte adaptativa: mais caracteres e fonte
                    // diminuindo para caber todo o nome dentro da tarefa.
                    var fit = self._ajustarTextoTarefa(eo.name, eo.w - 12, eo.h - 20);
                    var baseY = (eo.h / 2) - ((fit.linhas.length - 1) * (fit.fontSize * 0.95) / 2);
                    fit.linhas.forEach(function(linha, i) {
                        el('text', {
                            x: eo.w/2, y: baseY + i * (fit.fontSize * 1.15),
                            'text-anchor': 'middle', 'font-size': fit.fontSize,
                            'font-weight': 500, fill: '#212529'
                        }, g).textContent = linha;
                    });
                }
            }

            // Badge do número da tarefa de retorno (mensagem/documento do ramo Não)
            if (typeof eo.retornoNumero === 'number' && eo.retornoNumero > 0) {
                var retStr = String(eo.retornoNumero);
                var retR = 9;
                var retCx = eo.w - retR - 2;
                var retCy = retR + 2;
                el('circle', {
                    cx: retCx, cy: retCy, r: retR,
                    fill: '#c55a11', stroke: '#8a3d0a', 'stroke-width': 1
                }, g);
                el('text', {
                    x: retCx, y: retCy + 3.5,
                    'text-anchor': 'middle', 'font-size': retStr.length > 2 ? 8 : 10,
                    'font-weight': 700, fill: '#ffffff'
                }, g).textContent = retStr;
            }

            if (self._flags && self._flags[id]) self._desenharBandeira(g, eo, self._flags[id]);

            if (selecionado) {
                self._desenharHaloSelecao(g, eo.w, eo.h);
            }
        });
    };

    Diagram.prototype._renderConexoes = function () {
        var self = this;
        Object.keys(this.flows).forEach(function(id) {
            var f = self.flows[id];
            var pontos = self._rotaConexao(f);
            if (pontos.length < 2) return;
            
            var selecionado = self.selectedIds.indexOf(id) !== -1;
            var g = el('g', {
                class: 'djs-connection',
                'data-element-id': id,
                'data-element-kind': 'connection'
            }, self.gConnections);

            var d = 'M ' + pontos.map(function(p) { return p.x + ' ' + p.y; }).join(' L ');
            
            var strokeColor = selecionado ? '#0a6fc2' : '#5a6b7d';
            var strokeWidth = selecionado ? 2.5 : 1.5;
            
            var attrs = {
                d: d, fill: 'none', stroke: strokeColor, 'stroke-width': strokeWidth
            };
            
            // VERIFICA SE A CONEXÃO ENVOLVE START/END EVENT
            var source = self.elements[f.sourceId];
            var target = self.elements[f.targetId];
            var isStartEndConnection = source && target && 
                (source.type === 'bpmn:StartEvent' || source.type === 'bpmn:EndEvent' ||
                 target.type === 'bpmn:StartEvent' || target.type === 'bpmn:EndEvent');
            
            if (f.associacao || f.tipo === 'association') {
                attrs['stroke-dasharray'] = '4,3';
            } else if (f.tipo === 'eventoArtefato' && !isStartEndConnection) {
                // Só usa pontilhado se NÃO for Start/End Event
                attrs['stroke-dasharray'] = '5,4';
                attrs['marker-end'] = 'url(#vmap-arrow' + (selecionado ? '-selected' : '') + ')';
            } else {
                attrs['marker-end'] = 'url(#vmap-arrow' + (selecionado ? '-selected' : '') + ')';
            }
            
            el('path', attrs, g);
            
            el('path', {
                d: d, fill: 'none', stroke: 'transparent', 'stroke-width': 12
            }, g);

            // RENDERIZA O LABEL DA CONEXÃO
            var labelText = String(f.name == null ? '' : f.name).trim();
            if (labelText) {
                var labelPos;
                
                if (f._labelPos) {
                    labelPos = f._labelPos;
                } else {
                    // Encontra o segmento mais longo para colocar o label
                    var maiorComprimento = 0;
                    var melhorIdx = 0;
                    for (var i = 0; i < pontos.length - 1; i++) {
                        var dx = pontos[i+1].x - pontos[i].x;
                        var dy = pontos[i+1].y - pontos[i].y;
                        var comprimento = Math.sqrt(dx*dx + dy*dy);
                        if (comprimento > maiorComprimento) {
                            maiorComprimento = comprimento;
                            melhorIdx = i;
                        }
                    }
                    var p1 = pontos[melhorIdx];
                    var p2 = pontos[Math.min(melhorIdx + 1, pontos.length - 1)];
                    labelPos = { x: (p1.x + p2.x) / 2, y: (p1.y + p2.y) / 2 };
                }
                
                var mx = Number(labelPos && labelPos.x);
                var my = Number(labelPos && labelPos.y);
                if (!isFinite(mx) || !isFinite(my)) {
                    mx = Number(pontos[0].x) || 0;
                    my = Number(pontos[0].y) || 0;
                }
                
                // Determina o ângulo baseado no segmento mais longo
                var angulo = 0;
                var maiorComp = 0;
                for (var j = 0; j < pontos.length - 1; j++) {
                    var dx = pontos[j+1].x - pontos[j].x;
                    var dy = pontos[j+1].y - pontos[j].y;
                    var comprimento = Math.sqrt(dx*dx + dy*dy);
                    if (comprimento > maiorComp) {
                        maiorComp = comprimento;
                        angulo = Math.atan2(dy, dx) * 180 / Math.PI;
                        if (angulo > 90 || angulo < -90) angulo += 180;
                    }
                }
                
                var label = el('g', {
                    transform: 'translate(' + mx + ',' + my + ') rotate(' + angulo + ')'
                }, g);
                
                var larguraTexto = labelText.length * 7 + 16;
                var alturaTexto = 18;
                
                el('rect', {
                    x: -larguraTexto/2, y: -alturaTexto/2,
                    width: larguraTexto, height: alturaTexto,
                    fill: '#fff', rx: 4, stroke: '#d7dde4', 'stroke-width': 0.5,
                    opacity: 0.95
                }, label);
                
                el('text', {
                    x: 0, y: 4, 'text-anchor': 'middle',
                    'font-size': 10, fill: '#5a6b7d', 'font-weight': 600
                }, label).textContent = labelText;
            }
        });
    };

    Diagram.prototype._renderSelecao = function () {};

    // ================================================================
    // UTILITÁRIOS DE DESENHO
    // ================================================================
    Diagram.prototype._desenharSeloRisco = function (g, riscos) {
        var selo = el('g', { transform: 'translate(-6,-6)' }, g);
        el('circle', { cx: 0, cy: 0, r: 8, fill: '#dc3545', stroke: '#fff', 'stroke-width': 1.5 }, selo);
        el('path', {
            d: 'M-3,-4 L-3,4 M-3,-4 L3,-3 L0,-1 L3,1 L-3,2',
            fill: 'none', stroke: '#fff', 'stroke-width': 1.2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round'
        }, selo);
        
        if (riscos.length > 1) {
            var cont = el('g', { transform: 'translate(8,-8)' }, g);
            el('circle', { cx: 0, cy: 0, r: 6, fill: '#33404d', stroke: '#fff', 'stroke-width': 1 }, cont);
            el('text', {
                x: 0, y: 1, 'text-anchor': 'middle', 'font-size': 7,
                'font-weight': 700, fill: '#fff'
            }, cont).textContent = riscos.length > 9 ? '9+' : String(riscos.length);
        }
    };

    Diagram.prototype._desenharHaloSelecao = function (g, w, h) {
        var m = 5;
        el('rect', {
            x: -m, y: -m, width: w + m*2, height: h + m*2, rx: 4,
            fill: 'none', stroke: '#0a6fc2', 'stroke-width': 1.5, 'stroke-dasharray': '4,3'
        }, g);
        
        var cantos = [
            [-m, -m], [w+m, -m], [-m, h+m], [w+m, h+m]
        ];
        cantos.forEach(function(c) {
            el('rect', {
                x: c[0] - 3, y: c[1] - 3, width: 6, height: 6,
                fill: '#0a6fc2', stroke: '#fff', 'stroke-width': 1
            }, g);
        });
    };

    Diagram.prototype._quebrarTexto = function (texto, maxLen) {
        if (!texto) return [''];
        var palavras = String(texto).split(' ');
        var linhas = [], atual = '';
        palavras.forEach(function(p) {
            var teste = atual ? atual + ' ' + p : p;
            if (teste.length > maxLen && atual) {
                linhas.push(atual);
                atual = p;
            } else {
                atual = teste;
            }
        });
        if (atual) linhas.push(atual);
        return linhas.slice(0, 6); // permite mais linhas (fonte pode encolher)
    };

    /**
     * Ajusta o texto da tarefa para caber na caixa: quebra em linhas e
     * reduz a fonte progressivamente até o nome inteiro aparecer.
     * Retorna { linhas: string[], fontSize: number }.
     */
    Diagram.prototype._ajustarTextoTarefa = function (texto, maxW, maxH) {
        if (!texto) return { linhas: [''], fontSize: 11 };
        var self = this;
        var fontSizes = [11, 10, 9, 8, 7, 6];
        var charWidthFactor = 0.58; // aproximação para fonte sans-serif

        for (var fi = 0; fi < fontSizes.length; fi++) {
            var fs = fontSizes[fi];
            var maxChars = Math.max(8, Math.floor(maxW / (fs * charWidthFactor)));
            var linhas = self._quebrarTexto(texto, maxChars);
            var lineH = fs * 1.15;
            var totalH = linhas.length * lineH;
            if (totalH <= maxH + 2) {
                return { linhas: linhas, fontSize: fs };
            }
        }
        // fallback: menor fonte, até 6 linhas
        var fsMin = 6;
        var maxCharsMin = Math.max(8, Math.floor(maxW / (fsMin * charWidthFactor)));
        return { linhas: self._quebrarTexto(texto, maxCharsMin).slice(0, 6), fontSize: fsMin };
    };

    // ================================================================
    // UTILITÁRIOS DE COORDENADAS
    // ================================================================
    Diagram.prototype._pontoSvgParaModelo = function (ev) {
        var rect = this.svg.getBoundingClientRect();
        var sx = (ev.clientX - rect.left) / rect.width;
        var sy = (ev.clientY - rect.top) / rect.height;
        return {
            x: this.vbX + sx * this.vbW,
            y: this.vbY + sy * this.vbH
        };
    };

    Diagram.prototype._modeloParaSvg = function (mx, my) {
        var rect = this.svg.getBoundingClientRect();
        var sx = (mx - this.vbX) / this.vbW;
        var sy = (my - this.vbY) / this.vbH;
        return {
            x: rect.left + sx * rect.width,
            y: rect.top + sy * rect.height
        };
    };

    Diagram.prototype._bboxParticipant = function () {
        var self = this;
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        this.lanes.forEach(function(lane) {
            minX = Math.min(minX, lane.x);
            minY = Math.min(minY, lane.y);
            maxX = Math.max(maxX, lane.x + lane.w);
            maxY = Math.max(maxY, lane.y + lane.h);
        });
        if (minX === Infinity) return { x: 0, y: 0, w: 0, h: 0 };
        minX -= 30;
        return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
    };

    Diagram.prototype._bboxTotal = function () {
        var self = this;
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        var achou = false;
        
        Object.keys(this.elements).forEach(function(id) {
            var eo = self.elements[id];
            minX = Math.min(minX, eo.x);
            minY = Math.min(minY, eo.y);
            maxX = Math.max(maxX, eo.x + eo.w);
            maxY = Math.max(maxY, eo.y + eo.h);
            achou = true;
        });
        
        this.lanes.forEach(function(lane) {
            minX = Math.min(minX, lane.x);
            minY = Math.min(minY, lane.y);
            maxX = Math.max(maxX, lane.x + lane.w);
            maxY = Math.max(maxY, lane.y + lane.h);
            achou = true;
        });
        
        if (!achou) return { x: 0, y: 0, w: 1200, h: 800 };
        return { x: minX - 50, y: minY - 50, w: maxX - minX + 100, h: maxY - minY + 100 };
    };

    Diagram.prototype._elementoPublico = function (obj) {
        if (!obj) return null;
        if (obj.isFlow) {
            return {
                id: obj.id,
                type: 'bpmn:SequenceFlow',
                businessObject: { name: obj.name || '' },
                source: this.elements[obj.sourceId] ? this._elementoPublico(this.elements[obj.sourceId]) : null,
                target: this.elements[obj.targetId] ? this._elementoPublico(this.elements[obj.targetId]) : null,
                waypoints: this._rotaConexao(obj)
            };
        }
        var listaRiscos = Array.isArray(obj.riscos) ? obj.riscos.slice() : [];
        return {
            id: obj.id,
            type: obj.type,
            x: obj.x, y: obj.y, width: obj.w, height: obj.h,
            parent: true,
            name: obj.name || '',
            riscos: listaRiscos,
            businessObject: { name: obj.name || '', riscos: listaRiscos }
        };
    };

    Diagram.prototype._nextId = function (prefixo) {
        this._counter++;
        return prefixo + '_' + this._counter + '_' + gerarId();
    };

    // ================================================================
    // OVERLAYS
    // ================================================================
    Diagram.prototype._addOverlay = function (elementId, tipo, opcoes) {
        this._overlaysAtivos = this._overlaysAtivos || {};
        var chave = elementId + '::' + tipo;
        this._overlaysAtivos[chave] = { elementId: elementId, tipo: tipo, opcoes: opcoes };
        this._reaplicarOverlays();
    };

    Diagram.prototype._removeOverlay = function (filtro) {
        this._overlaysAtivos = this._overlaysAtivos || {};
        var self = this;
        Object.keys(this._overlaysAtivos).forEach(function(chave) {
            var ov = self._overlaysAtivos[chave];
            if (ov.elementId === filtro.element && ov.tipo === filtro.type) {
                delete self._overlaysAtivos[chave];
            }
        });
        this._reaplicarOverlays();
    };

    Diagram.prototype._reaplicarOverlays = function () {
        var self = this;
        this.overlayLayer.innerHTML = '';
        Object.keys(this._overlaysAtivos || {}).forEach(function(chave) {
            var ov = self._overlaysAtivos[chave];
            var eo = self.elements[ov.elementId];
            if (!eo) return;
            
            var pt = self._modeloParaSvg(eo.x, eo.y);
            var div = document.createElement('div');
            div.style.position = 'absolute';
            div.style.left = pt.x + 'px';
            div.style.top = pt.y + 'px';
            div.style.pointerEvents = 'none';
            div.innerHTML = ov.opcoes.html || '';
            self.overlayLayer.appendChild(div);
        });
    };

    // ================================================================
    // EXPANSÃO AUTOMÁTICA DO VIEWPORT (evita depender de zoom manual)
    // ================================================================
    /**
     * Garante que o viewBox atual (vbX/vbY/vbW/vbH) cubra todo o conteúdo
     * do diagrama. Diferente de _ajustarParaCaber (que recentraliza tudo e
     * volta o zoom para 100%), esta função só CRESCE o viewport na direção
     * necessária — preservando a posição de rolagem e o zoom atuais — para
     * que raias e elementos recém-inseridos fiquem visíveis imediatamente,
     * sem exigir que o usuário clique em "ajustar à tela" ou mexa no zoom.
     */
    Diagram.prototype._garantirViewportContemConteudo = function () {
        var box = this._bboxTotal();
        if (!box || !(box.w > 0) || !(box.h > 0)) return;

        var margem = 40;
        var mudou = false;

        // Borda direita: se o conteúdo (ex.: raia expandida por uma nova
        // tarefa) ultrapassa o limite direito atual do viewport, cresce vbW.
        var limiteDireitoAtual = this.vbX + this.vbW;
        var limiteDireitoConteudo = box.x + box.w;
        if (limiteDireitoConteudo > limiteDireitoAtual - margem) {
            this.vbW = (limiteDireitoConteudo - this.vbX) + margem;
            mudou = true;
        }

        // Borda inferior: mesma lógica para altura.
        var limiteInferiorAtual = this.vbY + this.vbH;
        var limiteInferiorConteudo = box.y + box.h;
        if (limiteInferiorConteudo > limiteInferiorAtual - margem) {
            this.vbH = (limiteInferiorConteudo - this.vbY) + margem;
            mudou = true;
        }

        // Borda esquerda/superior: se algo foi movido para fora dos limites
        // atuais (ex.: arrastar um elemento para a esquerda), expande sem
        // "empurrar" o conteúdo já visível.
        if (box.x < this.vbX + margem) {
            var deslocX = (this.vbX + margem) - box.x;
            this.vbX -= deslocX;
            this.vbW += deslocX;
            mudou = true;
        }
        if (box.y < this.vbY + margem) {
            var deslocY = (this.vbY + margem) - box.y;
            this.vbY -= deslocY;
            this.vbH += deslocY;
            mudou = true;
        }

        if (mudou) {
            this._atualizarViewport();
        }
    };

    // ================================================================
    // AJUSTAR PARA CABER
    // ================================================================
    Diagram.prototype._ajustarParaCaber = function () {
        var box = this._bboxTotal();
        this.vbX = box.x - 30;
        this.vbY = box.y - 30;
        this.vbW = Math.max(800, box.w + 60);
        this.vbH = Math.max(500, box.h + 60);
        this.scale = 1;
        this._atualizarViewport();
        this._render();
        if (this._atualizarZoomLabel) {
            this._atualizarZoomLabel();
        }
    };

    // ================================================================
    // XML
    // ================================================================
    Diagram.prototype.importXML = function (xmlString) {
        var self = this;
        return new Promise(function(resolve, reject) {
            try {
                var doc = new DOMParser().parseFromString(xmlString, 'text/xml');
                var pe = doc.querySelector('parsererror');
                if (pe) {
                    var detalhe = (pe.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 240);
                    throw new Error('XML inválido' + (detalhe ? (': ' + detalhe) : ''));
                }

                self.elements = {};
                self.flows = {};
                self.lanes = [];
                self.participant = null;
                self.participants = [];

                // ------------------------------------------------
                // Bounds DI (BPMNShape)
                // ------------------------------------------------
                var bounds = {};
                allTags(doc, 'BPMNShape').forEach(function(shapeEl) {
                    var elementoId = shapeEl.getAttribute('bpmnElement');
                    var b = firstTag(shapeEl, 'Bounds');
                    if (elementoId && b) {
                        bounds[elementoId] = {
                            x: parseFloat(b.getAttribute('x')) || 0,
                            y: parseFloat(b.getAttribute('y')) || 0,
                            w: parseFloat(b.getAttribute('width')) || 100,
                            h: parseFloat(b.getAttribute('height')) || 80
                        };
                    }
                });

                // ------------------------------------------------
                // Waypoints DI (BPMNEdge)
                // ------------------------------------------------
                var edgeWaypoints = {};
                allTags(doc, 'BPMNEdge').forEach(function(edgeEl) {
                    var elementoId = edgeEl.getAttribute('bpmnElement');
                    if (!elementoId) return;
                    var wps = [];
                    allTags(edgeEl, 'waypoint').forEach(function(wpEl) {
                        var x = parseFloat(wpEl.getAttribute('x'));
                        var y = parseFloat(wpEl.getAttribute('y'));
                        if (isFinite(x) && isFinite(y)) wps.push({ x: x, y: y });
                    });
                    if (wps.length >= 2) edgeWaypoints[elementoId] = wps;
                });

                // ------------------------------------------------
                // Participants / collaboration (múltiplos pools)
                // ------------------------------------------------
                var participants = allTags(doc, 'participant');
                var processRefToParticipant = {};
                participants.forEach(function(pEl) {
                    var pid = pEl.getAttribute('id');
                    var pref = pEl.getAttribute('processRef');
                    var pname = pEl.getAttribute('name') || '';
                    var pb = bounds[pid] || null;
                    var info = { id: pid, name: pname, processRef: pref, bounds: pb };
                    self.participants.push(info);
                    if (pref) processRefToParticipant[pref] = info;
                });
                if (self.participants.length) {
                    // participant "principal" = o de maior área (ou o primeiro)
                    var principal = self.participants.slice().sort(function(a, b) {
                        var aa = a.bounds ? a.bounds.w * a.bounds.h : 0;
                        var bb = b.bounds ? b.bounds.w * b.bounds.h : 0;
                        return bb - aa;
                    })[0];
                    self.participant = { id: principal.id, name: principal.name };
                    self.processName = principal.name || self.processName;
                }

                // ------------------------------------------------
                // Processes (TODOS os processos do arquivo)
                // ------------------------------------------------
                var processos = allTags(doc, 'process');
                if (processos.length) {
                    // processId = primeiro ou o referenciado pelo participant principal
                    var procPrincipal = processos[0];
                    if (self.participant) {
                        var pInfo = self.participants.find(function(p) {
                            return p.id === self.participant.id;
                        });
                        if (pInfo && pInfo.processRef) {
                            for (var pi = 0; pi < processos.length; pi++) {
                                if (processos[pi].getAttribute('id') === pInfo.processRef) {
                                    procPrincipal = processos[pi];
                                    break;
                                }
                            }
                        }
                    }
                    self.processId = procPrincipal.getAttribute('id') || self.processId;
                    if (procPrincipal.getAttribute('name')) {
                        self.processName = procPrincipal.getAttribute('name');
                    }
                }

                // ------------------------------------------------
                // Lanes de TODOS os processos (com bounds DI)
                // ------------------------------------------------
                allTags(doc, 'lane').forEach(function(laneEl) {
                    var refs = allTags(laneEl, 'flowNodeRef').map(function(r) {
                        return (r.textContent || '').trim();
                    }).filter(Boolean);
                    var laneId = laneEl.getAttribute('id');
                    var bl = bounds[laneId];
                    if (!bl) {
                        bl = {
                            x: 60,
                            y: 50 + self.lanes.length * (CONFIG.laneHeight + 10),
                            w: CONFIG.laneWidth,
                            h: CONFIG.laneHeight
                        };
                    }
                    self.lanes.push({
                        id: laneId,
                        name: laneEl.getAttribute('name') || '',
                        refs: refs,
                        x: bl.x,
                        y: bl.y,
                        w: bl.w,
                        h: bl.h
                    });
                });

                // Se há participant(s) sem lanes, cria raia sintética cobrindo o pool
                // para cada processo que não tenha lane própria.
                self.participants.forEach(function(pInfo) {
                    if (!pInfo.bounds) return;
                    var temLaneNoPool = self.lanes.some(function(l) {
                        // lane dentro do retângulo do participant
                        return l.x >= pInfo.bounds.x - 2 &&
                            l.y >= pInfo.bounds.y - 2 &&
                            (l.x + l.w) <= (pInfo.bounds.x + pInfo.bounds.w + 2) &&
                            (l.y + l.h) <= (pInfo.bounds.y + pInfo.bounds.h + 2);
                    });
                    if (temLaneNoPool) return;
                    // Pool sem lanes internas: uma raia = área do pool (menos header)
                    var header = 30;
                    self.lanes.push({
                        id: (pInfo.id || self._nextId('Lane')) + '_lane',
                        name: pInfo.name || 'Raia',
                        refs: [],
                        x: pInfo.bounds.x + header,
                        y: pInfo.bounds.y,
                        w: Math.max(100, pInfo.bounds.w - header),
                        h: pInfo.bounds.h
                    });
                });

                // Se não há nenhuma lane, cria uma padrão
                if (!self.lanes.length) {
                    self.lanes.push({
                        id: self._nextId('Lane'),
                        name: 'Raia 1',
                        refs: [],
                        x: 60,
                        y: 50,
                        w: CONFIG.laneWidth,
                        h: CONFIG.laneHeight
                    });
                }

                if (!self.participant && self.lanes.length) {
                    self.participant = {
                        id: self._nextId('Participant'),
                        name: self.processName || 'Processo'
                    };
                }

                // ------------------------------------------------
                // Elementos de fluxo (todos os processos)
                // ------------------------------------------------
                var mapaTipos = {
                    startEvent: 'bpmn:StartEvent',
                    endEvent: 'bpmn:EndEvent',
                    intermediateThrowEvent: 'bpmn:IntermediateThrowEvent',
                    intermediateCatchEvent: 'bpmn:IntermediateCatchEvent',
                    task: 'bpmn:Task',
                    userTask: 'bpmn:UserTask',
                    serviceTask: 'bpmn:ServiceTask',
                    scriptTask: 'bpmn:ScriptTask',
                    manualTask: 'bpmn:ManualTask',
                    businessRuleTask: 'bpmn:BusinessRuleTask',
                    sendTask: 'bpmn:SendTask',
                    receiveTask: 'bpmn:ReceiveTask',
                    subProcess: 'bpmn:SubProcess',
                    callActivity: 'bpmn:CallActivity',
                    adHocSubProcess: 'bpmn:AdHocSubProcess',
                    transaction: 'bpmn:Transaction',
                    exclusiveGateway: 'bpmn:ExclusiveGateway',
                    parallelGateway: 'bpmn:ParallelGateway',
                    inclusiveGateway: 'bpmn:InclusiveGateway',
                    eventBasedGateway: 'bpmn:EventBasedGateway',
                    complexGateway: 'bpmn:ComplexGateway',
                    textAnnotation: 'bpmn:TextAnnotation',
                    dataObjectReference: 'bpmn:DataObject',
                    dataStoreReference: 'bpmn:DataStore',
                    group: 'bpmn:Group'
                };

                Object.keys(mapaTipos).forEach(function(tagLocal) {
                    allTags(doc, tagLocal).forEach(function(nodeEl) {
                        var id = nodeEl.getAttribute('id');
                        if (!id) return;
                        var tipo = mapaTipos[tagLocal];
                        var b = bounds[id] || {
                            x: 100, y: 100,
                            w: (TAMANHOS[tipo] && TAMANHOS[tipo].w) || 100,
                            h: (TAMANHOS[tipo] && TAMANHOS[tipo].h) || 80
                        };
                        var nome = nodeEl.getAttribute('name') || '', defEv = null;

                        if (tagLocal === 'textAnnotation') {
                            var textoEl = firstTag(nodeEl, 'text');
                            nome = textoEl ? textoEl.textContent.trim() : nome;
                        }

                        if (tagLocal === 'intermediateCatchEvent' || tagLocal === 'intermediateThrowEvent' ||
                            tagLocal === 'startEvent' || tagLocal === 'endEvent') {
                            Object.keys(TAG_DEF).forEach(function (tg) { if (!defEv && firstTag(nodeEl, tg)) defEv = TAG_DEF[tg]; });
                        }

                        var riscosLista = [];
                        var atrRiscos = nodeEl.getAttribute('riscos');
                        if (atrRiscos) {
                            try { riscosLista = JSON.parse(atrRiscos); } catch (e) { riscosLista = []; }
                        } else if (nodeEl.getAttribute('riscoFlag') === 'true') {
                            riscosLista = ['Fator de risco'];
                        }

                        var numAttr = nodeEl.getAttribute('numero');
                        var numVal = numAttr ? parseInt(numAttr, 10) : undefined;
                        var retAttr = nodeEl.getAttribute('retornoNumero');
                        var retVal = retAttr ? parseInt(retAttr, 10) : undefined;
                        self.elements[id] = {
                            id: id,
                            type: tipo,
                            x: b.x,
                            y: b.y,
                            w: b.w,
                            h: b.h,
                            name: nome,
                            def: defEv,
                            riscos: riscosLista,
                            numero: (isFinite(numVal) && numVal > 0) ? numVal : undefined,
                            retornoNumero: (isFinite(retVal) && retVal > 0) ? retVal : undefined
                        };
                    });
                });

                // Garante refs das lanes com base na posição Y se refs vazias
                self.lanes.forEach(function(lane) {
                    if (lane.refs && lane.refs.length) return;
                    Object.keys(self.elements).forEach(function(eid) {
                        var el = self.elements[eid];
                        var cy = el.y + el.h / 2;
                        if (cy >= lane.y && cy <= lane.y + lane.h &&
                            el.x + el.w / 2 >= lane.x && el.x <= lane.x + lane.w) {
                            lane.refs.push(eid);
                        }
                    });
                });

                // Elementos fora de qualquer lane: associa à lane mais próxima
                Object.keys(self.elements).forEach(function(eid) {
                    var ja = self.lanes.some(function(l) {
                        return l.refs && l.refs.indexOf(eid) !== -1;
                    });
                    if (ja) return;
                    var el = self.elements[eid];
                    var cy = el.y + el.h / 2;
                    var melhor = null, melhorDist = Infinity;
                    self.lanes.forEach(function(l) {
                        var mid = l.y + l.h / 2;
                        var d = Math.abs(cy - mid);
                        if (d < melhorDist) { melhorDist = d; melhor = l; }
                    });
                    if (melhor) melhor.refs.push(eid);
                });

                // ------------------------------------------------
                // Sequence flows
                // ------------------------------------------------
                allTags(doc, 'sequenceFlow').forEach(function(flowEl) {
                    var id = flowEl.getAttribute('id');
                    if (!id) return;
                    var srcId = flowEl.getAttribute('sourceRef');
                    var tgtId = flowEl.getAttribute('targetRef');
                    var tipoSalvo = flowEl.getAttribute('vmapTipo');
                    var tipoResolvido = tipoSalvo || 'sequenceFlow';
                    var elOrigem = self.elements[srcId];
                    var elDestino = self.elements[tgtId];

                    var envolveInicioOuFim = !!(elOrigem && elDestino && (
                        elOrigem.type === 'bpmn:StartEvent' ||
                        elOrigem.type === 'bpmn:EndEvent' ||
                        elDestino.type === 'bpmn:StartEvent' ||
                        elDestino.type === 'bpmn:EndEvent'
                    ));
                    if (envolveInicioOuFim) {
                        tipoResolvido = 'sequenceFlow';
                    } else if (!tipoSalvo && elOrigem && elDestino) {
                        var origemAnex = !!TIPOS_ANEXAVEIS[elOrigem.type];
                        var destinoAnex = !!TIPOS_ANEXAVEIS[elDestino.type];
                        if (origemAnex !== destinoAnex) tipoResolvido = 'eventoArtefato';
                    } else if (tipoSalvo === 'eventoArtefato' && elOrigem && elDestino) {
                        var oa = !!TIPOS_ANEXAVEIS[elOrigem.type];
                        var da = !!TIPOS_ANEXAVEIS[elDestino.type];
                        if (oa === da) tipoResolvido = 'sequenceFlow';
                    }

                    var wps = edgeWaypoints[id] || [];
                    // Início/Fim LTR: deixa auto-route recalcular
                    if (envolveInicioOuFim && elOrigem && elDestino && elDestino.x >= elOrigem.x - 8) {
                        wps = [];
                    }

                    self.flows[id] = {
                        id: id,
                        isFlow: true,
                        sourceId: srcId,
                        targetId: tgtId,
                        name: flowEl.getAttribute('name') || '',
                        tipo: tipoResolvido,
                        waypoints: wps
                    };
                });

                // ------------------------------------------------
                // Associations
                // ------------------------------------------------
                allTags(doc, 'association').forEach(function(assocEl) {
                    var id = assocEl.getAttribute('id');
                    if (!id) return;
                    self.flows[id] = {
                        id: id,
                        isFlow: true,
                        sourceId: assocEl.getAttribute('sourceRef'),
                        targetId: assocEl.getAttribute('targetRef'),
                        name: '',
                        tipo: 'association',
                        associacao: true,
                        waypoints: edgeWaypoints[id] || []
                    };
                });

                // ------------------------------------------------
                // Message flows (entre pools) — importados como
                // associação tracejada para preservar o traçado DI
                // ------------------------------------------------
                allTags(doc, 'messageFlow').forEach(function(mfEl) {
                    var id = mfEl.getAttribute('id');
                    if (!id) return;
                    var srcId = mfEl.getAttribute('sourceRef');
                    var tgtId = mfEl.getAttribute('targetRef');
                    // Só importa se ambos os extremos existem como elementos
                    if (!self.elements[srcId] || !self.elements[tgtId]) return;
                    self.flows[id] = {
                        id: id,
                        isFlow: true,
                        sourceId: srcId,
                        targetId: tgtId,
                        name: mfEl.getAttribute('name') || '',
                        tipo: 'association',
                        associacao: true,
                        messageFlow: true,
                        waypoints: edgeWaypoints[id] || []
                    };
                });

                self._counter = Object.keys(self.elements).length + Object.keys(self.flows).length;
                // Restaura contador sequencial de tarefas a partir do diagrama importado
                var maxNum = 0;
                var tiposTarefaImp = {
                    'bpmn:Task': 1, 'bpmn:ManualTask': 1, 'bpmn:ServiceTask': 1,
                    'bpmn:UserTask': 1, 'bpmn:ScriptTask': 1, 'bpmn:BusinessRuleTask': 1,
                    'bpmn:SendTask': 1, 'bpmn:ReceiveTask': 1
                };
                var listaTarefasImp = [];
                Object.keys(self.elements).forEach(function (eid) {
                    var el = self.elements[eid];
                    if (el && tiposTarefaImp[el.type]) listaTarefasImp.push(el);
                });
                listaTarefasImp.sort(function (a, b) {
                    var na = typeof a.numero === 'number' ? a.numero : 1e9;
                    var nb = typeof b.numero === 'number' ? b.numero : 1e9;
                    return na - nb;
                });
                listaTarefasImp.forEach(function (el) {
                    if (typeof el.numero === 'number' && el.numero > 0) {
                        if (el.numero > maxNum) maxNum = el.numero;
                    } else {
                        maxNum++;
                        el.numero = maxNum;
                    }
                });
                self._taskSeq = maxNum;
                self._ajustarParaCaber();
                self._render();
                resolve({
                    warnings: [],
                    stats: {
                        elements: Object.keys(self.elements).length,
                        flows: Object.keys(self.flows).length,
                        lanes: self.lanes.length,
                        participants: self.participants.length
                    }
                });
            } catch (err) {
                reject(err);
            }
        });
    };

    Diagram.prototype.saveXML = function (opts) {
        var self = this;
        return new Promise(function(resolve) {
            var xml = self._serializar();
            resolve({ xml: xml });
        });
    };

    Diagram.prototype.saveSVG = function () {
        var self = this;
        return new Promise(function(resolve) {
            var clone = self.svg.cloneNode(true);
            var box = self._bboxTotal();
            clone.setAttribute('viewBox', box.x + ' ' + box.y + ' ' + box.w + ' ' + box.h);
            clone.setAttribute('width', Math.max(100, Math.round(box.w)));
            clone.setAttribute('height', Math.max(100, Math.round(box.h)));
            var xml = new XMLSerializer().serializeToString(clone);
            resolve({ svg: '<?xml version="1.0" encoding="UTF-8"?>\n' + xml });
        });
    };

    Diagram.prototype._serializar = function () {
        var self = this;
        var xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
        xml += '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" ' +
            'xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" ' +
            'xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn">\n';

        if (this.participant) {
            xml += '  <bpmn:collaboration id="Collaboration_1">\n';
            xml += '    <bpmn:participant id="' + this.participant.id + '" name="' + 
                escapeXml(this.participant.name) + '" processRef="' + this.processId + '" />\n';
            xml += '  </bpmn:collaboration>\n';
        }

        xml += '  <bpmn:process id="' + this.processId + '" name="' + 
            escapeXml(this.processName) + '" isExecutable="true">\n';

        if (this.lanes.length) {
            xml += '    <bpmn:laneSet id="LaneSet_1">\n';
            this.lanes.forEach(function(lane) {
                xml += '      <bpmn:lane id="' + lane.id + '" name="' + 
                    escapeXml(lane.name) + '">\n';
                lane.refs.forEach(function(ref) {
                    if (self.elements[ref]) {
                        xml += '        <bpmn:flowNodeRef>' + ref + '</bpmn:flowNodeRef>\n';
                    }
                });
                xml += '      </bpmn:lane>\n';
            });
            xml += '    </bpmn:laneSet>\n';
        }

        var tagPorTipo = {
            'bpmn:StartEvent': 'startEvent',
            'bpmn:EndEvent': 'endEvent',
            'bpmn:IntermediateThrowEvent': 'intermediateThrowEvent',
            'bpmn:IntermediateCatchEvent': 'intermediateCatchEvent',
            'bpmn:TimerEvent': 'intermediateCatchEvent',
            'bpmn:MessageEvent': 'intermediateCatchEvent',
            'bpmn:Task': 'task',
            'bpmn:UserTask': 'userTask',
            'bpmn:ServiceTask': 'serviceTask',
            'bpmn:ScriptTask': 'scriptTask',
            'bpmn:ManualTask': 'manualTask',
            'bpmn:BusinessRuleTask': 'businessRuleTask',
            'bpmn:SendTask': 'sendTask',
            'bpmn:ReceiveTask': 'receiveTask',
            'bpmn:SubProcess': 'subProcess',
            'bpmn:CallActivity': 'callActivity',
            'bpmn:AdHocSubProcess': 'adHocSubProcess',
            'bpmn:Transaction': 'transaction',
            'bpmn:ExclusiveGateway': 'exclusiveGateway',
            'bpmn:ParallelGateway': 'parallelGateway',
            'bpmn:InclusiveGateway': 'inclusiveGateway',
            'bpmn:EventBasedGateway': 'eventBasedGateway',
            'bpmn:ComplexGateway': 'complexGateway'
        };
        var eventDefs = {
            'bpmn:TimerEvent': 'timerEventDefinition',
            'bpmn:MessageEvent': 'messageEventDefinition'
        };

        Object.keys(this.elements).forEach(function(id) {
            var eo = self.elements[id];
            var temRiscos = eo.riscos && eo.riscos.length > 0;
            var atrRisco = temRiscos ? 
                ' riscoFlag="true" riscos="' + escapeXml(JSON.stringify(eo.riscos)) + '"' : '';
            var atrNumero = (typeof eo.numero === 'number' && eo.numero > 0) ?
                ' numero="' + eo.numero + '"' : '';
            var atrRetorno = (typeof eo.retornoNumero === 'number' && eo.retornoNumero > 0) ?
                ' retornoNumero="' + eo.retornoNumero + '"' : '';

            if (eo.type === 'bpmn:TextAnnotation') {
                xml += '    <bpmn:textAnnotation id="' + id + '"' + atrRisco + atrNumero + atrRetorno + '>' +
                    '<bpmn:text>' + escapeXml(eo.name) + '</bpmn:text></bpmn:textAnnotation>\n';
                return;
            }
            if (eo.type === 'bpmn:DataObject') {
                xml += '    <bpmn:dataObjectReference id="' + id + '" name="' + 
                    escapeXml(eo.name) + '"' + atrRisco + atrNumero + atrRetorno + ' />\n';
                return;
            }
            if (eo.type === 'bpmn:DataStore') {
                xml += '    <bpmn:dataStoreReference id="' + id + '" name="' + 
                    escapeXml(eo.name) + '"' + atrRisco + atrNumero + atrRetorno + ' />\n';
                return;
            }
            if (eo.type === 'bpmn:Group') {
                xml += '    <bpmn:group id="' + id + '" name="' + 
                    escapeXml(eo.name) + '"' + atrRisco + atrNumero + atrRetorno + ' />\n';
                return;
            }

            var tag = tagPorTipo[eo.type] || 'task';
            var incoming = Object.keys(self.flows).filter(function(fid) {
                return self.flows[fid].targetId === id && !self.flows[fid].associacao;
            });
            var outgoing = Object.keys(self.flows).filter(function(fid) {
                return self.flows[fid].sourceId === id && !self.flows[fid].associacao;
            });

            xml += '    <bpmn:' + tag + ' id="' + id + '" name="' + 
                escapeXml(eo.name) + '"' + atrRisco + atrNumero + atrRetorno + '>\n';
            incoming.forEach(function(fid) {
                xml += '      <bpmn:incoming>' + fid + '</bpmn:incoming>\n';
            });
            outgoing.forEach(function(fid) {
                xml += '      <bpmn:outgoing>' + fid + '</bpmn:outgoing>\n';
            });
            if (eventDefs[eo.type]) {
                xml += '      <bpmn:' + eventDefs[eo.type] + ' />\n';
            } else if (eo.def && DEF_TAG[eo.def]) {
                xml += '      <bpmn:' + DEF_TAG[eo.def] + (eo.def === 'link' ? ' name="' + escapeXml(eo.name || 'Link') + '"' : '') + ' />\n';
            }
            xml += '    </bpmn:' + tag + '>\n';
        });

        Object.keys(this.flows).forEach(function(fid) {
            var f = self.flows[fid];
            if (f.associacao) {
                xml += '    <bpmn:association id="' + fid + '" sourceRef="' + 
                    f.sourceId + '" targetRef="' + f.targetId + '" />\n';
                return;
            }
            xml += '    <bpmn:sequenceFlow id="' + fid + '"' +
                (f.name ? ' name="' + escapeXml(f.name) + '"' : '') +
                (f.tipo === 'eventoArtefato' ? ' vmapTipo="eventoArtefato"' : '') +
                ' sourceRef="' + f.sourceId + '" targetRef="' + f.targetId + '" />\n';
        });

        xml += '  </bpmn:process>\n';

        xml += '  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="' +
            (this.participant ? 'Collaboration_1' : this.processId) + '">\n';

        if (this.participant) {
            var boxP = this._bboxParticipant();
            xml += this._shapeXml(this.participant.id, boxP.x, boxP.y, boxP.w, boxP.h);
        }
        this.lanes.forEach(function(lane) {
            xml += self._shapeXml(lane.id, lane.x, lane.y, lane.w, lane.h);
        });
        Object.keys(this.elements).forEach(function(id) {
            var eo = self.elements[id];
            xml += self._shapeXml(id, eo.x, eo.y, eo.w, eo.h);
        });
        Object.keys(this.flows).forEach(function(fid) {
            var f = self.flows[fid];
            var pontos = self._rotaConexao(f);
            xml += '      <bpmndi:BPMNEdge id="' + fid + '_di" bpmnElement="' + fid + '">\n';
            pontos.forEach(function(p) {
                xml += '        <di:waypoint x="' + Math.round(p.x) + '" y="' + Math.round(p.y) + '" />\n';
            });
            xml += '      </bpmndi:BPMNEdge>\n';
        });

        xml += '    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n</bpmn:definitions>';
        return xml;
    };

    Diagram.prototype._shapeXml = function (id, x, y, w, h) {
        return '      <bpmndi:BPMNShape id="' + id + '_di" bpmnElement="' + id + '">\n' +
            '        <dc:Bounds x="' + Math.round(x) + '" y="' + Math.round(y) + 
            '" width="' + Math.round(w) + '" height="' + Math.round(h) + '" />\n' +
            '      </bpmndi:BPMNShape>\n';
    };

    Diagram.prototype.on = function (evt, cb) {
        this.events.on(evt, cb);
    };

    Diagram.prototype.get = function (nome) {
        var d = this;
        if (nome === 'elementRegistry') {
            return {
                getAll: function() {
                    var lista = [];
                    if (d.participant) {
                        lista.push(d._elementoPublico({ 
                            id: d.participant.id, 
                            type: 'bpmn:Participant',
                            x: 0, y: 0, w: 0, h: 0,
                            name: d.participant.name
                        }));
                    }
                    d.lanes.forEach(function(lane) {
                        lista.push(d._elementoPublico({
                            id: lane.id,
                            type: 'bpmn:Lane',
                            x: lane.x, y: lane.y, w: lane.w, h: lane.h,
                            name: lane.name
                        }));
                    });
                    Object.keys(d.elements).forEach(function(id) {
                        lista.push(d._elementoPublico(d.elements[id]));
                    });
                    Object.keys(d.flows).forEach(function(id) {
                        lista.push(d._elementoPublico(d.flows[id]));
                    });
                    return lista;
                },
                get: function(id) {
                    var obj = d.elements[id] || d.flows[id];
                    return obj ? d._elementoPublico(obj) : null;
                }
            };
        }
        if (nome === 'overlays') {
            return {
                add: function(elementId, tipo, opcoes) {
                    d._addOverlay(elementId, tipo, opcoes);
                },
                remove: function(filtro) {
                    d._removeOverlay(filtro);
                }
            };
        }
        if (nome === 'selection') {
            return {
                get: function() {
                    return d.selectedIds.map(function(id) {
                        var obj = d.elements[id] || d.flows[id];
                        return obj ? d._elementoPublico(obj) : null;
                    }).filter(Boolean);
                }
            };
        }
        if (nome === 'modeling') {
            return {
                reconnect: function(connection, source, target, start, end) {
                    var flowId = connection && connection.id;
                    var flow = flowId ? d.flows[flowId] : null;
                    if (!flow) throw new Error('Conexão não encontrada');

                    if (source && source.id) flow.sourceId = source.id;
                    if (target && target.id) flow.targetId = target.id;

                    // O ponto inicial/final informado pelo chamador é uma
                    // sugestão do cliente. Para gateways, a biblioteca deve
                    // continuar sendo a autoridade do roteamento.
                    flow.waypoints = [];
                    delete flow._labelPos;
                    d._render();
                    d.events.fire('connection.reconnected', {
                        connection: d._elementoPublico(flow),
                        source: source || null,
                        target: target || null
                    });
                    return d._elementoPublico(flow);
                },
                createConnection: function(source, target, attrs) {
                    if (!source || !target) throw new Error('Origem e destino são obrigatórios');
                    return d._criarConexao(source.id, target.id, (attrs && attrs.type) || 'sequenceFlow');
                },
                moveShape: function(element, delta) {
                    if (!element || !element.id) return;
                    var obj = d.elements[element.id];
                    if (!obj) return;
                    obj.x += Number(delta && delta.x || 0);
                    obj.y += Number(delta && delta.y || 0);
                    Object.keys(d.flows).forEach(function(fid) {
                        var f = d.flows[fid];
                        if (f.sourceId === obj.id || f.targetId === obj.id) {
                            f.waypoints = [];
                            delete f._labelPos;
                        }
                    });
                    d._render();
                },
                updateWaypoints: function(connection) {
                    var flow = connection && d.flows[connection.id];
                    if (!flow) return null;
                    flow.waypoints = [];
                    delete flow._labelPos;
                    d._render();
                    return d._elementoPublico(flow);
                }
            };
        }

        if (nome === 'canvas') {
            return {
                // Compatível com bpmn-js: zoom() retorna escala; zoom(n) define;
                // zoom('fit-viewport') ajusta o conteúdo à tela.
                zoom: function(modo) {
                    if (modo === undefined || modo === null) {
                        return d.scale || 1;
                    }
                    if (modo === 'fit-viewport') {
                        d._ajustarParaCaber();
                        return d.scale || 1;
                    }
                    var valor = Number(modo);
                    if (!isFinite(valor) || valor <= 0) return d.scale || 1;
                    d.scale = Math.min(4, Math.max(0.15, valor));
                    d._atualizarViewport();
                    d._render();
                    if (d._atualizarZoomLabel) d._atualizarZoomLabel();
                    return d.scale;
                },
                scroll: function(dx, dy) {
                    d.vbX += dx;
                    d.vbY += dy;
                    d._atualizarViewport();
                    d._render();
                }
            };
        }
        return {};
    };

    // ================================================================
    // FUNÇÕES AUXILIARES PARA XML
    // ================================================================
    function firstTag(root, nomeLocal) {
        var achado = root.getElementsByTagNameNS ? 
            root.getElementsByTagNameNS('*', nomeLocal)[0] : null;
        if (achado) return achado;
        var todos = root.querySelectorAll ? root.querySelectorAll('*') : [];
        for (var i = 0; i < todos.length; i++) {
            if (localName(todos[i]) === nomeLocal) return todos[i];
        }
        return null;
    }

    function allTags(root, nomeLocal) {
        var lista = [];
        var todos = root.getElementsByTagNameNS ? 
            root.getElementsByTagNameNS('*', nomeLocal) : [];
        for (var i = 0; i < todos.length; i++) lista.push(todos[i]);
        if (lista.length) return lista;
        var todosGeral = root.querySelectorAll ? root.querySelectorAll('*') : [];
        for (var j = 0; j < todosGeral.length; j++) {
            if (localName(todosGeral[j]) === nomeLocal) lista.push(todosGeral[j]);
        }
        return lista;
    }

    function localName(node) {
        return node.localName || node.nodeName.split(':').pop();
    }

    // ================================================================
    // CLASSE PRINCIPAL - BpmnJS
    // ================================================================
    function BpmnJS(opts) {
        var container = typeof opts.container === 'string' ? 
            document.querySelector(opts.container) : opts.container;
        this._diagram = new Diagram(container);
        this._diagram.init();
    }

    BpmnJS.prototype.importXML = function(xml) { 
        return this._diagram.importXML(xml); 
    };
    BpmnJS.prototype.saveXML = function(opts) { 
        return this._diagram.saveXML(opts); 
    };
    BpmnJS.prototype.saveSVG = function() { 
        return this._diagram.saveSVG(); 
    };
    BpmnJS.prototype.on = function(evt, cb) { 
        this._diagram.on(evt, cb); 
    };
    BpmnJS.prototype.get = function(nome) { 
        return this._diagram.get(nome); 
    };

    BpmnJS.prototype.setFlags = function(mapa) { this._diagram.setFlags(mapa); };

    global.BpmnJS = BpmnJS;
})(window);