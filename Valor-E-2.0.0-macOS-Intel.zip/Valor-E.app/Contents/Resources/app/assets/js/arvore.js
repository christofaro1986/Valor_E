/* arvore.js — "Árvore de gestão": árvore hierárquica reutilizável (tela e PDF).
   Usada na validação da CVA (macroprocessos → processos) e no módulo Processos (macroprocessos → processos → indicadores e riscos).
   Nó: { tipo: 'raiz'|'grupo'|'macro'|'proc'|'ind'|'risco', rotulo, href, meta, cor:'#hex', badges:[{t, cor:'#hex', fg:'#hex'}], filhos:[] } */
(function (w) {
  'use strict';
  var h = E.esc, seq = 0;
  var ICONE = { raiz: 'bi-bezier2', grupo: 'bi-layers', macro: 'bi-diagram-2', proc: 'bi-diagram-3', ind: 'bi-graph-up-arrow', risco: 'bi-exclamation-triangle' };
  var ROTULO_TAG = { ind: 'IND', risco: 'RISCO' };
  var COR_TIPO = { raiz: '#0b2447', grupo: '#0a6fc2', macro: '#0b3a73', proc: '#334155', ind: '#7c3aed', risco: '#d97706' };

  /* ---------- tela ---------- */
  function contar(n) { var t = 0; (n.filhos || []).forEach(function (f) { t += 1 + contar(f); }); return t; }
  function badges(n) {
    return (n.badges || []).map(function (b) {
      return '<span class="ag-b" style="background:' + h(b.cor || '#64748b') + ';color:' + h(b.fg || '#fff') + '"' + (b.dica ? ' title="' + h(b.dica) + '"' : '') + '>' + h(b.t) + '</span>';
    }).join('');
  }
  function noHtml(n, aberto) {
    var cor = n.cor || COR_TIPO[n.tipo] || '#334155', fil = n.filhos || [];
    var cab = '<span class="ag-ic" style="background:' + h(cor) + '"><i class="bi ' + (ICONE[n.tipo] || 'bi-dot') + '"></i></span>' +
      '<span class="ag-t">' + (n.href ? '<a href="' + h(n.href) + '">' + h(n.rotulo) + '</a>' : h(n.rotulo)) + '</span>' +
      (n.meta ? '<span class="ag-m">' + h(n.meta) + '</span>' : '') + badges(n);
    if (!fil.length) return '<li class="ag-n ag-' + n.tipo + '"><div class="ag-lin">' + cab + '</div></li>';
    return '<li class="ag-n ag-' + n.tipo + '"><details' + (aberto ? ' open' : '') + '><summary class="ag-lin">' + cab + '<span class="ag-cnt" title="Itens abaixo deste nível">' + contar(n) + '</span></summary><ul class="ag-sub">' +
      fil.map(function (f) { return noHtml(f, aberto); }).join('') + '</ul></details></li>';
  }
  function html(nos, opc) {
    opc = opc || {}; var id = opc.id || ('ag' + (++seq));
    return '<ul class="ag-tree" id="' + id + '">' + nos.map(function (n) { return noHtml(n, opc.aberto !== false); }).join('') + '</ul>';
  }
  function abrirTodos(sel, abrir) { Array.prototype.forEach.call(document.querySelectorAll(sel + ' details'), function (d) { d.open = !!abrir; }); }
  function imprimir() { abrirTodos('.ag-tree', true); document.body.classList.add('imp-arvore'); window.print(); setTimeout(function () { document.body.classList.remove('imp-arvore'); }, 600); }

  /* ---------- PDF ---------- */
  function pdfTxt(s) {
    s = String(s == null ? '' : s);
    var map = { ' ': ' ', '–': '-', '—': '-', '‘': "'", '’': "'", '“': '"', '”': '"', '•': '-', '◆': '*', '○': '-', '●': '*', '■': '*', '→': '->', '·': '-' };
    s = s.replace(/[ –—‘’“”•◆○●■→·]/g, function (ch) { return map[ch] || ' '; });
    return s.replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, '');
  }
  function rgb(hex) { hex = String(hex || '#64748b').replace('#', ''); if (hex.length === 3) hex = hex.replace(/(.)/g, '$1$1'); return [parseInt(hex.slice(0, 2), 16) || 0, parseInt(hex.slice(2, 4), 16) || 0, parseInt(hex.slice(4, 6), 16) || 0]; }

  /** cfg: { titulo, subtitulo, resumo:[texto], raiz:[nós], legenda:[{t,cor,fg}], observacao, notaFinal, arquivo } */
  function pdf(cfg) {
    if (!w.jspdf || !w.jspdf.jsPDF) { alert('Biblioteca PDF não disponível. Recarregue o aplicativo.'); return; }
    var doc = new w.jspdf.jsPDF({ unit: 'pt', format: 'a4' });
    var M = 40, PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight(), X1 = PW - M, y = M, RODAPE = 30;
    function fonte(est, tam, cor) { doc.setFont('helvetica', est || 'normal'); doc.setFontSize(tam || 9); var c = cor || [30, 41, 59]; doc.setTextColor(c[0], c[1], c[2]); }
    function precisa(alt) { if (y + alt > PH - M - RODAPE + 10) { doc.addPage(); y = M; return true; } return false; }

    // cabeçalho
    fonte('normal', 8, [100, 116, 139]); doc.text(pdfTxt('Valor-E - Gestão e Realização Estratégica'), M, y); y += 16;
    fonte('bold', 15, [11, 36, 71]); doc.splitTextToSize(pdfTxt(cfg.titulo || 'Árvore de gestão'), X1 - M).forEach(function (l) { doc.text(l, M, y); y += 17; });
    if (cfg.subtitulo) { fonte('normal', 9, [71, 85, 105]); doc.splitTextToSize(pdfTxt(cfg.subtitulo), X1 - M).forEach(function (l) { doc.text(l, M, y); y += 12; }); }
    fonte('normal', 8, [100, 116, 139]); doc.text(pdfTxt('Emitido em ' + E.dataBr(E.hoje())), M, y); y += 8;
    doc.setDrawColor(11, 36, 71); doc.setLineWidth(1.1); doc.line(M, y, X1, y); y += 14;
    (cfg.resumo || []).forEach(function (t) { fonte('normal', 8.5, [51, 65, 85]); doc.text(pdfTxt(t), M, y); y += 12; });
    if ((cfg.resumo || []).length) y += 6;

    // linhas da árvore (percurso em profundidade)
    var linhas = [];
    function andar(n, d, cont, ultimo) {
      linhas.push({ n: n, d: d, cont: cont.slice(), ultimo: ultimo });
      var fil = n.filhos || [], c2 = cont.slice(); if (d >= 1) c2[d] = !ultimo;
      fil.forEach(function (f, i) { andar(f, d + 1, c2, i === fil.length - 1); });
    }
    (cfg.raiz || []).forEach(function (n, i, a) { andar(n, 0, [], i === a.length - 1); });
    var GX = function (k) { return M + 6 + (k - 1) * 17; };

    linhas.forEach(function (L) {
      var n = L.n, d = L.d, tipo = n.tipo, cor = rgb(n.cor || COR_TIPO[tipo]), xt = d === 0 ? M : GX(d) + 11;
      // selos (à direita)
      fonte('bold', 7.2); var bs = (n.badges || []).map(function (b) { return { b: b, w: doc.getTextWidth(pdfTxt(b.t)) + 10 }; });
      var bw = bs.reduce(function (s, x) { return s + x.w + 3; }, 0);
      var tag = ROTULO_TAG[tipo], tagW = 0; if (tag) { fonte('bold', 6.5); tagW = doc.getTextWidth(tag) + 8; }
      var pad = (tipo === 'macro' || tipo === 'proc' || tipo === 'raiz') ? 6 : 0;
      var larg = X1 - xt - bw - 6 - tagW - pad * 2 - (tipo === 'proc' ? 4 : 0);
      var tam = tipo === 'raiz' ? 11 : tipo === 'grupo' ? 9.5 : tipo === 'macro' ? 9 : tipo === 'proc' ? 8.8 : 8.2;
      var est = (tipo === 'ind' || tipo === 'risco') ? 'normal' : 'bold';
      fonte(est, tam); var txt = pdfTxt(n.rotulo) + (n.meta && tipo !== 'raiz' ? '' : ''), ls = doc.splitTextToSize(txt, Math.max(60, larg));
      var rh = Math.max(tipo === 'raiz' ? 24 : 17, ls.length * (tam + 2) + 7);
      precisa(rh);
      var y0 = y, meio = y0 + Math.min(rh / 2, 9.5);
      // guias
      doc.setDrawColor(163, 181, 204); doc.setLineWidth(0.9);
      if (d >= 1) {
        for (var k = 1; k < d; k++) if (L.cont[k]) doc.line(GX(k), y0, GX(k), y0 + rh);
        doc.line(GX(d), y0, GX(d), L.ultimo ? meio : y0 + rh); doc.line(GX(d), meio, GX(d) + 9, meio);
      }
      var bx = xt, bwid = X1 - xt - bw - 4;
      if (tipo === 'raiz') { doc.setFillColor(cor[0], cor[1], cor[2]); doc.roundedRect(bx, y0 + 1, bwid, rh - 2, 4, 4, 'F'); }
      else if (tipo === 'macro') { doc.setFillColor(cor[0], cor[1], cor[2]); doc.roundedRect(bx, y0 + 1, bwid, rh - 2, 3, 3, 'F'); }
      else if (tipo === 'proc') { doc.setFillColor(241, 245, 249); doc.roundedRect(bx, y0 + 1, bwid, rh - 2, 3, 3, 'F'); doc.setFillColor(cor[0], cor[1], cor[2]); doc.rect(bx, y0 + 1, 2.6, rh - 2, 'F'); }
      else if (tipo === 'grupo') { doc.setFillColor(cor[0], cor[1], cor[2]); doc.rect(bx, y0 + 3, 3, rh - 7, 'F'); }
      var tx = bx + (tipo === 'grupo' ? 8 : pad) + (tipo === 'proc' ? 3 : 0);
      if (tag) { doc.setFillColor(cor[0], cor[1], cor[2]); doc.roundedRect(tx, meio - 4.8, tagW, 9.6, 2, 2, 'F'); fonte('bold', 6.5, [255, 255, 255]); doc.text(tag, tx + 4, meio + 2.2); tx += tagW + 4; }
      var corTxt = (tipo === 'raiz' || tipo === 'macro') ? [255, 255, 255] : (tipo === 'grupo' ? cor : (tipo === 'proc' ? [15, 23, 42] : [51, 65, 85]));
      fonte(est, tam, corTxt);
      var ty = y0 + (rh - ls.length * (tam + 2)) / 2 + tam - 0.5; ls.forEach(function (l, i) { doc.text(l, tx, ty + i * (tam + 2)); });
      if (n.meta && tipo === 'raiz') { fonte('normal', 8, [226, 232, 240]); doc.text(pdfTxt(n.meta), X1 - bw - pad - 4 - doc.getTextWidth(pdfTxt(n.meta)), y0 + rh / 2 + 3); }
      // selos
      var sx = X1; for (var q = bs.length - 1; q >= 0; q--) {
        var b = bs[q].b, c = rgb(b.cor), f = rgb(b.fg || '#ffffff'), wB = bs[q].w; sx -= wB;
        doc.setFillColor(c[0], c[1], c[2]); doc.roundedRect(sx, meio - 6, wB, 12, 6, 6, 'F'); fonte('bold', 7.2, f); doc.text(pdfTxt(b.t), sx + 5, meio + 2.6); sx -= 3;
      }
      y += rh + 1.5;
    });

    if (cfg.legenda && cfg.legenda.length) {
      precisa(30); y += 8; fonte('bold', 8, [71, 85, 105]); doc.text(pdfTxt(cfg.legendaTitulo || 'Legenda:'), M, y + 8); var lx = M + doc.getTextWidth(pdfTxt(cfg.legendaTitulo || 'Legenda:')) + 8;
      cfg.legenda.forEach(function (b) { fonte('bold', 7.2); var wB = doc.getTextWidth(pdfTxt(b.t)) + 10, c = rgb(b.cor), f = rgb(b.fg || '#ffffff'); if (lx + wB > X1) { lx = M; y += 16; precisa(16); } doc.setFillColor(c[0], c[1], c[2]); doc.roundedRect(lx, y, wB, 12, 6, 6, 'F'); fonte('bold', 7.2, f); doc.text(pdfTxt(b.t), lx + 5, y + 8.6); lx += wB + 4; });
      y += 18;
    }
    if (cfg.observacao) {
      precisa(40); y += 8; fonte('bold', 10, [11, 36, 71]); doc.text('Observações', M, y + 8); y += 18; fonte('normal', 9, [30, 41, 59]);
      doc.splitTextToSize(pdfTxt(cfg.observacao), X1 - M).forEach(function (l) { precisa(12); doc.text(l, M, y + 6); y += 12; });
    }
    if (cfg.notaFinal) { precisa(24); y += 12; fonte('italic', 8, [120, 130, 145]); doc.text(pdfTxt(cfg.notaFinal), M, y + 6); }
    var np = doc.internal.getNumberOfPages();
    for (var i = 1; i <= np; i++) {
      doc.setPage(i); doc.setDrawColor(210, 218, 228); doc.setLineWidth(0.5); doc.line(M, PH - 26, X1, PH - 26);
      fonte('normal', 7.5, [140, 150, 165]); doc.text(pdfTxt('Valor-E - ' + (cfg.titulo || 'Árvore de gestão')), M, PH - 14); doc.text('Página ' + i + ' de ' + np, X1, PH - 14, { align: 'right' });
    }
    doc.save(pdfTxt(cfg.arquivo || 'arvore-de-gestao') + '.pdf');
  }

  w.Arvore = { pdfTxt: pdfTxt, html: html, abrir: abrirTodos, imprimir: imprimir, pdf: pdf, contar: contar };
})(window);
