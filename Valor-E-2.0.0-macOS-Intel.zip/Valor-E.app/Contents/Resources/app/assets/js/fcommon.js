/* fcommon.js — ponte entre as telas do Folha (folha.js, diagrama.js, imprimir.js) e o roteador do AXIA. */
(function (w) {
  'use strict';
  var C = w.Common = {}, paginas = {};
  C.esc = function (s) { return String(s === null || s === undefined ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;'); };
  C.nl2br = function (s) { return C.esc(s).replace(/\r?\n/g, '<br>'); };
  C.param = function (k) { var m = new RegExp('[?&]' + k + '=([^&#]*)').exec(location.hash); return m ? decodeURIComponent(m[1]) : ''; };
  C.id = function () { return parseInt(C.param('id'), 10) || 0; };
  C.dataHora = function (s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/.exec(s || ''); if (!m) return s || '';
    var d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6])), p = function (n) { return ('0' + n).slice(-2); };
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  };
  // gancho de saída: a tela grava pendências antes de o roteador trocar de página
  var antes = null;
  Object.defineProperty(C, 'antes', {
    get: function () { return antes; },
    set: function (f) { antes = f; w.__riscoSair = f ? function () { return Promise.resolve(f()).then(function () { return DB.flush(); }); } : null; }
  });
  C.ir = function (hash) { Promise.resolve(antes ? antes() : null).then(function () { return DB.flush(); }).then(function () { Nav.ir(hash); }); };
  C.recarregar = function () { DB.flush().then(function () { w.Rota(); }); };
  function b64DeBlob(blob) {
    return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { var d = String(r.result); res(d.substring(d.indexOf(',') + 1)); }; r.onerror = rej; r.readAsDataURL(blob); });
  }
  C.baixar = function (nome, conteudo, tipo) {
    var blob = (conteudo instanceof Blob) ? conteudo : new Blob([conteudo], { type: tipo || 'application/octet-stream' });
    if (w.__maprisHost && w.__maprisHost.invocar) return b64DeBlob(blob).then(function (b64) { return w.__maprisHost.invocar('salvar', JSON.stringify({ nome: nome, b64: b64 })); });
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nome;
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
    return Promise.resolve();
  };
  // as telas se registram; o roteador as executa depois de montar o contêiner #raiz
  C.pagina = function (nome, fn) { paginas[nome] = fn; };
  C.executar = function (nome) { try { return paginas[nome](); } catch (e) { var r = document.getElementById('fraiz'); if (r) r.innerHTML = '<div class="alert alert-danger m-3">Não foi possível abrir a tela: ' + C.esc(e.message) + '</div>'; console.error(e); } };
  C.boot = function (fn) { return fn(); };
})(window);
