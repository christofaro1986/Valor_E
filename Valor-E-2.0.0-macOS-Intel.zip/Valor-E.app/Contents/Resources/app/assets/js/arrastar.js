/* arrastar.js — todos os modais: centralizados e arrastáveis pelo cabeçalho */
(function () {
  'use strict';
  var ALVO = '.modal-content, .vmodal-content', CAB = '.modal-header, .vmodal-hd';
  var drag = null;
  function pos(el) { return { x: +el.getAttribute('data-dx') || 0, y: +el.getAttribute('data-dy') || 0 }; }
  function aplica(el, x, y) { el.setAttribute('data-dx', x); el.setAttribute('data-dy', y); el.style.transform = 'translate(' + x + 'px,' + y + 'px)'; }
  document.addEventListener('mousedown', function (e) {
    if (e.button !== 0) return;
    var cab = e.target.closest && e.target.closest(CAB); if (!cab) return;
    if (e.target.closest('button, a, input, select, textarea, .btn-close, .btn-fechar')) return;
    var alvo = cab.closest(ALVO); if (!alvo) return;
    var p = pos(alvo), r = alvo.getBoundingClientRect();
    drag = { el: alvo, sx: e.clientX, sy: e.clientY, x0: p.x, y0: p.y, r: r };
    e.preventDefault();
  });
  document.addEventListener('mousemove', function (e) {
    if (!drag) return;
    var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy, r = drag.r, W = window.innerWidth, H = window.innerHeight;
    // mantém o cabeçalho sempre visível
    dx = Math.max(-r.left - r.width + 80, Math.min(W - r.left - 80, dx));
    dy = Math.max(-r.top, Math.min(H - r.top - 40, dy));
    aplica(drag.el, drag.x0 + dx, drag.y0 + dy);
  });
  document.addEventListener('mouseup', function () { drag = null; });
  // todo modal Bootstrap vai para o <body>: fica sempre na frente da página, fora de qualquer contexto de empilhamento
  document.addEventListener('show.bs.modal', function (e) { var m = e.target; if (m && m.parentNode !== document.body) document.body.appendChild(m); }, true);
  // centraliza todo modal Bootstrap e zera o deslocamento ao abrir de novo
  function ajusta(n) {
    if (n.nodeType !== 1) return;
    var ds = n.matches && n.matches('.modal-dialog') ? [n] : (n.querySelectorAll ? Array.prototype.slice.call(n.querySelectorAll('.modal-dialog')) : []);
    ds.forEach(function (d) { d.classList.add('modal-dialog-centered'); });
  }
  new MutationObserver(function (ms) {
    ms.forEach(function (m) {
      if (m.type === 'childList') Array.prototype.forEach.call(m.addedNodes, ajusta);
      else if (m.type === 'attributes' && m.target.classList && m.target.classList.contains('vmodal') && m.target.classList.contains('active')) {
        Array.prototype.forEach.call(m.target.querySelectorAll('.vmodal-content'), function (c) { aplica(c, 0, 0); });
      }
    });
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
})();
