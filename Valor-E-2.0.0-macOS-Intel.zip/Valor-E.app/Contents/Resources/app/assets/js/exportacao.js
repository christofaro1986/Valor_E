/* exportacao.js — relatórios para a direção: apresentação PowerPoint (.pptx) e pasta de trabalho Excel (.xlsx).
 * Funciona sem internet: as bibliotecas (PptxGenJS e ExcelJS, licença MIT) acompanham o aplicativo e só são carregadas na hora de exportar.
 * Os números vêm das mesmas regras do restante do sistema (MET, Ind, Val, E.painelDados, E.alertasTodos); aqui nada é recalculado por conta própria. */
(function (w) {
  'use strict';
  var Exportar = w.Exportar = w.Exportar || {};
  var COR = { azul: '1D4F91', azulClaro: '0EA5C6', verde: '2E7D32', amarelo: 'F9A825', vermelho: 'C62828', cinza: '6B7280', cinzaClaro: 'F3F4F6', texto: '1F2937' };
  var SIT = { ok: 'Em conformidade', atencao: 'Em atenção', critico: 'Crítico', 'sem-dados': 'Sem dados' };
  var COR_SIT = { ok: COR.verde, atencao: COR.amarelo, critico: COR.vermelho, 'sem-dados': '9CA3AF' };
  function n(sql, p) { try { return DB.one(sql, p).n; } catch (e) { return 0; } }
  function q(sql, p) { try { return DB.all(sql, p || []); } catch (e) { return []; } }
  function pct(v, casas) { return v == null || isNaN(v) ? '—' : (v * 100).toFixed(casas === undefined ? 0 : casas).replace('.', ',') + '%'; }
  function num(v, casas) { return v == null || v === '' || isNaN(v) ? '—' : (+v).toFixed(casas === undefined ? 2 : casas).replace('.', ',').replace(/,00$/, ''); }
  function br(d) { return d ? (w.E && E.dataBr ? E.dataBr(d) : d) : ''; }
  function periodo(a, b) { return a && b ? br(a) + ' a ' + br(b) : a ? 'desde ' + br(a) : b ? 'até ' + br(b) : '—'; }
  function cortar(s, t) { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > t ? s.slice(0, t - 1) + '…' : s; }
  function unidade() { var a = w.Org && Org.ativa(); return { sigla: a ? a.codigo : '', nome: a ? a.nome : '' }; }
  function rotuloUnidade() { var u = unidade(); return (u.sigla && u.nome) ? u.sigla + ' — ' + u.nome : (u.sigla || u.nome || ''); }

  /* ===== carregamento das bibliotecas (uma vez, sob demanda) ===== */
  var carregadas = {};
  function lib(src, teste) {
    if (teste()) return Promise.resolve();
    if (carregadas[src]) return carregadas[src];
    return carregadas[src] = new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src;
      s.onload = function () { teste() ? res() : rej(new Error('Biblioteca carregada, mas não reconhecida: ' + src)); };
      s.onerror = function () { delete carregadas[src]; rej(new Error('Não foi possível carregar ' + src)); };
      document.head.appendChild(s);
    });
  }
  function nome(prefixo, ext) { var u = unidade().sigla; return 'valore-' + prefixo + (u ? '-' + u.replace(/[^A-Za-z0-9_-]+/g, '') : '') + '-' + E.hoje() + '.' + ext; }
  function b64DeBuffer(buf) { var u = new Uint8Array(buf), s = '', k = 0x8000; for (var i = 0; i < u.length; i += k) s += String.fromCharCode.apply(null, u.subarray(i, i + k)); return btoa(s); }

  /* ===== coleta dos dados (estrutura única usada pelos dois formatos) ===== */
  Exportar.dados = function () {
    var D = { gerado_em: new Date(), unidade: rotuloUnidade(), app: 'Valor-E ' + (w.APP_VERSAO || '') };
    var I = (w.Ind && Ind.resumo) ? Ind.resumo() : { total: 0, verde: 0, amarelo: 0, vermelho: 0, semDados: 0 };
    var V = (w.Val && Val.resumo) ? Val.resumo() : { objetivos: 0, capacidades: 0, icv: null };
    var P = E.painelDados(''), AL = E.alertasTodos(''), AC = E.alertasContagem(AL), C = (w.Cva && Cva.resumo) ? Cva.resumo() : null;
    D.resumo = { macros: n('SELECT COUNT(*) AS n FROM macroprocessos'), processos: n('SELECT COUNT(*) AS n FROM processos'), projetos: n('SELECT COUNT(*) AS n FROM projetos'), projetosAndamento: n("SELECT COUNT(*) AS n FROM projetos WHERE status = 'Em andamento'"), tarefas: n('SELECT COUNT(*) AS n FROM proj_tarefas'),
      indicadores: I, riscos: P.total, riscosAltos: ((P.niveis || {})['Alto'] || 0) + ((P.niveis || {})['Extremo'] || 0), alertas: AC, objetivos: V.objetivos, capacidades: V.capacidades, icv: V.icv, ciclo: C ? C.ciclo : '', cicloValidade: C ? C.validade : '' };
    // indicadores avaliados pelas mesmas regras da tela de Indicadores
    D.indicadores = q('SELECT i.*, p.nome AS processo_nome FROM indicadores i LEFT JOIN processos p ON p.id = i.processo_id ORDER BY i.codigo, i.nome').map(function (i) {
      var e = null; try { e = MET.avaliarIndicador(i); } catch (x) {}
      return { id: i.id, codigo: i.codigo || '', nome: i.nome, processo: i.processo_nome || '', unidade: i.unidade || '', polaridade: i.polaridade === 'menor_melhor' ? 'Menor é melhor' : 'Maior é melhor', periodicidade: i.periodicidade || '', responsavel: i.responsavel || '', ativo: !e || e.ativo !== false,
        mes: e && e.mes || '', valor: e ? e.valor : null, meta: e ? e.meta : null, pct: e ? e.pct : null, status: e ? e.status : 'sem-dados', serie: e ? e.serie : [], progresso: /^PRJ-PROG-/.test(i.codigo || '') };
    });
    // riscos
    D.matriz = P.matriz_inerente; D.niveis = P.niveis; D.niveisRes = P.niveis_res; D.categorias = P.categorias;
    var alPorRisco = {}; AL.forEach(function (a) { alPorRisco[a.risco_id] = (alPorRisco[a.risco_id] || 0) + 1; });
    D.alertas = AL;
    D.riscos = q('SELECT r.*, p.nome AS processo_nome, j.nome AS projeto_nome FROM riscos r LEFT JOIN processos p ON p.id = r.processo_id LEFT JOIN projetos j ON j.id = r.projeto_id ORDER BY r.indice_medio DESC, r.id').map(function (r) {
      return { id: r.id, codigo: r.codigo || '', nome: r.nome, origem: r.projeto_id ? 'Projeto' : (r.processo_id ? 'Processo' : 'Outro ambiente'), ambiente: r.ambiente || r.projeto_nome || r.processo_nome || '', categoria: r.categoria || '', responsavel: r.responsavel || '', status: r.status || '', resposta: r.resposta || '',
        prob: r.prob_media, imp: r.imp_medio, indice: r.indice_medio, nivel: r.nivel_medio || '', indiceRes: r.indice_res, nivelRes: r.nivel_res || '', proxima: r.proxima_revisao || '', alertas: alPorRisco[r.id] || 0 };
    });
    D.fatores = q('SELECT f.*, r.codigo AS rcod, r.nome AS rnome FROM fatores f JOIN riscos r ON r.id = f.risco_id ORDER BY r.id, f.ordem, f.id');
    D.controles = q('SELECT c.*, f.nome AS fnome, r.codigo AS rcod, r.nome AS rnome FROM controles c JOIN fatores f ON f.id = c.fator_id JOIN riscos r ON r.id = f.risco_id ORDER BY r.id, f.ordem, c.ordem, c.id');
    var hoje = E.hoje();
    D.planos = q('SELECT p.*, r.codigo AS rcod, r.nome AS rnome FROM planos p JOIN riscos r ON r.id = p.risco_id ORDER BY r.id, p.prazo').map(function (p) { p.atrasado = !!(p.prazo && p.prazo < hoje && p.status !== 'Concluído' && p.status !== 'Cancelado'); return p; });
    // projetos
    D.projetos = q('SELECT j.*, o.nome AS objetivo_nome, o.codigo AS objetivo_cod, i.nome AS ini_nome FROM projetos j LEFT JOIN objetivos_estrategicos o ON o.id = j.objetivo_id LEFT JOIN iniciativas_estrategicas i ON i.id = j.iniciativa_id ORDER BY j.codigo, j.nome');
    D.tarefas = q('SELECT t.*, j.codigo AS jcod, j.nome AS jnome FROM proj_tarefas t JOIN projetos j ON j.id = t.projeto_id ORDER BY j.codigo, j.id, t.ordem, t.id');
    // valor estratégico
    D.objetivos = q('SELECT * FROM objetivos_estrategicos ORDER BY codigo').map(function (o) {
      var r = null; try { r = MET.icvObjetivo(o.id); } catch (x) {}
      return { id: o.id, codigo: o.codigo || '', nome: o.nome, icv: r ? r.icv : null, status: r ? r.status : 'sem-dados', cobertura: r ? r.cobertura : 0,
        caps: r ? r.caps.map(function (c) { return { codigo: c.c.codigo || '', nome: c.c.nome, wc: c.wc, ihc: c.ihc, status: c.res ? c.res.status : 'sem-dados', inds: c.res ? c.res.totalInds : 0 }; }) : [] };
    });
    // processos
    D.processos = q("SELECT p.*, m.nome AS macro_nome, m.tipo AS macro_tipo, (SELECT COUNT(*) FROM riscos r WHERE r.processo_id = p.id) AS nriscos, (SELECT COUNT(*) FROM indicadores i WHERE i.processo_id = p.id) AS ninds FROM processos p LEFT JOIN macroprocessos m ON m.id = p.macro_id ORDER BY m.ordem, m.nome, p.nome");
    // lacunas (as mesmas do Painel)
    D.lacunas = [
      [n('SELECT COUNT(*) AS n FROM processos WHERE macro_id IS NULL'), 'processo(s) sem macroprocesso vinculante'],
      [n('SELECT COUNT(*) AS n FROM processos p WHERE NOT EXISTS (SELECT 1 FROM indicadores i WHERE i.processo_id = p.id)'), 'processo(s) sem indicador'],
      [n('SELECT COUNT(*) AS n FROM processos p WHERE NOT EXISTS (SELECT 1 FROM riscos r WHERE r.processo_id = p.id)'), 'processo(s) sem risco identificado'],
      [n('SELECT COUNT(*) AS n FROM projetos p WHERE NOT EXISTS (SELECT 1 FROM proj_tarefas t WHERE t.projeto_id = p.id)'), 'projeto(s) sem tarefas'],
      [n('SELECT COUNT(*) AS n FROM projetos p WHERE NOT EXISTS (SELECT 1 FROM riscos r WHERE r.projeto_id = p.id)'), 'projeto(s) sem risco identificado'],
      [n('SELECT COUNT(*) AS n FROM indicadores WHERE processo_id IS NULL'), 'indicador(es) sem processo vinculado'],
      [n('SELECT COUNT(*) AS n FROM indicadores i WHERE NOT EXISTS (SELECT 1 FROM indicador_fatores x WHERE x.indicador_id = i.id)'), 'indicador(es) não usados em nenhuma dimensão'],
      [n('SELECT COUNT(*) AS n FROM capacidades c WHERE NOT EXISTS (SELECT 1 FROM objetivo_capacidades x WHERE x.capacidade_id = c.id)'), 'capacidade(s) sem objetivo estratégico'],
      [n('SELECT COUNT(*) AS n FROM riscos WHERE processo_id IS NULL AND projeto_id IS NULL'), 'risco(s) sem processo nem projeto']
    ].filter(function (x) { return x[0] > 0; });
    return D;
  };

  /* ===== PowerPoint ===== */
  var Y0 = 1.75;   // início da área de conteúdo (abaixo da faixa e da frase-síntese)
  function cabecalho(pptx, s, titulo, msg) {
    s.background = { color: 'FFFFFF' };
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.33, h: 0.85, fill: { color: COR.azul }, line: { color: COR.azul } });
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 0.85, w: 13.33, h: 0.05, fill: { color: COR.azulClaro }, line: { color: COR.azulClaro } });
    s.addText(titulo, { x: 0.5, y: 0.1, w: 12.3, h: 0.65, fontSize: 26, bold: true, color: 'FFFFFF', fontFace: 'Calibri', valign: 'middle' });
    if (msg) s.addText(msg, { x: 0.5, y: 1.0, w: 12.3, h: 0.6, fontSize: 18, bold: true, color: COR.azul, fontFace: 'Calibri', valign: 'middle', fit: 'shrink' });
  }
  function rodape(pptx, s, D, k) {
    s.addShape(pptx.ShapeType.line, { x: 0.5, y: 7.05, w: 12.33, h: 0, line: { color: 'D1D5DB', width: 0.75 } });
    s.addText((D.unidade ? D.unidade + '  ·  ' : '') + 'Valor-E  ·  ' + br(E.hoje()), { x: 0.5, y: 7.1, w: 10, h: 0.3, fontSize: 10, color: COR.cinza, fontFace: 'Calibri' });
    s.addText(String(k), { x: 12.2, y: 7.1, w: 0.63, h: 0.3, fontSize: 10, color: COR.cinza, align: 'right', fontFace: 'Calibri' });
  }
  function cel(t, o) { o = o || {}; return { text: String(t == null ? '' : t), options: { fontSize: o.fs || 11, bold: !!o.b, color: o.cor || COR.texto, fill: o.fill ? { color: o.fill } : undefined, align: o.al || 'left', valign: 'middle', fontFace: 'Calibri' } }; }
  function claro(hex) { var r = parseInt(hex.substr(0, 2), 16), g = parseInt(hex.substr(2, 2), 16), b = parseInt(hex.substr(4, 2), 16); return (r * 299 + g * 587 + b * 114) / 1000 > 150; }
  function txtSobre(hex) { return claro(hex) ? COR.texto : 'FFFFFF'; }
  function tabela(pptx, s, cab, linhas, x, y, wTotal, ws, extra) {
    extra = extra || {};
    var rows = [cab.map(function (c, i) { return cel(c, { b: true, cor: 'FFFFFF', fill: COR.azul, fs: 11, al: i >= (extra.numDe || 99) ? 'right' : 'left' }); })].concat(linhas);
    s.addTable(rows, { x: x, y: y, w: wTotal, colW: ws, rowH: extra.rowH || 0.42, border: { type: 'solid', pt: 0.5, color: 'D1D5DB' }, margin: [0.03, 0.09, 0.03, 0.09] });
  }
  function selo(t, cor) { return { fs: 10, b: true, cor: txtSobre(cor), fill: cor, al: 'center' }; }
  function cartao(pptx, s, x, y, w_, titulo, valor, sub, cor) {
    s.addShape(pptx.ShapeType.rect, { x: x, y: y, w: w_, h: 1.4, fill: { color: 'F9FAFB' }, line: { color: 'D1D5DB', width: 1 } });
    s.addShape(pptx.ShapeType.rect, { x: x, y: y, w: 0.1, h: 1.4, fill: { color: cor }, line: { color: cor } });
    s.addText(titulo, { x: x + 0.28, y: y + 0.08, w: w_ - 0.4, h: 0.3, fontSize: 13, color: COR.cinza, fontFace: 'Calibri' });
    s.addText(String(valor), { x: x + 0.28, y: y + 0.36, w: w_ - 0.4, h: 0.6, fontSize: 32, bold: true, color: cor, fontFace: 'Calibri' });
    s.addText(sub || '', { x: x + 0.28, y: y + 0.96, w: w_ - 0.4, h: 0.4, fontSize: 11, color: COR.texto, fontFace: 'Calibri', valign: 'top', fit: 'shrink' });
  }
  function vazio(s, txt) { s.addText(txt, { x: 0.5, y: Y0 + 0.2, w: 12.3, h: 0.6, fontSize: 18, color: COR.cinza, fontFace: 'Calibri' }); }
  function plural(n_, um, varios) { return n_ + ' ' + (n_ === 1 ? um : varios); }
  function montarPptx(D, pptx) {
    pptx.layout = 'LAYOUT_WIDE'; pptx.title = 'Valor-E — Relatório de gestão'; pptx.company = D.unidade || 'Valor-E'; pptx.author = 'Valor-E';
    var k = 1, R = D.resumo, I = R.indicadores, s;
    var ativos = D.indicadores.filter(function (i) { return i.ativo; }), cont = { ok: 0, atencao: 0, critico: 0, 'sem-dados': 0 };
    ativos.forEach(function (i) { cont[i.status] = (cont[i.status] || 0) + 1; });
    var avaliados = D.riscos.filter(function (r) { return r.nivel; }), semAval = D.riscos.length - avaliados.length;
    var planosAbertos = D.planos.filter(function (x) { return x.status !== 'Concluído' && x.status !== 'Cancelado'; }).length, planosAtras = D.planos.filter(function (x) { return x.atrasado; }).length;
    var comIcv = D.objetivos.filter(function (o) { return o.icv != null; });
    // 1. capa
    s = pptx.addSlide(); s.background = { color: COR.azul };
    s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 0.35, h: 7.5, fill: { color: COR.azulClaro }, line: { color: COR.azulClaro } });
    s.addText('RELATÓRIO DE GESTÃO', { x: 1.0, y: 1.7, w: 11.5, h: 0.5, fontSize: 18, bold: true, color: 'A9C8EE', fontFace: 'Calibri', charSpacing: 4 });
    s.addText(D.unidade || 'Valor-E', { x: 1.0, y: 2.25, w: 11.5, h: 1.5, fontSize: 40, bold: true, color: 'FFFFFF', fontFace: 'Calibri', valign: 'top', fit: 'shrink' });
    s.addText('Cadeia de valor  ·  Estratégia  ·  Processos  ·  Projetos  ·  Indicadores  ·  Riscos', { x: 1.0, y: 3.9, w: 11.5, h: 0.5, fontSize: 18, color: 'D6E4F5', fontFace: 'Calibri' });
    s.addShape(pptx.ShapeType.rect, { x: 1.0, y: 5.0, w: 2.2, h: 0.06, fill: { color: COR.azulClaro }, line: { color: COR.azulClaro } });
    s.addText('Emitido em ' + br(E.hoje()) + (R.ciclo ? '\n' + R.ciclo + (R.cicloValidade ? ' — ' + R.cicloValidade : '') : ''), { x: 1.0, y: 5.2, w: 11.5, h: 1.0, fontSize: 16, color: 'FFFFFF', fontFace: 'Calibri', valign: 'top' });
    // 2. resumo executivo
    var pior = ativos.filter(function (i) { return i.pct != null && i.status === 'critico'; }).sort(function (a, b) { return a.pct - b.pct; })[0];
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Resumo executivo', R.indicadores.vermelho || R.riscosAltos || planosAtras ? 'Há pontos que pedem decisão' : 'Situação sob controle nos módulos acompanhados');
    var cs = [
      ['Cadeia de valor', R.macros + ' / ' + R.processos, 'macroprocessos / processos', COR.azulClaro],
      ['Projetos', R.projetos, R.projetosAndamento + ' em andamento · ' + R.tarefas + ' tarefa(s)', '0F766E'],
      ['Indicadores', I.total, I.vermelho + ' críticos · ' + I.amarelo + ' em atenção · ' + I.verde + ' em conformidade', '7C3AED'],
      ['Riscos', R.riscos, R.riscosAltos + ' alto(s)/extremo(s) · ' + semAval + ' sem avaliação', 'D97706'],
      ['Valor estratégico (ICV)', R.icv == null ? '—' : pct(R.icv, 1), R.objetivos + ' objetivo(s) · ' + R.capacidades + ' capacidade(s)', COR.azul],
      ['Pendências', D.lacunas.length, D.lacunas.length ? 'tipos de lacuna entre módulos' : 'nenhuma lacuna encontrada', COR.vermelho]];
    cs.forEach(function (c, i) { cartao(pptx, s, 0.5 + (i % 3) * 4.17, Y0 - 0.05 + Math.floor(i / 3) * 1.6, 3.95, c[0], c[1], c[2], c[3]); });
    var pts = [];
    if (pior) pts.push('Indicador mais distante da meta: ' + cortar(pior.nome, 60) + ' (' + pct(pior.pct) + ' da meta).');
    if (I.vermelho) pts.push(plural(I.vermelho, 'indicador crítico', 'indicadores críticos') + ' de ' + I.total + ' com dados avaliáveis.');
    if (R.riscosAltos) pts.push(plural(R.riscosAltos, 'risco em nível alto ou extremo', 'riscos em nível alto ou extremo') + ' (valor inerente).');
    if (semAval) pts.push(plural(semAval, 'risco ainda sem avaliação', 'riscos ainda sem avaliação') + ' de probabilidade e impacto.');
    if (planosAtras) pts.push(plural(planosAtras, 'plano de tratamento atrasado', 'planos de tratamento atrasados') + ', de ' + planosAbertos + ' em aberto.');
    var caps = []; comIcv.forEach(function (o) { o.caps.forEach(function (c) { if (c.ihc != null) caps.push(c); }); }); var vistas = {}; caps = caps.filter(function (c) { var kk = c.codigo + '|' + c.nome; if (vistas[kk]) return false; vistas[kk] = 1; return true; });
    caps.sort(function (a, b) { return a.ihc - b.ihc; });
    if (caps.length && caps[0].status !== 'ok') pts.push('Capacidade com menor desempenho: ' + cortar(caps[0].nome, 50) + ' (IHC ' + pct(caps[0].ihc, 1) + ').');
    if (D.lacunas.length) pts.push('Há ' + D.lacunas.length + ' tipo(s) de lacuna entre módulos a resolver (ver último slide).');
    s.addText('Pontos de atenção', { x: 0.5, y: 5.0, w: 12.3, h: 0.35, fontSize: 15, bold: true, color: COR.azul, fontFace: 'Calibri' });
    s.addText(pts.length ? pts.slice(0, 5).map(function (t) { return { text: t, options: { bullet: true, breakLine: true } }; }) : [{ text: 'Nenhum ponto de atenção identificado.', options: {} }],
      { x: 0.5, y: 5.35, w: 12.3, h: 1.6, fontSize: 14, color: COR.texto, fontFace: 'Calibri', valign: 'top', paraSpaceAfter: 4, fit: 'shrink' });
    rodape(pptx, s, D, k);
    // 3. indicadores
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Indicadores', ativos.length ? (cont.critico ? cont.critico + ' de ' + ativos.length + ' indicadores estão em situação crítica' : 'Nenhum indicador em situação crítica') : 'Nenhum indicador cadastrado ainda');
    if (ativos.length) {
      s.addChart(pptx.charts.DOUGHNUT, [{ name: 'Situação', labels: ['Em conformidade', 'Em atenção', 'Crítico', 'Sem dados'], values: [cont.ok, cont.atencao, cont.critico, cont['sem-dados']] }],
        { x: 0.4, y: Y0, w: 4.4, h: 5.1, holeSize: 55, chartColors: [COR_SIT.ok, COR_SIT.atencao, COR_SIT.critico, COR_SIT['sem-dados']], showLegend: true, legendPos: 'b', legendFontSize: 12, showPercent: false, showValue: true, dataLabelColor: 'FFFFFF', dataLabelFontSize: 14 });
      var piores = ativos.filter(function (i) { return i.pct != null && i.status !== 'ok'; }).sort(function (a, b) { return a.pct - b.pct; }).slice(0, 9);
      if (piores.length) {
        s.addText('Os que mais pedem atenção', { x: 5.0, y: Y0 - 0.05, w: 7.8, h: 0.35, fontSize: 14, bold: true, color: COR.texto, fontFace: 'Calibri' });
        tabela(pptx, s, ['Indicador', 'Atual', 'Meta', '% meta', 'Situação'], piores.map(function (i) {
          return [cel(cortar((i.codigo ? i.codigo + ' · ' : '') + i.nome.replace(/^Progresso do projeto:\s*/i, 'Projeto: '), 64), { fs: 11 }), cel(num(i.valor), { al: 'right' }), cel(num(i.meta), { al: 'right' }), cel(pct(i.pct), { al: 'right', b: true }), cel(SIT[i.status], selo(null, COR_SIT[i.status]))]; }),
          5.0, Y0 + 0.3, 7.85, [4.0, 0.85, 0.85, 0.9, 1.25], { numDe: 1, rowH: 0.46 });
      } else s.addText('Todos os indicadores com dados estão em conformidade.', { x: 5.0, y: Y0 + 0.3, w: 7.8, h: 0.5, fontSize: 16, color: COR.verde, fontFace: 'Calibri' });
    } else vazio(s, 'Cadastre indicadores e registre valores para acompanhá-los aqui.');
    rodape(pptx, s, D, k);
    // 4. riscos — matriz e níveis
    var nivTop = null, maxN = -1; E.NIVEIS.forEach(function (v) { var c = (D.niveis && D.niveis[v]) || 0; if (c > maxN) { maxN = c; nivTop = v; } });
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Riscos — matriz de probabilidade × impacto', D.riscos.length ? avaliados.length + ' de ' + D.riscos.length + ' riscos avaliados' + (R.riscosAltos ? ' · ' + R.riscosAltos + ' em nível alto ou extremo' : '') : 'Nenhum risco cadastrado ainda');
    if (D.riscos.length) {
      var linhasM = [], p, i2;
      for (p = 5; p >= 1; p--) {
        var lin = [cel(String(p), { b: true, al: 'center', fill: 'E5E7EB', fs: 14 })];
        for (i2 = 1; i2 <= 5; i2++) { var mi = E.matrizIndice(p, i2), cnt = (D.matriz && D.matriz[p] && D.matriz[p][i2]) || 0, fh = mi.cor.replace('#', ''); lin.push(cel(cnt || '', { b: true, fs: 22, al: 'center', cor: txtSobre(fh), fill: fh })); }
        linhasM.push(lin);
      }
      s.addText('Probabilidade', { x: 0.45, y: Y0 - 0.05, w: 2.0, h: 0.3, fontSize: 12, bold: true, color: COR.cinza, fontFace: 'Calibri' });
      s.addTable([[cel('', { fill: 'E5E7EB' })].concat([1, 2, 3, 4, 5].map(function (x) { return cel(String(x), { b: true, al: 'center', fill: 'E5E7EB', fs: 14 }); }))].concat(linhasM),
        { x: 0.5, y: Y0 + 0.3, w: 6.0, colW: [0.6, 1.08, 1.08, 1.08, 1.08, 1.08], rowH: 0.7, border: { type: 'solid', pt: 1.5, color: 'FFFFFF' } });
      s.addText('Impacto  →', { x: 1.1, y: Y0 + 4.6, w: 5.4, h: 0.3, fontSize: 12, bold: true, color: COR.cinza, align: 'center', fontFace: 'Calibri' });
      s.addText('Cada célula mostra quantos riscos caem ali (valor inerente, antes dos controles).' + (semAval ? ' ' + plural(semAval, 'risco ainda não foi avaliado', 'riscos ainda não foram avaliados') + ' e não aparece(m) na matriz.' : ''), { x: 0.5, y: Y0 + 4.9, w: 6.0, h: 0.5, fontSize: 10, color: COR.cinza, fontFace: 'Calibri', valign: 'top' });
      var nivs = E.NIVEIS.slice();
      s.addChart(pptx.charts.BAR, [{ name: 'Inerente', labels: nivs, values: nivs.map(function (v) { return (D.niveis && D.niveis[v]) || 0; }) }, { name: 'Residual (após controles)', labels: nivs, values: nivs.map(function (v) { return (D.niveisRes && D.niveisRes[v]) || 0; }) }],
        { x: 6.9, y: Y0, w: 6.0, h: 5.1, barDir: 'col', barGrouping: 'clustered', chartColors: [COR.azul, COR.azulClaro], showLegend: true, legendPos: 'b', legendFontSize: 11, showValue: true, dataLabelFontSize: 12, catAxisLabelFontSize: 12, valAxisLabelFontSize: 11, valAxisMajorUnit: 1, showTitle: true, title: 'Riscos por nível', titleFontSize: 14, titleColor: COR.texto });
    } else vazio(s, 'Cadastre riscos para ver a matriz.');
    rodape(pptx, s, D, k);
    // 5. riscos — principais
    var corN = function (nv) { var c = E.COR_NIVEL[nv]; return c ? c.replace('#', '') : null; };
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Riscos — os mais relevantes', ((R.alertas && R.alertas.critico) || 0) + ' alerta(s) crítico(s) · ' + ((R.alertas && R.alertas.atencao) || 0) + ' de atenção · ' + planosAtras + ' plano(s) atrasado(s)');
    var top = D.riscos.filter(function (r) { return r.nivel; }).concat(D.riscos.filter(function (r) { return !r.nivel; })).slice(0, 9);
    if (top.length) tabela(pptx, s, ['Código', 'Risco', 'Origem', 'Inerente', 'Residual', 'Alertas'], top.map(function (r) {
      var ci = corN(r.nivel), cr = corN(r.nivelRes);
      return [cel(r.codigo, { fs: 11 }), cel(cortar(r.nome, 52), { fs: 11 }), cel(r.origem + (r.ambiente ? ': ' + cortar(r.ambiente, 26) : ''), { fs: 10 }),
        cel(r.nivel || 'Não avaliado', ci ? selo(null, ci) : { fs: 10, al: 'center', cor: COR.cinza, fill: 'E5E7EB' }), cel(r.nivelRes || '—', cr ? selo(null, cr) : { fs: 10, al: 'center', cor: COR.cinza }), cel(r.alertas || '', { al: 'center', b: true })]; }),
      0.5, Y0 - 0.05, 12.3, [1.0, 4.9, 3.2, 1.2, 1.2, 0.8], { rowH: 0.46 });
    else vazio(s, 'Nenhum risco cadastrado ainda.');
    if (D.riscos.length > top.length) s.addText('Exibindo ' + top.length + ' de ' + D.riscos.length + ' riscos, do mais grave ao menos grave. A lista completa está na planilha Excel.', { x: 0.5, y: 6.68, w: 12.3, h: 0.3, fontSize: 11, italic: true, color: COR.cinza, fontFace: 'Calibri' });
    rodape(pptx, s, D, k);
    // 6. projetos
    var concl = D.projetos.filter(function (j) { return /Conclu/.test(j.status || ''); }).length, progMed = D.projetos.length ? D.projetos.reduce(function (a, j) { return a + (+j.progresso || 0); }, 0) / D.projetos.length : 0;
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Projetos', D.projetos.length ? R.projetosAndamento + ' em andamento · ' + concl + ' concluído(s) · progresso médio de ' + num(progMed, 0) + '%' : 'Nenhum projeto cadastrado ainda');
    var pj = D.projetos.slice(0, 9);
    if (pj.length) {
      tabela(pptx, s, ['Código', 'Projeto', 'Situação', 'Período', 'Progresso'], pj.map(function (j) {
        var cor = /Conclu/.test(j.status) ? COR.verde : /Cancel/.test(j.status) ? '9CA3AF' : (j.status === 'Em andamento' ? COR.azul : '6B7280');
        return [cel(j.codigo || '', { fs: 11 }), cel(cortar(j.nome, 54), { fs: 11 }), cel(j.status || '', selo(null, cor)), cel(periodo(j.inicio, j.fim), { fs: 10 }), cel(num(j.progresso, 0) + '%', { b: true, al: 'right' })]; }),
        0.5, Y0, 12.3, [1.1, 5.6, 1.5, 2.9, 1.2], { numDe: 4, rowH: 0.5 });
      if (D.projetos.length > pj.length) s.addText('Exibindo ' + pj.length + ' de ' + D.projetos.length + '. A lista completa está na planilha Excel.', { x: 0.5, y: 6.6, w: 12, h: 0.35, fontSize: 11, color: COR.cinza, italic: true, fontFace: 'Calibri' });
    } else vazio(s, 'Cadastre projetos para acompanhá-los aqui.');
    rodape(pptx, s, D, k);
    // 7. valor estratégico
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Valor estratégico', R.icv == null ? 'Ainda sem dados suficientes para calcular o ICV' : 'ICV médio de ' + pct(R.icv, 1) + ' nos objetivos avaliados');
    if (comIcv.length) {
      s.addText('ICV por objetivo estratégico', { x: 0.5, y: Y0 - 0.05, w: 7.5, h: 0.35, fontSize: 14, bold: true, color: COR.texto, fontFace: 'Calibri' });
      comIcv.slice(0, 8).forEach(function (o, r) {
        var y = Y0 + 0.4 + r * 0.62, v = Math.max(0, Math.min(1, o.icv)), cor = COR_SIT[o.status] || COR.azul;
        s.addText((o.codigo ? o.codigo + ' · ' : '') + cortar(o.nome, 46), { x: 0.5, y: y, w: 3.9, h: 0.5, fontSize: 11, color: COR.texto, fontFace: 'Calibri', valign: 'middle', fit: 'shrink' });
        s.addShape(pptx.ShapeType.rect, { x: 4.5, y: y + 0.12, w: 2.7, h: 0.26, fill: { color: 'E5E7EB' }, line: { color: 'E5E7EB' } });
        if (v > 0) s.addShape(pptx.ShapeType.rect, { x: 4.5, y: y + 0.12, w: 2.7 * v, h: 0.26, fill: { color: cor }, line: { color: cor } });
        s.addText(pct(o.icv, 1), { x: 7.25, y: y, w: 0.8, h: 0.5, fontSize: 12, bold: true, color: COR.texto, fontFace: 'Calibri', valign: 'middle' });
      });
      s.addText('Capacidades com menor desempenho (IHC)', { x: 8.4, y: Y0 - 0.05, w: 4.5, h: 0.35, fontSize: 14, bold: true, color: COR.texto, fontFace: 'Calibri' });
      if (caps.length) tabela(pptx, s, ['Capacidade', 'IHC', 'Situação'], caps.slice(0, 8).map(function (c) { return [cel(cortar((c.codigo ? c.codigo + ' · ' : '') + c.nome, 30), { fs: 11 }), cel(pct(c.ihc, 1), { al: 'right', b: true }), cel(SIT[c.status], selo(null, COR_SIT[c.status]))]; }), 8.4, Y0 + 0.3, 4.45, [2.15, 0.8, 1.5], { numDe: 1, rowH: 0.46 });
      else s.addText('Nenhuma capacidade avaliada ainda.', { x: 8.4, y: Y0 + 0.4, w: 4.4, h: 0.4, fontSize: 13, color: COR.cinza, fontFace: 'Calibri' });
    } else vazio(s, 'Vincule indicadores às dimensões das capacidades e registre valores para calcular o ICV.');
    rodape(pptx, s, D, k);
    // 8. pendências
    s = pptx.addSlide(); k++; cabecalho(pptx, s, 'Pendências e lacunas', D.lacunas.length ? 'O que falta ligar entre os módulos' : 'Nenhuma lacuna encontrada entre os módulos');
    if (D.lacunas.length) tabela(pptx, s, ['Qtd.', 'O que falta'], D.lacunas.map(function (l) { return [cel(l[0], { b: true, al: 'center', fs: 14 }), cel(l[1], { fs: 14 })]; }), 0.5, Y0, 8.0, [1.1, 6.9], { rowH: 0.5 });
    cartao(pptx, s, 9.0, Y0, 3.85, 'Alertas de risco', D.alertas.length, ((R.alertas && R.alertas.critico) || 0) + ' crítico(s) · ' + ((R.alertas && R.alertas.atencao) || 0) + ' de atenção', 'D97706');
    s.addText('Resolver as lacunas melhora a confiabilidade dos indicadores, do valor estratégico e da gestão de riscos.', { x: 9.0, y: Y0 + 1.7, w: 3.85, h: 1.2, fontSize: 12, color: COR.cinza, italic: true, fontFace: 'Calibri', valign: 'top' });
    rodape(pptx, s, D, k);
    return pptx;
  }
  Exportar.pptx = function () {
    return lib('assets/js/pptxgen.bundle.js', function () { return !!w.PptxGenJS; }).then(function () {
      var D = Exportar.dados(), pptx = new w.PptxGenJS(); montarPptx(D, pptx);
      return pptx.write({ outputType: 'base64' });
    }).then(function (b64) { Mapris.baixarBin(nome('relatorio', 'pptx'), b64, 'application/vnd.openxmlformats-officedocument.presentationml.presentation'); if (w.SEC) SEC.audit('exportar', 'pptx'); return true; });
  };

  /* ===== Excel ===== */
  function planilha(wb, titulo, cab, linhas, o) {
    o = o || {}; var ws = wb.addWorksheet(titulo, { views: [{ state: 'frozen', ySplit: 1, xSplit: o.congelarCol || 0 }] });
    ws.addRow(cab); var hdr = ws.getRow(1);
    hdr.eachCell(function (c) { c.font = { bold: true, color: { argb: 'FFFFFFFF' }, name: 'Calibri', size: 11 }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + COR.azul } }; c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }; });
    hdr.height = 30;
    linhas.forEach(function (l) { ws.addRow(l); });
    var larg = cab.map(function (c) { return Math.min(60, Math.max(10, String(c).length + 2)); });
    linhas.forEach(function (l) { l.forEach(function (v, i) { var t = v == null ? 0 : (v instanceof Date ? 10 : String(v).length); if (t + 2 > larg[i]) larg[i] = Math.min(60, t + 2); }); });
    ws.columns.forEach(function (c, i) { c.width = larg[i]; });
    ws.eachRow(function (r, k) { if (k > 1) r.eachCell(function (c) { c.border = { top: { style: 'thin', color: { argb: 'FFE5E7EB' } }, bottom: { style: 'thin', color: { argb: 'FFE5E7EB' } } }; c.alignment = { vertical: 'top', wrapText: true }; }); });
    if (linhas.length) ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1 + linhas.length, column: cab.length } };
    (o.colorir || []).forEach(function (cc) {   // [coluna(1..), função(valor)→argb|null]
      for (var r = 2; r <= linhas.length + 1; r++) { var c = ws.getRow(r).getCell(cc[0]), argb = cc[1](c.value); if (argb) { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + argb } }; c.font = { bold: true, color: { argb: argb === 'F9A825' || argb === 'FBC02D' ? 'FF1F2937' : 'FFFFFFFF' } }; c.alignment = { horizontal: 'center', vertical: 'top' }; } }
    });
    (o.formatos || []).forEach(function (f) { for (var r = 2; r <= linhas.length + 1; r++) ws.getRow(r).getCell(f[0]).numFmt = f[1]; });
    return ws;
  }
  var corSit = function (v) { var m = { 'Em conformidade': COR.verde, 'Em atenção': COR.amarelo, 'Crítico': COR.vermelho, 'Sem dados': '9CA3AF' }; return m[v] || null; };
  var corNivel = function (v) { var c = E.COR_NIVEL[v]; return c ? c.replace('#', '').toUpperCase() : null; };
  function montarXlsx(D, wb) {
    wb.creator = 'Valor-E'; wb.created = new Date(); var R = D.resumo, I = R.indicadores;
    // Resumo
    var rs = wb.addWorksheet('Resumo'); rs.columns = [{ width: 38 }, { width: 22 }, { width: 60 }];
    rs.addRow(['Valor-E — Relatório de gestão']).font = { bold: true, size: 16, color: { argb: 'FF' + COR.azul } };
    rs.addRow(['Unidade', D.unidade || '(não informada)']); rs.addRow(['Emitido em', br(E.hoje())]); rs.addRow(['Ciclo da cadeia de valor', R.ciclo ? R.ciclo + (R.cicloValidade ? ' — ' + R.cicloValidade : '') : '']); rs.addRow([]);
    var cab = rs.addRow(['Indicador de gestão', 'Valor', 'Detalhe']); cab.eachCell(function (c) { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + COR.azul } }; });
    [['Macroprocessos', R.macros, ''], ['Processos', R.processos, ''], ['Projetos', R.projetos, R.projetosAndamento + ' em andamento'], ['Tarefas de projeto', R.tarefas, ''],
     ['Indicadores avaliáveis', I.total, I.verde + ' em conformidade · ' + I.amarelo + ' em atenção · ' + I.vermelho + ' críticos · ' + I.semDados + ' sem dados'], ['Riscos', R.riscos, R.riscosAltos + ' alto(s) ou extremo(s)'],
     ['Alertas de risco', D.alertas.length, R.alertas ? (R.alertas.critico || 0) + ' crítico(s)' : ''], ['Objetivos estratégicos', R.objetivos, ''], ['Capacidades', R.capacidades, ''], ['ICV médio', R.icv == null ? '—' : R.icv, 'índice de valor das capacidades (0 a 100%)']].forEach(function (l) { rs.addRow(l); });
    var icvRow = rs.lastRow; if (typeof icvRow.getCell(2).value === 'number') icvRow.getCell(2).numFmt = '0.0%';
    rs.addRow([]); rs.addRow(['Lacunas entre módulos']).font = { bold: true };
    if (D.lacunas.length) D.lacunas.forEach(function (l) { rs.addRow([l[1], l[0]]); }); else rs.addRow(['Nenhuma lacuna encontrada']);
    // Indicadores
    planilha(wb, 'Indicadores', ['Código', 'Indicador', 'Processo', 'Unidade de medida', 'Polaridade', 'Periodicidade', 'Responsável', 'Último mês', 'Valor atual', 'Meta', '% da meta', 'Situação'],
      D.indicadores.filter(function (i) { return i.ativo; }).map(function (i) { return [i.codigo, i.nome, i.processo || (i.progresso ? '(progresso de projeto)' : ''), i.unidade, i.polaridade, i.periodicidade, i.responsavel, i.mes, i.valor, i.meta, i.pct, SIT[i.status]]; }),
      { colorir: [[12, corSit]], formatos: [[11, '0.0%'], [9, '#,##0.##'], [10, '#,##0.##']], congelarCol: 2 });
    // Lançamentos (matriz indicador × mês)
    var meses = {}; D.indicadores.forEach(function (i) { i.serie.forEach(function (x) { meses[x.mes] = 1; }); }); var ms = Object.keys(meses).sort();
    planilha(wb, 'Lançamentos', ['Código', 'Indicador'].concat(ms.map(function (m) { return (MET.fmtMes ? MET.fmtMes(m) : m); })),
      D.indicadores.filter(function (i) { return i.ativo && i.serie.length; }).map(function (i) { var mp = {}; i.serie.forEach(function (x) { mp[x.mes] = x.valor; }); return [i.codigo, i.nome].concat(ms.map(function (m) { return mp[m] === undefined ? null : mp[m]; })); }), { congelarCol: 2 });
    // Riscos
    planilha(wb, 'Riscos', ['Código', 'Risco', 'Origem', 'Processo / projeto / ambiente', 'Categoria', 'Responsável', 'Situação', 'Resposta', 'Probabilidade', 'Impacto', 'Índice inerente', 'Nível inerente', 'Índice residual', 'Nível residual', 'Próxima revisão', 'Alertas'],
      D.riscos.map(function (r) { return [r.codigo, r.nome, r.origem, r.ambiente, r.categoria, r.responsavel, r.status, r.resposta, r.prob, r.imp, r.indice, r.nivel, r.indiceRes, r.nivelRes, br(r.proxima), r.alertas || 0]; }), { colorir: [[12, corNivel], [14, corNivel]], congelarCol: 2 });
    planilha(wb, 'Fatores e controles', ['Risco', 'Fator de risco', 'Probabilidade', 'Impacto', 'Índice', 'Controle', 'Tipo', 'Natureza', 'Eficácia (%)', 'Situação do controle'],
      D.controles.length || D.fatores.length ? D.fatores.map(function (f) { var cs = D.controles.filter(function (c) { return c.fator_id === f.id; }); return cs.length ? cs.map(function (c) { return [f.rcod, f.nome, f.probabilidade, f.impacto, f.indice, c.descricao, c.tipo_controle, c.natureza, c.eficacia, c.status]; }) : [[f.rcod, f.nome, f.probabilidade, f.impacto, f.indice, '(sem controle)', '', '', null, '']]; }).reduce(function (a, b) { return a.concat(b); }, []) : []);
    planilha(wb, 'Planos de tratamento', ['Risco', 'Plano', 'Responsável', 'Prazo', 'Situação', 'Prioridade', 'Atrasado?'],
      D.planos.map(function (p) { return [p.rcod, p.descricao, p.responsavel, br(p.prazo), p.status, p.prioridade, p.atrasado ? 'Sim' : 'Não']; }), { colorir: [[7, function (v) { return v === 'Sim' ? COR.vermelho : null; }]] });
    // Projetos
    planilha(wb, 'Projetos', ['Código', 'Projeto', 'Situação', 'Início', 'Fim', 'Responsável', 'Orçado', 'Progresso (%)', 'Objetivo estratégico', 'Iniciativa'],
      D.projetos.map(function (j) { return [j.codigo, j.nome, j.status, br(j.inicio), br(j.fim), j.responsavel, j.orcado, j.progresso, j.objetivo_cod ? j.objetivo_cod + ' ' + (j.objetivo_nome || '') : (j.objetivo_nome || ''), j.ini_nome || '']; }), { formatos: [[7, '#,##0.00'], [8, '0.0']], congelarCol: 2 });
    planilha(wb, 'Tarefas', ['Projeto', 'Tarefa', 'Início', 'Fim', 'Duração (dias)', 'Progresso (%)', 'Responsável', 'Custo'],
      D.tarefas.map(function (t) { return [t.jcod || t.jnome, (t.parent_id ? '   ' : '') + t.nome, br(t.inicio), br(t.fim), t.duracao, t.progresso, t.responsavel, t.custo]; }), { formatos: [[8, '#,##0.00']] });
    // Valor estratégico
    var vl = []; D.objetivos.forEach(function (o) { if (!o.caps.length) vl.push([o.codigo, o.nome, o.icv, SIT[o.status], '', null, null, '']); o.caps.forEach(function (c) { vl.push([o.codigo, o.nome, o.icv, SIT[o.status], (c.codigo ? c.codigo + ' ' : '') + c.nome, c.wc, c.ihc, SIT[c.status]]); }); });
    planilha(wb, 'Valor estratégico', ['Objetivo', 'Descrição', 'ICV do objetivo', 'Situação do objetivo', 'Capacidade', 'Peso (Wc)', 'IHC da capacidade', 'Situação da capacidade'], vl, { colorir: [[4, corSit], [8, corSit]], formatos: [[3, '0.0%'], [7, '0.0%'], [6, '0.00']] });
    // Processos
    planilha(wb, 'Processos', ['Macroprocesso', 'Tipo', 'Processo', 'Situação', 'Responsável', 'Riscos', 'Indicadores'], D.processos.map(function (p) { return [p.macro_nome || '(sem macroprocesso)', p.macro_tipo || '', p.nome, p.status, p.responsavel, p.nriscos, p.ninds]; }));
    return wb;
  }
  Exportar.xlsx = function () {
    return lib('assets/js/exceljs.min.js', function () { return !!w.ExcelJS; }).then(function () {
      var D = Exportar.dados(), wb = new w.ExcelJS.Workbook(); montarXlsx(D, wb);
      return wb.xlsx.writeBuffer();
    }).then(function (buf) { Mapris.baixarBin(nome('relatorio', 'xlsx'), b64DeBuffer(buf), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); if (w.SEC) SEC.audit('exportar', 'xlsx'); return true; });
  };

  /* ===== interface ===== */
  function executar(botao, fn) {
    var t = botao && botao.innerHTML; if (botao) { botao.disabled = true; botao.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Gerando…'; }
    fn().then(function () { if (botao) { botao.disabled = false; botao.innerHTML = t; } }, function (e) { if (botao) { botao.disabled = false; botao.innerHTML = t; } alert('Não foi possível gerar o arquivo: ' + (e && e.message || e)); });
  }
  Exportar.pptxUI = function (b) { executar(b, Exportar.pptx); };
  Exportar.xlsxUI = function (b) { executar(b, Exportar.xlsx); };
  /** Botões para o cabeçalho do Painel. */
  Exportar.botoes = function () {
    return '<div class="dropdown me-3"><button class="btn btn-sm btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-box-arrow-up-right"></i> Exportar relatório</button><ul class="dropdown-menu dropdown-menu-end">' +
      '<li><button class="dropdown-item" onclick="Exportar.pptxUI(this)"><i class="bi bi-file-earmark-slides"></i> Apresentação (PowerPoint .pptx)</button></li>' +
      '<li><button class="dropdown-item" onclick="Exportar.xlsxUI(this)"><i class="bi bi-file-earmark-excel"></i> Planilha (Excel .xlsx)</button></li></ul></div>';
  };
  /** Cartão para a tela Exportar / importar. */
  Exportar.cartao = function () {
    return '<div class="cartao mb-3"><h2><i class="bi bi-easel"></i> Relatórios para a direção</h2><div class="corpo">' +
      '<p class="ajuda">Gere uma <b>apresentação PowerPoint</b> (capa, visão geral, indicadores, riscos, projetos, valor estratégico e pendências) ou uma <b>planilha Excel</b> com os dados detalhados (indicadores e lançamentos, riscos, controles, planos, projetos, tarefas, valor estratégico e processos). Os números são os mesmos das telas do aplicativo. Funciona sem internet.</p>' +
      '<div class="d-flex flex-wrap gap-2"><button class="btn btn-primary" onclick="Exportar.pptxUI(this)"><i class="bi bi-file-earmark-slides"></i> Apresentação (.pptx)</button><button class="btn btn-success" onclick="Exportar.xlsxUI(this)"><i class="bi bi-file-earmark-excel"></i> Planilha (.xlsx)</button></div></div></div>';
  };
})(window);
