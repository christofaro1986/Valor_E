(function (DB) {
/* met.js — Metodologia Valor-E v1.0 (porte fiel de metodologia_v1.php) */
(function (w) {
  'use strict';
  var M = w.MET = {};
  var ABC_A = 0.80, ABC_B = 0.95;

  /* ---- Datas BR ---- */
  M.fmtData = function (iso) {
    if (!iso) return '—';
    var s = String(iso).trim();
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return m[3] + '/' + m[2] + '/' + m[1];
    m = s.match(/^(\d{4})-(\d{2})$/);
    if (m) return m[2] + '/' + m[1];
    m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (m) return s;
    return s;
  };
  M.parseData = function (br) {
    if (!br) return null;
    var s = String(br).trim();
    var m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (m) {
      var d = m[1].padStart(2, '0'), mo = m[2].padStart(2, '0');
      return m[3] + '-' + mo + '-' + d;
    }
    m = s.match(/^(\d{1,2})\/(\d{4})$/);
    if (m) return m[2] + '-' + m[1].padStart(2, '0');
    m = s.match(/^(\d{4})-(\d{2})(-\d{2})?$/);
    if (m) return s.length === 7 ? s : s.slice(0, 10);
    return null;
  };
  M.fmtMes = function (ym) {
    if (!ym) return '—';
    var s = String(ym).trim();
    var m = s.match(/^(\d{4})-(\d{2})/);
    if (m) return m[2] + '/' + m[1];
    m = s.match(/^(\d{2})\/(\d{4})$/);
    if (m) return s;
    return s;
  };
  M.parseMes = function (br) {
    if (!br) return null;
    var s = String(br).trim();
    var m = s.match(/^(\d{1,2})\/(\d{4})$/);
    if (m) return m[2] + '-' + m[1].padStart(2, '0');
    m = s.match(/^(\d{4})-(\d{2})$/);
    if (m) return s;
    return null;
  };

;
  var ABC_A = 0.80, ABC_B = 0.95;

  function limitar(v, min, max) { return Math.max(min, Math.min(max, v)); }

  M.normalizarAtingimento = function (valor, linhaBase, meta, polaridade) {
    if (valor == null || linhaBase == null || meta == null) return null;
    if (Math.abs(meta - linhaBase) < 1e-12) return null;
    var a;
    if (polaridade === 'menor_melhor') a = (linhaBase - valor) / (linhaBase - meta);
    else a = (valor - linhaBase) / (meta - linhaBase);
    return limitar(a, 0, 1);
  };

  M.desvio = function (a) { return Math.max(0, 1 - a); };
  M.deficitPonderado = function (grh, a) { return grh * M.desvio(a); };

  M.calcularIHC = function (indicadores) {
    var validos = [], somaGrh = 0;
    (indicadores || []).forEach(function (ind) {
      if (!ind.valido || ind.a == null || ind.grh == null) return;
      validos.push(ind);
      somaGrh += +ind.grh;
    });
    if (!validos.length) {
      return { ihc: null, cobertura: 0, status: 'nao_monitorada', deficit_total: null, itens: [], mensagem: 'Nenhum indicador válido. Capacidade marcada como não monitorada.' };
    }
    var fator = somaGrh > 0 ? 1 / somaGrh : 1;
    var ihc = 0, deficitTotal = 0, itens = [];
    validos.forEach(function (ind) {
      var grhNorm = +ind.grh * fator, a = +ind.a, d = M.deficitPonderado(grhNorm, a);
      ihc += grhNorm * a;
      deficitTotal += d;
      itens.push({
        id: ind.id, codigo: ind.codigo, nome: ind.nome,
        grh: grhNorm, grh_original: +ind.grh, grh_norm: grhNorm, a: a, g: M.desvio(a), d: d,
        valor: ind.valor, meta: ind.meta, fator_codigo: ind.fator_codigo, fator_nome: ind.fator_nome,
        participacao: null, classe_abc: null
      });
    });
    var cobertura = Math.min(1, somaGrh);
    return {
      ihc: limitar(ihc, 0, 1),
      cobertura: cobertura,
      status: cobertura < 0.999 ? 'parcial' : 'completo',
      deficit_total: deficitTotal,
      itens: itens
    };
  };

  M.classificarABC = function (res) {
    if (!res || !res.itens || !res.itens.length) return res;
    var itens = res.itens.slice().sort(function (a, b) { return (b.d || 0) - (a.d || 0); });
    var total = itens.reduce(function (s, x) { return s + (x.d || 0); }, 0) || 1;
    var acum = 0;
    itens.forEach(function (it) {
      acum += it.d || 0;
      it.participacao = (it.d || 0) / total;
      var ca = acum / total;
      it.classe_abc = ca <= ABC_A ? 'A' : ca <= ABC_B ? 'B' : 'C';
    });
    res.itens = itens;
    return res;
  };

  M.calcularICV = function (capacidades, linhaBaseOe, metaOe) {
    var validos = [], somaWc = 0;
    (capacidades || []).forEach(function (c) {
      if (!c.valido || c.ihc == null || c.wc == null) return;
      validos.push(c);
      somaWc += +c.wc;
    });
    if (!validos.length) {
      return { icv: null, p_oe: null, cobertura: 0, status: 'nao_monitorada', itens: [] };
    }
    var fator = somaWc > 0 ? 1 / somaWc : 1;
    var pOe = 0, itens = [];
    validos.forEach(function (c) {
      var wcN = +c.wc * fator, ihc = +c.ihc, contrib = wcN * ihc;
      pOe += contrib;
      itens.push({ id: c.id, nome: c.nome, codigo: c.codigo, wc: +c.wc, wc_norm: wcN, ihc: ihc, contribuicao: contrib });
    });
    pOe = limitar(pOe, 0, 1);
    var icv = null;
    if (linhaBaseOe != null && metaOe != null && Math.abs(metaOe - linhaBaseOe) > 1e-12) {
      icv = limitar((pOe - linhaBaseOe) / (metaOe - linhaBaseOe), 0, 1);
    }
    return {
      icv: icv,
      p_oe: pOe,
      cobertura: Math.min(1, somaWc),
      status: Math.min(1, somaWc) < 0.999 ? 'parcial' : 'completo',
      itens: itens
    };
  };

  M.deficitEstrategico = function (caps) {
    var itens = [], total = 0;
    (caps || []).forEach(function (cap) {
      if (cap.ihc == null || cap.wc == null) return;
      var metaReq = cap.meta_requerida != null ? +cap.meta_requerida : 1;
      var d = +cap.wc * Math.max(0, metaReq - +cap.ihc);
      total += d;
      itens.push({ id: cap.id, nome: cap.nome, codigo: cap.codigo, wc: +cap.wc, ihc: +cap.ihc, meta_requerida: metaReq, d: d, classe_abc: null });
    });
    itens.sort(function (a, b) { return b.d - a.d; });
    var acum = 0, den = total || 1;
    itens.forEach(function (it) {
      acum += it.d;
      var ca = acum / den;
      it.classe_abc = ca <= ABC_A ? 'A' : ca <= ABC_B ? 'B' : 'C';
    });
    return { total: total, itens: itens };
  };


  /* ---- AHP ---- */
  /** Escala Saaty 1–9; matriz[i][j] = importância de i sobre j */
  M.statusIndicador = function (atingimento) {
    if (atingimento == null || isNaN(atingimento)) return { key: 'sem-dados', label: 'Sem dados' };
    if (atingimento > 0.85) return { key: 'ok', label: 'No alvo' };
    if (atingimento >= 0.60) return { key: 'atencao', label: 'Atenção' };
    return { key: 'critico', label: 'Crítico' };
  };
  M.distanciaMeta = function (valor, meta, polaridade) {
    if (valor == null || meta == null || isNaN(valor) || isNaN(meta)) return null;
    if (polaridade === 'menor_melhor') return valor - meta; // positivo = pior
    return meta - valor; // positivo = falta atingir
  };
  M.ahpPesos = function (matriz) {
    var n = matriz.length;
    if (n < 1) return { pesos: [], rc: 0, consistente: true, lambda_max: 1 };
    if (n === 1) return { pesos: [1], rc: 0, consistente: true, lambda_max: 1 };
    // média geométrica das linhas + normalização
    var pesos = [], soma = 0;
    for (var i = 0; i < n; i++) {
      var prod = 1;
      for (var j = 0; j < n; j++) prod *= (matriz[i][j] > 0 ? matriz[i][j] : 1);
      var g = Math.pow(prod, 1 / n);
      pesos.push(g);
      soma += g;
    }
    for (i = 0; i < n; i++) pesos[i] /= (soma || 1);
    // λ_max aproximado
    var lambda = 0;
    for (i = 0; i < n; i++) {
      var s = 0;
      for (j = 0; j < n; j++) s += matriz[i][j] * pesos[j];
      lambda += s / (pesos[i] || 1e-12);
    }
    lambda /= n;
    var CI = n > 1 ? (lambda - n) / (n - 1) : 0;
    // RI Saaty
    var RI = [0, 0, 0, 0.58, 0.90, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49, 1.51, 1.48, 1.56, 1.57, 1.59];
    var ri = n < RI.length ? RI[n] : 1.59;
    var RC = ri > 0 ? CI / ri : 0;
    return { pesos: pesos, rc: RC, consistente: RC <= 0.10, lambda_max: lambda, ci: CI };
  };

  M.ahpMatrizIdentidade = function (n) {
    var m = [];
    for (var i = 0; i < n; i++) {
      m[i] = [];
      for (var j = 0; j < n; j++) m[i][j] = i === j ? 1 : 1;
    }
    return m;
  };

  /** Converte escolha UI (i melhor que j por k, ou iguais) em valor Saaty */
  M.ahpValor = function (lado, intensidade) {
    // lado: 'a' | 'b' | 'eq'; intensidade 1..9
    if (lado === 'eq') return 1;
    var k = Math.max(1, Math.min(9, +intensidade || 1));
    return lado === 'a' ? k : 1 / k;
  };

  /* ====================================================================
   * DOMÍNIO v3 — modelo SISREL: metas por ciclos do indicador, situação e risco
   * ==================================================================== */

  /* Limites da escala (fração da meta). Ver Metodologia: tolerância de 10% (conformidade)
   * + 15 p.p. adicionais (atenção); abaixo disso, crítico. */
  M.LIM = { conf: 0.90, aten: 0.75 };
  M.ROTULO = { ok: 'Em conformidade', atencao: 'Em atenção', critico: 'Crítico', 'sem-dados': 'Sem dados' };
  M.ROTULO_F = { ok: 'Em conformidade', atencao: 'Em atenção', critico: 'Crítica', 'sem-dados': 'Não avaliada' };
  M.RISCO = { ok: 'Baixo', atencao: 'Médio', critico: 'Alto', 'sem-dados': 'Sem dados' };
  M.classe = function (p) {
    if (p == null || isNaN(p)) return 'sem-dados';
    if (p + 1e-9 >= M.LIM.conf) return 'ok';
    if (p + 1e-9 >= M.LIM.aten) return 'atencao';
    return 'critico';
  };
  M.statusIndicador = function (a) { var k = M.classe(a); return { key: k, label: M.ROTULO[k] }; };
  M.pior = function (lista) {
    var ordem = { critico: 3, atencao: 2, ok: 1, 'sem-dados': 0 }, r = 'sem-dados';
    (lista || []).forEach(function (k) { if ((ordem[k] || 0) > ordem[r]) r = k; });
    return r;
  };

  /** Percentual do valor em relação à meta (fração; maior = melhor). Porte de calcularPercentualMeta do SISREL. */
  M.pctMeta = function (valor, meta, pol, refPior) {
    var v = parseFloat(valor), m = parseFloat(meta);
    if (isNaN(v)) return null;
    if (pol === 'menor_melhor') {
      if (v <= 0) return 1;
      if (!isNaN(m) && m === 0) {
        var r = parseFloat(refPior);
        if (!(r > 0)) return 0;
        return Math.max(0, Math.min(1, 1 - v / r));
      }
      if (v > 0 && m > 0) return Math.min(9.999, m / v);
      return null;
    }
    if (isNaN(m) || m <= 0) return null;
    return v / m;
  };
  M.distanciaMeta = function (valor, meta, pol) {
    if (valor == null || meta == null || isNaN(valor) || isNaN(meta)) return null;
    return pol === 'menor_melhor' ? valor - meta : meta - valor; // positivo = ainda distante da meta
  };

  /* ---- Ciclos de metas do indicador (SISREL) ---- */
  M.ciclosInd = function (indId) {
    return DB.rows('SELECT * FROM ind_ciclos WHERE indicador_id=? ORDER BY data_inicio, id', [indId]);
  };
  M.metaDoMes = function (ciclos, mes) {
    ciclos = (ciclos || []).slice().sort(function (a, b) { return String(a.data_inicio).localeCompare(String(b.data_inicio)); });
    if (!ciclos.length) return null;
    mes = String(mes || '').slice(0, 7);
    var i, c, ini, fim, m;
    if (mes) {
      for (i = 0; i < ciclos.length; i++) {
        c = ciclos[i]; ini = String(c.data_inicio || '').slice(0, 7); fim = String(c.data_fim || '').slice(0, 7);
        if (ini && fim && mes >= ini && mes <= fim) { m = parseFloat(c.meta); if (!isNaN(m)) return m; }
      }
      var primeiro = String(ciclos[0].data_inicio || '').slice(0, 7);
      if (primeiro && mes < primeiro) { m = parseFloat(ciclos[0].meta); return isNaN(m) ? null : m; }
      var cand = null;
      for (i = 0; i < ciclos.length; i++) { fim = String(ciclos[i].data_fim || '').slice(0, 7); if (fim && fim <= mes) cand = ciclos[i]; }
      if (cand) { m = parseFloat(cand.meta); return isNaN(m) ? null : m; }
    }
    m = parseFloat(ciclos[ciclos.length - 1].meta);
    return isNaN(m) ? null : m;
  };
  M.cicloVigenteInd = function (ciclos) {
    var hoje = new Date().toISOString().slice(0, 7), r = null;
    (ciclos || []).forEach(function (c) { if (String(c.data_inicio).slice(0, 7) <= hoje && hoje <= String(c.data_fim).slice(0, 7)) r = c; });
    return r || (ciclos && ciclos.length ? ciclos[ciclos.length - 1] : null);
  };

  /* ---- Posição em uma data de corte (viagem no tempo): considera só lançamentos até o mês informado ---- */
  M.CORTE = null;
  M.comCorte = function (mes, fn) { var ant = M.CORTE; M.CORTE = mes || null; try { return fn(); } finally { M.CORTE = ant; } };
  M.meses = function () {
    var s = {}; DB.rows('SELECT DISTINCT mes_ano m FROM lanc_ind UNION SELECT DISTINCT mes_ano FROM lanc_itm').forEach(function (r) { if (r.m) s[String(r.m).slice(0, 7)] = 1; });
    return Object.keys(s).sort();
  };

  M.itensIndicador = function (indId) {
    return DB.rows('SELECT * FROM indicador_itens WHERE indicador_id=? ORDER BY ordem, id', [indId]);
  };

  /** Avaliação completa de um indicador (linha da tabela `indicadores`). */
  M.avaliarIndicador = function (ind) {
    var pol = ind.polaridade || 'maior_melhor', ciclos = M.ciclosInd(ind.id), mult = ind.tipo === 'multiplo';
    var itens = mult ? M.itensIndicador(ind.id) : [], serie = [], itensRes = [];
    if (mult) {
      var soma = 0; itens.forEach(function (i) { soma += (+i.peso > 0 ? +i.peso : 0); });
      var porMes = {};
      itens.forEach(function (it) {
        var peso = (+it.peso > 0 ? +it.peso : (soma > 0 ? 0 : 1));
        var regs = DB.rows('SELECT id, mes_ano, valor, observacao FROM lanc_itm WHERE item_id=?' + (M.CORTE ? ' AND mes_ano<=?' : '') + ' ORDER BY mes_ano', M.CORTE ? [it.id, M.CORTE] : [it.id]);
        var ref = 0; regs.forEach(function (r) { if (r.valor != null && +r.valor > ref) ref = +r.valor; });
        var u = regs.length ? regs[regs.length - 1] : null, pctIt = null;
        if (u && u.valor != null) pctIt = M.pctMeta(+u.valor, M.metaDoMes(ciclos, u.mes_ano), pol, ref);
        itensRes.push({ id: it.id, nome: it.nome, unidade: it.unidade, peso: it.peso, valor: u ? u.valor : null, mes: u ? u.mes_ano : null, pct: pctIt, status: M.classe(pctIt), registros: regs });
        regs.forEach(function (r) {
          if (r.valor == null) return;
          var o = porMes[r.mes_ano] || (porMes[r.mes_ano] = { s: 0, p: 0 });
          o.s += peso * (+r.valor); o.p += peso;
        });
      });
      Object.keys(porMes).sort().forEach(function (mes) { var o = porMes[mes]; if (o.p > 0) serie.push({ mes: mes, valor: o.s / o.p }); });
    } else {
      DB.rows('SELECT id, mes_ano, valor, observacao FROM lanc_ind WHERE indicador_id=?' + (M.CORTE ? ' AND mes_ano<=?' : '') + ' ORDER BY mes_ano', M.CORTE ? [ind.id, M.CORTE] : [ind.id]).forEach(function (r) {
        if (r.valor != null) serie.push({ id: r.id, mes: r.mes_ano, valor: +r.valor, observacao: r.observacao });
      });
    }
    var ref2 = 0; serie.forEach(function (x) { if (x.valor > ref2) ref2 = x.valor; });
    serie.forEach(function (x) { x.meta = M.metaDoMes(ciclos, x.mes); x.pct = M.pctMeta(x.valor, x.meta, pol, ref2); });
    var last = serie.length ? serie[serie.length - 1] : null;
    var pct = last ? last.pct : null, status = M.classe(pct);
    if (mult && itensRes.length) {
      var piores = itensRes.filter(function (x) { return x.pct != null; }).map(function (x) { return x.status; });
      if (piores.length) {
        status = M.pior(piores);
        pct = Math.min.apply(null, itensRes.filter(function (x) { return x.pct != null; }).map(function (x) { return x.pct; })); // pior item (regra SISREL)
      }
    }
    var vig = M.cicloVigenteInd(ciclos), metaAtual = last ? last.meta : (vig ? +vig.meta : null);
    return {
      id: ind.id, ind: ind, tipo: ind.tipo || 'simples', polaridade: pol, ciclos: ciclos, itens: itensRes,
      serie: serie, valor: last ? last.valor : null, mes: last ? last.mes : null, meta: metaAtual,
      pct: pct, a: pct == null ? null : Math.min(1, Math.max(0, pct)), status: status, risco: M.RISCO[status],
      desvio: last ? M.distanciaMeta(last.valor, last.meta, pol) : null, ativo: (ind.status || 'ativo') === 'ativo'
    };
  };

  /** Dimensões (fatores) de uma capacidade com seus indicadores já avaliados. */
  M.dimensoes = function (capId, incluirInativos) {
    var fats = DB.rows("SELECT * FROM fatores_determinantes WHERE capacidade_id=? AND status='ativo' ORDER BY codigo, id", [capId]);
    return fats.map(function (f) {
      var rows = DB.rows(
        "SELECT i.*, x.grh FROM indicadores i JOIN indicador_fatores x ON x.indicador_id=i.id WHERE x.fator_id=? ORDER BY i.codigo, i.id", [f.id]);
      var inds = rows.map(function (r) { var e = M.avaliarIndicador(r); e.grh = r.grh; return e; });
      var ativos = inds.filter(function (x) { return x.ativo; });
      return { f: f, inds: inds, ativos: ativos, inativos: inds.filter(function (x) { return !x.ativo; }), status: M.pior(ativos.map(function (x) { return x.status; })) };
    });
  };

  /** Pesos GRH efetivos na dimensão (normalizados entre indicadores ativos com dados). */
  function pesosDim(ativos) {
    var vals = ativos.filter(function (x) { return x.a != null; });
    var soma = 0; vals.forEach(function (x) { soma += (+x.grh > 0 ? +x.grh : 0); });
    var out = {};
    vals.forEach(function (x) { out[x.id] = soma > 0 ? (+x.grh > 0 ? +x.grh : 0) / soma : 1 / vals.length; });
    return out;
  }

  /** IHC da capacidade: média (peso igual) do desempenho das dimensões; cada dimensão = Σ GRH×a. */
  M.ihcCapacidade = function (capId) {
    var dims = M.dimensoes(capId), validos = [], itens = [], totalDims = dims.length;
    dims.forEach(function (d) {
      var pw = pesosDim(d.ativos), vals = d.ativos.filter(function (x) { return x.a != null; });
      if (!vals.length) { d.desempenho = null; return; }
      var perf = 0; vals.forEach(function (x) { perf += pw[x.id] * x.a; });
      d.desempenho = perf; d.pw = pw; validos.push(d);
    });
    var ihc = null, deficitTotal = 0;
    if (validos.length) {
      ihc = 0;
      validos.forEach(function (d) {
        ihc += d.desempenho / validos.length;
        d.ativos.forEach(function (x) {
          if (x.a == null) return;
          var g = d.pw[x.id] / validos.length, def = g * Math.max(0, 1 - x.a);
          deficitTotal += def;
          itens.push({ id: x.id, nome: x.ind.nome, codigo: x.ind.codigo, grh: g, a: x.a, d: def, fator_codigo: d.f.codigo, essencial: d.f.essencial });
        });
      });
      ihc = Math.min(1, Math.max(0, ihc));
    }
    itens.sort(function (a, b) { return b.d - a.d; });
    var acum = 0, den = deficitTotal || 1;
    itens.forEach(function (it) { acum += it.d; it.participacao = it.d / den; var ca = acum / den; it.classe_abc = it.d <= 0 ? 'C' : (ca <= 0.80 ? 'A' : ca <= 0.95 ? 'B' : 'C'); });
    var todos = []; dims.forEach(function (d) { d.ativos.forEach(function (x) { todos.push(x); }); });
    var com = todos.filter(function (x) { return x.a != null; });
    var desvioMedio = com.length ? com.reduce(function (s, x) { return s + (1 - x.a); }, 0) / com.length : null;
    var essenciaisCrit = dims.filter(function (d) { return d.f.essencial && d.status === 'critico'; }).map(function (d) { return d.f.codigo; });
    var cont = { ok: 0, atencao: 0, critico: 0, 'sem-dados': 0 };
    todos.forEach(function (x) { cont[x.status]++; });
    var status = M.classe(ihc);
    return {
      ihc: ihc, status: status, risco: M.RISCO[status], cobertura: totalDims ? validos.length / totalDims : 0,
      parcial: totalDims > 0 && validos.length < totalDims, dims: dims, itens: itens, deficit_total: deficitTotal,
      desvioMedio: desvioMedio, contadores: cont, totalInds: todos.length, essenciaisCrit: essenciaisCrit,
      pior: todos.filter(function (x) { return x.pct != null; }).sort(function (a, b) { return a.pct - b.pct; })[0] || null
    };
  };

  M.capacidadesDoObjetivo = function (objId) {
    return DB.rows("SELECT c.*, oc.wc, oc.meta_requerida FROM objetivo_capacidades oc JOIN capacidades c ON c.id=oc.capacidade_id WHERE oc.objetivo_id=? AND c.status='ativo' ORDER BY c.codigo", [objId]);
  };
  M.objetivoDaCapacidade = function (capId) {
    return DB.one("SELECT o.* FROM objetivo_capacidades oc JOIN objetivos_estrategicos o ON o.id=oc.objetivo_id WHERE oc.capacidade_id=? ORDER BY oc.id LIMIT 1", [capId]);
  };

  /** ICV do objetivo: P(OE) = Σ Wc × IHC (pesos normalizados entre as capacidades avaliadas). */
  M.icvObjetivo = function (objId) {
    var caps = M.capacidadesDoObjetivo(objId).map(function (c) { var r = M.ihcCapacidade(c.id); return { c: c, wc: +c.wc || 0, res: r, ihc: r.ihc }; });
    var vals = caps.filter(function (x) { return x.ihc != null; }), soma = 0;
    vals.forEach(function (x) { soma += x.wc; });
    var icv = null;
    if (vals.length) {
      icv = 0;
      vals.forEach(function (x) { x.wcN = soma > 0 ? x.wc / soma : 1 / vals.length; x.contrib = x.wcN * x.ihc; icv += x.contrib; });
      icv = Math.min(1, Math.max(0, icv));
    }
    var pesoDefinido = caps.length > 0 && caps.every(function (x) { return x.wc > 0; });
    var st = M.classe(icv), ab = [], tot = 0;
    vals.forEach(function (x) { x.d = x.wcN * Math.max(0, 1 - x.ihc); tot += x.d; });
    var ord = vals.slice().sort(function (a, b) { return b.d - a.d; }), ac = 0;
    ord.forEach(function (x) { ac += x.d; var ca = tot > 0 ? ac / tot : 1; x.abc = x.d <= 0 ? 'C' : (ca <= 0.8 ? 'A' : ca <= 0.95 ? 'B' : 'C'); });
    return { caps: caps, icv: icv, status: st, risco: M.RISCO[st], cobertura: caps.length ? vals.length / caps.length : 0, parcial: vals.length < caps.length, pesoDefinido: pesoDefinido };
  };

  M.proximoCodigoInd = function () {
    var r = DB.one("SELECT COUNT(*) n FROM indicadores").n + 1, cod;
    do { cod = 'IND-' + String(r).padStart(3, '0'); r++; } while (DB.one('SELECT id FROM indicadores WHERE codigo=?', [cod]));
    return cod;
  };

  /* ---- Análise de dispersão (Six Sigma, exploratória) ---- */
  M.dispersao = function (e) {
    var v = e.serie.map(function (x) { return x.valor; });
    if (v.length < 6 || e.meta == null) return null;
    var n = v.length, mu = v.reduce(function (s, x) { return s + x; }, 0) / n;
    var sd = Math.sqrt(v.reduce(function (s, x) { return s + (x - mu) * (x - mu); }, 0) / (n - 1));
    if (!(sd > 0)) return null;
    var z = e.polaridade === 'menor_melhor' ? (mu - e.meta) / sd : (e.meta - mu) / sd;
    return { n: n, media: mu, desvio: sd, z: Math.max(0, z) };
  };

  /* ---- Verificação antes da apuração (critérios de cálculo) ---- */
  M.validar = function () {
    var res = [], objs = DB.rows("SELECT * FROM objetivos_estrategicos WHERE status='ativo' ORDER BY codigo");
    var inds = DB.rows("SELECT DISTINCT i.* FROM indicadores i JOIN indicador_fatores x ON x.indicador_id=i.id WHERE i.status='ativo' ORDER BY i.codigo");
    function item(chave, titulo, probs, okTxt) { res.push({ chave: chave, titulo: titulo, ok: !probs.length, detalhe: probs.length ? probs.length + ' pendência(s)' : okTxt, problemas: probs }); }
    item('oe', 'Objetivos estratégicos formalmente definidos', objs.length ? [] : ['Nenhum objetivo estratégico cadastrado.'], objs.length + ' objetivo(s)');
    var p = [];
    objs.forEach(function (o) { if (!DB.one('SELECT COUNT(*) n FROM objetivo_capacidades WHERE objetivo_id=?', [o.id]).n) p.push(o.codigo + ': sem capacidades vinculadas.'); });
    DB.rows("SELECT c.codigo FROM capacidades c WHERE c.status='ativo' AND c.id NOT IN (SELECT capacidade_id FROM objetivo_capacidades)").forEach(function (c) { p.push(c.codigo + ': capacidade sem objetivo estratégico.'); });
    item('cap', 'Capacidades relacionadas aos objetivos', p, 'Todas as capacidades e objetivos estão relacionados');
    p = [];
    DB.rows("SELECT id, codigo FROM capacidades WHERE status='ativo'").forEach(function (c) {
      if (!DB.one("SELECT COUNT(*) n FROM fatores_determinantes WHERE capacidade_id=? AND status='ativo'", [c.id]).n) p.push(c.codigo + ': sem dimensões (fatores determinantes).');
    });
    item('fat', 'Dimensões (fatores determinantes) identificadas', p, 'Todas as capacidades possuem dimensões');
    p = [];
    DB.rows("SELECT f.id, f.codigo FROM fatores_determinantes f JOIN capacidades c ON c.id=f.capacidade_id WHERE f.status='ativo' AND c.status='ativo'").forEach(function (f) {
      if (!DB.one("SELECT COUNT(*) n FROM indicador_fatores x JOIN indicadores i ON i.id=x.indicador_id WHERE x.fator_id=? AND i.status='ativo'", [f.id]).n) p.push('Dimensão ' + f.codigo + ': sem indicadores ativos.');
    });
    inds.forEach(function (i) { if (i.tipo === 'multiplo' && !M.itensIndicador(i.id).length) p.push(i.codigo + ': indicador múltiplo sem itens.'); });
    item('ind', 'Indicadores definidos em cada dimensão', p, inds.length + ' indicador(es) ativo(s)');
    p = []; var q = [];
    inds.forEach(function (i) {
      var cs = M.ciclosInd(i.id);
      if (!cs.length) { p.push(i.codigo + ': defina ao menos um ciclo de meta.'); return; }
      cs.forEach(function (c) { if (!(+c.meta > 0) && i.polaridade !== 'menor_melhor') q.push(i.codigo + ': meta zero com polaridade "maior é melhor".'); if (c.data_fim < c.data_inicio) q.push(i.codigo + ': ciclo com término anterior ao início.'); });
    });
    p = []; var cesc = M.ciclos();
    if (!cesc.length) p.push('Nenhum ciclo estratégico cadastrado (Valor Estratégico ▸ Ciclos e metas): as metas dos objetivos valem 100%.');
    else { var cv = M.cicloVigente(); objs.forEach(function (o) { if (cv && !M.metaObjetivo(o.id, cv.id)) p.push(o.codigo + ': sem meta no ciclo ' + cv.nome + '.'); }); }
    item('cicloOe', 'Ciclo estratégico e metas dos objetivos', p, 'Todos os objetivos possuem meta no ciclo vigente');
    item('meta', 'Ciclos e metas definidos nos indicadores', p, 'Todos os indicadores possuem ciclo e meta');
    item('pol', 'Metas e polaridades coerentes', q, 'Metas coerentes com as polaridades');
    p = [];
    DB.rows("SELECT f.id, f.codigo FROM fatores_determinantes f WHERE f.status='ativo'").forEach(function (f) {
      var r = DB.one("SELECT COUNT(*) n, SUM(x.grh) s FROM indicador_fatores x JOIN indicadores i ON i.id=x.indicador_id WHERE x.fator_id=? AND i.status='ativo'", [f.id]);
      if (r.n > 1 && Math.abs((r.s || 0) - 1) > 0.01) p.push('Pesos GRH da dimensão ' + f.codigo + ' somam ' + (Math.round((r.s || 0) * 1000) / 1000) + ' (devem somar 1 — use o AHP).');
    });
    objs.forEach(function (o) {
      var r = DB.one('SELECT COUNT(*) n, SUM(wc) s FROM objetivo_capacidades WHERE objetivo_id=?', [o.id]);
      if (r.n > 1 && Math.abs((r.s || 0) - 1) > 0.01) p.push('Pesos Wc do objetivo ' + o.codigo + ' somam ' + (Math.round((r.s || 0) * 1000) / 1000) + ' (devem somar 1 — use o AHP).');
    });
    item('pesos', 'Pesos GRH e Wc consistentes (somam 1)', p, 'Pesos consistentes');
    p = [];
    inds.forEach(function (i) {
      var n = i.tipo === 'multiplo' ? DB.one('SELECT COUNT(*) n FROM lanc_itm WHERE indicador_id=?', [i.id]).n : DB.one('SELECT COUNT(*) n FROM lanc_ind WHERE indicador_id=?', [i.id]).n;
      if (!n) p.push(i.codigo + ': sem registros apurados.');
    });
    item('dados', 'Dados disponíveis e rastreáveis', p, 'Todos os indicadores possuem registros');
    p = [];
    inds.forEach(function (i) { if (!i.om_responsavel && !i.responsavel) p.push(i.codigo + ': organização/responsável não definido.'); });
    item('resp', 'Responsáveis pela apuração definidos', p, 'Responsáveis definidos');
    res.push({ chave: 'crit', titulo: 'Critérios de cálculo registrados', ok: true, detalhe: 'metodologia do módulo Valor Estratégico', problemas: [] });
    return res;
  };

  M.registrarHistorico = function (tipo, ref, desc) {
    try { DB.run('INSERT INTO historico (tipo, ciclo_id, descricao) VALUES (?,?,?)', [tipo, ref || null, desc]); } catch (e) {}
  };

  /* ===== VEB-C: ciclos estratégicos, metas dos objetivos por ciclo, Curva ABC e desvio Six Sigma ===== */
  M.ABC_OBJ = { conf: 0.95, aten: 0.75 };          // Tabela 1 do referencial: >95% conformidade · 75–95% atenção · <75% crítico
  M.SIGMA_LIM = { baixo: 0.05, alto: 0.25 };        // Tabela 2: <5% baixo · 5–25% médio · >25% alto
  M.SIGMA_ROT = { baixo: 'Risco Baixo', medio: 'Risco Médio', alto: 'Risco Alto' };
  M.SIGMA_TXT = {
    baixo: 'Variabilidade controlada e aderente à tolerância operacional definida para o ciclo.',
    medio: 'Oscilação moderada frente à meta; exige análise de causas e mitigação preventiva.',
    alto: 'Severidade elevada de desvio; compromete a previsibilidade e requer ação corretiva imediata.'
  };
  M.ABC_TXT = {
    ok: 'Habilitação ou entrega aderente ao patamar esperado; manter monitoramento rotineiro.',
    atencao: 'Desempenho intermediário com sinal de alerta; requer acompanhamento preventivo e ajustes pontuais.',
    critico: 'Déficit relevante de habilitação ou resultado; demanda intervenção prioritária no plano de ação.'
  };
  M.classeObj = function (a) {
    if (a == null || isNaN(a)) return 'sem-dados';
    if (a > M.ABC_OBJ.conf + 1e-9) return 'ok';
    if (a + 1e-9 >= M.ABC_OBJ.aten) return 'atencao';
    return 'critico';
  };
  M.sigmaDesvio = function (d) {
    if (d == null || isNaN(d)) return null;
    if (d < M.SIGMA_LIM.baixo - 1e-9) return 'baixo';
    if (d <= M.SIGMA_LIM.alto + 1e-9) return 'medio';
    return 'alto';
  };
  M.ciclos = function () { try { return DB.rows('SELECT * FROM ciclos_estrategicos ORDER BY data_inicio, id'); } catch (e) { return []; } };
  M.cicloVigente = function () {
    var hoje = new Date().toISOString().slice(0, 10), cs = M.ciclos();
    var v = cs.filter(function (c) { return c.data_inicio <= hoje && hoje <= c.data_fim; })[0];
    return v || cs.filter(function (c) { return c.status === 'vigente'; })[0] || cs[cs.length - 1] || null;
  };
  M.cicloSel = null;
  M.cicloAtivo = function () { var cs = M.ciclos(), c = cs.filter(function (x) { return x.id === M.cicloSel; })[0]; return c || M.cicloVigente(); };
  M.metaObjetivo = function (objId, cicloId) { return cicloId ? DB.one('SELECT * FROM metas_objetivo_ciclo WHERE objetivo_id=? AND ciclo_id=?', [objId, cicloId]) : null; };
  /** ICV do objetivo no ciclo: ICV = Σ Wc × C, com C = min(1, IHC ÷ meta do ciclo). Sem meta definida, a meta é 100%. Classificação: Curva ABC (situação) e desvio Six Sigma (risco). */
  var icvBase = M.icvObjetivo;
  M.icvObjetivo = function (objId, cicloId) {
    var r = icvBase(objId), cs = M.ciclos(), c = cicloId ? cs.filter(function (x) { return x.id === cicloId; })[0] : M.cicloAtivo();
    var mt = c ? M.metaObjetivo(objId, c.id) : null, meta = mt && +mt.meta_poe > 0 ? +mt.meta_poe / 100 : 1;
    r.ciclo = c || null; r.metaDefinida = !!(mt && +mt.meta_poe > 0); r.meta = meta; r.linhaBase = mt && mt.linha_base_poe != null && mt.linha_base_poe !== '' ? +mt.linha_base_poe / 100 : null;
    r.icvBruto = r.icv;                                   // Σ Wc × IHC (sem a meta do ciclo)
    var vals = r.caps.filter(function (x) { return x.ihc != null; }), s = 0;
    if (vals.length) { vals.forEach(function (x) { x.contribC = Math.min(1, x.ihc / meta); s += (x.wcN != null ? x.wcN : 1 / vals.length) * x.contribC; }); r.icv = Math.min(1, Math.max(0, s)); }
    r.status = M.classeObj(r.icv);
    r.desvio = r.icv == null ? null : Math.max(0, 1 - r.icv);   // desvio em relação à meta do ciclo
    r.sigma = r.desvio == null ? null : M.sigmaDesvio(r.desvio);
    r.risco = r.sigma ? { baixo: 'Baixo', medio: 'Médio', alto: 'Alto' }[r.sigma] : 'Sem dados';
    return r;
  };
})(window);

})(window.DB);
