/* sisrel-html.js — sanitiza o HTML gerado pelo editor (lista branca de marcas, atributos e estilos) */
(function (w) {
  'use strict';
  var TAGS = 'P BR DIV SPAN STRONG B EM I U S STRIKE DEL SUB SUP CODE PRE KBD MARK H1 H2 H3 H4 H5 H6 BLOCKQUOTE UL OL LI HR A ' +
    'TABLE THEAD TBODY TFOOT TR TH TD COLGROUP COL CAPTION FIGURE FIGCAPTION IMG LABEL INPUT'.split(' ');
  var DESCARTAR = ['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'FORM', 'LINK', 'META', 'BASE', 'SVG', 'MATH', 'TEXTAREA', 'BUTTON', 'SELECT'];
  var ATTR = { '*': ['class', 'style'], A: ['href', 'target', 'rel'], IMG: ['src', 'alt', 'width', 'height'], OL: ['start', 'reversed', 'type'], UL: ['data-type'], LI: ['value', 'data-checked', 'data-type'], TD: ['colspan', 'rowspan'], TH: ['colspan', 'rowspan', 'scope'], COL: ['span'], INPUT: ['type', 'checked', 'disabled'] };
  var ESTILOS = /^(color|background-color|background|font-family|font-size|font-weight|font-style|text-align|text-decoration|text-indent|line-height|width|height|min-width|max-width|border|border-(top|right|bottom|left)(-(color|style|width))?|border-(color|style|width|collapse|spacing)|padding(-(top|right|bottom|left))?|margin(-(top|right|bottom|left))?|vertical-align|list-style-type|aspect-ratio|float|display|page-break-after|break-after)$/;
  function estiloSeguro(v) {
    return String(v || '').split(';').map(function (d) {
      var i = d.indexOf(':'); if (i < 0) return '';
      var k = d.slice(0, i).trim().toLowerCase(), val = d.slice(i + 1).trim();
      if (!ESTILOS.test(k) || /url\s*\(|expression|javascript|@import|[<>]/i.test(val)) return '';
      return k + ':' + val;
    }).filter(Boolean).join(';');
  }
  function limpar(no) {
    Array.prototype.slice.call(no.childNodes).forEach(function (f) {
      if (f.nodeType === 3) return;
      if (f.nodeType !== 1) { no.removeChild(f); return; }
      var t = f.tagName.toUpperCase();
      if (DESCARTAR.indexOf(t) >= 0) { no.removeChild(f); return; }
      if (TAGS.indexOf(t) < 0) { limpar(f); while (f.firstChild) no.insertBefore(f.firstChild, f); no.removeChild(f); return; }
      var ok = (ATTR['*'] || []).concat(ATTR[t] || []);
      Array.prototype.slice.call(f.attributes).forEach(function (a) {
        var n = a.name.toLowerCase(), v = a.value;
        if (ok.indexOf(n) < 0) { f.removeAttribute(a.name); return; }
        if (n === 'style') { var e = estiloSeguro(v); if (e) f.setAttribute('style', e); else f.removeAttribute('style'); }
        else if (n === 'href' && !/^(https?:|mailto:|#)/i.test(v.trim())) f.removeAttribute('href');
        else if (n === 'src' && !/^(data:image\/(png|jpe?g|gif|webp|bmp);base64,|https?:)/i.test(v.trim())) f.removeAttribute('src');
        else if (n === 'class') f.setAttribute('class', v.replace(/[^\w\- ]/g, ''));
        else if (n === 'type' && t === 'INPUT' && v !== 'checkbox') f.removeAttribute('type');
      });
      if (t === 'INPUT') { f.setAttribute('type', 'checkbox'); f.setAttribute('disabled', 'disabled'); }
      if (t === 'IMG' && !f.getAttribute('src')) { no.removeChild(f); return; }
      if (t === 'A') { f.setAttribute('target', '_blank'); f.setAttribute('rel', 'noopener noreferrer'); }
      limpar(f);
    });
  }
  var CSS = [
    '.sr-rich { line-height: 1.55; overflow-wrap: anywhere; }',
    '.sr-rich p { margin: 0 0 6px; } .sr-rich ul, .sr-rich ol { margin: 0 0 6px 22px; padding: 0; }',
    '.sr-rich table { border-collapse: collapse; margin: 6px 0; max-width: 100%; }',
    '.sr-rich td, .sr-rich th { border: 1px solid #b9c4bd; padding: 4px 8px; vertical-align: top; }',
    '.sr-rich th { background: #eef3ee; font-weight: 700; }',
    '.sr-rich img { max-width: 100%; height: auto; }',
    '.sr-rich figure { margin: 6px 0; } .sr-rich figure.table { display: block; }',
    '.sr-rich figure.image { text-align: center; } .sr-rich figure.image img { display: inline-block; }',
    '.sr-rich figcaption { font-size: 90%; color: #555; text-align: center; }',
    '.sr-rich blockquote { border-left: 4px solid #a9c27f; margin: 6px 0; padding-left: 12px; font-style: italic; }',
    '.sr-rich pre { background: #f4f6f3; padding: 8px 10px; border-radius: 4px; overflow-x: auto; white-space: pre-wrap; }',
    '.sr-rich code { background: #f0f3ef; padding: 0 3px; border-radius: 3px; }',
    '.sr-rich hr { border: 0; border-top: 1px solid #b9c4bd; margin: 8px 0; }',
    '.sr-rich ul.todo-list, .sr-rich ul[data-type="taskList"] { list-style: none; margin-left: 4px; padding: 0; } .sr-rich ul[data-type="taskList"] li { display: flex; gap: 6px; align-items: flex-start; } .sr-rich ul[data-type="taskList"] li > label { margin-top: 2px; } .sr-rich ul[data-type="taskList"] li > div { flex: 1; } .sr-rich ul[data-type="taskList"] li > div > p { margin: 0; } .sr-rich mark { padding: 0 1px; border-radius: 2px; }',
    '.sr-rich .page-break { page-break-after: always; break-after: page; height: 0; border: 0; margin: 0; }',
    '.sr-rich .marker-yellow { background-color: #fdfd77; } .sr-rich .marker-green { background-color: #62f962; } .sr-rich .marker-pink { background-color: #fc7899; } .sr-rich .marker-blue { background-color: #72ccfd; }',
    '.sr-rich .pen-red { color: #e91313; background: transparent; } .sr-rich .pen-green { color: #118800; background: transparent; }',
    '.sr-rich .text-tiny { font-size: .7em; } .sr-rich .text-small { font-size: .85em; } .sr-rich .text-big { font-size: 1.4em; } .sr-rich .text-huge { font-size: 1.8em; }',
    '.sr-rich .image-style-side { float: right; max-width: 50%; margin-left: 1.5em; }',
    '.sr-rich .image-style-align-left { float: left; margin-right: 1.5em; } .sr-rich .image-style-align-right { float: right; margin-left: 1.5em; }'
  ].join('\n');

  /* ---- Conversão do formato antigo (Quill) e de texto simples para HTML padrão ---- */
  function criar(doc, tag, html) { var e = doc.createElement(tag); if (html) e.innerHTML = html; return e; }
  function legadoQuill(doc) {
    var body = doc.body, tem = body.querySelector('.ql-ui, [data-list], [class*="ql-"], span[style*="background"]');
    if (!tem) return;
    Array.prototype.forEach.call(body.querySelectorAll('.ql-ui'), function (e) { e.remove(); });
    // listas: cada <li data-list> pode estar dentro de <ol> comum; reagrupa por tipo e recuo
    Array.prototype.slice.call(body.querySelectorAll('ol, ul')).forEach(function (lst) {
      if (!lst.querySelector(':scope > li[data-list]')) return;
      var itens = Array.prototype.slice.call(lst.children).filter(function (x) { return x.tagName === 'LI'; });
      var raiz = [], pilha = [], novo = doc.createDocumentFragment();
      function tipoDe(li) { var d = li.getAttribute('data-list'); return d === 'ordered' ? 'ol' : (d === 'bullet' ? 'ul' : (d ? 'task' : 'ul')); }
      function nova(tp) { var l = tp === 'ol' ? doc.createElement('ol') : doc.createElement('ul'); if (tp === 'task') l.setAttribute('data-type', 'taskList'); return l; }
      itens.forEach(function (li) {
        var m = /ql-indent-(\d)/.exec(li.className || ''), nivel = m ? +m[1] : 0, tp = tipoDe(li);
        var d = li.getAttribute('data-list');
        var novoLi = doc.createElement('li');
        if (tp === 'task') { novoLi.setAttribute('data-type', 'taskItem'); novoLi.setAttribute('data-checked', d === 'checked' ? 'true' : 'false'); novoLi.innerHTML = '<p>' + li.innerHTML + '</p>'; }
        else novoLi.innerHTML = li.innerHTML;
        while (pilha.length > nivel + 1) pilha.pop();
        while (pilha.length < nivel + 1) {
          var l = nova(tp);
          if (pilha.length === 0) { novo.appendChild(l); }
          else { var pai = pilha[pilha.length - 1].lastElementChild; if (!pai) { pai = doc.createElement('li'); pilha[pilha.length - 1].appendChild(pai); } pai.appendChild(l); }
          pilha.push(l);
        }
        var atual = pilha[pilha.length - 1], atualTp = atual.tagName === 'OL' ? 'ol' : (atual.getAttribute('data-type') === 'taskList' ? 'task' : 'ul');
        if (atualTp !== tp) { // muda o tipo no mesmo nível: abre nova lista irmã
          var l2 = nova(tp), pai2 = pilha.length > 1 ? pilha[pilha.length - 2].lastElementChild : null;
          if (pai2) pai2.appendChild(l2); else novo.appendChild(l2);
          pilha[pilha.length - 1] = l2; atual = l2;
        }
        atual.appendChild(novoLi);
      });
      lst.parentNode.replaceChild(novo, lst);
    });
    // bloco de código
    Array.prototype.slice.call(body.querySelectorAll('.ql-code-block-container')).forEach(function (c) {
      var linhas = Array.prototype.map.call(c.querySelectorAll('.ql-code-block'), function (l) { return l.textContent; });
      var pre = doc.createElement('pre'), code = doc.createElement('code'); code.textContent = linhas.join('\n'); pre.appendChild(code);
      c.parentNode.replaceChild(pre, c);
    });
    // alinhamento, fundo
    Array.prototype.forEach.call(body.querySelectorAll('[class*="ql-align-"]'), function (e) {
      var m = /ql-align-(center|right|justify)/.exec(e.className); if (m) e.style.textAlign = m[1];
    });
    Array.prototype.forEach.call(body.querySelectorAll('span[style*="background-color"]'), function (e) {
      var bg = e.style.backgroundColor, cor = e.style.color, mk = doc.createElement('mark');
      mk.setAttribute('data-color', bg); mk.style.backgroundColor = bg; mk.style.color = cor || 'inherit';
      while (e.firstChild) mk.appendChild(e.firstChild); e.parentNode.replaceChild(mk, e);
    });
    Array.prototype.forEach.call(body.querySelectorAll('[class*="ql-"]'), function (e) {
      e.className = e.className.split(/\s+/).filter(function (c) { return c && c.indexOf('ql-') !== 0; }).join(' ');
      if (!e.className) e.removeAttribute('class');
      if (e.style) { e.style.fontFamily = ''; e.style.fontSize = ''; if (!e.getAttribute('style')) e.removeAttribute('style'); }
    });
  }
  function temMarcas(s) { return /<\s*\/?\s*[a-z][^>]*>/i.test(s); }
  function textoParaHtml(s) {
    return String(s).split(/\r?\n/).map(function (l) { return '<p>' + (l.trim() ? esc(l) : '<br>') + '</p>'; }).join('');
  }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  try { var st = document.createElement('style'); st.setAttribute('data-sr-rich', '1'); st.textContent = CSS; (document.head || document.documentElement).appendChild(st); } catch (e) {}
  w.SisrelHtml = {
    css: CSS,
    seguro: function (raw) {
      var doc; raw = String(raw == null ? '' : raw);
      if (!raw.trim()) return '';
      if (!temMarcas(raw)) raw = textoParaHtml(raw);
      try { doc = new DOMParser().parseFromString(raw, 'text/html'); } catch (e) { return esc(raw); }
      try { legadoQuill(doc); } catch (e) {}
      limpar(doc.body);
      return doc.body.innerHTML.trim();
    },
    /** HTML padrão pronto para carregar no editor (aceita texto simples e o formato antigo do Quill). */
    paraEditor: function (raw) { return w.SisrelHtml.seguro(raw); },
    texto: function (raw) {
      var base = String(raw || '').replace(/<\s*br\s*\/?>/gi, '\n').replace(/<\/\s*(p|div|li|h[1-6]|ul|ol|tr|figure)\s*>/gi, '\n');
      var t; try { t = new DOMParser().parseFromString(base, 'text/html').body.textContent || ''; } catch (e) { t = base.replace(/<[^>]*>/g, ''); }
      return t.trim();
    }
  };
})(window);
