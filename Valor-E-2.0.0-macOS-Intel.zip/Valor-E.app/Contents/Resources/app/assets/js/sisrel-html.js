/* sisrel-html.js — sanitiza o HTML gerado pelo editor (lista branca de marcas, atributos e estilos) */
(function (w) {
  'use strict';
  var TAGS = 'P BR DIV SPAN STRONG B EM I U S STRIKE DEL SUB SUP CODE PRE KBD MARK H1 H2 H3 H4 H5 H6 BLOCKQUOTE UL OL LI HR A ' +
    'TABLE THEAD TBODY TFOOT TR TH TD COLGROUP COL CAPTION FIGURE FIGCAPTION IMG LABEL INPUT'.split(' ');
  var DESCARTAR = ['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'FORM', 'LINK', 'META', 'BASE', 'SVG', 'MATH', 'TEXTAREA', 'BUTTON', 'SELECT'];
  var ATTR = { '*': ['class', 'style'], A: ['href', 'target', 'rel'], IMG: ['src', 'alt', 'width', 'height'], OL: ['start', 'reversed', 'type'], LI: ['value'], TD: ['colspan', 'rowspan'], TH: ['colspan', 'rowspan', 'scope'], COL: ['span'], INPUT: ['type', 'checked', 'disabled'] };
  var ESTILOS = /^(color|background-color|background|font-family|font-size|font-weight|font-style|text-align|text-decoration|text-indent|line-height|width|height|min-width|max-width|border|border-(top|right|bottom|left)(-(color|style|width))?|border-(color|style|width|collapse|spacing)|padding(-(top|right|bottom|left))?|margin(-(top|right|bottom|left))?|vertical-align|list-style-type|aspect-ratio|float|display|page-break-after|break-after)$/;
  function estiloSeguro(v) {
    return String(v || '').split(';').map(function (d) {
      var i = d.indexOf(':'); if (i < 0) return '';
      var k = d.slice(0, i).trim().toLowerCase(), val = d.slice(i + 1).trim();
      if (!ESTILOS.test(k) || /url\s*\(|expression|javascript|@import|[<>]/i.test(val)) return '';
      return k + ':' + val;
    }).filter(Boolean).join(';');
  }
  function limpar(no) {
    Array.prototype.slice.call(no.childNodes).forEach(function (f) {
      if (f.nodeType === 3) return;
      if (f.nodeType !== 1) { no.removeChild(f); return; }
      var t = f.tagName.toUpperCase();
      if (DESCARTAR.indexOf(t) >= 0) { no.removeChild(f); return; }
      if (TAGS.indexOf(t) < 0) { limpar(f); while (f.firstChild) no.insertBefore(f.firstChild, f); no.removeChild(f); return; }
      var ok = (ATTR['*'] || []).concat(ATTR[t] || []);
      Array.prototype.slice.call(f.attributes).forEach(function (a) {
        var n = a.name.toLowerCase(), v = a.value;
        if (ok.indexOf(n) < 0) { f.removeAttribute(a.name); return; }
        if (n === 'style') { var e = estiloSeguro(v); if (e) f.setAttribute('style', e); else f.removeAttribute('style'); }
        else if (n === 'href' && !/^(https?:|mailto:|#)/i.test(v.trim())) f.removeAttribute('href');
        else if (n === 'src' && !/^(data:image\/(png|jpe?g|gif|webp|bmp);base64,|https?:)/i.test(v.trim())) f.removeAttribute('src');
        else if (n === 'class') f.setAttribute('class', v.replace(/[^\w\- ]/g, ''));
        else if (n === 'type' && t === 'INPUT' && v !== 'checkbox') f.removeAttribute('type');
      });
      if (t === 'INPUT') { f.setAttribute('type', 'checkbox'); f.setAttribute('disabled', 'disabled'); }
      if (t === 'IMG' && !f.getAttribute('src')) { no.removeChild(f); return; }
      if (t === 'A') { f.setAttribute('target', '_blank'); f.setAttribute('rel', 'noopener noreferrer'); }
      limpar(f);
    });
  }
  var CSS = [
    '.sr-rich { line-height: 1.55; overflow-wrap: anywhere; }',
    '.sr-rich p { margin: 0 0 6px; } .sr-rich ul, .sr-rich ol { margin: 0 0 6px 22px; padding: 0; }',
    '.sr-rich table { border-collapse: collapse; margin: 6px 0; max-width: 100%; }',
    '.sr-rich td, .sr-rich th { border: 1px solid #b9c4bd; padding: 4px 8px; vertical-align: top; }',
    '.sr-rich th { background: #eef3ee; font-weight: 700; }',
    '.sr-rich img { max-width: 100%; height: auto; }',
    '.sr-rich figure { margin: 6px 0; } .sr-rich figure.table { display: block; }',
    '.sr-rich figure.image { text-align: center; } .sr-rich figure.image img { display: inline-block; }',
    '.sr-rich figcaption { font-size: 90%; color: #555; text-align: center; }',
    '.sr-rich blockquote { border-left: 4px solid #a9c27f; margin: 6px 0; padding-left: 12px; font-style: italic; }',
    '.sr-rich pre { background: #f4f6f3; padding: 8px 10px; border-radius: 4px; overflow-x: auto; white-space: pre-wrap; }',
    '.sr-rich code { background: #f0f3ef; padding: 0 3px; border-radius: 3px; }',
    '.sr-rich hr { border: 0; border-top: 1px solid #b9c4bd; margin: 8px 0; }',
    '.sr-rich ul.todo-list { list-style: none; margin-left: 4px; } .sr-rich .todo-list__label input { margin-right: 6px; }',
    '.sr-rich .page-break { page-break-after: always; break-after: page; height: 0; border: 0; margin: 0; }',
    '.sr-rich .marker-yellow { background-color: #fdfd77; } .sr-rich .marker-green { background-color: #62f962; } .sr-rich .marker-pink { background-color: #fc7899; } .sr-rich .marker-blue { background-color: #72ccfd; }',
    '.sr-rich .pen-red { color: #e91313; background: transparent; } .sr-rich .pen-green { color: #118800; background: transparent; }',
    '.sr-rich .text-tiny { font-size: .7em; } .sr-rich .text-small { font-size: .85em; } .sr-rich .text-big { font-size: 1.4em; } .sr-rich .text-huge { font-size: 1.8em; }',
    '.sr-rich .image-style-side { float: right; max-width: 50%; margin-left: 1.5em; }',
    '.sr-rich .image-style-align-left { float: left; margin-right: 1.5em; } .sr-rich .image-style-align-right { float: right; margin-left: 1.5em; }'
  ].join('\n');
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  try { var st = document.createElement('style'); st.setAttribute('data-sr-rich', '1'); st.textContent = CSS; (document.head || document.documentElement).appendChild(st); } catch (e) {}
  w.SisrelHtml = {
    css: CSS,
    seguro: function (raw) {
      var doc;
      try { doc = new DOMParser().parseFromString(String(raw || ''), 'text/html'); } catch (e) { return esc(raw); }
      limpar(doc.body);
      return doc.body.innerHTML.trim();
    },
    texto: function (raw) {
      var base = String(raw || '').replace(/<\s*br\s*\/?>/gi, '\n').replace(/<\/\s*(p|div|li|h[1-6]|ul|ol|tr|figure)\s*>/gi, '\n');
      var t; try { t = new DOMParser().parseFromString(base, 'text/html').body.textContent || ''; } catch (e) { t = base.replace(/<[^>]*>/g, ''); }
      return t.trim();
    }
  };
})(window);
