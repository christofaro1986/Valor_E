/* telas_processos.js — módulo Processos: lista, novo, importar Folha, exclusão sincronizada com riscos e indicadores. */
(function (w) {
  'use strict';
  var h = E.esc;
  function macrosAgrupados(sel, cadeia) {
    var l = DB.all("SELECT m.id, m.nome, m.tipo, c.cadeia FROM macroprocessos m JOIN cva_ciclos c ON c.id = m.ciclo_id WHERE c.status = 'Vigente'" + (cadeia ? ' AND c.cadeia = ?' : '') + " ORDER BY c.cadeia, m.tipo, m.ordem, m.nome", cadeia ? [cadeia] : []);
    if (!l.length) l = DB.all('SELECT m.id, m.nome, m.tipo, c.cadeia FROM macroprocessos m JOIN cva_ciclos c ON c.id = m.ciclo_id ORDER BY c.cadeia, m.tipo, m.ordem, m.nome');
    var varias = (w.Cva && Cva.cadeias ? Cva.cadeias().length : 1) > 1, g = {}, ord = [], o = '';
    l.forEach(function (m) { var k = (varias ? (m.cadeia || 'Principal') + ' › ' : '') + m.tipo + 's'; if (!g[k]) { g[k] = []; ord.push(k); } g[k].push(m); });
    ord.forEach(function (k) { o += '<optgroup label="' + h(k) + '">' + g[k].map(function (m) { return '<option value="' + m.id + '"' + (String(sel) === String(m.id) ? ' selected' : '') + '>' + h(m.nome) + '</option>'; }).join('') + '</optgroup>'; });
    return o;
  }
  w.macrosAgrupados = macrosAgrupados;

  function html(q) {
    var l = E.processosListar({ q: q.q || '', macro: q.macro || '', cadeia: q.cadeia || '' }), cads = (w.Cva && Cva.cadeias) ? Cva.cadeias() : [];
    var tem = DB.one('SELECT COUNT(*) AS n FROM processos').n;
    var o = '<div class="pagina"><div class="d-flex flex-wrap align-items-center mb-3"><h1 class="h4 mb-0 me-auto"><i class="bi bi-diagram-3"></i> Processos</h1>' +
      '<form class="filtros d-flex flex-wrap align-items-center" style="margin-right:8px"><input class="form-control form-control-sm" name="q" value="' + h(q.q || '') + '" placeholder="Buscar processo…" style="width:200px;margin-right:6px">' +
      (cads.length > 1 ? '<select class="form-select form-select-sm" name="cadeia" title="Cadeia de valor" style="width:190px;margin-right:6px"><option value="">Todas as cadeias</option>' + cads.map(function (x) { return '<option value="' + h(x) + '"' + (q.cadeia === x ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select>' : '') + '<select class="form-select form-select-sm" name="macro" style="width:200px;margin-right:6px"><option value="">Todos os macroprocessos</option>' + macrosAgrupados(q.macro, q.cadeia) + '</select><button class="btn btn-sm btn-outline-secondary">Filtrar</button></form>' +
      '<a class="btn btn-sm btn-outline-dark me-1" href="#/processos-arvore" title="Árvore de gestão: macroprocessos, processos, indicadores e riscos"><i class="bi bi-diagram-3-fill"></i> Árvore de gestão</a>' +
      '<button class="btn btn-outline-secondary btn-sm" style="margin-right:6px" onclick="document.getElementById(\'impFolha\').click()"><i class="bi bi-upload"></i> Importar Folha (.xml)</button><input type="file" id="impFolha" accept=".xml" hidden>' +
      '<button class="btn btn-success btn-sm" onclick="Proc.novo()"><i class="bi bi-plus-lg"></i> Novo processo</button></div>';
    if (!l.length) o += '<div class="cartao"><div class="vazio">' + (tem ? 'Nenhum processo encontrado com o filtro.' : 'Nenhum processo cadastrado. Clique em <b>Novo processo</b> para preencher a Folha de dados e gerar o diagrama BPMN, onde você marca os riscos nas atividades.') + '</div></div>';
    else {
      o += '<div class="cartao"><div class="table-responsive"><table class="tabela"><thead><tr><th>Processo</th><th>Macroprocesso</th><th>Status</th><th class="text-center" title="Bandeiras de risco no diagrama">Bandeiras</th><th class="text-center">Riscos</th><th class="text-center">Indicadores</th><th>Atualizado</th><th></th></tr></thead><tbody>';
      l.forEach(function (c) {
        o += '<tr><td><a href="#/folha?id=' + c.id + '"><b>' + h(c.nome) + '</b></a></td><td>' + (c.macro_nome ? h(c.macro_nome) + (cads.length > 1 && c.cadeia ? ' <small class="text-muted">· ' + h(c.cadeia) + '</small>' : '') : '<span class="text-muted">—</span>') + '</td><td>' + h(c.status || '') + '</td>' +
          '<td class="text-center">' + c.n_flags + '</td><td class="text-center">' + (c.n_riscos ? '<a href="#/riscos?processo=' + c.id + '">' + c.n_riscos + '</a>' : 0) + '</td><td class="text-center">' + (c.n_ind ? '<a href="#/indicadores?processo=' + c.id + '">' + c.n_ind + '</a>' : 0) + '</td>' +
          '<td>' + h(E.dataBr(String(c.atualizado_em || '').slice(0, 10))) + '</td><td class="text-end text-nowrap">' +
          '<a class="btn btn-sm btn-outline-secondary" href="#/processo-form?id=' + c.id + '" title="Dados do processo"><i class="bi bi-pencil"></i></a> ' +
          '<a class="btn btn-sm btn-outline-success" href="#/folha?id=' + c.id + '" title="Folha de dados"><i class="bi bi-file-earmark-text"></i> Folha</a> ' +
          '<a class="btn btn-sm btn-outline-success" href="#/diagrama?id=' + c.id + '" title="Diagrama BPMN e riscos"><i class="bi bi-diagram-3"></i> Diagrama</a> ' +
          '<a class="btn btn-sm btn-outline-primary" href="#/indicador?novo=1&processo=' + c.id + '" title="Novo indicador deste processo"><i class="bi bi-graph-up-arrow"></i> Indicador</a> ' +
          '<button class="btn btn-sm btn-outline-secondary" onclick="Proc.exportar(' + c.id + ')" title="Exportar Folha (.xml)"><i class="bi bi-download"></i></button> ' +
          '<button class="btn btn-sm btn-outline-danger" onclick="Proc.excluir(' + c.id + ')" title="Excluir"><i class="bi bi-trash"></i></button></td></tr>';
      });
      o += '</tbody></table></div></div>';
    }
    return o + '</div>';
  }
  function apos() {
    var f = document.getElementById('impFolha');
    if (f) f.addEventListener('change', function (e) {
      var a = e.target.files[0]; if (!a) return;
      var fr = new FileReader(); fr.onload = function () {
        var r = API.acao('importar_xml', { xml: String(fr.result) });
        if (!r.ok) return alert(r.erro);
        if (r.avisos && r.avisos.length) alert('Importado com avisos:\n' + r.avisos.join('\n'));
        Nav.ir('#/folha?id=' + r.id);
      };
      fr.readAsText(a);
    });
  }

  var COR_TIPO = { 'Finalístico': '#0b3a73', 'Gerencial': '#0a6fc2', 'Apoio': '#01b2a1' };
  var PLUR = { 'Finalístico': 'Macroprocessos finalísticos', 'Gerencial': 'Macroprocessos gerenciais', 'Apoio': 'Macroprocessos de apoio' };
  var COR_NIVEL = { 'Muito Baixo': ['#1976d2', '#ffffff'], 'Baixo': ['#388e3c', '#ffffff'], 'Médio': ['#fbc02d', '#4a3b00'], 'Alto': ['#f57c00', '#ffffff'], 'Extremo': ['#d32f2f', '#ffffff'] };
  var COR_SIT = { 'Ativo': ['#2e7d32', '#ffffff'], 'Em revisão': ['#f9a825', '#3b2f00'], 'Arquivado': ['#64748b', '#ffffff'] };
  var COR_VAL = { 'Manter': ['#2e7d32', '#ffffff'], 'Revisar': ['#f9a825', '#3b2f00'], 'Alterar': ['#c62828', '#ffffff'] };
  var COR_IND = { ok: ['#2e7d32', '#ffffff', 'Em conformidade'], atencao: ['#f9a825', '#3b2f00', 'Em atenção'], critico: ['#c62828', '#ffffff', 'Crítico'] };
  function selo(t, par, dica) { par = par || ['#64748b', '#ffffff']; return { t: t, cor: par[0], fg: par[1], dica: dica }; }

  /** Cadeia → nível → macroprocesso → processo → indicadores e riscos. Retorna a árvore já com selos de situação e criticidade. */
  function arvoreGestao(cadeia) {
    var macros = DB.all("SELECT m.*, c.nome AS ciclo_nome, c.cadeia, c.status AS ciclo_status FROM macroprocessos m LEFT JOIN cva_ciclos c ON c.id = m.ciclo_id ORDER BY c.cadeia, c.id DESC, CASE m.tipo WHEN 'Finalístico' THEN 1 WHEN 'Gerencial' THEN 2 WHEN 'Apoio' THEN 3 ELSE 4 END, m.ordem, m.nome");
    // só o ciclo vigente de cada cadeia (ou o mais recente, se nenhum estiver vigente)
    var ciclosUsados = {};
    macros.forEach(function (m) { var cd = m.cadeia || 'Principal'; if (m.ciclo_status === 'Vigente') ciclosUsados[cd] = m.ciclo_id; });
    macros.forEach(function (m) { var cd = m.cadeia || 'Principal'; if (!ciclosUsados[cd]) ciclosUsados[cd] = m.ciclo_id; });
    macros = macros.filter(function (m) { var cd = m.cadeia || 'Principal'; return (!cadeia || cd === cadeia) && ciclosUsados[cd] === m.ciclo_id; });
    var totais = { macro: 0, proc: 0, ind: 0, risco: 0, crit: 0 }, cads = [], porCad = {};
    function noProcesso(p) {
      var inds = [], riscos = [];
      try { inds = DB.all('SELECT id, codigo, nome FROM indicadores WHERE processo_id = ? ORDER BY codigo, nome', [p.id]); } catch (e) {}
      try { riscos = DB.all('SELECT id, codigo, nome, nivel_res, nivel_medio FROM riscos WHERE processo_id = ? ORDER BY CASE COALESCE(nivel_res, nivel_medio) WHEN \'Extremo\' THEN 1 WHEN \'Alto\' THEN 2 WHEN \'Médio\' THEN 3 WHEN \'Baixo\' THEN 4 ELSE 5 END, codigo, nome', [p.id]); } catch (e) {}
      totais.proc++; totais.ind += inds.length; totais.risco += riscos.length;
      var bs = [selo(p.status || 'Ativo', COR_SIT[p.status || 'Ativo'], 'Situação do processo')];
      if (p.validacao) bs.push(selo('Validação: ' + p.validacao, COR_VAL[p.validacao], 'Decisão da última validação da CVA'));
      var fil = [];
      inds.forEach(function (i) {
        var sit = null; try { sit = (w.Ind && Ind.situacao) ? Ind.situacao(i.id) : null; } catch (e) {}
        var c = sit && COR_IND[sit];
        fil.push({ tipo: 'ind', rotulo: (i.codigo ? i.codigo + ' — ' : '') + i.nome, href: '#/indicador?id=' + i.id, badges: c ? [selo(c[2], c, 'Situação do indicador')] : [] });
      });
      riscos.forEach(function (r) {
        var niv = r.nivel_res || r.nivel_medio, c = COR_NIVEL[niv]; if (niv === 'Extremo' || niv === 'Alto') totais.crit++;
        fil.push({ tipo: 'risco', rotulo: (r.codigo ? r.codigo + ' — ' : '') + r.nome, href: '#/risco?id=' + r.id, badges: [selo(niv ? ((r.nivel_res ? 'Residual ' : 'Inerente ') + niv) : 'Não avaliado', c || ['#94a3b8', '#ffffff'], 'Criticidade do risco')] });
      });
      return { tipo: 'proc', rotulo: p.nome, href: '#/folha?id=' + p.id, badges: bs, filhos: fil };
    }
    macros.forEach(function (m) {
      var cad = m.cadeia || 'Principal'; if (!porCad[cad]) { porCad[cad] = { tipo: 'raiz', rotulo: 'Cadeia de valor: ' + cad, meta: m.ciclo_nome || '', filhos: [], _g: {} }; cads.push(porCad[cad]); }
      var C = porCad[cad], tp = TIPOS_OK(m.tipo);
      if (!C._g[tp]) { C._g[tp] = { tipo: 'grupo', rotulo: PLUR[tp] || 'Outros macroprocessos', cor: COR_TIPO[tp] || '#64748b', filhos: [] }; C.filhos.push(C._g[tp]); }
      var procs = DB.all('SELECT * FROM processos WHERE macro_id = ? ORDER BY nome COLLATE NOCASE', [m.id]);
      totais.macro++;
      C._g[tp].filhos.push({ tipo: 'macro', rotulo: m.nome, cor: COR_TIPO[tp] || '#475569', badges: [selo(procs.length + ' processo(s)', ['#e2e8f0', '#334155'])], filhos: procs.map(noProcesso) });
    });
    var orf = DB.all('SELECT * FROM processos WHERE macro_id IS NULL OR macro_id NOT IN (SELECT id FROM macroprocessos) ORDER BY nome COLLATE NOCASE');
    if (orf.length) cads.push({ tipo: 'raiz', rotulo: 'Processos sem macroprocesso', cor: '#64748b', filhos: orf.map(noProcesso) });
        return { raiz: cads, totais: totais };
  }
  function TIPOS_OK(t) { return COR_TIPO[t] ? t : ''; }
  function legendaArvore() {
    return [selo('Ativo', COR_SIT['Ativo']), selo('Em revisão', COR_SIT['Em revisão']), selo('Arquivado', COR_SIT['Arquivado']), selo('Risco Extremo', COR_NIVEL['Extremo']), selo('Risco Alto', COR_NIVEL['Alto']), selo('Risco Médio', COR_NIVEL['Médio']), selo('Risco Baixo', COR_NIVEL['Baixo']), selo('Risco Muito Baixo', COR_NIVEL['Muito Baixo'])];
  }
  function resumoArvore(t) { return t.macro + ' macroprocesso(s) · ' + t.proc + ' processo(s) · ' + t.ind + ' indicador(es) · ' + t.risco + ' risco(s) (' + t.crit + ' alto/extremo)'; }
  function htmlArvore(q) {
    var cads = (w.Cva && Cva.cadeias) ? Cva.cadeias() : [], A = arvoreGestao(q.cadeia || '');
    var o = '<div class="pagina rel-proc"><div class="d-flex flex-wrap align-items-center mb-2 no-print"><h1 class="h4 mb-0 me-auto"><i class="bi bi-diagram-3-fill"></i> Árvore de gestão — Processos</h1>' +
      (cads.length > 1 ? '<select class="form-select form-select-sm" style="width:190px;margin-right:6px" title="Cadeia de valor" onchange="Nav.ir(\'#/processos-arvore?cadeia=\'+encodeURIComponent(this.value))"><option value="">Todas as cadeias</option>' + cads.map(function (x) { return '<option value="' + h(x) + '"' + (q.cadeia === x ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select>' : '') +
      '<button class="btn btn-sm btn-outline-secondary" style="margin-right:6px" onclick="Arvore.abrir(\'#arvProc\',true)"><i class="bi bi-arrows-expand"></i> Expandir</button><button class="btn btn-sm btn-outline-secondary" style="margin-right:6px" onclick="Arvore.abrir(\'#arvProc\',false)"><i class="bi bi-arrows-collapse"></i> Recolher</button>' +
      '<a class="btn btn-sm btn-outline-secondary" style="margin-right:6px" href="#/processos"><i class="bi bi-arrow-left"></i> Processos</a>' +
      '<button class="btn btn-sm btn-outline-danger" style="margin-right:6px" onclick="Proc.arvorePdf(\'' + h(q.cadeia || '').replace(/'/g, "\\'") + '\')"><i class="bi bi-filetype-pdf"></i> PDF</button><button class="btn btn-sm btn-outline-secondary" onclick="Arvore.imprimir()"><i class="bi bi-printer"></i> Imprimir</button></div>';
    if (!A.raiz.length) return o + '<div class="cartao"><div class="vazio">Nenhum macroprocesso ou processo cadastrado.</div></div></div>';
    o += '<div class="cartao"><h2><span class="me-auto"><i class="bi bi-diagram-3"></i> Macroprocessos, processos, indicadores e riscos</span><span class="small fw-normal text-muted">' + h(resumoArvore(A.totais)) + '</span></h2><div class="corpo">' +
      '<div class="ag-leg mb-2 no-print"><span style="margin-right:6px"><b>Situação do processo e criticidade do risco:</b></span>' + legendaArvore().map(function (b) { return '<span class="ag-b" style="background:' + b.cor + ';color:' + b.fg + '">' + h(b.t) + '</span>'; }).join('') + '</div>' +
      Arvore.html(A.raiz, { id: 'arvProc', aberto: true }) + '</div></div></div>';
    return o;
  }
  /** Página de cadastro do processo — mesmo padrão do cadastro de risco (página própria, seções numeradas, Salvar no topo). */
  function formulario(q) {
    var id = parseInt(q.id, 10) || 0, c = id ? E.processoCarregar(id) : null;
    if (id && !c) { Nav.ir('#/processos'); return ''; }
    if (!c) c = { nome: '', macro_id: parseInt(q.macro, 10) || '', status: 'Ativo', responsavel: '', descricao: '' };
    setTimeout(function () { var d = document.getElementById('formProc'); if (!d) return; var m = function () { var st = document.getElementById('prSt'); if (st) st.textContent = 'Alterações não salvas…'; }; d.addEventListener('input', m); d.addEventListener('change', m); montarDescricao(c.descricao); }, 30);
    var sts = ['Ativo', 'Em revisão', 'Arquivado'];
    return '<div class="pagina" id="formProc" data-id="' + id + '"><div class="d-flex align-items-center gap-2 mb-3 flex-wrap"><a class="btn btn-outline-secondary btn-sm" href="#/processos"><i class="bi bi-arrow-left"></i> Processos</a>' +
      '<h5 class="mb-0 flex-grow-1" id="prTitulo" style="color:var(--verde-esc)">' + (id ? h(c.nome) : 'Novo processo') + '</h5><span class="ajuda" id="prSt">Pronto</span>' +
      '<button class="btn btn-success btn-sm" onclick="Proc.formSalvar()"><i class="bi bi-save"></i> Salvar</button>' +
      '<a class="btn btn-outline-success btn-sm' + (id ? '' : ' disabled') + '" id="prFolha" href="' + (id ? '#/folha?id=' + id : '#') + '" title="Folha de dados"><i class="bi bi-file-earmark-text"></i> Folha</a>' +
      '<a class="btn btn-outline-success btn-sm' + (id ? '' : ' disabled') + '" id="prDiag" href="' + (id ? '#/diagrama?id=' + id : '#') + '" title="Diagrama BPMN e riscos"><i class="bi bi-diagram-3"></i> Diagrama</a>' +
      '<button class="btn btn-outline-danger btn-sm" id="prDel" onclick="Proc.formExcluir()" ' + (id ? '' : 'disabled') + '><i class="bi bi-trash"></i> Excluir</button></div>' +
      '<div class="cartao mb-3"><h2><span class="passo">1</span><i class="bi bi-diagram-3"></i> Identificação do processo</h2><div class="corpo"><div class="row g-3">' +
      '<div class="col-md-8 campo"><label>Nome do processo *</label><input class="form-control" id="prn" maxlength="300" value="' + h(c.nome) + '" placeholder="Ex.: Realizar aquisição de material" autocomplete="off"></div>' +
      '<div class="col-md-4 campo"><label>Situação</label><select class="form-select" id="prs">' + sts.map(function (x) { return '<option' + ((c.status || 'Ativo') === x ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div>' +
      '<div class="col-md-8 campo"><label>Macroprocesso (Cadeia de Valor)</label><select class="form-select" id="prm"><option value="">— sem macroprocesso —</option>' + macrosAgrupados(c.macro_id) + '</select><div class="ajuda mt-1">Os macroprocessos são cadastrados em <b>CVA</b>.</div></div>' +
      '<div class="col-md-4 campo"><label>Responsável</label><input class="form-control" id="prr" maxlength="300" value="' + h(c.responsavel || '') + '" placeholder="Dono do processo"></div>' +
      '<div class="col-12 campo"><label>Descrição</label><div id="prd"></div></div></div></div></div>' +
      (id ? '' : '<div class="ajuda" id="prDica">Depois de salvar, use <b>Folha</b> para detalhar o processo (entradas, saídas, atores, regras) e <b>Diagrama</b> para modelá-lo em BPMN e associar riscos.</div>') + '</div>';
  }
  var edDesc = null;
  function descProc() { return edDesc ? w.SisrelHtml.seguro(edDesc.getData() || '') : ''; }
  function montarDescricao(html) {
    var el = document.getElementById('prd'); if (!el || !w.SisrelEditor) return;
    edDesc = null;
    w.SisrelEditor.criar(el, { placeholder: 'Descreva o processo: finalidade, abrangência, quando começa e termina…', dados: html || '', minAltura: 120, aoMudar: function () { var st = document.getElementById('prSt'); if (st) st.textContent = 'Alterações não salvas…'; } })
      .then(function (ed) { edDesc = ed; }).catch(function (er) { el.innerHTML = '<p class="alert alert-warn">Editor indisponível: ' + h(er && er.message || er) + '</p>'; });
  }
  var Proc = w.Proc = {
    arvorePdf: function (cadeia) {
      var A = arvoreGestao(cadeia || '');
      Arvore.pdf({ titulo: 'Árvore de gestão — Processos', subtitulo: 'Macroprocessos da CVA, processos vinculados, indicadores e riscos' + (cadeia ? ' · Cadeia: ' + cadeia : ''), resumo: [resumoArvore(A.totais)], raiz: A.raiz, legendaTitulo: 'Situação e criticidade:', legenda: legendaArvore(), arquivo: 'arvore-de-gestao-processos-' + E.hoje() });
    },
    novo: function () { Nav.ir('#/processo-form?id=0'); },
    editar: function (id) { if (E.processoCarregar(id)) Nav.ir('#/processo-form?id=' + id); },
    formSalvar: function () {
      var d = document.getElementById('formProc'); if (!d) return;
      var val = function (s) { var e = d.querySelector(s); return e ? e.value : ''; }, id = parseInt(d.getAttribute('data-id'), 10) || 0;
      if (!val('#prn').trim()) { alert('Informe o nome do processo.'); document.getElementById('prn').focus(); return; }
      var novo = !id;
      try { id = E.processoSalvar({ id: id, nome: val('#prn'), macro_id: val('#prm'), status: val('#prs'), responsavel: val('#prr'), descricao: descProc() }); } catch (e) { alert(e.message); return; }
      d.setAttribute('data-id', id);
      document.getElementById('prSt').textContent = 'Salvo ✓';
      document.getElementById('prTitulo').textContent = val('#prn').trim();
      ['prFolha', 'prDiag'].forEach(function (b) { var e = document.getElementById(b); e.classList.remove('disabled'); e.setAttribute('href', (b === 'prFolha' ? '#/folha?id=' : '#/diagrama?id=') + id); });
      document.getElementById('prDel').disabled = false;
      var dica = document.getElementById('prDica'); if (dica) dica.remove();
      if (novo) { history.replaceState(null, '', '#/processo-form?id=' + id); Nav.atual = '#/processo-form?id=' + id; }
    },
    formExcluir: function () {
      var d = document.getElementById('formProc'), id = parseInt(d && d.getAttribute('data-id'), 10) || 0; if (id) Proc.excluir(id);
    },
    exportar: function (id) { var r = API.acao('exportar_xml', { id: id }); if (r.ok) Common.baixar(r.nome, r.texto, r.tipo); else alert(r.erro); },
    excluir: function (id) {
      var c = E.processoCarregar(id); if (!c) return;
      var nr = DB.one('SELECT COUNT(*) AS n FROM riscos WHERE processo_id = ?', [id]).n, modo = 'riscos';
      if (!confirm('Excluir o processo "' + c.nome + '" (Folha de dados e diagrama)?')) return;
      if (nr) modo = confirm(nr + ' risco(s) estão vinculados a este processo.\n\nOK = excluir também esses riscos.\nCancelar = manter os riscos (sem vínculo, com o ambiente preservado).') ? 'riscos' : 'manter';
      E.processoExcluir(id, modo);
      if (w.Ind && Ind.excluirVinculoProcesso) Ind.excluirVinculoProcesso(id);
      Nav.ir('#/processos');
    }
  };
  Modulos.registrar('/processo-form', { ativo: 'processos', titulo: 'Cadastro de processo', html: formulario });
  Modulos.registrar('/processos', { ativo: 'processos', titulo: 'Processos', html: html, apos: apos });
  Modulos.registrar('/processos-arvore', { ativo: 'processos', titulo: 'Árvore de gestão — Processos', html: htmlArvore });
  Modulos.registrar('/processos-relatorio', { ativo: 'processos', titulo: 'Árvore de gestão — Processos', html: htmlArvore });   // rota antiga (relatório preliminar) agora abre a árvore
})(window);
