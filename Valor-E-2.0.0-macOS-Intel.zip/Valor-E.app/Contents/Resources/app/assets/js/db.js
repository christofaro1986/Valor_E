/* db.js — banco SQLite (sql.js) dentro da janela + persistência em arquivo pelo aplicativo hospedeiro.
 * Arquivo egidepro.sqlite. */
(function (w) {
  'use strict';
  var DB = w.DB = { db: null, SQL: null, info: '' };

  // ---------- ponte com o hospedeiro (macOS / Windows / Ubuntu); no navegador comum usa IndexedDB ----------
  function b64de(u8) { var s = '', n = 0x8000; for (var i = 0; i < u8.length; i += n) s += String.fromCharCode.apply(null, u8.subarray(i, i + n)); return btoa(s); }
  function b64para(b) { var s = atob(b), u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }

  function idb(modo, valor) {
    return new Promise(function (res) {
      try {
        var rq = indexedDB.open('mapris', 1);
        rq.onupgradeneeded = function () { rq.result.createObjectStore('kv'); };
        rq.onerror = function () { res(null); };
        rq.onsuccess = function () {
          var tx = rq.result.transaction('kv', modo === 'get' ? 'readonly' : 'readwrite'), st = tx.objectStore('kv');
          if (modo === 'get') { var g = st.get('db'); g.onsuccess = function () { res(g.result || null); }; g.onerror = function () { res(null); }; }
          else { st.put(valor, 'db'); tx.oncomplete = function () { res('ok'); }; tx.onerror = function () { res(null); }; }
        };
      } catch (e) { res(null); }
    });
  }
  function host(op, dados) {
    if (w.__maprisHost && w.__maprisHost.invocar) return Promise.resolve(w.__maprisHost.invocar(op, dados || '')).then(function (r) { return r == null ? '' : String(r); });
    // sem hospedeiro (teste em navegador)
    if (op === 'carregar') return idb('get').then(function (v) { return v || ''; });
    if (op === 'gravar') return idb('put', dados).then(function (v) { return v || 'erro'; });
    return Promise.resolve('');
  }
  DB.host = host;

  // ---------- esquema (idêntico ao da versão PHP) ----------
  var ESQUEMA = [
    "CREATE TABLE IF NOT EXISTS riscos (id INTEGER PRIMARY KEY AUTOINCREMENT, ambiente TEXT NOT NULL DEFAULT '', nome TEXT NOT NULL, descricao TEXT DEFAULT '', consequencias TEXT DEFAULT '', categoria TEXT DEFAULT '', responsavel TEXT DEFAULT '', status TEXT DEFAULT 'Identificado', resposta TEXT DEFAULT '', objetivo TEXT DEFAULT '', partes TEXT DEFAULT '', resposta_just TEXT DEFAULT '', aceite_por TEXT DEFAULT '', aceite_validade TEXT, ultima_revisao TEXT, proxima_revisao TEXT, prob_media REAL, imp_medio REAL, indice_medio INTEGER, nivel_medio TEXT, prob_res REAL, imp_res REAL, indice_res INTEGER, nivel_res TEXT, nivel_est TEXT, indice_est INTEGER, nivel_def TEXT, indice_def INTEGER, criado_em TEXT DEFAULT CURRENT_TIMESTAMP, atualizado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS fatores (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, ordem INTEGER DEFAULT 0, nome TEXT DEFAULT '', descricao TEXT DEFAULT '', probabilidade INTEGER DEFAULT 3, impacto INTEGER DEFAULT 3, indice INTEGER, nivel TEXT, p_res REAL, i_res REAL, indice_res INTEGER, nivel_res TEXT, indice_est INTEGER, nivel_est TEXT, indice_def INTEGER, nivel_def TEXT, eficacia REAL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS controles (id INTEGER PRIMARY KEY AUTOINCREMENT, fator_id INTEGER NOT NULL REFERENCES fatores(id) ON DELETE CASCADE, ordem INTEGER DEFAULT 0, descricao TEXT DEFAULT '', tipo_controle TEXT DEFAULT 'Preventivo', natureza TEXT DEFAULT 'Manual', eficacia REAL DEFAULT 0, status TEXT DEFAULT 'Planejado', prob_controle INTEGER DEFAULT 3, imp_controle INTEGER DEFAULT 3, indice INTEGER, nivel TEXT, responsavel TEXT DEFAULT '', prazo TEXT, data_implementacao TEXT, observacoes TEXT DEFAULT '')",
    "CREATE TABLE IF NOT EXISTS planos (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, controle_id INTEGER REFERENCES controles(id) ON DELETE SET NULL, controle_desc TEXT DEFAULT '', descricao TEXT DEFAULT '', responsavel TEXT DEFAULT '', prazo TEXT, status TEXT DEFAULT 'Pendente', prioridade TEXT DEFAULT 'Média', observacoes TEXT DEFAULT '', concluido_em TEXT)",
    "CREATE TABLE IF NOT EXISTS monitoramentos (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, controle_desc TEXT DEFAULT '', data TEXT, acao TEXT DEFAULT '', resultado TEXT DEFAULT '', evidencias TEXT DEFAULT '')",
    "CREATE TABLE IF NOT EXISTS revisoes (id INTEGER PRIMARY KEY AUTOINCREMENT, risco_id INTEGER NOT NULL REFERENCES riscos(id) ON DELETE CASCADE, data TEXT NOT NULL, parecer TEXT DEFAULT '', autor TEXT DEFAULT '', nivel_inerente TEXT, indice_inerente INTEGER, nivel_residual TEXT, indice_residual INTEGER, criado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS config (chave TEXT PRIMARY KEY, valor TEXT)",
    "CREATE TABLE IF NOT EXISTS cva_ciclos (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, missao TEXT DEFAULT '', resultado TEXT DEFAULT '', inicio TEXT, fim TEXT, status TEXT DEFAULT 'Vigente', obs TEXT DEFAULT '', criado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS macroprocessos (id INTEGER PRIMARY KEY AUTOINCREMENT, ciclo_id INTEGER NOT NULL REFERENCES cva_ciclos(id) ON DELETE CASCADE, tipo TEXT NOT NULL DEFAULT 'Finalístico', nome TEXT NOT NULL, descricao TEXT DEFAULT '', responsavel TEXT DEFAULT '', ordem INTEGER DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS processos (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, macro_id INTEGER REFERENCES macroprocessos(id) ON DELETE SET NULL, folha_json TEXT NOT NULL DEFAULT '{}', atividades_json TEXT NOT NULL DEFAULT '[]', opcoes_json TEXT NOT NULL DEFAULT '{}', bpmn_xml TEXT, bpmn_svg TEXT, bpmn_origem TEXT, bpmn_hash TEXT, descricao TEXT DEFAULT '', responsavel TEXT DEFAULT '', status TEXT DEFAULT 'Ativo', validacao TEXT DEFAULT '', validado_ciclo_id INTEGER, criado_em TEXT DEFAULT CURRENT_TIMESTAMP, atualizado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
    "CREATE TABLE IF NOT EXISTS flags (id INTEGER PRIMARY KEY AUTOINCREMENT, processo_id INTEGER NOT NULL REFERENCES processos(id) ON DELETE CASCADE, elemento TEXT NOT NULL DEFAULT '', tarefa TEXT DEFAULT '', criado_em TEXT DEFAULT CURRENT_TIMESTAMP)",
    "CREATE INDEX IF NOT EXISTS idx_flags_processo ON flags(processo_id)",
    "CREATE INDEX IF NOT EXISTS idx_revisoes_risco ON revisoes(risco_id)",
    "CREATE INDEX IF NOT EXISTS idx_fatores_risco ON fatores(risco_id)",
    "CREATE INDEX IF NOT EXISTS idx_controles_fator ON controles(fator_id)",
    "CREATE INDEX IF NOT EXISTS idx_planos_risco ON planos(risco_id)",
    "CREATE INDEX IF NOT EXISTS idx_riscos_ambiente ON riscos(ambiente)"
  ];
  var COLUNAS_NOVAS = { processo_id: 'INTEGER', flag_id: 'INTEGER', projeto_id: 'INTEGER', codigo: "TEXT DEFAULT ''", objetivo: "TEXT DEFAULT ''", partes: "TEXT DEFAULT ''", resposta_just: "TEXT DEFAULT ''", aceite_por: "TEXT DEFAULT ''", aceite_validade: 'TEXT', ultima_revisao: 'TEXT', proxima_revisao: 'TEXT' };

  function tabelas() { return DB.all("SELECT name FROM sqlite_master WHERE type='table'").map(function (r) { return r.name; }); }
  function colunas(t) { return DB.all('PRAGMA table_info(' + t + ')').map(function (c) { return c.name; }); }
  function migrarVersoesAnteriores() {
    var t = tabelas(), d = DB.db;
    if (t.indexOf('cenarios') >= 0 && t.indexOf('processos') < 0) {            // AXIA 3.x: "cenários" viraram "processos"
      d.run('ALTER TABLE cenarios RENAME TO processos');
      if (t.indexOf('flags') >= 0) { d.run('DROP TABLE flags'); }             // flags antigas (posição em PDF) não têm equivalente no diagrama
      if (t.indexOf('cenario_pdf') >= 0) d.run('DROP TABLE cenario_pdf');
      if (colunas('riscos').indexOf('cenario_id') >= 0) d.run('ALTER TABLE riscos RENAME COLUMN cenario_id TO processo_id');
      d.run('UPDATE riscos SET flag_id = NULL');
    }
  }
  DB.extras = DB.extras || [];
  /** Migração versionada: cada módulo registra a criação/alteração das suas tabelas com um id único e estável.
   *  A migração roda uma vez por banco (o id fica em schema_versoes) e deve ser idempotente (CREATE IF NOT EXISTS, ALTER em try). */
  DB.migracao = function (id, fn) { DB.extras.push({ id: id, fn: fn }); };
  function rodarMigracoes() {
    DB.db.run('CREATE TABLE IF NOT EXISTS schema_versoes (id TEXT PRIMARY KEY, aplicada_em TEXT DEFAULT CURRENT_TIMESTAMP)');
    var feitas = {}; DB.all('SELECT id FROM schema_versoes').forEach(function (r) { feitas[r.id] = 1; });
    DB.extras.forEach(function (m) {
      var id = typeof m === 'function' ? null : m.id, fn = typeof m === 'function' ? m : m.fn;
      if (id && feitas[id]) return;
      fn();
      if (id) DB.db.run('INSERT OR IGNORE INTO schema_versoes (id) VALUES (?)', [id]);
    });
  }
  function esquema() {
    DB.db.run('PRAGMA foreign_keys = ON');
    migrarVersoesAnteriores();
    ESQUEMA.forEach(function (s) { DB.db.run(s); });
    var cols = colunas('riscos');
    Object.keys(COLUNAS_NOVAS).forEach(function (c) { if (cols.indexOf(c) < 0) DB.db.run('ALTER TABLE riscos ADD COLUMN ' + c + ' ' + COLUNAS_NOVAS[c]); });
    var pc = colunas('processos'), NP = { macro_id: 'INTEGER', validacao: "TEXT DEFAULT ''", validado_ciclo_id: 'INTEGER', descricao: "TEXT DEFAULT ''", responsavel: "TEXT DEFAULT ''", status: "TEXT DEFAULT 'Ativo'" };
    Object.keys(NP).forEach(function (c) { if (pc.indexOf(c) < 0) DB.db.run('ALTER TABLE processos ADD COLUMN ' + c + ' ' + NP[c]); });
    DB.db.run('CREATE INDEX IF NOT EXISTS idx_riscos_flag ON riscos(flag_id)');
    DB.db.run('CREATE INDEX IF NOT EXISTS idx_riscos_processo ON riscos(processo_id)');
    DB.db.run('CREATE INDEX IF NOT EXISTS idx_proc_macro ON processos(macro_id)');
    rodarMigracoes();
    // códigos (R1, R2…) para riscos que ainda não têm
    DB.all("SELECT id FROM riscos WHERE codigo IS NULL OR codigo = '' ORDER BY id").forEach(function (r) {
      var n = (DB.one("SELECT MAX(CAST(SUBSTR(codigo,2) AS INTEGER)) AS m FROM riscos WHERE codigo GLOB 'R[0-9]*'") || {}).m || 0;
      DB.db.run('UPDATE riscos SET codigo = ? WHERE id = ?', ['R' + (n + 1), r.id]);
    });
  }

  // ---------- consultas ----------
  DB.all = function (sql, p) {
    var st = DB.db.prepare(sql), r = [];
    try { if (p && p.length) st.bind(p); while (st.step()) r.push(st.getAsObject()); } finally { st.free(); }
    return r;
  };
  DB.one = function (sql, p) { return DB.all(sql, p)[0] || null; };
  DB.run = function (sql, p) { DB.db.run(sql, p && p.length ? p : undefined); };
  // nomes usados pelo motor de métricas (Valor Estratégico e Indicadores): mesma camada, sem adaptador
  DB.rows = DB.all;
  DB.exec = function (sql) { return DB.db.exec(sql); };
  DB.persistir = function () { DB.sujo(); };
  DB.lastId = function () { return DB.one('SELECT last_insert_rowid() AS i').i; };
  var txNivel = 0;
  DB.tx = function (fn) {   // reentrante: transações aninhadas participam da externa
    if (txNivel > 0) return fn();
    DB.db.run('BEGIN'); txNivel = 1;
    try { var r = fn(); DB.db.run('COMMIT'); txNivel = 0; DB.sujo(); return r; }
    catch (e) { txNivel = 0; try { DB.db.run('ROLLBACK'); } catch (x) {} throw e; }
  };

  // ---------- persistência (uma gravação por vez; coalesce alterações) ----------
  var gravando = false, pendente = false, esperas = [];
  DB.sujo = function () { pendente = true; if (!gravando) laco(); };
  function laco() {
    if (w.SEC && SEC.cfg().senhaAtiva && !SEC._sessionPassword) { pendente = true; gravando = false; return; } // bloqueado: não grava em claro
    gravando = true; pendente = false;
    var b64 = b64de(DB.db.export());
    // db.export() fecha os statements e redefine pragmas: restabelece as chaves estrangeiras
    try { DB.db.run('PRAGMA foreign_keys = ON'); } catch (e) {}
    var prep = (w.SEC && SEC.cfg().senhaAtiva)
      ? SEC.wrapForHost(b64)
      : Promise.resolve(b64);
    prep.then(function (payload) {
      return host('gravar', payload);
    }).then(function (r) {
      if (r && r !== 'ok') DB.erroGravar && DB.erroGravar(r);
    }).then(function () {
      gravando = false;
      if (pendente) laco(); else { var e = esperas; esperas = []; e.forEach(function (f) { f(); }); }
    }).catch(function (err) {
      gravando = false;
      if (DB.erroGravar) DB.erroGravar(String(err && err.message || err));
    });
  }
  DB.flush = function () { return new Promise(function (res) { if (!gravando && !pendente) res(); else esperas.push(res); }); };

  DB.iniciar = function () {
    return initSqlJs({ wasmBinary: window.__SQLJS_WASM }).then(function (SQL) {
      DB.SQL = SQL;
      // chave do sistema (v2): o aplicativo nativo guarda uma chave aleatória; sem ela cai no modo de senha
      return host('chave').then(function (k) { if (w.SEC && typeof k === 'string' && k.length >= 40) SEC._chaveSis = k; }, function () {});
    }).then(function () {
      return host('carregar');
    }).then(function (b64) {
      function abrir(plainB64) {
        DB.db = plainB64 ? new DB.SQL.Database(b64para(plainB64)) : new DB.SQL.Database();
        esquema();
        try {
          DB.db.run("CREATE TABLE IF NOT EXISTS sec_auditoria (id INTEGER PRIMARY KEY AUTOINCREMENT, em TEXT DEFAULT (datetime('now','localtime')), acao TEXT, detalhe TEXT)");
        } catch (e) {}
        DB.sujo();
        return host('info').then(function (i) { DB.info = i || ''; }).then(function () {
          return (w.SEC && !SEC.cfg().senhaAtiva) ? (SEC._chaveSis ? SEC.ativarSistema() : SEC.exigirSenha()).then(function () { DB.sujo(); }) : null;
        });
      }
      if (b64 && w.SEC && SEC.isEncryptedBlob(b64)) {
        return SEC.abrirCifrado(b64).then(function (plain) {
          if (w.SEC) SEC.audit('abertura', 'banco cifrado');
          return abrir(plain);
        });
      }
      return abrir(b64);
    });
  };
  DB.exportarBytes = function () { var u = DB.db.export(); try { DB.db.run('PRAGMA foreign_keys = ON'); } catch (e) {} return u; };
  // substitui o banco inteiro (restauração de backup)
  DB.substituir = function (bytes) {
    var novo = new DB.SQL.Database(bytes);
    DB.db.close(); DB.db = novo; esquema(); DB.sujo();
  };

  // Limpar todos os dados (mantém as tabelas; confirmação dupla)
  w.limparBase = function () {
    if (!confirm('Apagar TODOS os dados deste aplicativo (cadastros e lançamentos)? Esta ação não pode ser desfeita.')) return;
    if (!confirm('Confirma novamente: apagar tudo e começar com a base vazia?')) return;
    if (w.SEC) SEC.audit('limpar_base', 'confirmado');
    var d = DB.db, keep = [];
    try { d.run('PRAGMA foreign_keys = OFF'); } catch (e) {}
    var res = d.exec("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
    ((res[0] && res[0].values) || []).forEach(function (r) { if (keep.indexOf(r[0]) < 0) { try { d.run('DELETE FROM "' + r[0] + '"'); } catch (e) {} } });
    try { d.run('DELETE FROM sqlite_sequence'); } catch (e) {}
    DB.sujo(); DB.flush().then(function () { location.reload(); });
  };
  w.addEventListener('pagehide', function () { if (DB.db && pendente) laco(); });
})(window);
