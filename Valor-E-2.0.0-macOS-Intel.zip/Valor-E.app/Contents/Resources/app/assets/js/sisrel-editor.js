/* sisrel-editor.js — editor de texto rico do Valor-E (TipTap/ProseMirror, 100% local, sem rede).
 * API:  SisrelEditor.criar(elemento, { placeholder, dados, minAltura, barra: 'completa'|'simples', aoMudar(html) }) -> Promise<editor>
 * Compatível: window.ClassicEditor.create(el, cfg) usa a mesma API.
 * editor.getData() ('' quando vazio) / setData(html) / destroy() / focus()
 * O HTML gravado é padrão (p, ul, ol, h1-h3, table, mark, span[style=color]…) e é saneado por SisrelHtml.seguro.
 */
(function (w) {
  'use strict';
  var T = w.TipTap;
  if (!T) { console.error('TipTap não carregado (tiptap.bundle.js ausente)'); return; }

  var LISTA = [];
  var CORES = ['#000000', '#434343', '#7f7f7f', '#c00000', '#e36c09', '#f2b705', '#2e7d32', '#00796b', '#1565c0', '#6a1b9a', '#d81b60', '#ffffff'];
  var MARCAS = ['#fff59d', '#ffe0b2', '#ffcdd2', '#f8bbd0', '#e1bee7', '#c5cae9', '#bbdefb', '#b2ebf2', '#c8e6c9', '#dcedc8'];

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

  // [id, ícone, título, ação(ed, api), ativo(ed)]
  var BTN = {
    negrito: ['bi-type-bold', 'Negrito (Ctrl+B)', function (e) { e.chain().focus().toggleBold().run(); }, function (e) { return e.isActive('bold'); }],
    italico: ['bi-type-italic', 'Itálico (Ctrl+I)', function (e) { e.chain().focus().toggleItalic().run(); }, function (e) { return e.isActive('italic'); }],
    sublinhado: ['bi-type-underline', 'Sublinhado (Ctrl+U)', function (e) { e.chain().focus().toggleUnderline().run(); }, function (e) { return e.isActive('underline'); }],
    tachado: ['bi-type-strikethrough', 'Tachado', function (e) { e.chain().focus().toggleStrike().run(); }, function (e) { return e.isActive('strike'); }],
    sobrescrito: ['bi-superscript', 'Sobrescrito', function (e) { e.chain().focus().toggleSuperscript().run(); }, function (e) { return e.isActive('superscript'); }],
    subscrito: ['bi-subscript', 'Subscrito', function (e) { e.chain().focus().toggleSubscript().run(); }, function (e) { return e.isActive('subscript'); }],
    esquerda: ['bi-text-left', 'Alinhar à esquerda', function (e) { e.chain().focus().setTextAlign('left').run(); }, function (e) { return e.isActive({ textAlign: 'left' }); }],
    centro: ['bi-text-center', 'Centralizar', function (e) { e.chain().focus().setTextAlign('center').run(); }, function (e) { return e.isActive({ textAlign: 'center' }); }],
    direita: ['bi-text-right', 'Alinhar à direita', function (e) { e.chain().focus().setTextAlign('right').run(); }, function (e) { return e.isActive({ textAlign: 'right' }); }],
    justificado: ['bi-justify', 'Justificar', function (e) { e.chain().focus().setTextAlign('justify').run(); }, function (e) { return e.isActive({ textAlign: 'justify' }); }],
    marcadores: ['bi-list-ul', 'Lista com marcadores', function (e) { e.chain().focus().toggleBulletList().run(); }, function (e) { return e.isActive('bulletList'); }],
    numerada: ['bi-list-ol', 'Lista numerada', function (e) { e.chain().focus().toggleOrderedList().run(); }, function (e) { return e.isActive('orderedList'); }],
    tarefas: ['bi-list-check', 'Lista de tarefas', function (e) { e.chain().focus().toggleTaskList().run(); }, function (e) { return e.isActive('taskList'); }],
    recuar: ['bi-text-indent-left', 'Diminuir recuo', function (e) { var t = e.isActive('taskItem') ? 'taskItem' : 'listItem'; e.chain().focus().liftListItem(t).run(); }],
    avancar: ['bi-text-indent-right', 'Aumentar recuo', function (e) { var t = e.isActive('taskItem') ? 'taskItem' : 'listItem'; e.chain().focus().sinkListItem(t).run(); }],
    citacao: ['bi-quote', 'Citação', function (e) { e.chain().focus().toggleBlockquote().run(); }, function (e) { return e.isActive('blockquote'); }],
    codigo: ['bi-code-slash', 'Bloco de código', function (e) { e.chain().focus().toggleCodeBlock().run(); }, function (e) { return e.isActive('codeBlock'); }],
    linha: ['bi-dash-lg', 'Linha horizontal', function (e) { e.chain().focus().setHorizontalRule().run(); }],
    limpar: ['bi-eraser', 'Limpar formatação', function (e) { e.chain().focus().unsetAllMarks().clearNodes().run(); }],
    desfazer: ['bi-arrow-counterclockwise', 'Desfazer (Ctrl+Z)', function (e) { e.chain().focus().undo().run(); }],
    refazer: ['bi-arrow-clockwise', 'Refazer (Ctrl+Y)', function (e) { e.chain().focus().redo().run(); }]
  };

  var BARRA_COMPLETA = [['titulo'], ['negrito', 'italico', 'sublinhado', 'tachado'], ['cor', 'marca'], ['sobrescrito', 'subscrito'],
    ['esquerda', 'centro', 'direita', 'justificado'], ['marcadores', 'numerada', 'tarefas', 'recuar', 'avancar'], ['citacao', 'codigo', 'linha'],
    ['link', 'imagem', 'tabela'], ['limpar', 'desfazer', 'refazer']];
  var BARRA_SIMPLES = [['negrito', 'italico', 'sublinhado', 'tachado'], ['cor', 'marca'], ['marcadores', 'numerada', 'recuar', 'avancar'], ['esquerda', 'centro', 'direita'], ['link', 'limpar']];

  function criar(el, opt) {
    opt = opt || {};
    return new Promise(function (resolve, reject) {
      try {
        if (!el) return reject(new Error('Elemento inválido'));
        var escondido = null, caixa;
        if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
          caixa = document.createElement('div');
          if (el.id) caixa.id = el.id + '_editor';
          el.parentNode.insertBefore(caixa, el);
          el.style.display = 'none'; el.setAttribute('data-sr-editor-hidden', '1'); escondido = el;
        } else caixa = el;
        caixa.innerHTML = '';
        caixa.classList.add('sr-editor');
        if (opt.barra === 'simples') caixa.classList.add('sr-editor-simples');

        var barra = document.createElement('div'); barra.className = 'sr-ed-barra';
        var entrada = document.createElement('div'); entrada.className = 'sr-ed-entrada'; entrada.style.display = 'none';
        var area = document.createElement('div'); area.className = 'sr-ed-area sr-rich';
        var contador = document.createElement('div'); contador.className = 'sr-editor-contador';
        caixa.appendChild(barra); caixa.appendChild(entrada); caixa.appendChild(area); caixa.appendChild(contador);
        var min = opt.minAltura || 160;

        var ed = new T.Editor({
          element: area,
          content: opt.dados ? w.SisrelHtml.paraEditor(opt.dados) : '',
          extensions: [
            T.StarterKit.configure({ link: { openOnClick: false, autolink: true, HTMLAttributes: { rel: 'noopener noreferrer', target: '_blank' } } }),
            T.TextStyle, T.Color, T.Highlight.configure({ multicolor: true }),
            T.TextAlign.configure({ types: ['heading', 'paragraph'] }),
            T.Subscript, T.Superscript,
            T.TaskList, T.TaskItem.configure({ nested: true }),
            T.Table.configure({ resizable: false }), T.TableRow, T.TableHeader, T.TableCell,
            T.Image.configure({ allowBase64: true }),
            T.Placeholder.configure({ placeholder: opt.placeholder || '' })
          ],
          editorProps: { attributes: { class: 'sr-ed-conteudo', style: 'min-height:' + min + 'px', spellcheck: 'true' } },
          onUpdate: function () { sincronizar(); if (opt.aoMudar) { try { opt.aoMudar(api.getData()); } catch (e) {} } },
          onSelectionUpdate: function () { atualizarBarra(); },
          onTransaction: function () { atualizarBarra(); }
        });

        function sincronizar() {
          var t = ed.getText();
          var palavras = t.trim() ? t.trim().split(/\s+/).length : 0;
          contador.textContent = palavras + ' palavra(s) · ' + t.length + ' caractere(s)';
          if (escondido) escondido.value = api.getData();
        }

        // ---------- barra de ferramentas ----------
        var botoes = {}, menuAberto = null;
        function fecharMenu() { if (menuAberto) { menuAberto.remove(); menuAberto = null; } }
        function btn(id, icone, titulo, acao) {
          var b = document.createElement('button'); b.type = 'button'; b.className = 'sr-ed-btn'; b.title = titulo; b.setAttribute('aria-label', titulo);
          b.innerHTML = '<i class="bi ' + icone + '"></i>';
          b.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
          b.addEventListener('click', function (ev) { ev.preventDefault(); fecharMenu(); acao(b); });
          botoes[id] = b; return b;
        }
        function menu(ancora, itens) {
          fecharMenu();
          var m = document.createElement('div'); m.className = 'sr-ed-menu';
          itens.forEach(function (it) {
            var i = document.createElement('button'); i.type = 'button'; i.className = 'sr-ed-menu-item'; i.textContent = it[0];
            i.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
            i.addEventListener('click', function (ev) { ev.preventDefault(); fecharMenu(); it[1](); });
            m.appendChild(i);
          });
          posicionar(m, ancora); return m;
        }
        function posicionar(m, ancora) {
          caixa.appendChild(m);
          var cr = caixa.getBoundingClientRect(), ar = ancora.getBoundingClientRect();
          m.style.left = Math.max(0, Math.min(ar.left - cr.left, cr.width - 200)) + 'px';
          m.style.top = (ar.bottom - cr.top + 2) + 'px';
          menuAberto = m;
        }
        function paleta(ancora, cores, aplicar, remover) {
          fecharMenu();
          var m = document.createElement('div'); m.className = 'sr-ed-menu sr-ed-paleta';
          cores.forEach(function (c) {
            var s = document.createElement('button'); s.type = 'button'; s.className = 'sr-ed-cor'; s.style.background = c; s.title = c;
            s.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
            s.addEventListener('click', function (ev) { ev.preventDefault(); fecharMenu(); aplicar(c); });
            m.appendChild(s);
          });
          var r = document.createElement('button'); r.type = 'button'; r.className = 'sr-ed-menu-item'; r.textContent = 'Sem cor';
          r.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
          r.addEventListener('click', function (ev) { ev.preventDefault(); fecharMenu(); remover(); });
          m.appendChild(r); posicionar(m, ancora);
        }
        // pequena barra de entrada (link / endereço de imagem) — não depende de prompt(), que alguns webviews bloqueiam
        function pedir(rotulo, valor, ok, extra) {
          entrada.innerHTML = '';
          var l = document.createElement('span'); l.textContent = rotulo;
          var i = document.createElement('input'); i.type = 'text'; i.className = 'form-control form-control-sm'; i.value = valor || ''; i.placeholder = 'https://…';
          var b1 = document.createElement('button'); b1.type = 'button'; b1.className = 'btn btn-success btn-sm'; b1.textContent = 'OK';
          var b2 = document.createElement('button'); b2.type = 'button'; b2.className = 'btn btn-outline-secondary btn-sm'; b2.textContent = 'Cancelar';
          function fim() { entrada.style.display = 'none'; entrada.innerHTML = ''; ed.commands.focus(); }
          b1.onclick = function () { var v = i.value.trim(); fim(); ok(v); };
          b2.onclick = fim;
          i.addEventListener('keydown', function (ev) { ev.stopPropagation(); if (ev.key === 'Enter') { ev.preventDefault(); b1.onclick(); } if (ev.key === 'Escape') fim(); });
          entrada.appendChild(l); entrada.appendChild(i); entrada.appendChild(b1); entrada.appendChild(b2);
          if (extra) entrada.appendChild(extra);
          entrada.style.display = 'flex'; i.focus(); i.select();
        }
        function urlSegura(u) { return /^(https?:\/\/|mailto:|#)/i.test(u) ? u : (u ? 'https://' + u : ''); }

        function reduzirImagem(arq, cb) {
          var fr = new FileReader();
          fr.onload = function () {
            var im = new Image();
            im.onload = function () {
              var maxL = 1400, f = Math.min(1, maxL / im.width);
              if (f === 1 && arq.size < 600000) return cb(fr.result);
              var c = document.createElement('canvas'); c.width = Math.round(im.width * f); c.height = Math.round(im.height * f);
              c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
              cb(c.toDataURL(arq.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.85));
            };
            im.onerror = function () { cb(fr.result); };
            im.src = fr.result;
          };
          fr.readAsDataURL(arq);
        }

        var ESPECIAIS = {
          titulo: function () {
            var s = document.createElement('select'); s.className = 'sr-ed-sel'; s.title = 'Estilo do parágrafo';
            [['0', 'Parágrafo'], ['1', 'Título 1'], ['2', 'Título 2'], ['3', 'Título 3']].forEach(function (o) { var op = document.createElement('option'); op.value = o[0]; op.textContent = o[1]; s.appendChild(op); });
            s.addEventListener('change', function () { var n = +s.value; if (n) ed.chain().focus().setHeading({ level: n }).run(); else ed.chain().focus().setParagraph().run(); });
            botoes.titulo = s; return s;
          },
          cor: function () { return btn('cor', 'bi-palette', 'Cor do texto', function (b) { paleta(b, CORES, function (c) { ed.chain().focus().setColor(c).run(); }, function () { ed.chain().focus().unsetColor().run(); }); }); },
          marca: function () { return btn('marca', 'bi-paint-bucket', 'Cor de destaque (marca-texto)', function (b) { paleta(b, MARCAS, function (c) { ed.chain().focus().setHighlight({ color: c }).run(); }, function () { ed.chain().focus().unsetHighlight().run(); }); }); },
          link: function () {
            return btn('link', 'bi-link-45deg', 'Inserir ou editar link', function () {
              var atual = ed.getAttributes('link').href || '';
              if (ed.state.selection.empty && !atual) { ed.chain().focus().insertContent('<a href="https://">link</a>').run(); }
              pedir('Endereço do link:', atual, function (v) {
                if (!v) ed.chain().focus().extendMarkRange('link').unsetLink().run();
                else ed.chain().focus().extendMarkRange('link').setLink({ href: urlSegura(v) }).run();
              });
            });
          },
          imagem: function () {
            return btn('imagem', 'bi-image', 'Inserir imagem', function () {
              var f = document.createElement('input'); f.type = 'file'; f.accept = 'image/png,image/jpeg,image/gif,image/webp'; f.style.display = 'none';
              f.addEventListener('change', function () {
                var a = f.files && f.files[0]; if (!a) return;
                reduzirImagem(a, function (src) { ed.chain().focus().setImage({ src: src, alt: a.name }).run(); });
              });
              pedir('Endereço da imagem (ou escolha um arquivo):', '', function (v) { if (v) ed.chain().focus().setImage({ src: urlSegura(v) }).run(); }, (function () {
                var b = document.createElement('button'); b.type = 'button'; b.className = 'btn btn-outline-success btn-sm'; b.textContent = 'Arquivo…';
                b.onclick = function () { entrada.style.display = 'none'; f.click(); }; return b;
              })());
            });
          },
          tabela: function () {
            return btn('tabela', 'bi-table', 'Tabela', function (b) {
              var it = [];
              if (!ed.isActive('table')) it.push(['Inserir tabela 3×3', function () { ed.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run(); }]);
              else {
                it.push(['Adicionar linha abaixo', function () { ed.chain().focus().addRowAfter().run(); }]);
                it.push(['Adicionar coluna à direita', function () { ed.chain().focus().addColumnAfter().run(); }]);
                it.push(['Excluir linha', function () { ed.chain().focus().deleteRow().run(); }]);
                it.push(['Excluir coluna', function () { ed.chain().focus().deleteColumn().run(); }]);
                it.push(['Linha de cabeçalho on/off', function () { ed.chain().focus().toggleHeaderRow().run(); }]);
                it.push(['Excluir tabela', function () { ed.chain().focus().deleteTable().run(); }]);
              }
              menu(b, it);
            });
          }
        };

        (opt.barra === 'simples' ? BARRA_SIMPLES : BARRA_COMPLETA).forEach(function (grupo) {
          var g = document.createElement('span'); g.className = 'sr-ed-grupo';
          grupo.forEach(function (id) {
            if (ESPECIAIS[id]) g.appendChild(ESPECIAIS[id]());
            else { var d = BTN[id]; g.appendChild(btn(id, d[0], d[1], function () { d[2](ed); })); }
          });
          barra.appendChild(g);
        });

        function atualizarBarra() {
          Object.keys(BTN).forEach(function (id) {
            var d = BTN[id], b = botoes[id]; if (!b || !d[3]) return;
            b.classList.toggle('ativo', !!d[3](ed));
          });
          if (botoes.link) botoes.link.classList.toggle('ativo', ed.isActive('link'));
          if (botoes.tabela) botoes.tabela.classList.toggle('ativo', ed.isActive('table'));
          if (botoes.titulo) { var n = 0; for (var k = 1; k <= 3; k++) if (ed.isActive('heading', { level: k })) n = k; botoes.titulo.value = String(n); }
          if (botoes.desfazer) botoes.desfazer.disabled = !ed.can().undo();
          if (botoes.refazer) botoes.refazer.disabled = !ed.can().redo();
        }
        document.addEventListener('mousedown', function fechar(ev) {
          if (!caixa.isConnected) { document.removeEventListener('mousedown', fechar); return; }
          if (menuAberto && !menuAberto.contains(ev.target)) fecharMenu();
        });

        // Espaço não deve ser capturado por atalhos de modais
        ed.view.dom.addEventListener('keydown', function (ev) { if (ev.key === ' ' || ev.keyCode === 32) ev.stopPropagation(); }, true);
        // Cola texto: se vier HTML, o TipTap já filtra pelo esquema; imagens coladas viram data URI reduzida
        ed.view.dom.addEventListener('paste', function (ev) {
          var itens = (ev.clipboardData && ev.clipboardData.items) || [];
          for (var i = 0; i < itens.length; i++) {
            if (itens[i].kind === 'file' && /^image\//.test(itens[i].type)) {
              var arq = itens[i].getAsFile(); if (!arq) continue;
              ev.preventDefault(); reduzirImagem(arq, function (src) { ed.chain().focus().setImage({ src: src }).run(); }); return;
            }
          }
        });

        var api = {
          _tiptap: ed, _host: caixa, _hidden: escondido,
          getData: function () { return ed.isEmpty ? '' : ed.getHTML(); },
          setData: function (html) { ed.commands.setContent(w.SisrelHtml.paraEditor(html || ''), { emitUpdate: false }); sincronizar(); atualizarBarra(); },
          focus: function () { try { ed.commands.focus(); } catch (e) {} },
          destroy: function () {
            try { ed.destroy(); } catch (e) {}
            try {
              if (caixa && escondido && caixa.parentNode) caixa.parentNode.removeChild(caixa);
              else if (caixa) { caixa.innerHTML = ''; caixa.classList.remove('sr-editor', 'sr-editor-simples'); }
              if (escondido) { escondido.style.display = ''; escondido.removeAttribute('data-sr-editor-hidden'); }
            } catch (e) {}
            var i = LISTA.indexOf(api); if (i >= 0) LISTA.splice(i, 1);
            return Promise.resolve();
          },
          on: function () { /* compat CKEditor */ },
          editing: { view: { getDomRoot: function () { return ed.view.dom; }, change: function () {} } },
          ui: { view: { element: caixa } },
          plugins: { get: function () { return null; } }
        };
        sincronizar(); atualizarBarra();
        LISTA.push(api);
        resolve(api);
      } catch (err) {
        console.error('SisrelEditor:', err);
        reject(err);
      }
    });
  }

  w.SisrelEditor = { criar: criar, lista: LISTA };
  w.ClassicEditor = {
    create: function (el, cfg) {
      cfg = cfg || {};
      return criar(el, { placeholder: cfg.placeholder || '', minAltura: 180 }).then(function (ed) {
        if (el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') && el.value) ed.setData(el.value);
        return ed;
      });
    }
  };
})(window);
