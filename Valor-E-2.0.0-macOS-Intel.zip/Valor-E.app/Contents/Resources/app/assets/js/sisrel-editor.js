/* sisrel-editor.js — editor de texto rico do SISREL (Quill 2, 100% local, sem rede).
 * API:  SisrelEditor.criar(elemento, { placeholder, dados, minAltura }) -> Promise<editor>
 * Compatível: window.ClassicEditor.create(el, cfg) usa a mesma API.
 * editor.getData() / setData(html) / destroy() / focus()
 */
(function (w) {
  'use strict';
  if (!w.Quill) {
    console.error('Quill não carregado (quill.js ausente)');
    return;
  }

  // Toolbar completa (equivalente prática ao CKEditor usado no SISREL)
  var TOOLBAR = [
    [{ header: [1, 2, 3, false] }],
    [{ font: [] }, { size: ['small', false, 'large', 'huge'] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ color: [] }, { background: [] }],
    [{ script: 'sub' }, { script: 'super' }],
    [{ align: [] }],
    [{ list: 'ordered' }, { list: 'bullet' }, { list: 'check' }],
    [{ indent: '-1' }, { indent: '+1' }],
    ['blockquote', 'code-block'],
    ['link', 'image'],
    ['clean']
  ];

  var LISTA = [];

  function htmlParaDelta(quill, html) {
    if (!html) return;
    try {
      var delta = quill.clipboard.convert({ html: html });
      quill.setContents(delta, 'silent');
    } catch (e) {
      try { quill.root.innerHTML = html; } catch (e2) {}
    }
  }

  function criar(el, opt) {
    opt = opt || {};
    return new Promise(function (resolve, reject) {
      try {
        if (!el) return reject(new Error('Elemento inválido'));

        // Se for textarea/input, troca por um container contenteditable do Quill
        var host = el;
        if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
          host = document.createElement('div');
          host.className = 'sr-editor-host';
          if (el.id) host.id = el.id + '_quill';
          if (el.parentNode) el.parentNode.insertBefore(host, el);
          el.style.display = 'none';
          el.setAttribute('data-sr-editor-hidden', '1');
        }

        var min = opt.minAltura || 220;
        host.style.minHeight = min + 'px';

        var quill = new w.Quill(host, {
          theme: 'snow',
          placeholder: opt.placeholder || '',
          modules: {
            toolbar: TOOLBAR
          }
        });

        // Área editável
        var editorRoot = quill.root;
        editorRoot.style.minHeight = min + 'px';
        editorRoot.classList.add('sr-editor-area');

        // Contador simples
        var box = document.createElement('div');
        box.className = 'sr-editor-contador';
        var wrap = host.parentNode;
        // Toolbar fica como irmão anterior; coloca contador depois do host
        if (host.parentNode) host.parentNode.insertBefore(box, host.nextSibling);

        function atualizarContador() {
          var texto = (quill.getText() || '').replace(/\n$/, '');
          var palavras = texto.trim() ? texto.trim().split(/\s+/).length : 0;
          var chars = texto.length;
          box.textContent = palavras + ' palavra(s) · ' + chars + ' caractere(s)';
        }
        quill.on('text-change', atualizarContador);
        atualizarContador();

        // Espaço não deve ser capturado por atalhos de modais
        editorRoot.addEventListener('keydown', function (ev) {
          if (ev.key === ' ' || ev.keyCode === 32) ev.stopPropagation();
        }, true);

        if (opt.dados) htmlParaDelta(quill, opt.dados);

        var api = {
          _quill: quill,
          _host: host,
          _hidden: (el !== host) ? el : null,
          _box: box,
          getData: function () {
            var html = quill.root.innerHTML;
            // Quill vazio costuma ser <p><br></p>
            if (!quill.getText().trim()) return '';
            return html;
          },
          setData: function (html) {
            htmlParaDelta(quill, html || '');
            atualizarContador();
          },
          focus: function () {
            try { quill.focus(); } catch (e) {}
          },
          destroy: function () {
            try {
              if (box && box.parentNode) box.parentNode.removeChild(box);
              // Remove toolbar gerada pelo Quill
              var toolbar = host.previousSibling;
              if (toolbar && toolbar.classList && toolbar.classList.contains('ql-toolbar')) {
                toolbar.parentNode.removeChild(toolbar);
              }
              if (host && host.parentNode && el !== host) {
                host.parentNode.removeChild(host);
              }
              if (el && el !== host) {
                el.style.display = '';
                el.removeAttribute('data-sr-editor-hidden');
              }
            } catch (e) {}
            var i = LISTA.indexOf(api);
            if (i >= 0) LISTA.splice(i, 1);
            return Promise.resolve();
          },
          on: function () { /* no-op compat CKEditor */ },
          editing: { view: { getDomRoot: function () { return editorRoot; }, change: function () {} } },
          ui: { view: { element: host } },
          plugins: { get: function () { return null; } }
        };

        LISTA.push(api);
        resolve(api);
      } catch (err) {
        console.error('SisrelEditor:', err);
        reject(err);
      }
    });
  }

  w.SisrelEditor = { criar: criar, lista: LISTA };
  w.ClassicEditor = {
    create: function (el, cfg) {
      cfg = cfg || {};
      return criar(el, {
        placeholder: cfg.placeholder || '',
        dados: undefined,
        minAltura: 180
      }).then(function (ed) {
        // se textarea já tinha valor
        if (el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') && el.value) {
          ed.setData(el.value);
        }
        return ed;
      });
    }
  };
})(window);
