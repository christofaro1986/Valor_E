/* fapi.js — regras da Folha de dados dentro do AXIA: o 'processo' do Folha é um processo de origem 'folha'. */
(function (w) {
  'use strict';
  var API = w.API = {};

  API.folhaPadrao = function () {
    return {
      codigo: '', objetivo: '', siglas: [], campo_aplicacao: '', gestor: [], executores: [], escopo_inicio: '', escopo_fim: '',
      areas: [], fornecedores: [], clientes: [], documentos: [], competencias: [], registros: [], alertas: [], indicadores: [],
      ambientais: [
        { variavel: 'Nível de ruído', minimo: 'N.A.', maximo: 'N.A.' }, { variavel: 'Temperatura', minimo: 'N.A.', maximo: 'N.A.' },
        { variavel: 'Umidade', minimo: 'N.A.', maximo: 'N.A.' }, { variavel: 'Luminosidade', minimo: 'N.A.', maximo: 'N.A.' }
      ],
      instalacoes: [], equipamentos: [], softwares: [],
      alteracoes: [{ versao: 'Versão 00.', descricao: 'Emissão do documento.' }],
      elaboracao: '', aprovacao: ''
    };
  };
  function jp(s, d) { try { var v = JSON.parse(s); return (v === null || v === undefined || v === '' || v === 0) ? d : v; } catch (e) { return d; } }
  // arrays vazios vindos do PHP ([]) no lugar de objetos vazios ({}) — normaliza para objeto
  function normAtiv(a) {
    if (!Array.isArray(a)) return [];
    a.forEach(function (r) { if (r && typeof r === 'object') { if (!r.seq || Array.isArray(r.seq) || typeof r.seq !== 'object') r.seq = {}; if (!Array.isArray(r.anexos)) r.anexos = []; } });
    return a;
  }
  API.hash = function (ativ, op) { return 'n1:' + w.md5(JSON.stringify([ativ, op])); };
  // hash de versões antigas (PHP) não é recalculável aqui: considera-se atualizado
  function desatualizado(p) {
    if (!p.bpmn_xml || !p.bpmn_hash || String(p.bpmn_hash).indexOf('n1:') !== 0) return false;
    return p.bpmn_hash !== API.hash(jp(p.atividades_json, []), jp(p.opcoes_json, {}));
  }
  API.buscar = function (id) { return DB.one("SELECT * FROM processos WHERE id = ?", [id]); };
  API.dados = function (p) {
    var folha = Object.assign(API.folhaPadrao(), jp(p.folha_json, {}));
    var ativ = normAtiv(jp(p.atividades_json, [])), op = Object.assign({ auto_inicio_fim: true }, jp(p.opcoes_json, {}));
    return { id: p.id, nome: p.nome, folha: folha, atividades: ativ, opcoes: op, temDiagrama: !!p.bpmn_xml };
  };
  API.listar = function () {
    return DB.all('SELECT id,nome,atividades_json,bpmn_xml,bpmn_origem,atualizado_em FROM processos ORDER BY atualizado_em DESC, id DESC').map(function (r) {
      var a = jp(r.atividades_json, []);
      r.n = (Array.isArray(a) ? a : []).filter(function (x) { return x && (x.tipo || x.descricao); }).length;
      return r;
    });
  };
  API.slug = function (n) { return String(n).replace(/[^A-Za-z0-9_-]+/g, '_') || 'processo'; };

  function salvarDados(id, b) {
    var folha = (b.folha && typeof b.folha === 'object') ? b.folha : {}, ativ = Array.isArray(b.atividades) ? b.atividades : [];
    var op = (b.opcoes && typeof b.opcoes === 'object') ? b.opcoes : {}, nome = String(b.nome || '').replace(/^\s+|\s+$/g, '');
    if (nome !== '' && DB.one('SELECT 1 AS x FROM processos WHERE nome = ? COLLATE NOCASE AND id != ?', [nome, id])) throw new Error('Já existe um processo com este nome.');
    DB.tx(function () {
      var sql = 'UPDATE processos SET folha_json=?, atividades_json=?, opcoes_json=?, atualizado_em=CURRENT_TIMESTAMP' + (nome !== '' ? ', nome=?' : '') + ' WHERE id=?';
      var par = [JSON.stringify(folha), JSON.stringify(ativ), JSON.stringify(op)];
      if (nome !== '') par.push(nome);
      par.push(id);
      DB.run(sql, par);
      if (nome !== '') DB.run('UPDATE riscos SET ambiente = ? WHERE processo_id = ?', [nome, id]); // o ambiente dos riscos acompanha o nome
    });
  }
  function gravarDiagrama(id, nome, ativ, op) {
    var r = Bpmn.gerar(nome, ativ, { auto_inicio_fim: op.auto_inicio_fim === undefined || op.auto_inicio_fim === null ? true : op.auto_inicio_fim });
    DB.run("UPDATE processos SET bpmn_xml=?, bpmn_svg=NULL, bpmn_origem='gerado', bpmn_hash=? WHERE id=?", [r.xml, API.hash(ativ, op), id]);
    return r;
  }

  // todas as ações devolvem {ok:true,...} ou {ok:false,erro}
  API.acao = function (a, body) {
    body = body || {};
    var id = parseInt(body.id, 10) || 0, p, r;
    try {
      switch (a) {
        case 'salvar':
          p = API.buscar(id); if (!p) return { ok: false, erro: 'Processo não encontrado' };
          salvarDados(id, body); p = API.buscar(id);
          return { ok: true, atualizado_em: p.atualizado_em, desatualizado: desatualizado(p) };
        case 'gerar': {
          p = API.buscar(id); if (!p) return { ok: false, erro: 'Processo não encontrado' };
          if (body.atividades !== undefined) { salvarDados(id, body); p = API.buscar(id); }
          r = gravarDiagrama(id, p.nome, normAtiv(jp(p.atividades_json, [])), jp(p.opcoes_json, {}));
          return { ok: true, avisos: r.avisos, estat: r.estat };
        }
        case 'salvar_bpmn':
          if (!API.buscar(id)) return { ok: false, erro: 'Processo não encontrado' };
          if (!body.xml || String(body.xml).indexOf('<') < 0) return { ok: false, erro: 'XML vazio' };
          DB.run("UPDATE processos SET bpmn_xml=?, bpmn_svg=?, bpmn_origem='editado', atualizado_em=CURRENT_TIMESTAMP WHERE id=?", [String(body.xml), String(body.svg || ''), id]);
          return { ok: true };
        case 'exportar_json':
          p = API.buscar(id); if (!p) return { ok: false, erro: 'Processo não encontrado' };
          return { ok: true, nome: API.slug(p.nome) + '.folha.json', tipo: 'application/json', texto: JSON.stringify({ formato: 'folha-bpmn', versao: 1, nome: p.nome, folha: jp(p.folha_json, {}), atividades: jp(p.atividades_json, []), opcoes: jp(p.opcoes_json, {}), bpmn_xml: p.bpmn_xml }, null, 4) };
        case 'exportar_xml':
          p = API.buscar(id); if (!p) return { ok: false, erro: 'Processo não encontrado' };
          return { ok: true, nome: API.slug(p.nome) + '.folha.xml', tipo: 'application/xml', texto: FolhaXml.paraXml({ nome: p.nome, folha: jp(p.folha_json, {}), atividades: jp(p.atividades_json, []), opcoes: jp(p.opcoes_json, {}) }) };
        case 'importar_xml': {
          var o = FolhaXml.deXml(String(body.xml || ''));
          var folha = (o.folha && Object.keys(o.folha).length) ? o.folha : API.folhaPadrao();
          var nm = String(o.nome || 'Processo importado'), avisos = [], novo;
          var ja = DB.one('SELECT id FROM processos WHERE nome = ? COLLATE NOCASE ORDER BY id LIMIT 1', [nm]);
          if (ja) {   // já existe: atualiza a Folha de dados e o diagrama (bandeiras e riscos vinculados são mantidos)
            novo = ja.id;
            DB.run("UPDATE processos SET folha_json=?, atividades_json=?, opcoes_json=?, atualizado_em=CURRENT_TIMESTAMP WHERE id=?", [JSON.stringify(folha), JSON.stringify(o.atividades), JSON.stringify(o.opcoes), novo]);
          } else {
            DB.run("INSERT INTO processos (nome, folha_json, atividades_json, opcoes_json) VALUES (?,?,?,?)", [nm, JSON.stringify(folha), JSON.stringify(o.atividades), JSON.stringify(o.opcoes)]);
            novo = DB.lastId();
          }
          if (o.atividades.length) avisos = gravarDiagrama(novo, nm, normAtiv(o.atividades), o.opcoes).avisos;
          if (ja) avisos.unshift('Processo já existente: dados atualizados.');
          return { ok: true, id: novo, avisos: avisos };
        }
        default: return { ok: false, erro: 'Ação desconhecida' };
      }
    } catch (e) { return { ok: false, erro: e.message || String(e) }; }
  };
  API.call = function (a, body) { return Promise.resolve(API.acao(a, body)); };
})(window);
