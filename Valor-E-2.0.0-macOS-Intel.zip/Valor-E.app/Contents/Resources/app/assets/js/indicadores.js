/* indicadores.js — módulo Indicadores: lista, ficha (Registro de valores, metas por ciclo, gráfico, análise e plano de ação), relatório analítico. */
(function (w) {
  'use strict';
  var h = E.esc, U = function () { return w.UI._u; };
  function aval(i) { try { return MET.avaliarIndicador(i); } catch (e) { return null; } }
  function linhas(q) {
    var sql = 'SELECT i.*, (SELECT p.nome FROM processos p WHERE p.id = i.processo_id) AS proc_nome, (SELECT COUNT(*) FROM indicador_fatores x WHERE x.indicador_id = i.id) AS n_dim FROM indicadores i', wh = [], p = [];
    if (q.processo) { wh.push('i.processo_id = ?'); p.push(parseInt(q.processo, 10)); }
    if (q.cadeia) { wh.push('i.processo_id IN (SELECT pr.id FROM processos pr JOIN macroprocessos m ON m.id = pr.macro_id JOIN cva_ciclos cc ON cc.id = m.ciclo_id WHERE cc.cadeia = ?)'); p.push(q.cadeia); }
    if (q.q) { wh.push('(i.nome LIKE ? OR i.codigo LIKE ?)'); p.push('%' + q.q + '%', '%' + q.q + '%'); }
    var l = DB.all(sql + (wh.length ? ' WHERE ' + wh.join(' AND ') : '') + ' ORDER BY i.nome COLLATE NOCASE', p).map(function (i) { return { i: i, e: aval(i) }; });
    if (q.sit) l = l.filter(function (x) { return x.e && x.e.status === q.sit; });
    return l;
  }
  var NOMES_SIT = { ok: 'Atingido', atencao: 'Atenção', critico: 'Crítico', 'sem-dados': 'Sem dados' };
  function lista(q) {
    var l = linhas(q), u = U(), todos = DB.one('SELECT COUNT(*) AS n FROM indicadores').n, o = '<main class="pagina">';
    o += '<div class="d-flex flex-wrap align-items-center mb-3 gap-2"><h1 class="h4 mb-0 me-auto"><i class="bi bi-graph-up-arrow"></i> Indicadores</h1>' +
      '<form class="filtros d-flex flex-wrap align-items-center gap-1" style="margin:0">' +
      '<input class="form-control form-control-sm" name="q" value="' + h(q.q || '') + '" placeholder="Buscar…" style="width:170px">' +
      '<select class="form-select form-select-sm" name="processo" style="width:210px"><option value="">Todos os processos</option>' + UI.optsProc(q.processo).replace('<option value="">— sem processo —</option>', '') + '</select>' +
      (w.Cva && Cva.cadeias && Cva.cadeias().length > 1 ? '<select class="form-select form-select-sm" name="cadeia" title="Cadeia de valor" style="width:170px"><option value="">Todas as cadeias</option>' + Cva.cadeias().map(function (x) { return '<option value="' + h(x) + '"' + (q.cadeia === x ? ' selected' : '') + '>' + h(x) + '</option>'; }).join('') + '</select>' : '') +
      '<select class="form-select form-select-sm" name="sit" style="width:150px"><option value="">Toda situação</option>' + Object.keys(NOMES_SIT).map(function (k) { return '<option value="' + k + '"' + (q.sit === k ? ' selected' : '') + '>' + NOMES_SIT[k] + '</option>'; }).join('') + '</select>' +
      '<button class="btn btn-sm btn-outline-secondary">Filtrar</button></form>' +
      '<button class="btn btn-sm btn-outline-secondary" onclick="Ind.relatorioSel()"><i class="bi bi-file-earmark-bar-graph"></i> Relatório</button>' +
      '<button class="btn btn-sm btn-success" onclick="UI.novoIndicador(' + (q.processo || 0) + ')"><i class="bi bi-plus-lg"></i> Novo indicador</button></div>';
    if (!l.length) o += '<div class="card"><p class="vazio mb-0">' + (todos ? 'Nenhum indicador com o filtro informado.' : 'Nenhum indicador cadastrado. Clique em <b>+ Novo indicador</b> — ou use o botão <b>Indicador</b> na Folha de dados de um processo.') + '</p></div>';
    else {
      o += '<div class="card border-0 shadow-sm"><div class="card-body p-0"><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0">' +
        '<thead class="table-light"><tr>' +
        '<th style="width:36px" class="text-center"><input type="checkbox" class="form-check-input" onclick="Ind.todos(this.checked)" title="Selecionar todos"></th>' +
        '<th style="min-width:200px">Indicador</th>' +
        '<th style="min-width:140px">Processo</th>' +
        '<th class="text-end" style="width:90px">Meta</th>' +
        '<th class="text-end" style="width:110px">Último valor</th>' +
        '<th class="text-end" style="width:80px">% meta</th>' +
        '<th style="width:100px">Situação</th>' +
        '<th style="width:100px">Risco</th>' +
        '<th class="text-center" style="width:56px" title="Dimensões no Valor Estratégico">Dim.</th>' +
        '<th style="width:160px" class="text-end">Ações</th></tr></thead><tbody>';
      l.forEach(function (x) {
        var i = x.i, e = x.e || {}, multi = i.tipo === 'multiplo';
        var st = e.status || 'sem-dados';
        o += '<tr' + (e.ativo === false ? ' class="table-secondary"' : '') + '>' +
          '<td class="text-center"><input type="checkbox" class="form-check-input ind_ck" value="' + i.id + '"></td>' +
          '<td><a class="fw-semibold text-decoration-none" href="#/indicador?id=' + i.id + '">' + h(i.nome) + '</a>' +
          '<div class="small text-muted">' + h(i.codigo || '—') + ' · ' + (multi ? 'múltiplo' : 'simples') + (i.unidade && !multi ? ' · ' + h(i.unidade) : '') + '</div></td>' +
          '<td>' + (i.proc_nome ? '<a class="text-decoration-none" href="#/folha?id=' + i.processo_id + '"><i class="bi bi-diagram-3"></i> ' + h(i.proc_nome) + '</a>' : '<span class="text-muted">—</span>') + '</td>' +
          '<td class="text-end">' + (e.meta == null ? '<span class="text-muted">—</span>' : u.num(e.meta, 2)) + '</td>' +
          '<td class="text-end">' + (multi ? '<span class="badge text-bg-light border">composto</span>' : (e.valor == null ? '<span class="text-muted">—</span>' : u.num(e.valor, 2))) +
          (e.mes ? '<div class="small text-muted">' + MET.fmtMes(e.mes) + '</div>' : '') + '</td>' +
          '<td class="text-end fw-semibold">' + u.pct(e.pct, 0) + '</td>' +
          '<td>' + u.chip(st) + '</td><td>' + u.chipRisco(st) + '</td>' +
          '<td class="text-center">' + (i.n_dim ? '<a class="badge text-bg-primary text-decoration-none" href="#/valor" title="Usado em dimensões do Valor Estratégico">' + i.n_dim + '</a>' : '<span class="text-muted">0</span>') + '</td>' +
          '<td class="text-end text-nowrap">' +
          (/^PRJ-PROG-/.test(i.codigo || '') ? '' : '<button type="button" class="btn btn-sm btn-success" onclick="UI.formLanc(' + i.id + ')" title="Registrar valor"><i class="bi bi-plus-lg"></i> Registro</button> ') +
          '<a class="btn btn-sm btn-outline-primary" href="#/indicador?id=' + i.id + '" title="Abrir ficha"><i class="bi bi-box-arrow-up-right"></i></a></td></tr>';
      });
      o += '</tbody></table></div></div>' +
        '<div class="card-footer small text-muted py-2">' + l.length + ' indicador(es) listado(s)' + (todos !== l.length ? ' · ' + todos + ' no total' : '') + '</div></div>';
    }
    return o + '</main>';
  }
  /* ---------- análise estatística ---------- */
  function regressao(ys) {
    var n = ys.length; if (n < 3) return null;
    var sx = 0, sy = 0, sxy = 0, sxx = 0, syy = 0, i;
    for (i = 0; i < n; i++) { sx += i; sy += ys[i]; sxy += i * ys[i]; sxx += i * i; syy += ys[i] * ys[i]; }
    var den = n * sxx - sx * sx, a = (n * sxy - sx * sy) / den, b = (sy - a * sx) / n;
    var ssT = syy - sy * sy / n, ssE = 0; for (i = 0; i < n; i++) { var f = a * i + b; ssE += (ys[i] - f) * (ys[i] - f); }
    return { a: a, b: b, r2: ssT > 0 ? Math.max(0, 1 - ssE / ssT) : 0, n: n };
  }
  function analisar(i, e) {
    var s = e.serie || [], pol = i.polaridade === 'menor_melhor' ? -1 : 1, r = { s: s, pol: pol };
    if (!s.length) { r.rec = ['Sem registros de valores: lance os valores mensais para habilitar a análise de tendência, projeção e recomendações.'].concat(i.processo_id ? [] : ['Vincule o indicador a um processo para que a gestão do desempenho alcance a cadeia de valor e os riscos.']); return r; }
    var vals = s.map(function (x) { return +x.valor; }), ult = s[s.length - 1], janela = vals.slice(-12);
    r.ult = ult; r.reg = regressao(janela);
    var med = vals.reduce(function (a, b) { return a + b; }, 0) / vals.length; r.media = med;
    r.dp = vals.length > 1 ? Math.sqrt(vals.reduce(function (a, b) { return a + (b - med) * (b - med); }, 0) / (vals.length - 1)) : 0; r.cv = med ? Math.abs(r.dp / med) : null;
    var ok = s.filter(function (x) { return x.pct != null && x.pct >= 1; }).length, com = s.filter(function (x) { return x.pct != null; }).length; r.aderencia = com ? ok / com : null; r.mesesOk = ok; r.mesesCom = com;
    if (r.reg) {
      var mm = Math.abs(med) || 1, rel = r.reg.a / mm; r.relMes = rel;
      r.tend = Math.abs(rel) < 0.005 || r.reg.r2 < 0.15 ? 'estável' : ((r.reg.a * pol) > 0 ? 'melhora' : 'piora');
      r.proj = [1, 2, 3].map(function (k) { return r.reg.a * (janela.length - 1 + k) + r.reg.b; });
      var ci = (e.ciclos || []).filter(function (c) { return String(c.data_fim).slice(0, 7) >= String(ult.mes).slice(0, 7); })[0];
      if (ci) {
        var fim = String(ci.data_fim).slice(0, 7), a1 = ult.mes.split('-'), a2 = fim.split('-'), k = (+a2[0] - +a1[0]) * 12 + (+a2[1] - +a1[1]);
        r.fimCiclo = { mes: fim, k: k, valor: r.reg.a * (janela.length - 1 + k) + r.reg.b, meta: ci.meta };
        r.fimCiclo.atinge = pol > 0 ? r.fimCiclo.valor >= ci.meta : r.fimCiclo.valor <= ci.meta;
      }
    }
    var rec = [];
    if (e.pct != null) {
      if (e.pct >= 1) rec.push('Meta atingida no último período: mantenha o padrão de execução e avalie se a meta pode ser desafiada (benchmark interno/externo).');
      else if (e.pct >= 0.85) rec.push('Resultado próximo da meta (zona de atenção): identifique a causa do desvio residual e acione ações corretivas de baixo custo.');
      else rec.push('Resultado distante da meta (zona crítica): analise as causas raiz (5 Porquês / Ishikawa), defina plano de ação com responsável e prazo e reavalie em até 30 dias.');
    }
    if (r.tend === 'piora') rec.push('A tendência é de piora: a meta deve ser revista apenas após tratar as causas; intensifique o monitoramento (apuração mais frequente).');
    if (r.tend === 'melhora' && e.pct != null && e.pct < 1) rec.push('Há tendência de melhora, ainda insuficiente para a meta: preserve as ações em curso e verifique se o ritmo atual alcança a meta no fim do ciclo.');
    if (r.fimCiclo && !r.fimCiclo.atinge) rec.push('Pela projeção linear, a meta do ciclo (' + num(r.fimCiclo.meta) + ') não será atingida em ' + MET.fmtMes(r.fimCiclo.mes) + ' (previsto ' + num(r.fimCiclo.valor) + '): replaneje ações ou renegocie a meta formalmente.');
    if (r.cv != null && r.cv > 0.25) rec.push('Alta variabilidade (CV ' + (r.cv * 100).toFixed(0) + '%): o processo é instável; priorize reduzir a dispersão (padronização, controle estatístico) antes de perseguir a média.');
    if (s.length < 6) rec.push('Série curta (' + s.length + ' registro(s)): tendência e projeção são indicativas; recomenda-se ao menos 12 apurações para conclusões robustas.');
    if (!i.processo_id) rec.push('Vincule o indicador a um processo para que a gestão do desempenho alcance a cadeia de valor e os riscos.');
    r.rec = rec; return r;
  }
  function num(v, c) { return v == null || isNaN(v) ? '—' : (+v).toFixed(c == null ? 2 : c).replace('.', ','); }
  function relatorio(q) {
    var ids = String(q.ids || '').split(',').map(function (x) { return parseInt(x, 10); }).filter(Boolean), u = U();
    var all = DB.all('SELECT i.*, (SELECT p.nome FROM processos p WHERE p.id=i.processo_id) AS proc_nome FROM indicadores i ORDER BY i.nome COLLATE NOCASE');
    var o = '<main class="pagina ind-host val-host"><div class="toolbar no-print"><h1 style="margin:0;font-size:20px"><i class="bi bi-file-earmark-bar-graph"></i> Relatório de indicadores</h1><div class="sp"></div>' + (ids.length ? '<button class="btn btn-sm btn-outline" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir / salvar PDF</button>' : '') + '</div>';
    if (!ids.length) {
      o += '<div class="card no-print"><h2>Selecione os indicadores</h2>' + (all.length ? '<div class="caixa-lista">' + all.map(function (i) { return '<label class="chk-lin"><input type="checkbox" class="rel_ck" value="' + i.id + '" checked> <b>' + h(i.codigo) + '</b> · ' + h(i.nome) + (i.proc_nome ? ' <small class="muted">— ' + h(i.proc_nome) + '</small>' : '') + '</label>'; }).join('') + '</div><div style="margin-top:10px"><button class="btn" onclick="Ind.gerar()">Gerar relatório</button></div>' : '<p class="vazio">Não há indicadores cadastrados.</p>') + '</div></main>';
      return o;
    }
    o += '<div class="card"><h2 style="margin:0 0 4px">Relatório de análise de indicadores</h2><div class="muted">Emitido em ' + E.dataBr(E.hoje()) + ' · ' + ids.length + ' indicador(es) · metodologia: atingimento da meta (conforme polaridade), tendência por regressão linear (últimos 12 registros), projeção linear, variabilidade (desvio-padrão e coeficiente de variação) e aderência histórica à meta.</div></div>';
    ids.forEach(function (id, k) {
      var i = DB.one('SELECT * FROM indicadores WHERE id=?', [id]); if (!i) return;
      var e = aval(i), a = analisar(i, e), pn = i.processo_id ? (DB.one('SELECT nome FROM processos WHERE id=?', [i.processo_id]) || {}).nome : '';
      o += '<div class="card rel-ind" style="page-break-inside:avoid"><h2 style="margin:0">' + (k + 1) + '. ' + h(i.nome) + ' <small class="muted">' + h(i.codigo) + '</small></h2><div class="muted" style="font-size:12.5px">Processo: ' + (pn ? h(pn) : '—') + ' · Polaridade: ' + (a.pol > 0 ? 'maior é melhor' : 'menor é melhor') + ' · Unidade: ' + h(i.unidade || (i.tipo === 'multiplo' ? 'por item' : '—')) + '</div>' +
        '<div class="kpi-grid" style="margin-top:8px">' + u.kpi('Último valor', a.ult ? num(a.ult.valor) : '—', a.ult ? MET.fmtMes(a.ult.mes) : 'sem registros') + u.kpi('Meta vigente', e && e.meta != null ? num(e.meta) : '—', '') + u.kpi('% da meta', u.pct(e && e.pct, 1), '') + u.kpi('Aderência à meta', a.aderencia == null ? '—' : (a.aderencia * 100).toFixed(0) + '%', a.mesesOk + ' de ' + a.mesesCom + ' períodos') +
        '<div class="classe-card st-' + (e ? e.status : 'sem-dados') + ' kpi-status"><div class="cc-top"><span class="cc-cod">Situação</span></div>' + u.chip(e ? e.status : 'sem-dados') + '<div style="margin-top:6px">' + u.chipRisco(e ? e.status : 'sem-dados') + '</div></div></div>';
      if (a.s.length) {
        o += '<div class="chart-box" style="height:260px"><canvas id="rg_' + id + '"></canvas></div><table class="tabela-compacta" style="margin-top:8px"><tbody>' +
          '<tr><th>Tendência</th><td>' + (a.reg ? '<b>' + a.tend + '</b> — variação média de ' + num(a.reg.a, 3) + ' por período (' + (a.relMes * 100).toFixed(1).replace('.', ',') + '% da média); R² = ' + num(a.reg.r2, 2) : 'dados insuficientes (mínimo de 3 registros)') + '</td></tr>' +
          '<tr><th>Projeção</th><td>' + (a.proj ? 'Próximos 3 períodos: ' + a.proj.map(function (v) { return num(v); }).join(' · ') + (a.fimCiclo ? '<br>No fim do ciclo (' + MET.fmtMes(a.fimCiclo.mes) + '): <b>' + num(a.fimCiclo.valor) + '</b> versus meta ' + num(a.fimCiclo.meta) + ' → ' + (a.fimCiclo.atinge ? '<b style="color:#2e7d32">tende a atingir</b>' : '<b style="color:#c62828">tende a não atingir</b>') : '') : '—') + '</td></tr>' +
          '<tr><th>Variabilidade</th><td>média ' + num(a.media) + ' · desvio-padrão ' + num(a.dp) + (a.cv != null ? ' · CV ' + (a.cv * 100).toFixed(1).replace('.', ',') + '%' : '') + '</td></tr></tbody></table>';
      } else o += '<p class="vazio">Sem registros de valores para analisar.</p>';
      if (a.rec.length) o += '<h3 style="font-size:14px;margin:12px 0 4px">Análise e recomendações</h3><ul>' + a.rec.map(function (t) { return '<li>' + h(t) + '</li>'; }).join('') + '</ul>';
      if (i.analise_html) o += '<h3 style="font-size:14px;margin:12px 0 4px">Análise de situação (registrada)</h3><div class="sr-rich">' + w.SisrelHtml.seguro(i.analise_html) + '</div>';
      if (i.plano_html) o += '<h3 style="font-size:14px;margin:12px 0 4px">Plano de ação (registrado)</h3><div class="sr-rich">' + w.SisrelHtml.seguro(i.plano_html) + '</div>';
      o += '</div>';
    });
    return o + '</main>';
  }
  function aposRelatorio(q) {
    String(q.ids || '').split(',').map(function (x) { return parseInt(x, 10); }).filter(Boolean).forEach(function (id) {
      var i = DB.one('SELECT * FROM indicadores WHERE id=?', [id]); if (!i || !document.getElementById('rg_' + id)) return;
      var e = aval(i), a = analisar(i, e); if (!a.s.length) return;
      var lb = a.s.map(function (s) { return MET.fmtMes(s.mes); }), vs = a.s.map(function (s) { return s.valor; }), ms = a.s.map(function (s) { return s.meta; });
      var proj = a.proj ? lb.concat(['proj. +1', 'proj. +2', 'proj. +3']) : lb;
      var tend = a.reg ? a.s.map(function (s, k) { var off = a.s.length - Math.min(12, a.s.length); return k >= off ? a.reg.a * (k - off) + a.reg.b : null; }).concat(a.proj) : null;
      var ctx = document.getElementById('rg_' + id).getContext('2d');
      new Chart(ctx, { type: 'line', data: { labels: proj, datasets: [
        { label: 'Valor', data: vs, borderColor: '#0a6fc2', backgroundColor: '#0a6fc2', tension: .2, pointRadius: 3 },
        { label: 'Meta', data: ms.concat(a.proj ? [ms[ms.length - 1], ms[ms.length - 1], ms[ms.length - 1]] : []), borderColor: '#2e7d32', borderDash: [6, 4], pointRadius: 0 }
      ].concat(tend ? [{ label: 'Tendência / projeção', data: tend, borderColor: '#f57c00', borderDash: [2, 3], pointRadius: 0 }] : []) }, options: { responsive: true, maintainAspectRatio: false, animation: false } });
    });
  }
  var Ind = w.Ind = {
    todos: function (v) { Array.prototype.forEach.call(document.querySelectorAll('.ind_ck'), function (c) { c.checked = v; }); },
    relatorioSel: function () {
      var ids = Array.prototype.map.call(document.querySelectorAll('.ind_ck:checked'), function (c) { return c.value; });
      Nav.ir('#/relindicadores' + (ids.length ? '?ids=' + ids.join(',') : ''));
    },
    gerar: function () {
      var ids = Array.prototype.map.call(document.querySelectorAll('.rel_ck:checked'), function (c) { return c.value; });
      if (!ids.length) return alert('Selecione ao menos um indicador.'); Nav.ir('#/relindicadores?ids=' + ids.join(','));
    },
    contarPorProcesso: function (id) { return DB.one('SELECT COUNT(*) AS n FROM indicadores WHERE processo_id = ?', [id]).n; },
    excluirVinculoProcesso: function (id) { DB.run('UPDATE indicadores SET processo_id = NULL WHERE processo_id = ?', [id]); },
    /** Situação do indicador: 'ok' | 'atencao' | 'critico' (ou null, sem dados). */
    situacao: function (id) { var i = DB.one('SELECT * FROM indicadores WHERE id = ?', [id]), e = i && aval(i); return (e && e.ativo !== false && (e.status === 'ok' || e.status === 'atencao' || e.status === 'critico')) ? e.status : null; },
    resumo: function () {
      var r = { total: 0, verde: 0, amarelo: 0, vermelho: 0, semDados: 0 };
      DB.all('SELECT * FROM indicadores').forEach(function (i) { var e = aval(i); if (!e || e.ativo === false) return; r.total++; if (e.status === 'ok') r.verde++; else if (e.status === 'atencao') r.amarelo++; else if (e.status === 'critico') r.vermelho++; else r.semDados++; });
      return r;
    }
  };
  Modulos.registrar('/indicadores', { ativo: 'indicadores', titulo: 'Indicadores', html: function (q) { return UI.sub(UI.SUB_IND, 'lista') + lista(q); } });
  Modulos.registrar('/indicador', {
    ativo: 'indicadores', titulo: 'Indicador',
    html: function (q) { return q.novo ? UI.sub(UI.SUB_IND, 'lista') + lista({ processo: q.processo }) : UI.render('indicador', q); },
    apos: function (q) { if (q.novo) setTimeout(function () { UI.novoIndicador(parseInt(q.processo, 10) || 0); }, 30); }
  });
  Modulos.registrar('/relindicadores', { ativo: 'indicadores', titulo: 'Relatório de indicadores', html: function (q) { return UI.sub(UI.SUB_IND, 'relind') + relatorio(q); }, apos: aposRelatorio });
})(window);
