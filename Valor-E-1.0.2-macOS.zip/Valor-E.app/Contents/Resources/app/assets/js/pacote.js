/* pacote.js — exportar / importar TUDO (todas as tabelas, todos os módulos) em JSON ou XML, com remapeamento de vínculos (modo "mesclar") ou restauração integral (modo "substituir"). */
(function (w) {
  'use strict';
  var h = E.esc, FORMATO = 'axia-pacote', VERSAO = '4.0';
  /* Grupos de tabelas para exportação seletiva */
  var GRUPOS = {
    processos: [
      'cva_ciclos', 'macroprocessos', 'processos', 'flags', 'cva_validacoes',
      'riscos', 'fatores', 'controles', 'planos', 'monitoramentos', 'revisoes'
    ],
    projetos: [
      'projetos', 'proj_tarefas', 'proj_deps', 'proj_recursos', 'proj_baseline'
    ],
    indicadores: [
      'organizacoes', 'usuarios', 'ciclos_estrategicos', 'periodos_ciclo',
      'objetivos_estrategicos', 'capacidades', 'objetivo_capacidades',
      'fatores_determinantes', 'indicadores', 'indicador_fatores', 'indicador_itens',
      'indicador_capacidades', 'ind_ciclos', 'lanc_ind', 'lanc_itm',
      'metas_indicador_ciclo', 'metas_objetivo_ciclo', 'series_historicas',
      'lancamentos_indicador', 'lancamentos_item', 'ciclos_meta_indicador',
      'planos_intervencao', 'ahp_registros', 'historico',
      'me_mapas', 'me_perspectivas', 'me_temas', 'me_objetivos'
    ]
  };
  // vínculos lógicos (além das FKs declaradas): tabela.coluna -> tabela pai
  var LOGICAS = {
    '*.processo_id': 'processos', '*.flag_id': 'flags', '*.macro_id': 'macroprocessos', '*.risco_id': 'riscos', '*.objetivo_id': 'objetivos_estrategicos',
    '*.capacidade_id': 'capacidades', '*.indicador_id': 'indicadores', '*.item_id': 'indicador_itens', '*.validado_ciclo_id': 'cva_ciclos',
    'controles.fator_id': 'fatores', 'indicador_fatores.fator_id': 'fatores_determinantes', 'fatores_determinantes.capacidade_id': 'capacidades',
    'me_perspectivas.mapa_id': 'me_mapas', 'me_temas.perspectiva_id': 'me_perspectivas', 'me_objetivos.perspectiva_id': 'me_perspectivas', 'me_objetivos.tema_id': 'me_temas', 'me_objetivos.oe_id': 'objetivos_estrategicos',
    'macroprocessos.ciclo_id': 'cva_ciclos', 'cva_validacoes.ciclo_id': 'cva_ciclos', 'planos.controle_id': 'controles', 'monitoramentos.controle_desc': 'controles'
  };
  // chave natural de cada tabela: se já existe um registro com os mesmos valores (após refazer os vínculos), ele é ATUALIZADO; senão é criado
  var CHAVES = {
    cva_ciclos: ['cadeia', 'nome'], macroprocessos: ['ciclo_id', 'tipo', 'nome'], processos: ['nome', 'macro_id'], flags: ['processo_id', 'elemento'],
    riscos: ['nome', 'processo_id', 'ambiente'], fatores: ['risco_id', 'nome'], controles: ['fator_id', 'descricao'], planos: ['risco_id', 'descricao'],
    revisoes: ['risco_id', 'data'], monitoramentos: ['risco_id', 'data', 'acao'],
    indicadores: ['nome', 'processo_id'], indicador_itens: ['indicador_id', 'nome'], ind_ciclos: ['indicador_id', 'data_inicio', 'data_fim'],
    ciclos_meta_indicador: ['indicador_id', 'data_inicio', 'data_fim'], lanc_ind: ['indicador_id', 'mes_ano'], lanc_itm: ['item_id', 'mes_ano'],
    lancamentos_indicador: ['indicador_id', 'ciclo_id', 'mes_ano'], lancamentos_item: ['item_id', 'ciclo_id', 'mes_ano'], metas_indicador_ciclo: ['indicador_id', 'ciclo_id'],
    series_historicas: ['indicador_id', 'data_observacao'], indicador_capacidades: ['indicador_id', 'capacidade_id'], indicador_fatores: ['indicador_id', 'fator_id'],
    capacidades: ['nome'], fatores_determinantes: ['capacidade_id', 'nome'], objetivos_estrategicos: ['nome'], objetivo_capacidades: ['objetivo_id', 'capacidade_id'],
    ciclos_estrategicos: ['nome'], periodos_ciclo: ['ciclo_id', 'codigo'], metas_objetivo_ciclo: ['objetivo_id', 'ciclo_id'],
    me_mapas: ['nome'], me_perspectivas: ['mapa_id', 'nome'], me_temas: ['perspectiva_id', 'nome'], me_objetivos: ['perspectiva_id', 'oe_id'],
    planos_intervencao: ['tipo_alvo', 'alvo_id', 'titulo'], cva_validacoes: ['ciclo_id', 'alvo', 'ref_id', 'em']
  };
  var GENERICOS_CICLO = { 'ciclo_id': 'ciclos_estrategicos' };
  function tabelas() { return DB.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").map(function (t) { return t.name; }); }
  function colunas(t) { return DB.all('PRAGMA table_info(' + t + ')').map(function (c) { return c.name; }); }
  function pai(t, c) {
    if (LOGICAS[t + '.' + c]) return LOGICAS[t + '.' + c];
    var fk = DB.all('PRAGMA foreign_key_list(' + t + ')').filter(function (f) { return f.from === c; })[0];
    if (fk) return fk.table;
    if (LOGICAS['*.' + c]) return LOGICAS['*.' + c];
    if (GENERICOS_CICLO[c]) return GENERICOS_CICLO[c];
    return null;
  }
  function ordenar(ts) {
    var dep = {}, out = [], vis = {};
    ts.forEach(function (t) { dep[t] = colunas(t).map(function (c) { return pai(t, c); }).filter(function (p) { return p && p !== t && ts.indexOf(p) >= 0; }); });
    function v(t) { if (vis[t]) return; vis[t] = 1; dep[t].forEach(v); out.push(t); }
    ts.forEach(v); return out;
  }

    function coletar(filtro) {
    var o = { formato: FORMATO, versao: VERSAO, gerado_em: new Date().toISOString(), tabelas: {} };
    var lista = tabelas();
    if (filtro && filtro.length) {
      var set = {};
      filtro.forEach(function (t) { set[t] = 1; });
      lista = lista.filter(function (t) { return set[t]; });
    }
    lista.forEach(function (t) {
      // só nomes de tabela seguros
      var cs = colunas(t).filter(function (c) { return /^[a-z0-9_]+$/i.test(c); });
      o.tabelas[t] = { colunas: cs, linhas: DB.all('SELECT * FROM ' + t).map(function (r) { return cs.map(function (c) { return r[c]; }); }) };
    });
    return o;
  }
  function tabelasDosGrupos(grupos) {
    if (!grupos || !grupos.length || grupos.indexOf('tudo') >= 0) return null; // null = todas
    var set = {}, out = [];
    grupos.forEach(function (g) {
      (GRUPOS[g] || []).forEach(function (t) { if (!set[t]) { set[t] = 1; out.push(t); } });
    });
    // sempre incluir config se houver algum grupo (parâmetros básicos)
    if (out.length && !set.config) out.push('config');
    return out;
  }
  function gruposSelecionados() {
    var els = document.querySelectorAll('input[name=pexport]:checked');
    var g = [];
    for (var i = 0; i < els.length; i++) g.push(els[i].value);
    if (!g.length) return ['tudo'];
    return g;
  }
  function sufixoGrupos(grupos) {
    if (!grupos || grupos.indexOf('tudo') >= 0) return '';
    return '-' + grupos.join('-');
  }
  function bytesParaB64(u) { var s = '', n = 0x8000; for (var i = 0; i < u.length; i += n) s += String.fromCharCode.apply(null, u.subarray(i, i + n)); return btoa(s); }
  function jsonStr(o) { return JSON.stringify(o, function (k, v) { return (v instanceof Uint8Array) ? { __b64: bytesParaB64(v) } : v; }); }
  function xesc(s) { return String(s).replace(/[&<>"\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, function (c) { return c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '"' ? '&quot;' : ''; }); }
  function xml(o) {
    var s = '<?xml version="1.0" encoding="UTF-8"?>\n<axia-pacote formato="' + FORMATO + '" versao="' + VERSAO + '" gerado_em="' + o.gerado_em + '">\n';
    Object.keys(o.tabelas).forEach(function (t) {
      var T = o.tabelas[t]; s += '  <tabela nome="' + t + '" colunas="' + xesc(T.colunas.join(',')) + '">\n';
      T.linhas.forEach(function (l) { s += '    <linha>' + l.map(function (v) { return v === null || v === undefined ? '<c n="1"/>' : (v instanceof Uint8Array ? '<c b="1">' + bytesParaB64(v) + '</c>' : '<c>' + xesc(v) + '</c>'); }).join('') + '</linha>\n'; });
      s += '  </tabela>\n';
    });
    return s + '</axia-pacote>\n';
  }
  function deXml(txt) {
    var d = new DOMParser().parseFromString(txt, 'application/xml');
    if (d.getElementsByTagName('parsererror').length) throw new Error('O arquivo não é um XML válido.');
    var r = d.documentElement; if (r.nodeName !== 'axia-pacote' && r.nodeName !== 'nomika-pacote') return null;
    var o = { formato: FORMATO, versao: r.getAttribute('versao'), tabelas: {} };
    Array.prototype.forEach.call(r.getElementsByTagName('tabela'), function (t) {
      var cs = (t.getAttribute('colunas') || '').split(',');
      o.tabelas[t.getAttribute('nome')] = { colunas: cs, linhas: Array.prototype.map.call(t.getElementsByTagName('linha'), function (l) {
        return Array.prototype.map.call(l.getElementsByTagName('c'), function (c) { if (c.getAttribute('n')) return null; if (c.getAttribute('b')) return { __b64: c.textContent }; return c.textContent; });
      }) };
    });
    return o;
  }
  function numerico(def) { return /INT|REAL|NUM|FLOA|DOUB/i.test(def || ''); }
  function aplicar(o, modo) {
    var res = { tabelas: {}, atualizados: {}, avisos: [] };
    if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote') || !o.tabelas) throw new Error('Arquivo não reconhecido como pacote do Valor-E.');
    var existentes = tabelas(), nomes = ordenar(Object.keys(o.tabelas).filter(function (t) { return existentes.indexOf(t) >= 0; }));
    Object.keys(o.tabelas).forEach(function (t) { if (existentes.indexOf(t) < 0) res.avisos.push('Tabela desconhecida ignorada: ' + t); });
    var mapa = {}; DB.db.run('PRAGMA foreign_keys = OFF');
    try {
      DB.db.run('BEGIN');
      if (modo === 'substituir') existentes.forEach(function (t) { DB.db.run('DELETE FROM ' + t); });
      nomes.forEach(function (t) {
        var T = o.tabelas[t], cols = colunas(t), tipos = {}; DB.all('PRAGMA table_info(' + t + ')').forEach(function (c) { tipos[c.name] = c.type; });
        var temId = cols.indexOf('id') >= 0, n = 0, at = 0, pais = {}; cols.forEach(function (c) { pais[c] = pai(t, c); });
        mapa[t] = mapa[t] || {};
        T.linhas.forEach(function (l) {
          var reg = {}; T.colunas.forEach(function (c, i) { if (cols.indexOf(c) >= 0) { var v = l[i]; reg[c] = (v && typeof v === 'object' && v.__b64 !== undefined) ? (function (b) { var s = atob(b), u = new Uint8Array(s.length); for (var k = 0; k < s.length; k++) u[k] = s.charCodeAt(k); return u; })(v.__b64) : v; } });
          var antigo = reg.id;
          if (modo === 'mesclar') {
            cols.forEach(function (c) {
              if (c === 'id' || !pais[c] || reg[c] === null || reg[c] === undefined || reg[c] === '') return;
              var m = mapa[pais[c]]; if (!m) return;
              var novo = m[reg[c]]; reg[c] = novo !== undefined ? (numerico(tipos[c]) ? novo : String(novo)) : (numerico(tipos[c]) ? null : reg[c]);
            });
            if (t === 'cva_ciclos' && !reg.cadeia) reg.cadeia = 'Principal';
            if (t === 'config') { if (DB.one('SELECT 1 AS x FROM config WHERE chave = ?', [reg.chave])) return; }
            if (t === 'organizacoes' || t === 'usuarios') return;
            if (t === 'ahp_registros' || t === 'historico') return;
            // já existe? então atualiza
            var ch = CHAVES[t], ex = null;
            if (ch && temId) {
              var kk = ch.filter(function (c) { return cols.indexOf(c) >= 0; });
              if (kk.length && kk.some(function (c) { return reg[c] !== null && reg[c] !== undefined && reg[c] !== ''; })) {
                ex = DB.one('SELECT id FROM ' + t + ' WHERE ' + kk.map(function (c) { return c + ' IS ? COLLATE NOCASE'; }).join(' AND '), kk.map(function (c) { return reg[c] === undefined ? null : reg[c]; }));
              }
            }
            if (ex) {
              var up = Object.keys(reg).filter(function (c) { return c !== 'id' && c !== 'criado_em' && !(t === 'riscos' && c === 'codigo'); });
              try {
                if (up.length) DB.db.run('UPDATE ' + t + ' SET ' + up.map(function (c) { return c + ' = ?'; }).join(', ') + ' WHERE id = ?', up.map(function (c) { return reg[c]; }).concat([ex.id]));
                mapa[t][antigo] = ex.id; at++;
              } catch (e) { if (res.avisos.length < 12) res.avisos.push(t + ': ' + e.message); }
              return;
            }
            if (t === 'riscos' && reg.codigo && !E.codigoRiscoLivre(reg.codigo)) reg.codigo = E.proximoCodigoRisco();
            if (temId) delete reg.id;
          }
          var ks = Object.keys(reg);
          try {
            DB.db.run('INSERT INTO ' + t + ' (' + ks.join(',') + ') VALUES (' + ks.map(function () { return '?'; }).join(',') + ')', ks.map(function (c) { return reg[c]; }));
            if (temId) mapa[t][antigo] = modo === 'mesclar' ? DB.one('SELECT last_insert_rowid() AS i').i : antigo;
            n++;
          } catch (e) { if (res.avisos.length < 12) res.avisos.push(t + ': ' + e.message); }
        });
        res.tabelas[t] = n; res.atualizados[t] = at;
      });
      // vínculos que apontam para tabelas importadas depois (ex.: processos.validado_ciclo_id) já foram resolvidos pela ordem topológica
      DB.db.run('COMMIT');
    } catch (e) { try { DB.db.run('ROLLBACK'); } catch (x) {} DB.db.run('PRAGMA foreign_keys = ON'); throw e; }
    DB.db.run('PRAGMA foreign_keys = ON'); DB.sujo();
    return res;
  }
  var Pacote = w.Pacote = {
    coletar: coletar,
    exportarJson: function () {
      var grupos = gruposSelecionados();
      var filtro = tabelasDosGrupos(grupos);
      var o = coletar(filtro);
      o.escopo = grupos.indexOf('tudo') >= 0 ? ['tudo'] : grupos;
      var body = jsonStr(o);
      function baixa(txt) { Mapris.baixar('valore' + sufixoGrupos(grupos) + '-' + E.hoje() + '.json', txt, 'application/json'); if (w.SEC) SEC.audit('exportar', 'json ' + grupos.join(',')); }
      if (w.SEC && SEC.sha256Hex) {
        SEC.sha256Hex(body).then(function (hash) {
          try { var j = JSON.parse(body); j.seguranca = j.seguranca || {}; j.seguranca.sha256 = hash; baixa(JSON.stringify(j)); }
          catch (e) { baixa(body); }
        });
      } else baixa(body);
    },
    exportarXml: function () {
      var grupos = gruposSelecionados();
      var filtro = tabelasDosGrupos(grupos);
      var o = coletar(filtro);
      o.escopo = grupos.indexOf('tudo') >= 0 ? ['tudo'] : grupos;
      Mapris.baixar('valore' + sufixoGrupos(grupos) + '-' + E.hoje() + '.xml', xml(o), 'application/xml');
      if (w.SEC) SEC.audit('exportar', 'xml ' + grupos.join(','));
    },
    /** Lê o texto do arquivo, detecta o formato e importa. Retorna {res, legado}. */
    importarTexto: function (txt, modo) {
      if (w.SEC) SEC.validateImportText(txt);
      var xmlTxt = txt.trim().charAt(0) === '<', o = null;
      if (xmlTxt) o = deXml(txt); else { try { o = JSON.parse(txt); } catch (e) { throw new Error('Arquivo inválido.'); } }
      if (!o || (o.formato !== FORMATO && o.formato !== 'nomika-pacote')) return null;
      if (w.SEC && SEC.sanitizarObjeto) o = SEC.sanitizarObjeto(o);
      // rejeita tabelas com nomes suspeitos
      if (o.tabelas) {
        Object.keys(o.tabelas).forEach(function (t) {
          if (!/^[a-z0-9_]+$/i.test(t)) throw new Error('Pacote rejeitado: nome de tabela inválido (' + t + ').');
        });
      }
      if (w.SEC) SEC.audit('importar', (modo || 'mesclar') + ' pacote');
      return aplicar(o, modo);
    },
    resumo: function (r) { var ls = Object.keys(r.tabelas).filter(function (t) { return r.tabelas[t] || (r.atualizados && r.atualizados[t]); }).map(function (t) { return t + ': ' + r.tabelas[t] + ' novo(s), ' + ((r.atualizados && r.atualizados[t]) || 0) + ' atualizado(s)'; }); return ls.join('\n') + (r.avisos.length ? '\n\nAvisos:\n' + r.avisos.join('\n') : ''); },
    /** Cartão da tela de configurações. */
    cartao: function () {
      var n = tabelas().reduce(function (s, t) { return s + DB.one('SELECT COUNT(*) AS n FROM ' + t).n; }, 0);
      var sec = (w.SEC && SEC.cartaoUI) ? SEC.cartaoUI(h) : '';
      return sec + '<div class="cartao mb-3"><h2><i class="bi bi-arrow-left-right"></i> Exportar e importar</h2><div class="corpo">' +
        '<p class="ajuda">Escolha o que deseja exportar. A importação continua aceitando pacotes completos ou parciais (mesclar ou substituir). Hoje há ' + n + ' registro(s) no banco.</p>' +
        '<div class="mb-3 p-3 border rounded" style="background:#f8f9fa">' +
        '<div class="fw-semibold mb-2">O que exportar</div>' +
        '<div class="d-flex flex-wrap gap-3">' +
        '<label class="form-check-label"><input type="checkbox" class="form-check-input me-1" name="pexport" value="tudo" checked onchange="Pacote._syncTudo(this)"> <b>Tudo</b></label>' +
        '<label class="form-check-label"><input type="checkbox" class="form-check-input me-1" name="pexport" value="processos" onchange="Pacote._syncGrupo()"> Processos <span class="text-muted small">(CVA, folhas, riscos)</span></label>' +
        '<label class="form-check-label"><input type="checkbox" class="form-check-input me-1" name="pexport" value="projetos" onchange="Pacote._syncGrupo()"> Projetos</label>' +
        '<label class="form-check-label"><input type="checkbox" class="form-check-input me-1" name="pexport" value="indicadores" onchange="Pacote._syncGrupo()"> Indicadores / Valor Estratégico</label>' +
        '</div></div>' +
        '<div class="d-flex flex-wrap gap-2 mb-3">' +
        '<button class="btn btn-success" onclick="Pacote.exportarJson()"><i class="bi bi-filetype-json"></i> Exportar (.json)</button>' +
        '<button class="btn btn-outline-success" onclick="Pacote.exportarXml()"><i class="bi bi-filetype-xml"></i> Exportar (.xml)</button>' +
        '<button class="btn btn-outline-secondary" onclick="Acoes.expBanco()"><i class="bi bi-database"></i> Cópia do banco (.sqlite)</button></div>' +
        '<h6>Importar</h6><div class="mb-2"><label class="me-3"><input type="radio" name="pmodo" value="mesclar" checked> <b>Mesclar</b> — o que já existe é <b>atualizado</b> e o que não existe é <b>criado</b> (vínculos são refeitos)</label><label><input type="radio" name="pmodo" value="substituir"> <b>Substituir tudo</b> — restaura o pacote e apaga o conteúdo atual</label></div>' +
        '<input type="file" class="form-control" id="pArq" accept=".json,.xml,.sqlite,.db" style="max-width:420px"><div class="mt-2"><button class="btn btn-warning" onclick="Pacote.importarArquivo()"><i class="bi bi-upload"></i> Importar arquivo</button></div><pre id="pRes" class="small mt-2" style="white-space:pre-wrap"></pre></div></div>';
    },
    _syncTudo: function (el) {
      if (el.checked) {
        document.querySelectorAll('input[name=pexport]').forEach(function (c) {
          if (c.value !== 'tudo') c.checked = false;
        });
      }
    },
    _syncGrupo: function () {
      var tudo = document.querySelector('input[name=pexport][value=tudo]');
      var algum = false;
      document.querySelectorAll('input[name=pexport]').forEach(function (c) {
        if (c.value !== 'tudo' && c.checked) algum = true;
      });
      if (algum && tudo) tudo.checked = false;
      if (!algum && tudo) tudo.checked = true;
    },
    importarArquivo: function () {
      var f = document.getElementById('pArq').files[0]; if (!f) return alert('Escolha um arquivo.');
      var modo = document.querySelector('input[name=pmodo]:checked').value;
      if (/\.(sqlite|db)$/i.test(f.name)) {
        if (f.size > ((w.SEC && SEC.MAX_IMPORT_BYTES) || 80*1024*1024)) return alert('Arquivo acima do limite de segurança.');
        if (!confirm('Substituir TODO o banco atual por este arquivo? Esta ação não pode ser desfeita.')) return;
        var fr0 = new FileReader(); fr0.onload = function () {
          try {
            var u = new Uint8Array(fr0.result);
            // SQLite magic "SQLite format 3"
            var mag = String.fromCharCode.apply(null, u.subarray(0, 15));
            if (mag.indexOf('SQLite format 3') !== 0) throw new Error('Não é um arquivo SQLite válido.');
            DB.substituir(u);
            if (w.SEC) SEC.audit('importar', 'sqlite substituir');
            alert('Banco restaurado.'); Nav.ir('#/');
          } catch (e) { alert('Arquivo inválido: ' + e.message); }
        }; fr0.readAsArrayBuffer(f); return;
      }
      if (modo === 'substituir' && !confirm('Isto APAGA o conteúdo atual e restaura o pacote. Continuar?')) return;
      var fr = new FileReader(); fr.onload = function () {
        try {
          var r = Pacote.importarTexto(String(fr.result), modo);
          if (r) { document.getElementById('pRes').textContent = 'Importação concluída (' + (modo === 'substituir' ? 'substituir' : 'mesclar') + ').\n' + Pacote.resumo(r); return; }
          Acoes.importar(f);   // formatos anteriores (riscos .xml/.json, processos)
        } catch (e) { document.getElementById('pRes').textContent = 'Erro: ' + e.message; }
      };
      fr.readAsText(f);
    }
  };
})(window);
